This source code is provided for information and in order to comply with the terms of the GPL.

Please obtain the latest released source and project files from Source Forge.
Browse at:
http://neocortex.cvs.sourceforge.net/neocortex
14/12/2008