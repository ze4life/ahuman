#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int f0( int argc , char **argv , char **arge )
{
	int k;
	char **pe;

	/* print parameters */
	printf( "parameters:\n" );
	for( k = 0; k < argc; k++ )
		printf( "argv[%d]=%s\n" , k , argv[ k ] );

	/* print environment */
	printf( "environment variables:\n" );
	for( pe = arge , k = 0; *pe != NULL; pe++ , k++ )
		printf( "arge[%d]=%s\n" , k , *pe );

	return( 12345 );
}

void f1( char **argv )
{
	double l_percent;
	int l_years;
	double l_value;
	
	l_percent = atof( argv[ 1 ] ) / 100;
	l_years = 0;
	
	/* iterate years */
	l_value = 1;
	while( l_value < 2 )
		l_value *= 1 + l_percent , l_years++;

	printf( "Money will be doubled in %d year(s)\n" , l_years );
}

void f2( char **argv )
{
	double sum_expected;
	double X , A1 , B1 , A2 , B2;

	sum_expected = atof( argv[ 1 ] );

	/* sum_expected = A + B * X */
	/* case 1: X greater than 10 - use 10 for first 3 classes */
	/* case 2: X lesser or equals to 10 - use X for all */
	A1 = B1 = A2 = B2 = 0;

	/* 10 classes * 20 students * X */
	B1 = B2 = 10 * 20;

	/* 1-3 class no more than 10 */
	A1 += 3 * 20 * 10;
	B1 -= 3 * 20;

	/* 2 students give 1/2 of required in each class */
	A1 -= 3 * 2 * 10 / 2;
	B1 -= ( 10 - 3 ) * 2 / 2;
	B2 -= 10 * 2 / 2;

	/* 1 from 10 class give 5000 not X */
	A1 += 5000;
	A2 += 5000;
	B1 -= 1;
	B2 -= 1;

	X = ( sum_expected - A2 ) / B2;

	/* if cannot pay mininum */
	if( X > 10 )
		X = ( sum_expected - A1 ) / B1;

	/* if negative then no reason to collect money */
	if( X < 0 )
		X = 0;

	printf( "average sum to collect: %lf\n" , ceil( X * 100 ) / 100 );
}

void f3_add( char *dst , const char *src )
{
	short cf = 0;
	char v1 , v2;
	while( *src || *dst )
		{
			v1 = v2 = '0';
			if( *src )
				v1 = *src++;
			if( *dst )
				v2 = *dst;
			
			if( v1 == '0' && v2 == '0' )
				{
					*dst++ = ( cf )? '1' : '0';
					cf = 0;
				}
			else
			if( v1 == '1' && v2 == '1' )
				{
					*dst++ = ( cf )? '1' : '0';
					cf = 1;
				}
			else
				{
					*dst++ = ( cf )? '0' : '1';
				}
		}
	if( cf )
		*dst++ = '1';
}

void f3_mul( int v , const char *x10 , char *dst )
{
	int k;
	int vt;
	char *z;

	/* use only 4 bits */
	z = ( char * )calloc( strlen( x10 ) + 4 + 1 , 1 );
	memcpy( z , x10 , strlen( x10 ) );
	for( k = 0 , vt = 1; k < 4; k++ , vt <<= 1 )
		{
			/* if bit exists then add it to dst */
			if( v & vt )
				f3_add( dst , z );

			/* shift z value */
			memmove( z + 1 , z , strlen( z ) );
			z[ 0 ] = '0';
		}
	free( z );
}		

void f3( char **argv )
{
	char *p = argv[ 1 ];
	int count = strlen( p );
	char *bits_sum = ( char * )calloc( count + 1 , 4 );
	char *bits_10x = ( char * )calloc( count + 1 , 4 );
	char *bits_val = ( char * )calloc( count + 1 , 4 );
	int k;
	double x;

	int v;

	bits_10x[ 0 ] = '1';
	for( k = count - 1;	k >= 0; k-- )
		{
			/* get next digit */
			v = p[ k ] - '0';

			/* multiply	by power of 10 */
			memset( bits_val , 0 , count * 4 );
			f3_mul( v , bits_10x , bits_val );

			/* add to the sum */
			f3_add( bits_sum , bits_val );

			/* calculate next power of 10 */
			memset( bits_val , 0 , count * 4 );
			f3_mul( 10 , bits_10x , bits_val );
			memcpy( bits_10x , bits_val , count * 4 );
		}

	/* reverse */
	memset( bits_val , 0 , count * 4 );
	p = bits_val;
	for( k = strlen( bits_sum ) - 1; k >= 0; k-- )
		*p++ = bits_sum[ k ];

	/* check */
	for( x = 0 , p = bits_val; *p != 0; p++ )
		if( *p == '1' )
			x += pow( 2 , strlen( p ) - 1 );

	printf( "checked input is: %lf\n" , x );
	printf( "result is: %s\n" , bits_val );

	free( bits_sum );
	free( bits_10x );
	free( bits_val );
}

extern void test();

int main( int argc , char **argv , char **arge )
{
	f2( argv );

	return( 0 );
}
