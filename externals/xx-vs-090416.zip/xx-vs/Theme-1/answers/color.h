#define RGB( R , G , B )	( ((R) << 16) | ((G) << 8) | (B) )
#define RGB_RED( rgb )		( ( (rgb) >> 16 ) & 0x000000FF )
#define RGB_GREEN( rgb )	( ( (rgb) >> 8 ) & 0x000000FF )
#define RGB_BLUE( rgb )		( (rgb) & 0x000000FF )
typedef int COLORREF;
#define min(x,y)			( ( (x) < (y) )? (x) : (y) )
class CColor
{
public:
	COLORREF color;

	CColor();
	
	const CColor& operator =( COLORREF p_color );
	const CColor& operator =( const char *p_cs );
	COLORREF value() const;
};

CColor operator +( const CColor& p_lc , const CColor& p_rc );
CColor operator *( const CColor& p_c , unsigned int p_mul );
CColor operator *( unsigned int p_mul , const CColor& p_c );
