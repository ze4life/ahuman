#include <stdio.h>
#include <string.h>
#include "color.h"

extern "C" void test()
{
	CColor c1; c1 = RGB( 0 , 255 , 255 );
	CColor c2; c2 = "blue";
	CColor c3 = c1 + c2;
	CColor c4 = c1 + 2 * c2;

	printf( "c1=0x%x, c2=0x%x, c3=0x%x, c3=0x%x\n" , c1.value() , c2.value() , c3.value() , c4.value() );
}

CColor::CColor()
{
	color = RGB( 0 , 0 , 0 );
}

const CColor& CColor::operator =( COLORREF p_color )
{
	color = p_color;
	return ( *this );
}

const CColor& CColor::operator =( const char *p_cs )
{
	if( !strcmp( p_cs , "red" ) )
		return( *this = RGB( 255 , 0 , 0 ) );
	if( !strcmp( p_cs , "green" ) )
		return( *this = RGB( 0 , 255 , 0 ) );
	if( !strcmp( p_cs , "blue" ) )
		return( *this = RGB( 0 , 0 , 255 ) );

	// ignore others - do not change anything
	return( *this );
}

COLORREF CColor::value() const
{
	return( color );
}

CColor operator +( const CColor& p_lc , const CColor& p_rc )
{
	CColor c;
	c.color = p_lc.color | p_rc.color;
	return( c );
}

CColor operator *( const CColor& p_c , unsigned int p_mul )
{
	return( operator *( p_mul , p_c ) );
}

CColor operator *( unsigned int p_mul , const CColor& p_c )
{
	unsigned int l_cr = p_mul * RGB_RED( p_c.color );
	unsigned int l_cg = p_mul * RGB_GREEN( p_c.color );
	unsigned int l_cb = p_mul * RGB_BLUE( p_c.color );

	CColor c;
	c.color = RGB( min( l_cr , 255 ) , min( l_cg , 255 ) , min( l_cb , 255 ) );
	return( c );	
}

