/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_CONSOLE

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <dir.h>
#include <io.h>
#include <process.h>
#include <ctype.h> // for isprint()

#ifdef USE_SMALL
#include "small/sc.h"
#endif

#ifdef USE_LUA
extern "C" {
  int lc_compile(int argc, const char* argv[]);
}
#endif

#include "glconsole.h"

#include "datasets.inc"

//
// GLConsole
//
#define EDITOR_STATUS_LEN 58
#define EDITOR_STATUS_STR \
  "Row:      |Col:    |ALT+Q Quit|ALT+E Exit|ALT+[] {}|File: "

GLConsole::GLConsole():
  currentRow(0), currentCol(0), historyBase(0), historyCurrent(-1),
  editMode(false), editorBase(0), editorRow(0), editorCol(0),
  suspended(true), prompt('>')
#ifdef USE_LUA
  , luaInteractiveString(NULL), wasLastCommandLua(false)
#endif
{
  char dir[MAX_PATH];
  programDir.setText(getcwd(dir,MAX_PATH));
  editFile.setText("untitled.txt");
  editorStatus.setText(EDITOR_STATUS_STR);
  editorStatus.concat(editFile.getText());
  editor.addElement(new String(""));
  for(int ct = 0; ct < CONSOLE_ROWS; ct++) screen[ct][0] = '\0';
#ifdef USE_LUA
  println("*  LUA  Language (c) 1994-2006 Lua.org PUC-Rio *");
#endif
#ifdef USE_SMALL
  println("* SMALL Language (c) 1997-2001 ITB CompuPhase  *");
#endif
  println("\nType 'h' for help.\n");
  printPrompt();
}

GLConsole* GLConsole::console = new GLConsole();

void GLConsole::print(char ch, bool typed) {
  switch(ch) {
    case '\n': {
      newLine();
      drawCursor();
      break;
    }
    case '\b': {
      if(currentCol > 2) {
        currentCol--;
        drawCursor();
      }
      break;
    }
    case '\t': {
      print(' ',typed);
      break;
    }
    default: {
      if(typed && (currentCol >= CONSOLE_COLS-1))
        break;
      screen[currentRow][currentCol] = ch;
      if(++currentCol >= CONSOLE_COLS) newLine();
      drawCursor();
      break;
    }
  }
}

void GLConsole::print(const char* text) {
  int len = strlen(text);
  for(int ct = 0; ct < len; ct++)
    print(text[ct]);
}

void GLConsole::keyPressed(char key, bool extended, bool altDown) {
  if(editMode) {
    if(extended) {
      switch(key) {
        case VK_DOWN: {
          editorRow++;
          if(editorRow >= editor.getSize()) {
            editorRow = editor.getSize()-1;
          } else {
            if(editorCol > editor.getElement(editorRow)->getLength())
              editorCol = editor.getElement(editorRow)->getLength();
            if(editorRow >= editorBase+(CONSOLE_ROWS-1))
              editorBase = editorRow-(CONSOLE_ROWS-2);
          }
          break;
        }
        case VK_NEXT: {
          editorRow += CONSOLE_ROWS-2;
          if(editorRow >= editor.getSize()) {
            editorRow = editor.getSize()-1;
            editorBase = editorRow-(CONSOLE_ROWS-2);
          } else {
            if(editorRow >= editorBase+(CONSOLE_ROWS-1))
              editorBase = editorRow-(CONSOLE_ROWS-2);
          }
          if(editorCol > editor.getElement(editorRow)->getLength())
            editorCol = editor.getElement(editorRow)->getLength();
          break;
        }
        case VK_UP: {
          editorRow--;
          if(editorRow < 0) {
            editorRow = 0;
          } else {
            if(editorCol > editor.getElement(editorRow)->getLength())
              editorCol = editor.getElement(editorRow)->getLength();
            if(editorRow < editorBase)
              editorBase = editorRow;
          }
          break;
        }
        case VK_PRIOR: {
          editorRow -= CONSOLE_ROWS-2;
          if(editorRow < 0) {
            editorRow = 0;
            editorBase = 0;
          } else {
            if(editorRow < editorBase)
              editorBase = editorRow;
          }
          if(editorCol > editor.getElement(editorRow)->getLength())
            editorCol = editor.getElement(editorRow)->getLength();
          break;
        }
        case VK_LEFT: {
          editorCol--;
          if(editorCol < 0) {
            editorRow--;
            if(editorRow < 0) {
              editorRow = 0;
              editorCol = 0;
            } else {
              editorCol = editor.getElement(editorRow)->getLength();
              if(editorRow < editorBase)
                editorBase = editorRow;
            }
          }
          break;
        }
        case VK_RIGHT: {
          editorCol++;
          if(editorCol > editor.getElement(editorRow)->getLength()) {
            editorRow++;
            if(editorRow >= editor.getSize()) {
              editorRow = editor.getSize()-1;
              editorCol = editor.getElement(editorRow)->getLength();
            } else {
              editorCol = 0;
              if(editorRow > editorBase+(CONSOLE_ROWS-1))
                editorBase = editorRow-(CONSOLE_ROWS-2);
            }
          }
          break;
        }
        case VK_DELETE: {
          if(editorCol < editor.getElement(editorRow)->getLength()) {
            editor.getElement(editorRow)->del(editorCol);
          } else {
            editor.getElement(editorRow)->concat(
              editor.getElement(editorRow+1)->getText()
            );
            for(int ct = editorRow+1; ct < editor.getSize()-1; ct++)
              editor.setElement(ct,editor.getElement(ct+1));
            editor.setElement(editor.getSize()-1,NULL);
            editor.decrementSize();
          }
          break;
        }
        case VK_END: {
          editorCol = editor.getElement(editorRow)->getLength();
          break;
        }
        case VK_HOME: {
          editorCol = 0;
          break;
        }
        case VK_BACK: {
          if(editorCol > 0) {
            editor.getElement(editorRow)->del(editorCol-1);
            editorCol--;
          } else {
            if(editorRow == 0)
              return;
            editorRow--;
            if(editorRow < editorBase)
              editorBase = editorRow;
            editorCol = editor.getElement(editorRow)->getLength();
            editor.getElement(editorRow)->concat(
              editor.getElement(editorRow+1)->getText()
            );
            for(int ct = editorRow+1; ct < editor.getSize()-1; ct++)
              editor.setElement(ct,editor.getElement(ct+1));
            editor.setElement(editor.getSize()-1,NULL);
            editor.decrementSize();
          }
          break;
        }
      }
    } else {
      switch(key) {
        case 'E':
        case 'e':
        {
          if(altDown) {
            editMode = false;
            if(workingDir.getSize() > 0)
              chdir(workingDir.getText());
            FILE* f = fopen(editFile.getText(),"w");
            if(f) {
              for(int ct = 0; ct < editor.getSize(); ct++) {
                fputs(editor.getElement(ct)->getText(),f);
                fputc('\n',f);
              }
              fclose(f);
            }
            if(workingDir.getSize() > 0)
              chdir(programDir.getText());
            return;
          }
          break;
        }
        case 'Q':
        case 'q':
        {
          if(altDown) {
            editMode = false;
            return;
          }
          break;
        }
        case '[': {
          if(altDown)
            key = '{';
          break;
        }
        case ']': {
          if(altDown)
            key = '}';
          break;
        }
        case '\t': {
          editor.getElement(editorRow)->insert(' ',editorCol);
          editorCol++;
          editor.getElement(editorRow)->insert(' ',editorCol);
          editorCol++;
          break;
        }
        case '\b': {
          if(editorCol > 0) {
            editor.getElement(editorRow)->del(editorCol-1);
            editorCol--;
          } else {
            if(editorRow == 0)
              return;
            editorRow--;
            if(editorRow < editorBase)
              editorBase = editorRow;
            editorCol = editor.getElement(editorRow)->getLength();
            editor.getElement(editorRow)->concat(
              editor.getElement(editorRow+1)->getText()
            );
            for(int ct = editorRow+1; ct < editor.getSize()-1; ct++)
              editor.setElement(ct,editor.getElement(ct+1));
            editor.setElement(editor.getSize()-1,NULL);
            editor.decrementSize();
          }
          return;
        }
        case '\r': {
          int size = editor.getSize();
          int sizeM1 = size-1;
          editor.setElement(size,editor.getElement(sizeM1));
          for(int ct = sizeM1; ct > editorRow+1; ct--)
            editor.setElement(ct,editor.getElement(ct-1));
          char* line = editor.getElement(editorRow)->getText()+editorCol;
          editor.setElement(editorRow+1,new String(*line? line: ""));
          editor.getElement(editorRow)->setLength(editorCol);
          editorCol = 0;
          editorRow++;
          if(editorRow >= editorBase+(CONSOLE_ROWS-1))
            editorBase = editorRow-(CONSOLE_ROWS-2);
          return;
        }
      }
      if(isprint(key)) {
        editor.getElement(editorRow)->insert(key,editorCol);
        editorCol++;
      }
    }
  } else {
    if(extended) {
      switch(key) {
        case VK_BACK:
        case VK_LEFT: {
          print('\b',true);
          break;
        }
        case VK_UP: {
          if((--historyCurrent) < 0)
            historyCurrent = HISTORY_LENGTH-1;
          currentCol = 0;
          printPrompt();
          print(history[historyCurrent].getText());
          break;
        }
        case VK_DOWN: {
          if(historyCurrent == historyBase) {
            currentCol = 0;
            printPrompt();
          } else {
            if((++historyCurrent) >= HISTORY_LENGTH)
              historyCurrent = 0;
            currentCol = 0;
            printPrompt();
            print(history[historyCurrent].getText());
          }
          break;
        }
        case VK_HOME: {
          currentCol = 0;
          printPrompt();
          break;
        }
      }
    } else {
      switch(key) {
        case '\r': {
          char* commandLine = screen[currentRow];
          history[historyBase].setText(commandLine+2);
          history[historyBase].setLength(strlen(commandLine+2)-1);
          if((++historyBase) >= HISTORY_LENGTH)
            historyBase = 0;
          historyCurrent = historyBase;
          newLine();
          if(executeCommand(commandLine)) {
            printPrompt();
#ifdef USE_LUA
            if(wasLastCommandLua)
              print("i ");
#endif
          }
          break;
        }
        default: {
          if(isprint(key))
            print(key,true);
          else if(key == '\b')
            print(key,true);
          break;
        }
      }
    }
  }
}

bool GLConsole::executeCommand(char* textLine) {
  if(workingDir.getSize() > 0)
    chdir(workingDir.getText());
#ifdef USE_LUA
  wasLastCommandLua = false;
  if(luaInteractiveString != NULL) {
    int lineLen = strlen(textLine)-2;
    if(lineLen == 0) {
      luaInterpreter.doString(luaInteractiveString);
      delete luaInteractiveString;
      luaInteractiveString = NULL;
      setPrompt('>');
    } else {
      char* oldString = luaInteractiveString;
      luaInteractiveString = new char[strlen(oldString)+lineLen+2];
      strcat(strcpy(luaInteractiveString,oldString),textLine+1);
      delete oldString;
    }
    return true;
  }
#endif
  if(textLine[0] != '>')
    return true;
  char commandLine[CONSOLE_COLS+1];
  strcpy(commandLine,textLine);
  char* token = strtok(commandLine+2," ");
  if(token) {
    strlwr(token);
    switch(token[0]) {
      case 'h': {
        println("List of valid commands:");
        println("h            : show this list.");
#ifdef USE_LUA
        println("i            : interpret LUA strings.");
        println("l            : list LUA scripts.");
        println("c <filename> : compile LUA script.");
        println("r <filename> : execute LUA script.");
#endif
#ifdef USE_SMALL
        println("p            : list SMALL scripts.");
        println("s <filename> : compile SMALL script.");
        println("x <filename> : execute SMALL script.");
#endif
        println("g <command>  : run external program.");
        println("d [dirname]  : list files/change dir.");
        println("e [filename] : open editor/edit file.");
        break;
      }
      case 'g': {
        const int MAX_ARGS = 16;
        char* args[MAX_ARGS];
        token = strtok(NULL," ");
        if(token == NULL) {
          println("Command missing.");
          break;
        }
        args[0] = token;
        int nargs = 1;
        for(; nargs < MAX_ARGS-1; nargs++) {
          token = strtok(NULL," ");
          if(token)
            args[nargs] = token;
          else
            break;
        }
        args[nargs] = NULL;
        spawnv(P_NOWAIT,args[0],args);
        break;
      }
      case 'd': {
        char dir[MAX_PATH];
        token = strtok(NULL," ");
        if(token) {
          if(chdir(token)) {
            println("Directory not found.");
            break;
          }
          workingDir.setText(getcwd(dir,MAX_PATH));
          print("  ");
          println(workingDir.getText());
        } else {
          print("  ");
          println(getcwd(dir,MAX_PATH));
        }
        struct _finddata_t f;
        int handle = _findfirst("*.*",&f);
        if(handle != -1) {
          do {
            if((f.attrib & _A_SUBDIR) != 0) {
              print("D \\");
              println(f.name);
            }
          } while(_findnext(handle,&f) != -1);
          _findclose(handle);
        }
        handle = _findfirst("*.*",&f);
        if(handle != -1) {
          do {
            if((f.attrib & _A_SUBDIR) == 0) {
#ifdef USE_LUA
              if(strstr(f.name,".lua"))
                print("L ");
              else
#endif
#ifdef USE_SMALL
              if(strstr(f.name,".sma"))
                print("S ");
              else
#endif
                print("  ");
              println(f.name);
            }
          } while(_findnext(handle,&f) != -1);
          _findclose(handle);
        }
        break;
      }
      case 'e': {
        token = strtok(NULL," ");
        editMode = true;
        if(token) {
          editFile.setText(token);
          editorStatus.setLength(EDITOR_STATUS_LEN);
          editorStatus.concat(token);
          editor.deleteElements();
          editorBase = 0;
          editorRow = 0;
          editorCol = 0;
          FILE* f = fopen(token,"r");
          if(f) {
            const int BUF_LEN = 1023;
            char line[BUF_LEN+1];
            while(fgets(line,BUF_LEN,f)) {
              int len = strlen(line)-1;
              if(line[len] == '\n')
                line[len] = '\0';
              editor.addElement(new String(line));
            }
            fclose(f);
          } else {
            editor.addElement(new String(""));
          }
        }
        break;
      }
#ifdef USE_SMALL
      case 's': {
        const int MAX_ARGS = 16;
        char* args[MAX_ARGS];
        args[0] = "sc.exe";
        int nargs = 1;
        for(; nargs < MAX_ARGS-1; nargs++) {
          token = strtok(NULL," ");
          if(token)
            args[nargs] = token;
          else
            break;
        }
        args[nargs] = NULL;
        sc_compile(nargs,args);
        break;
      }
      case 'x': {
        token = strtok(NULL," ");
        if(token) {
          if(!strrchr(token,'.')) {
            char fileName[32];
            strcat(strcpy(fileName,token),".amx");
            token = fileName;
          }
          if(smallInterpreter.load(token)) {
            suspended = false;
            int ret = smallInterpreter.initMain();
            return ret != AMX_ERR_SLEEP;
          } else {
            println("Error loading script file.");
          }
        } else {
          println("Missing file name. Usage: x \"file name\"");
        }
        break;
      }
      case 'p': {
        struct _finddata_t f;
        int handle = _findfirst("*.sma",&f);
        if(handle == -1) {
          println("No SMALL scripts found.");
        } else {
          do {
            println(f.name);
          } while(_findnext(handle,&f) != -1);
          _findclose(handle);
        }
        break;
      }
#endif // USE_SMALL
#ifdef USE_LUA
      case 'c': {
        const int MAX_ARGS = 8;
        const char* args[MAX_ARGS];
        args[0] = "luac";
        int nargs = 1;
        for(; nargs < MAX_ARGS; nargs++) {
          token = strtok(NULL," ");
          if(token)
            args[nargs] = token;
          else
            break;
        }
        lc_compile(nargs,args);
        break;
      }
      case 'r': {
        char fileName[MAX_PATH];
        token = strtok(NULL," ");
        if(token) {
          strcpy(fileName,token);
          if(!strrchr(fileName,'.'))
            strcat(fileName,".lua");
        } else {
          struct _finddata_t f;
          int handle = _findfirst("*.lua",&f);
          if(handle == -1) {
            println("Missing file name. Usage: r \"file name\"");
            break;
          }
          strcpy(fileName,f.name);
          _findclose(handle);
        }
        if(luaInterpreter.doFile(fileName))
          printPrompt();
        break;
      }
      case 'i': {
        wasLastCommandLua = true;
        token = strtok(NULL,"\n");
        if(token) {
          luaInterpreter.doString(token);
        } else {
          wasLastCommandLua = false;
          println("* enter blank line to end input");
          setPrompt('|');
          luaInteractiveString = new char[1];
          luaInteractiveString[0] = '\0';
        }
        break;
      }
      case 'l': {
        struct _finddata_t f;
        int handle = _findfirst("*.lua",&f);
        if(handle == -1) {
          println("No LUA scripts found.");
        } else {
          do {
            println(f.name);
          } while(!_findnext(handle,&f));
          _findclose(handle);
        }
        break;
      }
#endif // USE_LUA
      default: {
        println("Unknown command.");
        break;
      }
    }
  }
  if(workingDir.getSize() > 0)
    chdir(programDir.getText());
  return true;
}

char* GLConsole::getRow(int idx) {
  if(editMode) {
    if(idx == CONSOLE_ROWS-1) {
      char txt[16];
      char* s = editorStatus.getText();
      itoa(editorRow,txt,10);
      strcpy(strchr(s,':')+2,txt);
      s += strlen(s);
      *s = ' ';
      itoa(editorCol,txt,10);
      strcpy(strchr(s,':')+2,txt);
      s += strlen(s);
      *s = ' ';
      return editorStatus.getText();
    } else {
      int index = editorBase+idx;
      if(index < editor.getSize() && index >= 0)
        return editor.getElement(editorBase+idx)->getText();
    }
    return NULL;
  } else {
    if((idx < 0) || (idx >= CONSOLE_ROWS)) return NULL;
    if(idx == CONSOLE_ROWS) return screen[currentRow];
    if((idx += currentRow+1) >= CONSOLE_ROWS) idx -= CONSOLE_ROWS;
    return screen[idx];
  }
}

//
// for GLConsole
//

#if defined(USE_SMALL) || defined(USE_LUA)
extern "C" {

int sc_vprintf(const char *message, va_list argptr) {
  const int MAX_STRING_LENGTH = 4096;
  char string[MAX_STRING_LENGTH];
  int ret = vsprintf(string,message,argptr);
  GLConsole::get().print(string);
  return ret;
}

int sc_printf(const char *message, ...) {
  va_list argptr;
  va_start(argptr,message);
  int ret = sc_vprintf(message,argptr);
  va_end(argptr);
  return ret;
}

int sc_putchar(int c)
  {return sc_printf("%c",c) == 1? c: EOF;}

void sc_print_string(const char *string)
  {GLConsole::get().print(string);}

}
#endif // USE_SMALL || USE_LUA

#endif // USE_CONSOLE

