/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glmaterial.h"
#include "glextensions.h"

#include "datasets.inc"

//
// GLBasicMaterial
//

GLBasicMaterial::GLBasicMaterial():
  ambient(1,1,1), diffuse(1,1,1), specular(0,0,0), emissive(0,0,0),
  shininess(10.0f), diffuseTexture(NULL), enlighted(true)
{}

void GLBasicMaterial::destroyObject() {
  if(diffuseTexture) diffuseTexture->releaseReference();
  delete this;
}

void GLBasicMaterial::applyColor() {
  if(isEnlighted()) {
    glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,shininess);
    glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,ambient.getFloatArray());
    glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,diffuse.getFloatArray());
    glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,specular.getFloatArray());
    glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,emissive.getFloatArray());
  } else {
    glDisable(GL_LIGHTING);
#ifdef USE_OGLES
    glColor4f(
      emissive.getRed(),emissive.getGreen(),
      emissive.getBlue(),emissive.getAlpha()
    );
#else // !USE_OGLES
    glColor4fv(emissive.getFloatArray());
#endif // !USE_OGLES
  }
}

//
// GLMaterial
//

GLMaterial::GLMaterial():
  glossTexture(NULL), environmentTexture(NULL), environment(-1.0f)
{}

void GLMaterial::destroyObject() {
  if(environmentTexture) environmentTexture->releaseReference();
  if(glossTexture) glossTexture->releaseReference();
  GLBasicMaterial::destroyObject();
}

void GLMaterial::enableEnvironment(GLCamera& camera) {
  float env[] = {1,1,1,environment};
  glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,env);
  glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,env);
  glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,env);
  glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,env);
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
#ifndef USE_OGLES
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);
  if(typeid(*environmentTexture) == typeid(GLCubeMapTexture)) {
    if(IS_TEXTURE_CUBE_MAP_SUPPORTED) {
      glEnable(GL_TEXTURE_CUBE_MAP_ARB);
      glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,GL_REFLECTION_MAP_ARB);
      glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,GL_REFLECTION_MAP_ARB);
      glTexGeni(GL_R,GL_TEXTURE_GEN_MODE,GL_REFLECTION_MAP_ARB);
      glEnable(GL_TEXTURE_GEN_R);
      glMatrixMode(GL_TEXTURE);
      glPushMatrix();
      glScalef(1,-1,1);
      glMatrixMode(GL_MODELVIEW);
    }
  } else {
    glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);
    glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,GL_SPHERE_MAP);
  }
#endif // !USE_OGLES
  environmentTexture->apply();
}

void GLMaterial::disableEnvironment() {
#ifndef USE_OGLES
  if(typeid(*environmentTexture) == typeid(GLCubeMapTexture)) {
    glMatrixMode(GL_TEXTURE);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glDisable(GL_TEXTURE_GEN_R);
    glDisable(GL_TEXTURE_CUBE_MAP_ARB);
  }
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);
#endif // !USE_OGLES
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
}

#ifdef USE_EMBOSS

//
// GLBumpedMaterial
//

GLBumpedMaterial::GLBumpedMaterial(): bumpedTexture(NULL), bump(0.0f) {
}

void GLBumpedMaterial::destroyObject() {
  if(bumpedTexture) bumpedTexture->releaseReference();
  GLMaterial::destroyObject();
}

#endif // USE_EMBOSS

//
// GLProgramMaterial
//

GLProgramMaterial::GLProgramMaterial(GLVertexProgram* vp, GLFragmentProgram* fp):
  vertexProgram(vp), fragmentProgram(fp)
{
  if(vp) vp->acquireReference();
  if(fp) fp->acquireReference();
}

void GLProgramMaterial::destroyObject() {
  for(int ct = 0; ct < textures.getSize(); ct++)
    textures.getElement(ct)->releaseReference();
  if(vertexProgram) vertexProgram->releaseReference();
  if(fragmentProgram) fragmentProgram->releaseReference();
  GLMaterial::destroyObject();
}

void GLProgramMaterial::apply() {
  applyColor();
  if(IS_MULTITEXTURING_ENABLED) {
    int texIndex = 0;
    if(hasGloss()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glEnable(getGlossTexture()->getTextureDim());
      applyGloss();
      texIndex++;
    }
    if(hasEnvironment()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      GLTexture* t = getEnvironmentTexture();
      glEnable(t->getTextureDim());
      t->apply();
      texIndex++;
    }
    for(int ct = 0; ct < textures.getSize(); ct++) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex+ct);
      GLTexture* t = textures.getElement(ct);
      glEnable(t->getTextureDim());
      t->apply();
    }
    glActiveTextureARB(GL_TEXTURE0_ARB);
  }
  glDisable(GL_TEXTURE_2D);
  if(hasDiffuse()) {
    glEnable(getDiffuseTexture()->getTextureDim());
    applyDiffuse();
  }
  if(vertexProgram) {
    vertexProgram->enable();
    vertexProgram->apply();
  }
  if(fragmentProgram) {
    fragmentProgram->enable();
    fragmentProgram->apply();
  }
}

void GLProgramMaterial::unapply() {
  if(IS_MULTITEXTURING_ENABLED) {
    int texIndex = 0;
    if(hasGloss()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glDisable(getGlossTexture()->getTextureDim());
      texIndex++;
    }
    if(hasEnvironment()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glDisable(getEnvironmentTexture()->getTextureDim());
      texIndex++;
    }
    for(int ct = 0; ct < textures.getSize(); ct++) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex+ct);
      GLTexture* t = textures.getElement(ct);
      glDisable(t->getTextureDim());
    }
    glActiveTextureARB(GL_TEXTURE0_ARB);
  }
  if(hasDiffuse())
    glDisable(getDiffuseTexture()->getTextureDim());
  glEnable(GL_TEXTURE_2D);
  unapplyColor();
  if(vertexProgram) {
    vertexProgram->disable();
    vertexProgram->unapply();
  }
  if(fragmentProgram) {
    fragmentProgram->disable();
    fragmentProgram->unapply();
  }
}

//
// GLShaderMaterial
//

GLShaderMaterial::GLShaderMaterial(GLShaderProgram* sp): shaderProgram(sp) {
  if(sp) sp->acquireReference();
}

void GLShaderMaterial::destroyObject() {
  for(int ct = 0; ct < textures.getSize(); ct++)
    textures.getElement(ct)->releaseReference();
  if(shaderProgram) shaderProgram->releaseReference();
  GLMaterial::destroyObject();
}

void GLShaderMaterial::apply() {
  applyColor();
  if(IS_MULTITEXTURING_ENABLED) {
    int texIndex = 0;
    if(hasGloss()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glEnable(getGlossTexture()->getTextureDim());
      applyGloss();
      texIndex++;
    }
    if(hasEnvironment()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      GLTexture* t = getEnvironmentTexture();
      glEnable(t->getTextureDim());
      t->apply();
      texIndex++;
    }
    for(int ct = 0; ct < textures.getSize(); ct++) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex+ct);
      GLTexture* t = textures.getElement(ct);
      glEnable(t->getTextureDim());
      t->apply();
    }
    glActiveTextureARB(GL_TEXTURE0_ARB);
  }
  glDisable(GL_TEXTURE_2D);
  if(hasDiffuse()) {
    glEnable(getDiffuseTexture()->getTextureDim());
    applyDiffuse();
  }
  if(shaderProgram)
    shaderProgram->apply();
}

void GLShaderMaterial::unapply() {
  if(IS_MULTITEXTURING_ENABLED) {
    int texIndex = 0;
    if(hasGloss()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glDisable(getGlossTexture()->getTextureDim());
      texIndex++;
    }
    if(hasEnvironment()) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex);
      glDisable(getEnvironmentTexture()->getTextureDim());
      texIndex++;
    }
    for(int ct = 0; ct < textures.getSize(); ct++) {
      glActiveTextureARB(GL_TEXTURE1_ARB+texIndex+ct);
      GLTexture* t = textures.getElement(ct);
      glDisable(t->getTextureDim());
    }
    glActiveTextureARB(GL_TEXTURE0_ARB);
  }
  if(hasDiffuse())
    glDisable(getDiffuseTexture()->getTextureDim());
  glEnable(GL_TEXTURE_2D);
  unapplyColor();
  if(shaderProgram)
    shaderProgram->useFixedPipeline();
}

//
// GLBasicMaterialOwner
//
GLBasicMaterialOwner::GLBasicMaterialOwner(GLBasicMaterial* mat) {
  if(mat == NULL)
    mat = new GLMaterial();
  material = mat->acquireReference();
}

GLBasicMaterialOwner::~GLBasicMaterialOwner() {
  material->releaseReference();
}

