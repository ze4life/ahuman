/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

//
// Example of engine API for SMALL.
// WARNING: Possible problems with raw pointer conversion and C++ objects.
// WARNING: Probably calls to classes and functions very outdated.
//

/*

#include "small/amx.h"

#include "glconsole.h"
#include "dataread.h"

#include "glflatterrain.h"

//
// C strings
//
inline static char* newString(AMX *amx, cell param) {
  cell *address;
  amx_GetAddr(amx,param,&address);
  int len;
  amx_StrLen(address,&len);
  char *string = new char[len+1];
  amx_GetString(string,address);
  return string;
}

inline static void delString(char *string) {
  delete string;
}

//
// C floats
//
inline static cell float2Cell(float f) {
  float *theFloat;
  cell theCell;
  theFloat = (float*)((void*)&theCell);
  *theFloat = f;
  return theCell;
}

inline static float cell2Float(cell c) {
  float *theFloat;
  theFloat = (float*)((void*)&c);
  return *theFloat;
}

//
// ZipHandler:newZipHandler(const fileName[]);
//
static cell AMX_NATIVE_CALL newZipHandler(AMX *amx, cell *param) {
  char *fileName = newString(amx,param[1]);
  cell zipHandler = (cell)new DRZipFile(fileName);
  delString(fileName);
  return zipHandler;
}

//
// delZipHandler(ZipHandler:zipHandler);
//
static cell AMX_NATIVE_CALL delZipHandler(AMX *amx, cell *param) {
  DRZipFile *zipFile = (DRZipFile*)param[1];
  zipFile->closeZippedFile();
  delete zipFile;
}

//
// Image:getImageFromZip(ZipHandler:zipFile, const imageName[]);
//
static cell AMX_NATIVE_CALL getImageFromZip(AMX *amx ,cell *param) {
  DRZipFile *zipFile = (DRZipFile*)param[1];
  char *imageName = newString(amx,param[2]);
  DRImage *image = zipFile->getImage(imageName);
  delString(imageName);
  return (cell)image;
}

//
// delImage(Image:image);
//
static cell AMX_NATIVE_CALL delImage(AMX *amx ,cell *param) {
  DRImage *image = (DRImage*)param[1];
  delete image;
}

//
// Texture:getTextureFromZip(
//   ZipHandler:zipFile, const imageName[], bool:repeat = false
// );
//
static cell AMX_NATIVE_CALL getTextureFromZip(AMX *amx ,cell *param) {
  DRZipFile *zipFile = (DRZipFile*)param[1];
  char *imageName = newString(amx,param[2]);
  GLTexture *texture = zipFile->getTexture(imageName,(bool)param[3]);
  delString(imageName);
  return (cell)texture;
}

//
// Object:getMeshFromZip(ZipHandler:zipFile, const meshName[]);
//
static cell AMX_NATIVE_CALL getMeshFromZip(AMX *amx ,cell *param) {
  DRZipFile *zipFile = (DRZipFile*)param[1];
  char *meshName = newString(amx,param[2]);
  GLObjects *meshes = zipFile->getMeshes(meshName);
  delString(meshName);
  return (cell)meshes;
}

//
// showObj(Object:object);
//
static cell AMX_NATIVE_CALL showObj(AMX *amx ,cell *param) {
  GLObject *obj = (GLObject*)param[1];
  obj->setVisible(true);
}

//
// hideObj(Object:object);
//
static cell AMX_NATIVE_CALL hideObj(AMX *amx ,cell *param) {
  GLObject *obj = (GLObject*)param[1];
  obj->setVisible(false);
}

//
// moveObj(Object:object, const position[3]);
//
static cell AMX_NATIVE_CALL moveObj(AMX *amx ,cell *param) {
  GLObject *obj = (GLObject*)param[1];
  cell *pos;
  amx_GetAddr(amx,param[2],&pos);
  obj->move(cell2Float(pos[0]),cell2Float(pos[1]),cell2Float(pos[2]));
}

//
// rotYObj(Object:object, float:angle);
//
static cell AMX_NATIVE_CALL rotYObj(AMX *amx ,cell *param) {
  GLObject *obj = (GLObject*)param[1];
  obj->rotateStanding(cell2Float(param[2]));
}

//
// addObj(Object:object);
//
static cell AMX_NATIVE_CALL addObj(AMX *amx ,cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  GLObject *obj = (GLObject*)param[1];
  obj->setVisible(true);
  glWin->getWorld().addObject(obj);
}

//
// Texture:newAnimatedTexture(
//   imagesCount, const Image:images[], float:duration, bool:repeat = false
// );
//
static cell AMX_NATIVE_CALL newAnimatedTexture(AMX *amx ,cell *param) {
  cell *images;
  amx_GetAddr(amx,param[2],&images);
  GLAnimatedTexture* animatedTexture = new GLAnimatedTexture(
    param[1],(DRImage**)images,cell2Float(param[3]),(bool)param[4]
  );
  return (cell)animatedTexture;
}

//
// Material:newMaterial();
//
static cell AMX_NATIVE_CALL newMaterial(AMX *amx, cell *param) {
  GLMaterial *mat = new GLMaterial();
  return (cell)mat;
}

//
// setMatAmbient(Material:material, const color[3]);
//
static cell AMX_NATIVE_CALL setMatAmbient(AMX *amx, cell *param) {
  GLMaterial *mat = (GLMaterial*)param[1];
  cell *color;
  amx_GetAddr(amx,param[2],&color);
  mat->setAmbient(
    cell2Float(color[0]),cell2Float(color[1]),cell2Float(color[2])
  );
}

//
// setMatDiffuse(Material:material, const color[3]);
//
static cell AMX_NATIVE_CALL setMatDiffuse(AMX *amx, cell *param) {
  GLMaterial *mat = (GLMaterial*)param[1];
  cell *color;
  amx_GetAddr(amx,param[2],&color);
  mat->setDiffuse(
    cell2Float(color[0]),cell2Float(color[1]),cell2Float(color[2])
  );
}

//
// setMatDiffuseMap(Material:material, Texture:texture);
//
static cell AMX_NATIVE_CALL setMatDiffuseMap(AMX *amx, cell *param) {
  GLMaterial *mat = (GLMaterial*)param[1];
  GLTexture *txt = (GLTexture*)param[2];
  mat->setDiffuseTexture(txt);
}

//
// Background:newSky(const Texture:textures[6]);
//
static cell AMX_NATIVE_CALL newSky(AMX *amx, cell *param) {
  cell *textures;
  amx_GetAddr(amx,param[1],&textures);
  GLSkybox *sky = new GLSkybox((GLTexture**)textures);
  sky->setColor(1,1,1);
  return (cell)sky;
}

//
// Background:newMirroredSky(const Texture:textures[5]);
//
static cell AMX_NATIVE_CALL newMirroredSky(AMX *amx, cell *param) {
  cell *textures;
  amx_GetAddr(amx,param[1],&textures);
  GLMirroredSkybox *sky = new GLMirroredSkybox((GLTexture**)textures);
  sky->setColor(1,1,1);
  return (cell)sky;
}

//
// setBackground(Background:background);
//
static cell AMX_NATIVE_CALL setBackground(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  GLBackground *background = (GLBackground*)param[1];
  glWin->getWorld().setBackground(background);
}

//
// Terrain::newFlatTerrain(
//   Material:material, float:size, tiles,
//   bool:reflective = false, bool:transparent = false
// );
//
static cell AMX_NATIVE_CALL newFlatTerrain(AMX *amx, cell *param) {
  GLMaterial *mat = (GLMaterial*)param[1];
  GLFlatTerrain *terrain = new GLFlatTerrain(mat,cell2Float(param[2]),param[3]);
  terrain->setVisible(false);
  terrain->setReflective((bool)param[4]);
  terrain->setTransparent((bool)param[5]);
}

//
// setTerrain(Terrain:terrain);
//
static cell AMX_NATIVE_CALL setTerrain(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  GLTerrain *terrain = (GLTerrain*)param[1];
  terrain->setVisible(true);
  glWin->getWorld().setTerrain(terrain);
}

//
// Sun:newSun(
//   Texture:sunTexture, float:sunSize, const direction[3],
//   Texture:flaresTexture, flaresCount, float:flaresSize
// );
//
static cell AMX_NATIVE_CALL newSun(AMX *amx, cell *param) {
  cell *dir;
  amx_GetAddr(amx,param[3],&dir);
  M3Vector direction(cell2Float(dir[0]),cell2Float(dir[1]),cell2Float(dir[2]));
  GLSunLight* sun = new GLSunLight(
    (GLTexture*)param[1],cell2Float(param[2]),direction,(GLTexture*)param[4],
    param[5],cell2Float(param[6])
  );
  sun->setVisible(true);
  sun->setColor(1,1,1);
  return (cell)sun;
}

//
// setSun(Sun:sun);
//
static cell AMX_NATIVE_CALL setSun(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  GLSunLight* sun = (GLSunLight*)param[1];
  glWin->getWorld().setSun(sun);
}

//
// setPerspective(float:fieldOfView, float:minClip, float:maxClip);
//
static cell AMX_NATIVE_CALL setPerspective(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  glWin->setPerspective(
    cell2Float(param[1]),cell2Float(param[2]),cell2Float(param[3])
  );
}

//
// setCameraPos(const position[3]);
//
static cell AMX_NATIVE_CALL setCameraPos(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  cell *pos;
  amx_GetAddr(amx,param[1],&pos);
  glWin->getCamera().setPosition(
    cell2Float(pos[0]),cell2Float(pos[1]),cell2Float(pos[2])
  );
}

//
// setAmbient(const color[3]);
//
static cell AMX_NATIVE_CALL setAmbient(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  cell *color;
  amx_GetAddr(amx,param[1],&color);
  glWin->getWorld().setAmbient(
    cell2Float(color[0]),cell2Float(color[1]),cell2Float(color[2])
  );
}

//
// empty();
//
static cell AMX_NATIVE_CALL empty(AMX *amx, cell *param) {
  GLWin *glWin = GLConsole::get().getWin();
  glWin->getWorld().empty();
}

//
// natives
//
extern AMX_NATIVE_INFO engn_Natives[] = {
  {"newZipHandler",newZipHandler},
  {"delZipHandler",delZipHandler},
  {"getImageFromZip",getImageFromZip},
  {"delImage",delImage},
  {"getTextureFromZip",getTextureFromZip},
  {"getMeshFromZip",getMeshFromZip},
  {"showObj",showObj},
  {"hideObj",showObj},
  {"moveObj",moveObj},
  {"rotYObj",rotYObj},
  {"addObj",addObj},
  {"newAnimatedTexture",newAnimatedTexture},
  {"newMaterial",newMaterial},
  {"setMatAmbient",setMatAmbient},
  {"setMatDiffuse",setMatDiffuse},
  {"setMatDiffuseMap",setMatDiffuseMap},
  {"newSky",newSky},
  {"newMirroredSky",newMirroredSky},
  {"setBackground",setBackground},
  {"newFlatTerrain",newFlatTerrain},
  {"setTerrain",setTerrain},
  {"newSun",newSun},
  {"setSun",setSun},
  {"setPerspective",setPerspective},
  {"setCameraPos",setCameraPos},
  {"setAmbient",setAmbient},
  {"empty",empty},
  { 0, 0 }
};

*/

#endif // USE_CONSOLE && USE_SMALL
