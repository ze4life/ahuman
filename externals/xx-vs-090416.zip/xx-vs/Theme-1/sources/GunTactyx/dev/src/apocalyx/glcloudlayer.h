#ifndef GLCLOUDLAYER_H
#define GLCLOUDLAYER_H

/*
  Copyright (C) 2001-2005 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "void.h"

#include "gldisplaylist.h"
#include "glmaterial.h"

//
// GLCloudLayer
//
class GLCloudLayer:
  public GLBasicMaterialOwner, public GLVisible, virtual public Void
{
private:
  enum {
    TEX_COMPS = 2, VERT_COMPS = 3, COL_COMPS = 4,
    FAN_VERT_COUNT = 7, MAX_VERT_COUNT = 13,
    FAN_IDX_COUNT = 8, STRIP_IDX_COUNT = 14,
  };
protected:
  unsigned short fanIndexes[FAN_IDX_COUNT];
  unsigned short stripIndexes[STRIP_IDX_COUNT];
  float texArray[MAX_VERT_COUNT*TEX_COMPS];
  float colArray[MAX_VERT_COUNT*COL_COMPS];
  float vertArray[MAX_VERT_COUNT*VERT_COMPS];
private:
  float speedX, speedZ;
  float height;
  float size;
  int tiles;
public:
  GLCloudLayer(GLBasicMaterial* mat, float siz, float h, int tils = 1);
  void setColor(float r, float g, float b, float a = 1);
  void setSpeed(float sx, float sz) {speedX = sx; speedZ = sz;}
  float getSpeedX() {return speedX;}
  float getSpeedZ() {return speedZ;}
  virtual void render(GLCamera& camera);
};

#endif // CLOUDLAYER_H
