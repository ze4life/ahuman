/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gtsim.h"

#include "apocalyx/glbsp.h"
#include "apocalyx/glconsole.h"

#include "apocalyx/datasets.inc"

#include "small/amx.h"

#include <stdlib.h> // for rand()

//
// Small AI Library
//

// int:getGoal();
static cell AMX_NATIVE_CALL getGoal(AMX *amx, cell *param) {amx;param;
  return GTArena::get()->getGoalIndex();
}
// int:getPlay();
static cell AMX_NATIVE_CALL getPlay(AMX *amx, cell *param) {amx;param;
  return GTArena::get()->getPlayIndex();
}
// int:getTeams();
static cell AMX_NATIVE_CALL getTeams(AMX *amx, cell *param) {amx;param;
  return GTArena::get()->getTeamsCount();
}
// int:getMates();
static cell AMX_NATIVE_CALL getMates(AMX *amx, cell *param) {amx;param;
  return GTArena::get()->getMatesCount();
}
// int:getKilledEnemies();
static cell AMX_NATIVE_CALL getKilledEnemies(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getKilledEnemies();
}
// int:getKilledFriends();
static cell AMX_NATIVE_CALL getKilledFriends(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getKilledFriends();
}
// float:getTimeout();
static cell AMX_NATIVE_CALL getTimeout(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTArena::get()->getMatchDuration());
}
// bool:getGoalLocation(int:team,&float:x,&float:y,&float:z);
static cell AMX_NATIVE_CALL getGoalLocation(AMX *amx, cell *param) {amx;param;
  GTArena* arena = GTArena::get();
  if(param[1] >= arena->getTeamsCount())
    return 0;
  GTBot* bot = GTBot::getCurrentBot();
  float* x;
  amx_GetAddr(amx,param[2],&(cell*)x);
  float* y;
  amx_GetAddr(amx,param[3],&(cell*)y);
  float* z;
  amx_GetAddr(amx,param[4],&(cell*)z);
  if(param[1] == 0) {
    BSPVector& loc = arena->getCorner(bot->getTeamID());
    *x =  loc.x*BSP_SCENE_SCALE_INV;
    *y = -loc.z*BSP_SCENE_SCALE_INV;
    *z =  loc.y*BSP_SCENE_SCALE_INV;
    return 1;
  }
  if(arena->getPlayIndex() != ID_PLAY_SOCCER)
    return 0;
  int counter = 0;
  for(int ct = 0; ct < arena->getTeamsCount(); ct++) {
    if(ct != bot->getTeamID()) {
      if((++counter) == param[1]) {
        BSPVector& loc = arena->getCorner(ct);
        *x =  loc.x*BSP_SCENE_SCALE_INV;
        *y = -loc.z*BSP_SCENE_SCALE_INV;
        *z =  loc.y*BSP_SCENE_SCALE_INV;
        return 1;
      }
    }
  }
  return 0;
}
// float:getGoalSize();
static cell AMX_NATIVE_CALL getGoalSize(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTArena::GOAL_SIZE);
}
// float:getTargetSize();
static cell AMX_NATIVE_CALL getTargetSize(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTTarget::SIZE);
}
// float:getTargetMaxSpeed();
static cell AMX_NATIVE_CALL getTargetMaxSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTTarget::MAX_SPEED);
}
// int:getTicksCount();
static cell AMX_NATIVE_CALL getTicksCount(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getTicksCount()-amx_timer;
}
// float:getTime();
static cell AMX_NATIVE_CALL getTime(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTArena::get()->getRealTime());
}
// float:getSimulationStep();
static cell AMX_NATIVE_CALL getSimulationStep(AMX *amx, cell *param) {
  amx;param; return SLInterpreter::float2Cell(GTBotBrain::SIMULATION_TIME_STEP);
}
// float:getCPUPeriod();
static cell AMX_NATIVE_CALL getCPUPeriod(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(1.0f/GTBotBrain::CPU_FREQUENCY);
}
// float:getTimeNeededFor(int:action);
static cell AMX_NATIVE_CALL getTimeNeededFor(AMX *amx, cell *param) {amx;param;
  switch(param[1]) {
    case ID_ACTION_MOVE: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_MOVE);
    case ID_ACTION_DROP: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_DROP);
    case ID_ACTION_SHOOT: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SHOOT);
    case ID_ACTION_SAY: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SAY);
    case ID_ACTION_SPEAK: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SPEAK);
    default: return SLInterpreter::float2Cell(0);
  }
}
// float:getTimeForRespawn(int:item);
static cell AMX_NATIVE_CALL getTimeForRespawn(AMX *amx, cell *param) {
  amx;param;
  switch(param[1]) {
    case ID_ITEM_MEDIKIT:
      return SLInterpreter::float2Cell(GTPowerup::MEDIKIT_RESPAWN_TIME);
    case ID_ITEM_FOOD:
      return SLInterpreter::float2Cell(GTPowerup::FOOD_RESPAWN_TIME);
    case ID_ITEM_ARMOR:
      return SLInterpreter::float2Cell(GTPowerup::ARMOR_RESPAWN_TIME);
    case ID_ITEM_BULLETS:
      return SLInterpreter::float2Cell(GTPowerup::BULLETS_RESPAWN_TIME);
    case ID_ITEM_GRENADES:
      return SLInterpreter::float2Cell(GTPowerup::GRENADES_RESPAWN_TIME);
  }
  return SLInterpreter::float2Cell(-1);
}
// float:getTimeLostTo(int:action);
static cell AMX_NATIVE_CALL getTimeLostTo(AMX *amx, cell *param) {amx;param;
  switch(param[1]) {
    case ID_ACTION_HEAR: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_HEAR);
    case ID_ACTION_SIGHT: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_SIGHT);
    case ID_ACTION_AIM: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_AIM);
    case ID_ACTION_WATCH: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_WATCH);
    case ID_ACTION_LISTEN: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_LISTEN);
    default: return SLInterpreter::float2Cell(0);
  }
}
// int:getMemorySize();
static cell AMX_NATIVE_CALL getMemorySize(AMX *amx, cell *param) {amx;param;
  return GTBotBrain::MEMORY_SIZE;
}
// int:getID();
static cell AMX_NATIVE_CALL getID(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getMateID();
}
// getLocation(&float:x,&float:y,&float:z);
static cell AMX_NATIVE_CALL getLocation(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  float* x;
  amx_GetAddr(amx,param[1],&(cell*)x);
  float* y;
  amx_GetAddr(amx,param[2],&(cell*)y);
  float* z;
  amx_GetAddr(amx,param[3],&(cell*)z);
  *x =  bot->getX()*BSP_SCENE_SCALE_INV;
  *y = -bot->getZ()*BSP_SCENE_SCALE_INV;
  *z =  bot->getY()*BSP_SCENE_SCALE_INV;
  return 0;
}
// float:getSize();
static cell AMX_NATIVE_CALL getSize(AMX *amx, cell *param) {
  amx;param; return SLInterpreter::float2Cell(2*GTBot::SIZE_X*BSP_SCENE_SCALE_INV);
}
// float:getHeight();
static cell AMX_NATIVE_CALL getHeight(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  return SLInterpreter::float2Cell(2*bot->getHalfHeight()*BSP_SCENE_SCALE_INV);
}
// float:getGunHeight();
static cell AMX_NATIVE_CALL getGunHeight(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  return SLInterpreter::float2Cell(bot->getWeaponY()*BSP_SCENE_SCALE_INV);
}
// float:getGunLength();
static cell AMX_NATIVE_CALL getGunLength(AMX *amx, cell *param) {
  amx;param; return SLInterpreter::float2Cell(GTWeapon::LENGTH*BSP_SCENE_SCALE_INV);
}
// bool:stand();
static cell AMX_NATIVE_CALL stand(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::IDLE)? 1: 0;
}
// bool:crouch();
static cell AMX_NATIVE_CALL crouch(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::IDLECR)? 1: 0;
}
// bool:walk();
static cell AMX_NATIVE_CALL walk(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::WALK)? 1: 0;
}
// bool:walkcr();
static cell AMX_NATIVE_CALL walkcr(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::WALKCR)? 1: 0;
}
// bool:walkbk();
static cell AMX_NATIVE_CALL walkbk(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::WALKBK)? 1: 0;
}
// bool:run();
static cell AMX_NATIVE_CALL run(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->setLegsAttitude(GTBot::RUN)? 1: 0;
}
// bool:isStanding();
static cell AMX_NATIVE_CALL isStanding(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::IDLE? 1: 0;
}
// bool:isCrouched();
static cell AMX_NATIVE_CALL isCrouched(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::IDLECR? 1: 0;
}
// bool:isWalking();
static cell AMX_NATIVE_CALL isWalking(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::WALK? 1: 0;
}
// bool:isWalkingcr();
static cell AMX_NATIVE_CALL isWalkingcr(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::WALKCR? 1: 0;
}
// bool:isWalkingbk();
static cell AMX_NATIVE_CALL isWalkingbk(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::WALKBK? 1: 0;
}
// bool:isRunning();
static cell AMX_NATIVE_CALL isRunning(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getLegsAttitude() == GTBot::RUN? 1: 0;
}
// bool:rotate(float:angle);
static cell AMX_NATIVE_CALL rotate(AMX *amx, cell *param) {amx;param;
  GTBot::getCurrentBot()->getLegsAngle().setRequired(SLInterpreter::cell2Float(param[1]));
  return 1;
}
// bool:isRotating();
static cell AMX_NATIVE_CALL isRotating(AMX *amx, cell *param) {amx;param;
  return
    (GTBot::getCurrentBot()->getLegsAngle().getRequired() !=
    GTBot::getCurrentBot()->getLegsAngle().getCurrent())? 1: 0;
}
// bool:rotateTorso(float:angle);
static cell AMX_NATIVE_CALL rotateTorso(AMX *amx, cell *param) {amx;param;
  float angle = SLInterpreter::cell2Float(param[1]);
  if(angle > GTBot::TORSO_YAW_MAX)
    angle = GTBot::TORSO_YAW_MAX;
  else if(angle < GTBot::TORSO_YAW_MIN)
    angle = GTBot::TORSO_YAW_MIN;
  GTBot::getCurrentBot()->getTorsoAngles().getYaw().setRequired(angle);
  return 1;
}
// bool:isTorsoRotating();
static cell AMX_NATIVE_CALL isTorsoRotating(AMX *amx, cell *param) {amx;param;
  return
    (GTBot::getCurrentBot()->getTorsoAngles().getYaw().getRequired() !=
    GTBot::getCurrentBot()->getTorsoAngles().getYaw().getCurrent())? 1: 0;
}
// bool:rotateHead(float:angle);
static cell AMX_NATIVE_CALL rotateHead(AMX *amx, cell *param) {amx;param;
  float angle = SLInterpreter::cell2Float(param[1]);
  if(angle > GTBot::HEAD_YAW_MAX)
    angle = GTBot::HEAD_YAW_MAX;
  else if(angle < GTBot::HEAD_YAW_MIN)
    angle = GTBot::HEAD_YAW_MIN;
  GTBot::getCurrentBot()->getHeadAngles().getYaw().setRequired(angle);
  return 1;
}
// bool:isHeadRotating();
static cell AMX_NATIVE_CALL isHeadRotating(AMX *amx, cell *param) {amx;param;
  return
    (GTBot::getCurrentBot()->getHeadAngles().getYaw().getRequired() !=
    GTBot::getCurrentBot()->getHeadAngles().getYaw().getCurrent())? 1: 0;
}
// bool:bendTorso(float:angle);
static cell AMX_NATIVE_CALL bendTorso(AMX *amx, cell *param) {amx;param;
  float angle = SLInterpreter::cell2Float(param[1]);
  if(angle > GTBot::TORSO_PITCH_MAX)
    angle = GTBot::TORSO_PITCH_MAX;
  else if(angle < GTBot::TORSO_PITCH_MIN)
    angle = GTBot::TORSO_PITCH_MIN;
  GTBot::getCurrentBot()->getTorsoAngles().getPitch().setRequired(angle);
  return 1;
}
// bool:isTorsoBending();
static cell AMX_NATIVE_CALL isTorsoBending(AMX *amx, cell *param) {amx;param;
  return
    (GTBot::getCurrentBot()->getTorsoAngles().getPitch().getRequired() !=
    GTBot::getCurrentBot()->getTorsoAngles().getPitch().getCurrent())? 1: 0;
}
// bool:bendHead(float:angle);
static cell AMX_NATIVE_CALL bendHead(AMX *amx, cell *param) {amx;param;
  float angle = SLInterpreter::cell2Float(param[1]);
  if(angle > GTBot::HEAD_PITCH_MAX)
    angle = GTBot::HEAD_PITCH_MAX;
  else if(angle < GTBot::HEAD_PITCH_MIN)
    angle = GTBot::HEAD_PITCH_MIN;
  GTBot::getCurrentBot()->getHeadAngles().getPitch().setRequired(angle);
  return 1;
}
// bool:isHeadBending();
static cell AMX_NATIVE_CALL isHeadBending(AMX *amx, cell *param) {amx;param;
  return
    (GTBot::getCurrentBot()->getHeadAngles().getPitch().getRequired() !=
    GTBot::getCurrentBot()->getHeadAngles().getPitch().getCurrent())? 1: 0;
}
// bool:wait(float:time);
static cell AMX_NATIVE_CALL wait(AMX *amx, cell *param) {amx;param;
  float time = SLInterpreter::cell2Float(param[1]);
  if(time < 0) time = 0;
  GTBot::decreaseTimer(int(time*GTBotBrain::CPU_FREQUENCY+0.5f));
  return 1;
}
// bool:say(int:word);
bool GTBot::say(int word) {
  if(isTalking())
    return false;
  setSpeakingOnRadio(false);
  setTalkingAbout(word);
  setTalkingCountdown(GTBot::TIME_NEEDED_TO_SAY);
  return true;
}

static cell AMX_NATIVE_CALL say(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->say(param[1]);
}
// bool:speak(int:channel,int:word);
static cell AMX_NATIVE_CALL speak(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  if(bot->isTalking())
    return 0;
  GTBot::getCurrentBot()->setTalkingAbout(param[2]);
  GTArena* arena = GTArena::get();
  for(int ct = 0; ct < arena->getBotsSize(); ct++) {
    GTBot* otherBot = arena->getBot(ct);
    if(
      otherBot != bot &&
      otherBot->isTalking() &&
      otherBot->isSpeakingOnRadio() &&
      otherBot->getSpeakingChannel() == param[1]
    )
      return 0;
  }
  GTBot::getCurrentBot()->setSpeakingOnRadio(true);
  GTBot::getCurrentBot()->setSpeakingChannel(param[1]);
  GTBot::getCurrentBot()->setTalkingCountdown(GTBot::TIME_NEEDED_TO_SPEAK);
  return 1;
}
// bool:listen(int:channel,&int:word,&int:id);
static cell AMX_NATIVE_CALL listen(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  GTBot::decreaseTimer(
    int(GTBot::TIME_LOST_TO_LISTEN*GTBotBrain::CPU_FREQUENCY+0.5f)
  );
  cell*  pWord;
  amx_GetAddr(amx,param[2],&pWord);
  cell*  pID;
  amx_GetAddr(amx,param[3],&pID);
  for(int ct = 0; ct < GTArena::get()->getBotsSize(); ct++) {
    GTBot* otherBot = GTArena::get()->getBot(ct);
    if(
      otherBot->isTalking() &&
      otherBot->isSpeakingOnRadio() &&
      otherBot->getSpeakingChannel() == param[1]
    ) {
      *pWord = otherBot->getTalkingAbout();
      bool isFriend = bot->getTeamID() == otherBot->getTeamID();
      *pID = isFriend? otherBot->getMateID(): (otherBot->getMateID()+
        GTArena::get()->getMatesCount()*otherBot->getTeamID()+
        GTArena::get()->getRandomSeed()
      );
      return 1;
    }
  }
  *pWord = 0;
  *pID = 0;
  return 0;
}
// float:hear(&int:item,&int:sound,&float:yaw,&float:pitch,&int:id);
static cell AMX_NATIVE_CALL hear(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  GTBot::decreaseTimer(
    int(GTBot::TIME_LOST_TO_HEAR*GTBotBrain::CPU_FREQUENCY+0.5f)
  );
  cell*  pItem;
  amx_GetAddr(amx,param[1],&pItem);
  cell*  pSound;
  amx_GetAddr(amx,param[2],&pSound);
  float* pYaw;
  amx_GetAddr(amx,param[3],&(cell*)pYaw);
  float* pPitch;
  amx_GetAddr(amx,param[4],&(cell*)pPitch);
  cell*  pID;
  amx_GetAddr(amx,param[5],&pID);
  const bool FILTER_GRENADES = (*pItem & ID_ITEM_GRENADE) != 0;
  const bool FILTER_WEAPONS = (*pItem & ID_ITEM_WEAPON) != 0;
  if(bot->isShotHeard() && !FILTER_GRENADES) {
    *pItem = ID_ITEM_WEAPON|ID_ITEM_FRIEND;
    *pSound = ID_SOUND_SHOT;
    *pYaw = 0;
    *pPitch = -M_PI/2;
    *pID = 0;
    return SLInterpreter::float2Cell((GTBot::SIZE_Y-GTWeapon::HEIGHT)*BSP_SCENE_SCALE_INV);
  }
  if(bot->isSaying() && !FILTER_WEAPONS && !FILTER_GRENADES) {
    *pItem = ID_ITEM_WARRIOR|ID_ITEM_FRIEND;
    *pSound = bot->getTalkingAbout();
    *pYaw = 0;
    *pPitch = 0;
    *pID = bot->getMateID();
    return SLInterpreter::float2Cell(0);
  }
  GTItems& items = GTArena::get()->getItems();
  int botIndex;
  for(botIndex = 0; botIndex < items.getSize(); botIndex++)
    if(items.getElement(botIndex) == bot)
      break;
  GLBsp* bsp = GTArena::get()->getBsp();
	int botCluster =
    bsp->leaves[bsp->findLeaf(bot->getX(),bot->getY(),bot->getZ())].cluster;
  int heardIndex = -1;
  float dist2 = GTBot::SENSORS_DISTANCE_MAX*GTBot::SENSORS_DISTANCE_MAX;
  float distX, distY, distZ;
  for(int ct = botIndex-1; ct >= 0; ct--) {
    GTItem* otherItem = items.getElement(ct);
    switch(otherItem->getClassID()) {
      case ID_ITEM_WARRIOR: {
        if(FILTER_GRENADES)
          continue;
        GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
        if(
          otherBot->isDead() ||
          ((!otherBot->isSaying()) && (!otherBot->isShotHeard()))
        )
          continue;
        if(otherBot->isSaying() && FILTER_WEAPONS)
          continue;
        float otherDistX = otherBot->getX()-bot->getX();
        float otherDist2 = otherDistX*otherDistX;
        if(otherDist2 > dist2) {
          ct = -1;
          continue;
        }
        if(
          !bsp->isClusterVisible(
            botCluster,
            bsp->leaves[
              bsp->findLeaf(otherBot->getX(),otherBot->getY(),otherBot->getZ())
            ].cluster
          )
        )
          continue;
        float otherDistZ = otherBot->getZ()-bot->getZ();
        otherDist2 += otherDistZ*otherDistZ;
        float otherDistY = (otherBot->isShotHeard()?
          otherBot->getWeaponY(): otherBot->getEyeY()
        )-bot->getEyeY();
        otherDist2 += otherDistY*otherDistY;
        if(otherDist2 < dist2) {
          dist2 = otherDist2;
          distX = otherDistX;
          distY = otherDistY;
          distZ = otherDistZ;
          heardIndex = ct;
        }
        continue;
      }
      case ID_ITEM_GRENADE: {
        GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
        if(!grenade->isExploded())
          continue;
        float otherDistX = grenade->getX()-bot->getX();
        float otherDist2 = otherDistX*otherDistX;
        if(otherDist2 > dist2) {
          ct = -1;
          continue;
        }
        if(
          !bsp->isClusterVisible(
            botCluster,
            bsp->leaves[
              bsp->findLeaf(grenade->getX(),grenade->getY(),grenade->getZ())
            ].cluster
          )
        )
          continue;
        float otherDistZ = grenade->getZ()-bot->getZ();
        otherDist2 += otherDistZ*otherDistZ;
        float otherDistY = grenade->getY()-bot->getEyeY();
        otherDist2 += otherDistY*otherDistY;
        if(otherDist2 < dist2) {
          dist2 = otherDist2;
          distX = otherDistX;
          distY = otherDistY;
          distZ = otherDistZ;
          heardIndex = ct;
        }
        continue;
      }
    }
  }
  for(int ct = botIndex+1; ct < items.getSize(); ct++) {
    GTItem* otherItem = items.getElement(ct);
    switch(otherItem->getClassID()) {
      case ID_ITEM_WARRIOR: {
        if(FILTER_GRENADES)
          continue;
        GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
        if(
          otherBot->isDead() ||
          ((!otherBot->isSaying()) && (!otherBot->isShotHeard()))
        )
          continue;
        if(otherBot->isSaying() && FILTER_WEAPONS)
          continue;
        float otherDistX = otherBot->getX()-bot->getX();
        float otherDist2 = otherDistX*otherDistX;
        if(otherDist2 > dist2) {
          ct = items.getSize();
          continue;
        }
        if(
          !bsp->isClusterVisible(
            botCluster,
            bsp->leaves[
              bsp->findLeaf(otherBot->getX(),otherBot->getY(),otherBot->getZ())
            ].cluster
          )
        )
          continue;
        float otherDistZ = otherBot->getZ()-bot->getZ();
        otherDist2 += otherDistZ*otherDistZ;
        float otherDistY = (otherBot->isShotHeard()?
          otherBot->getWeaponY(): otherBot->getEyeY()
        )-bot->getEyeY();
        otherDist2 += otherDistY*otherDistY;
        if(otherDist2 < dist2) {
          dist2 = otherDist2;
          distX = otherDistX;
          distY = otherDistY;
          distZ = otherDistZ;
          heardIndex = ct;
        }
        continue;
      }
      case ID_ITEM_GRENADE: {
        GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
        if(!grenade->isExploded())
          continue;
        float otherDistX = grenade->getX()-bot->getX();
        float otherDist2 = otherDistX*otherDistX;
        if(otherDist2 > dist2) {
          ct =items.getSize();
          continue;
        }
        if(
          !bsp->isClusterVisible(
            botCluster,
            bsp->leaves[
              bsp->findLeaf(grenade->getX(),grenade->getY(),grenade->getZ())
            ].cluster
          )
        )
          continue;
        float otherDistZ = grenade->getZ()-bot->getZ();
        otherDist2 += otherDistZ*otherDistZ;
        float otherDistY = grenade->getY()-bot->getEyeY();
        otherDist2 += otherDistY*otherDistY;
        if(otherDist2 < dist2) {
          dist2 = otherDist2;
          distX = otherDistX;
          distY = otherDistY;
          distZ = otherDistZ;
          heardIndex = ct;
        }
        continue;
      }
    }
  }
  if(heardIndex < 0) {
    *pItem = ID_ITEM_NONE;
    *pSound = ID_SOUND_NONE;
    *pYaw = 0;
    *pPitch = 0;
    *pID = 0;
    return SLInterpreter::float2Cell(0);
  }
  switch(items.getElement(heardIndex)->getClassID()) {
    case ID_ITEM_WARRIOR: {
      GTBot* otherBot = dynamic_cast<GTBot*>(items.getElement(heardIndex));
      bool isFriend = bot->getTeamID() == otherBot->getTeamID();
      if(otherBot->isShotHeard()) {
        *pItem = ID_ITEM_WEAPON | (isFriend? ID_ITEM_FRIEND: ID_ITEM_ENEMY);
        *pSound = ID_SOUND_SHOT;
        *pID = 0;
      } else {
        *pItem = ID_ITEM_WARRIOR | (isFriend? ID_ITEM_FRIEND: ID_ITEM_ENEMY);
        *pSound = otherBot->getTalkingAbout();
        *pID = isFriend? otherBot->getMateID(): (otherBot->getMateID()+
          GTArena::get()->getMatesCount()*otherBot->getTeamID()+
          GTArena::get()->getRandomSeed()
        );
      }
      break;
    }
    case ID_ITEM_GRENADE: {
      GTGrenade* grenade = dynamic_cast<GTGrenade*>(items.getElement(heardIndex));
      *pItem = ID_ITEM_GRENADE |
        (bot->getTeamID() == grenade->getTeamID()? ID_ITEM_FRIEND: ID_ITEM_ENEMY);
      *pSound = ID_SOUND_BOOM;
      *pID = 0;
      break;
    }
    default: {
      *pItem = ID_ITEM_NONE;
      *pSound = ID_SOUND_NONE;
      *pID = 0;
      break;
    }
  }
  float distXZ = float(sqrt(distX*distX+distZ*distZ));
  float botYaw =
    bot->getLegsAngle().getCurrent()+
    bot->getTorsoAngles().getYaw().getCurrent()+
    bot->getHeadAngles().getYaw().getCurrent();
  float botPitch =
    bot->getTorsoAngles().getPitch().getCurrent()+
    bot->getHeadAngles().getPitch().getCurrent();
  float cosBotPitch = float(cos(botPitch));
  float viewX = cosBotPitch*float(cos(botYaw));
  float viewY = float(sin(botPitch));
  float viewZ = -cosBotPitch*float(sin(botYaw));
  float viewXZ = float(sqrt(viewX*viewX+viewZ*viewZ));
  float arg = (viewX*distX+viewZ*distZ)/(viewXZ*distXZ);
  if(fabs(arg) > 1)
    arg = arg > 0? 1: -1;
  *pYaw = float(acos(arg));
  if(viewX*distZ-viewZ*distX > 0)
    *pYaw = -*pYaw;
  float dist = float(sqrt(dist2));
  arg = (viewXZ*distXZ+viewY*distY)/dist;
  if(fabs(arg) > 1)
    arg = arg > 0? 1: -1;
  *pPitch = float(acos(arg));
  if(viewXZ*distY-viewY*distXZ < 0)
    *pPitch = -*pPitch;
  return SLInterpreter::float2Cell(dist*BSP_SCENE_SCALE_INV);
}
// float:getMaxKickSpeed();
static cell AMX_NATIVE_CALL getMaxKickSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::KICK_SPEED_MAX);
}
// float:getKickSpeed();
static cell AMX_NATIVE_CALL getKickSpeed(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  return SLInterpreter::float2Cell(bot->getKickSpeed());
}
// float:setKickSpeed(float:speed);
static cell AMX_NATIVE_CALL setKickSpeed(AMX *amx, cell *param) {amx;param;
  float speed = SLInterpreter::cell2Float(param[1]);
  if(speed < 0)
    speed = 0;
  else if(speed > GTBot::KICK_SPEED_MAX)
    speed = GTBot::KICK_SPEED_MAX;
  GTBot::getCurrentBot()->setKickSpeed(speed);
  return SLInterpreter::float2Cell(speed);
}
// float:getWalkSpeed();
static cell AMX_NATIVE_CALL getWalkSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::SPEED_WALK);
}
// float:getWalkcrSpeed();
static cell AMX_NATIVE_CALL getWalkcrSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::SPEED_WALKCR);
}
// float:getWalkbkSpeed();
static cell AMX_NATIVE_CALL getWalkbkSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::SPEED_WALKBK);
}
// float:getRunSpeed();
static cell AMX_NATIVE_CALL getRunSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::SPEED_RUN);
}
// float:getFallMaxSpeed();
static cell AMX_NATIVE_CALL getFallMaxSpeed(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::SPEED_VERTICAL_MAX);
}
// int:watch(&int:item,&float:dist,&float:yaw,&float:pitch,&int:id);
static cell AMX_NATIVE_CALL watch(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  GTBot::decreaseTimer(
    int(GTBot::TIME_LOST_TO_WATCH*GTBotBrain::CPU_FREQUENCY+0.5f)
  );
  cell*  pItem;
  amx_GetAddr(amx,param[1],&pItem);
  float* pDist;
  amx_GetAddr(amx,param[2],&(cell*)pDist);
  *pDist *= BSP_SCENE_SCALE;
  float* pYaw;
  amx_GetAddr(amx,param[3],&(cell*)pYaw);
  float* pPitch;
  amx_GetAddr(amx,param[4],&(cell*)pPitch);
  cell*  pID;
  amx_GetAddr(amx,param[5],&pID);
  GTItems& items = GTArena::get()->getItems();
  int botIndex;
  for(botIndex = 0; botIndex < items.getSize(); botIndex++)
    if(items.getElement(botIndex) == bot)
      break;
  GLBsp* bsp = GTArena::get()->getBsp();
	int botCluster =
    bsp->leaves[bsp->findLeaf(bot->getX(),bot->getY(),bot->getZ())].cluster;
  float botYaw = bot->getLegsAngle().getCurrent()+
    bot->getTorsoAngles().getYaw().getCurrent()+
    bot->getHeadAngles().getYaw().getCurrent();
  float botPitch = bot->getTorsoAngles().getPitch().getCurrent()+
    bot->getHeadAngles().getPitch().getCurrent();
  float cosBotPitch = float(cos(botPitch));
  float viewX = cosBotPitch*float(cos(botYaw));
  float viewY = float(sin(botPitch));
  float viewZ = -cosBotPitch*float(sin(botYaw));
  float viewXZ = float(sqrt(viewX*viewX+viewZ*viewZ));
  int watchedIndex = -1;
  float watchedDist;
  float watchedYaw;
  float watchedPitch;
  float dist2 = GTBot::SENSORS_DISTANCE_MAX*GTBot::SENSORS_DISTANCE_MAX;
  for(int ct = botIndex-1; ct >= 0; ct--) {
    GTItem* otherItem = items.getElement(ct);
    switch(otherItem->getClassID()) {
      case ID_ITEM_WARRIOR: {
        GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
        if(otherBot->isDead() || ((*pItem & ID_ITEM_WARRIOR) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == otherBot->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_BULLET: {
        GTBullet* bullet = dynamic_cast<GTBullet*>(otherItem);
        if(bullet->isExhausted() || ((*pItem & ID_ITEM_BULLET) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == bullet->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_GRENADE: {
        GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
        if(grenade->isExhausted() || ((*pItem & ID_ITEM_GRENADE) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == grenade->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_MEDIKIT:
      case ID_ITEM_FOOD:
      case ID_ITEM_ARMOR:
      case ID_ITEM_BULLETS:
      case ID_ITEM_GRENADES:
      {
        GTPowerup* p = dynamic_cast<GTPowerup*>(otherItem);
        if(
          p->isExhausted() ||
          ((*pItem & otherItem->getClassID()) == 0) ||
          !p->isActive()
        )
          continue;
        break;
      }
      case ID_ITEM_WEAPON:
      case ID_ITEM_TARGET:
      case ID_ITEM_SIGN:
      {
        GTExhaustable* p = dynamic_cast<GTExhaustable*>(otherItem);
        if(p->isExhausted() || ((*pItem & otherItem->getClassID()) == 0))
          continue;
        break;
      }
      default:
        continue;
    }
    float otherDistX = otherItem->getX()-bot->getX();
    float otherDistX2 = otherDistX*otherDistX;
    if(otherDistX2 > dist2)
      break;
    float otherDistZ = otherItem->getZ()-bot->getZ();
    float otherDistZ2 = otherDistZ*otherDistZ;
    float otherDistY = (otherItem->getClassID() == ID_ITEM_WARRIOR?
      dynamic_cast<GTBot*>(otherItem)->getEyeY(): otherItem->getY()
    )-bot->getEyeY();
    float otherDistY2 = otherDistY*otherDistY;
    float otherDist2 = otherDistX2+otherDistY2+otherDistZ2;
    if((otherDist2 > dist2) || (otherDist2 < (*pDist)*(*pDist)))
      continue;
    if(
      !bsp->isClusterVisible(
        botCluster,
        bsp->leaves[
          bsp->findLeaf(otherItem->getX(),otherItem->getY(),otherItem->getZ())
        ].cluster
      )
    )
      continue;
    float viewDistX = viewX*otherDistX;
    float viewDistY = viewY*otherDistY;
    float viewDistZ = viewZ*otherDistZ;
    if(viewDistX+viewDistY+viewDistZ <= 0)
      continue;
    float otherDistXZ = float(sqrt(otherDistX2+otherDistZ2));
    float argYaw = (viewDistX+viewDistZ)/(viewXZ*otherDistXZ);
    if(argYaw < GTBot::HEAD_COS_ANGLE_OF_VIEW)
      continue;
    float otherDist = float(sqrt(otherDist2));
    float argPitch = (viewXZ*otherDistXZ+viewDistY)/otherDist;
    if(argPitch < GTBot::HEAD_COS_ANGLE_OF_VIEW)
      continue;
    if(fabs(argYaw) > 1)
      argYaw = argYaw > 0? 1: -1;
    float viewYaw = float(acos(argYaw));
    if(viewX*otherDistZ-viewZ*otherDistX > 0)
      viewYaw = -viewYaw;
    if(fabs(argPitch) > 1)
      argPitch = argPitch > 0? 1: -1;
    float viewPitch = float(acos(argPitch));
    if(viewXZ*otherDistY-viewY*otherDistXZ < 0)
      viewPitch = -viewPitch;
    BSPVector pos(bot->getX(),bot->getEyeY(),bot->getZ());
    BSPVector vel(otherDistX,otherDistY,otherDistZ);
    BSPVector endPos(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
    bsp->checkCollision(pos,vel);
    if((pos.x != endPos.x) || (pos.y != endPos.y) || (pos.z != endPos.z))
      continue;
    watchedIndex = ct;
    dist2 = otherDist2;
    watchedDist = otherDist;
    watchedYaw = viewYaw;
    watchedPitch = viewPitch;
  }
  for(int ct = botIndex+1; ct < items.getSize(); ct++) {
    GTItem* otherItem = items.getElement(ct);
    switch(otherItem->getClassID()) {
      case ID_ITEM_WARRIOR: {
        GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
        if(otherBot->isDead() || ((*pItem & ID_ITEM_WARRIOR) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == otherBot->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_BULLET: {
        GTBullet* bullet = dynamic_cast<GTBullet*>(otherItem);
        if(bullet->isExhausted() || ((*pItem & ID_ITEM_BULLET) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == bullet->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_GRENADE: {
        GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
        if(grenade->isExhausted() || ((*pItem & ID_ITEM_GRENADE) == 0))
          continue;
        bool isTeamMate = (bot->getTeamID() == grenade->getTeamID());
        if(isTeamMate) {
          if((*pItem & ID_ITEM_FRIEND) == 0)
            continue;
        } else {
          if((*pItem & ID_ITEM_ENEMY) == 0)
            continue;
        }
        break;
      }
      case ID_ITEM_MEDIKIT:
      case ID_ITEM_FOOD:
      case ID_ITEM_ARMOR:
      case ID_ITEM_BULLETS:
      case ID_ITEM_GRENADES:
      {
        GTPowerup* p = dynamic_cast<GTPowerup*>(otherItem);
        if(
          p->isExhausted() ||
          ((*pItem & otherItem->getClassID()) == 0) ||
          !p->isActive()
        )
          continue;
        break;
      }
      case ID_ITEM_WEAPON:
      case ID_ITEM_TARGET:
      case ID_ITEM_SIGN:
      {
        GTExhaustable* p = dynamic_cast<GTExhaustable*>(otherItem);
        if(p->isExhausted() || ((*pItem & otherItem->getClassID()) == 0))
          continue;
        break;
      }
      default:
        continue;
    }
    float otherDistX = otherItem->getX()-bot->getX();
    float otherDistX2 = otherDistX*otherDistX;
    if(otherDistX2 > dist2)
      break;
    float otherDistZ = otherItem->getZ()-bot->getZ();
    float otherDistZ2 = otherDistZ*otherDistZ;
    float otherDistY = (otherItem->getClassID() == ID_ITEM_WARRIOR?
      dynamic_cast<GTBot*>(otherItem)->getEyeY(): otherItem->getY()
    )-bot->getEyeY();
    float otherDistY2 = otherDistY*otherDistY;
    float otherDist2 = otherDistX2+otherDistY2+otherDistZ2;
    if((otherDist2 > dist2) || (otherDist2 < (*pDist)*(*pDist)))
      continue;
    if(
      !bsp->isClusterVisible(
        botCluster,
        bsp->leaves[
          bsp->findLeaf(otherItem->getX(),otherItem->getY(),otherItem->getZ())
        ].cluster
      )
    )
      continue;
    float viewDistX = viewX*otherDistX;
    float viewDistY = viewY*otherDistY;
    float viewDistZ = viewZ*otherDistZ;
    if(viewDistX+viewDistY+viewDistZ <= 0)
      continue;
    float otherDistXZ = float(sqrt(otherDistX2+otherDistZ2));
    float argYaw = (viewDistX+viewDistZ)/(viewXZ*otherDistXZ);
    if(argYaw < GTBot::HEAD_COS_ANGLE_OF_VIEW)
      continue;
    float otherDist = float(sqrt(otherDist2));
    float argPitch = (viewXZ*otherDistXZ+viewDistY)/otherDist;
    if(argPitch < GTBot::HEAD_COS_ANGLE_OF_VIEW)
      continue;
    if(fabs(argYaw) > 1)
      argYaw = argYaw > 0? 1: -1;
    float viewYaw = float(acos(argYaw));
    if(viewX*otherDistZ-viewZ*otherDistX > 0)
      viewYaw = -viewYaw;
    if(fabs(argPitch) > 1)
      argPitch = argPitch > 0? 1: -1;
    float viewPitch = float(acos(argPitch));
    if(viewXZ*otherDistY-viewY*otherDistXZ < 0)
      viewPitch = -viewPitch;
    BSPVector pos(bot->getX(),bot->getEyeY(),bot->getZ());
    BSPVector vel(otherDistX,otherDistY,otherDistZ);
    BSPVector endPos(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
    bsp->checkCollision(pos,vel);
    if((pos.x != endPos.x) || (pos.y != endPos.y) || (pos.z != endPos.z))
      continue;
    watchedIndex = ct;
    dist2 = otherDist2;
    watchedDist = otherDist;
    watchedYaw = viewYaw;
    watchedPitch = viewPitch;
  }
  if(watchedIndex < 0) {
    *pItem = ID_ITEM_NONE;
    *pDist = GTBot::SENSORS_DISTANCE_MAX*BSP_SCENE_SCALE_INV;
    *pYaw = 0;
    *pPitch = 0;
    *pID = 0;
    return ID_ATTRIBUTE_NONE;
  }
  GTItem* theItem = items.getElement(watchedIndex);
  *pDist = watchedDist*BSP_SCENE_SCALE_INV;
  *pYaw = watchedYaw;
  *pPitch = watchedPitch;
  switch(theItem->getClassID()) {
    case ID_ITEM_WARRIOR: {
      GTBot* otherBot = dynamic_cast<GTBot*>(theItem);
      bool isFriend = bot->getTeamID() == otherBot->getTeamID();
      *pItem = ID_ITEM_WARRIOR | (isFriend? ID_ITEM_FRIEND: ID_ITEM_ENEMY);
      *pID = isFriend? otherBot->getMateID(): (otherBot->getMateID()+
        GTArena::get()->getMatesCount()*otherBot->getTeamID()+
        GTArena::get()->getRandomSeed()
      );
      if(otherBot->hasWeapon()) return ID_ATTRIBUTE_HAS_WEAPON;
      if(otherBot->hasSign()) return ID_ATTRIBUTE_HAS_SIGN;
      return ID_ATTRIBUTE_NONE;
    }
    case ID_ITEM_BULLET: {
      GTBullet* theBullet = dynamic_cast<GTBullet*>(theItem);
      *pItem = ID_ITEM_BULLET | (
        bot->getTeamID() == theBullet->getTeamID()? ID_ITEM_FRIEND: ID_ITEM_ENEMY
      );
      *pID = 0;
      return ID_ATTRIBUTE_NONE;
    }
    case ID_ITEM_GRENADE: {
      GTGrenade* theGrenade = dynamic_cast<GTGrenade*>(theItem);
      *pItem = ID_ITEM_GRENADE | (
        bot->getTeamID() == theGrenade->getTeamID()? ID_ITEM_FRIEND: ID_ITEM_ENEMY
      );
      *pID = 0;
      return ID_ATTRIBUTE_NONE;
    }
    case ID_ITEM_MEDIKIT:
    case ID_ITEM_FOOD:
    case ID_ITEM_ARMOR:
    case ID_ITEM_BULLETS:
    case ID_ITEM_GRENADES:
    case ID_ITEM_WEAPON:
    case ID_ITEM_TARGET:
    case ID_ITEM_SIGN:
    {
      *pItem = theItem->getClassID();
      *pID = 0;
      return ID_ATTRIBUTE_NONE;
    }
    default: {
      *pItem = ID_ITEM_NONE;
      *pID = 0;
      return ID_ATTRIBUTE_NONE;
    }
  }
}
// float:sight();
static cell AMX_NATIVE_CALL sight(AMX *amx, cell *param) {amx;param;
  GTBot::decreaseTimer(
    int(GTBot::TIME_LOST_TO_SIGHT*GTBotBrain::CPU_FREQUENCY+0.5f)
  );
  GLBsp* bsp = GTArena::get()->getBsp();
  GTBot* bot = GTBot::getCurrentBot();
  float yaw = bot->getLegsAngle().getCurrent()+
    bot->getTorsoAngles().getYaw().getCurrent()+
    bot->getHeadAngles().getYaw().getCurrent();
  float pitch = bot->getTorsoAngles().getPitch().getCurrent()+
    bot->getHeadAngles().getPitch().getCurrent();
  float cosPitch = cos(pitch);
  BSPVector pos(bot->getX(),bot->getEyeY(),bot->getZ());
  BSPVector vel(
     GTBot::SENSORS_DISTANCE_MAX*cosPitch*cos(yaw),
     GTBot::SENSORS_DISTANCE_MAX*sin(pitch),
    -GTBot::SENSORS_DISTANCE_MAX*cosPitch*sin(yaw)
  );
  bsp->checkCollision(pos,vel);
  float x = pos.x-bot->getX();
  float y = pos.y-bot->getEyeY();
  float z = pos.z-bot->getZ();
  return SLInterpreter::float2Cell(
    float((sqrt(x*x+y*y+z*z)*BSP_SCENE_SCALE_INV))
  );
}
// float:aim(&int:item);
static cell AMX_NATIVE_CALL aim(AMX *amx, cell *param) {amx;param;
  GTBot::decreaseTimer(
    int(GTBot::TIME_LOST_TO_AIM*GTBotBrain::CPU_FREQUENCY+0.5f)
  );
  cell* pItem;
  amx_GetAddr(amx,param[1],&pItem);
  GLBsp* bsp = GTArena::get()->getBsp();
  GTBot* bot = GTBot::getCurrentBot();
  float yaw = bot->getLegsAngle().getCurrent()+
    bot->getTorsoAngles().getYaw().getCurrent();
  float pitch = bot->getTorsoAngles().getPitch().getCurrent();
  BSPVector pos(bot->getX(),bot->getWeaponY(),bot->getZ());
  float cosPitch = cos(pitch);
  BSPVector view(cosPitch*cos(yaw),sin(pitch),-cosPitch*sin(yaw));
  BSPVector vel(
    GTBot::SENSORS_DISTANCE_MAX*view.x,
    GTBot::SENSORS_DISTANCE_MAX*view.y,
    GTBot::SENSORS_DISTANCE_MAX*view.z
  );
  bsp->checkCollision(pos,vel);
  float x = pos.x-bot->getX();
  float y = pos.y-bot->getWeaponY();
  float z = pos.z-bot->getZ();
  float maxDist2 = x*x+y*y+z*z;
  GTItems& items = GTArena::get()->getItems();
  int botIndex;
  for(botIndex = 0; botIndex < items.getSize(); botIndex++)
    if(items.getElement(botIndex) == bot)
      break;
	int botCluster =
    bsp->leaves[bsp->findLeaf(bot->getX(),bot->getY(),bot->getZ())].cluster;
  int aimedIndex = -1;
  for(int ct = botIndex-1; ct >= 0; ct--) {
    GTItem* otherItem = items.getElement(ct);
    if(otherItem->getClassID() != ID_ITEM_WARRIOR)
      continue;
    GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
    if(otherBot->isDead())
      continue;
    float otherDistX = otherBot->getX()-bot->getX();
    if(otherDistX*otherDistX > maxDist2)
      break;
    if(
      !bsp->isClusterVisible(
        botCluster,
        bsp->leaves[
          bsp->findLeaf(otherBot->getX(),otherBot->getY(),otherBot->getZ())
        ].cluster
      )
    )
      continue;
    float otherDistZ = otherBot->getZ()-bot->getZ();
    float otherDistY = otherBot->getCenterY()-bot->getWeaponY();
    bool done = false;
    float dist;
    if(view.x < 0) {
      dist = otherDistX+GTBot::SIZE_X;
      if(
        dist < 0 &&
        fabs(view.z*dist-view.x*otherDistZ) < -view.x*GTBot::SIZE_Z &&
        fabs(view.y*dist-view.x*otherDistY) < -view.x*(
          otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
        )
      ) {
        dist /= view.x;
        done = true;
      }
    } else if(view.x > 0) {
      dist = otherDistX-GTBot::SIZE_X;
      if(
        dist > 0 &&
        fabs(view.z*dist-view.x*otherDistZ) < view.x*GTBot::SIZE_Z &&
        fabs(view.y*dist-view.x*otherDistY) < view.x*(
          otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
        )
      ) {
        dist /= view.x;
        done = true;
      }
    }
    if(!done) {
      if(view.z < 0) {
        dist = otherDistZ+GTBot::SIZE_Z;
        if(
          dist < 0 &&
          fabs(view.x*dist-view.z*otherDistX) < -view.z*GTBot::SIZE_X &&
          fabs(view.y*dist-view.z*otherDistY) < -view.z*(
            otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
          )
        ) {
          dist /= view.z;
          done = true;
        }
      } else if(view.z > 0) {
        dist = otherDistZ-GTBot::SIZE_Z;
        if(
          dist > 0 &&
          fabs(view.x*dist-view.z*otherDistX) < view.z*GTBot::SIZE_X &&
          fabs(view.y*dist-view.z*otherDistY) < view.z*(
            otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
          )
        ) {
          dist /= view.z;
          done = true;
        }
      }
      if(!done) {
        if(view.y < 0) {
          dist = otherDistY+
            (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y);
          if(
            dist < 0 &&
            fabs(view.x*dist-view.y*otherDistX) < -view.y*GTBot::SIZE_X &&
            fabs(view.z*dist-view.y*otherDistZ) < -view.y*GTBot::SIZE_Z
          ) {
            dist /= view.y;
            done = true;
          }
        } else if(view.y > 0) {
            dist = otherDistY-
              (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y);
          if(
            dist > 0 &&
            fabs(view.x*dist-view.y*otherDistX) < view.y*GTBot::SIZE_X &&
            fabs(view.z*dist-view.y*otherDistZ) < view.y*GTBot::SIZE_Z
          ) {
            dist /= view.y;
            done = true;
          }
        }
      }
    }
    if(done && (dist *= dist) < maxDist2) {
      maxDist2 = dist;
      aimedIndex = ct;
    }
  }
  for(int ct = botIndex+1; ct < items.getSize(); ct++) {
    GTItem* otherItem = items.getElement(ct);
    if(otherItem->getClassID() != ID_ITEM_WARRIOR)
      continue;
    GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
    if(otherBot->isDead())
      continue;
    float otherDistX = otherBot->getX()-bot->getX();
    if(otherDistX*otherDistX > maxDist2)
      break;
    if(
      !bsp->isClusterVisible(
        botCluster,
        bsp->leaves[
          bsp->findLeaf(otherBot->getX(),otherBot->getY(),otherBot->getZ())
        ].cluster
      )
    )
      continue;
    float otherDistZ = otherBot->getZ()-bot->getZ();
    float otherDistY = otherBot->getCenterY()-bot->getWeaponY();
    bool done = false;
    float dist;
    if(view.x < 0) {
      dist = otherDistX+GTBot::SIZE_X;
      if(
        dist < 0 &&
        fabs(view.z*dist-view.x*otherDistZ) < -view.x*GTBot::SIZE_Z &&
        fabs(view.y*dist-view.x*otherDistY) < -view.x*(
          otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
        )
      ) {
        dist /= view.x;
        done = true;
      }
    } else if(view.x > 0) {
      dist = otherDistX-GTBot::SIZE_X;
      if(
        dist > 0 &&
        fabs(view.z*dist-view.x*otherDistZ) < view.x*GTBot::SIZE_Z &&
        fabs(view.y*dist-view.x*otherDistY) < view.x*(
          otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
        )
      ) {
        dist /= view.x;
        done = true;
      }
    }
    if(!done) {
      if(view.z < 0) {
        dist = otherDistZ+GTBot::SIZE_Z;
        if(
          dist < 0 &&
          fabs(view.x*dist-view.z*otherDistX) < -view.z*GTBot::SIZE_X &&
          fabs(view.y*dist-view.z*otherDistY) < -view.z*(
            otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
          )
        ) {
          dist /= view.z;
          done = true;
        }
      } else if(view.z > 0) {
        dist = otherDistZ-GTBot::SIZE_Z;
        if(
          dist > 0 &&
          fabs(view.x*dist-view.z*otherDistX) < view.z*GTBot::SIZE_X &&
          fabs(view.y*dist-view.z*otherDistY) < view.z*(
            otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y
          )
        ) {
          dist /= view.z;
          done = true;
        }
      }
      if(!done) {
        if(view.y < 0) {
          dist = otherDistY+
            (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y);
          if(
            dist < 0 &&
            fabs(view.x*dist-view.y*otherDistX) < -view.y*GTBot::SIZE_X &&
            fabs(view.z*dist-view.y*otherDistZ) < -view.y*GTBot::SIZE_Z
          ) {
            dist /= view.y;
            done = true;
          }
        } else if(view.y > 0) {
            dist = otherDistY-
              (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y);
          if(
            dist > 0 &&
            fabs(view.x*dist-view.y*otherDistX) < view.y*GTBot::SIZE_X &&
            fabs(view.z*dist-view.y*otherDistZ) < view.y*GTBot::SIZE_Z
          ) {
            dist /= view.y;
            done = true;
          }
        }
      }
    }
    if(done && (dist *= dist) < maxDist2) {
      maxDist2 = dist;
      aimedIndex = ct;
    }
  }
  if(aimedIndex < 0) {
    *pItem = ID_ITEM_NONE;
  } else {
    GTBot* otherBot = dynamic_cast<GTBot*>(items.getElement(aimedIndex));
    *pItem = ID_ITEM_WARRIOR |
      (bot->getTeamID() == otherBot->getTeamID()?
      ID_ITEM_FRIEND: ID_ITEM_ENEMY
    );
  }
  return SLInterpreter::float2Cell(float(sqrt(maxDist2))*BSP_SCENE_SCALE_INV);
}
// float:getEnergy();
static cell AMX_NATIVE_CALL getEnergy(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::getCurrentBot()->getEnergy());
}
// float:getMaxEnergy();
static cell AMX_NATIVE_CALL getMaxEnergy(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::ENERGY_MAX);}
// float:getRunEnergyLoss();
static cell AMX_NATIVE_CALL getRunEnergyLoss(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::ENERGY_RUN);}
// float:getStandEnergyGain();
static cell AMX_NATIVE_CALL getStandEnergyGain(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::ENERGY_STAND);}
// float:getHealth();
static cell AMX_NATIVE_CALL getHealth(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::getCurrentBot()->getHealth());
}
// float:getMaxHealth();
static cell AMX_NATIVE_CALL getMaxHealth(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEALTH_MAX);}
// float:getBulletHealthLoss();
static cell AMX_NATIVE_CALL getBulletHealthLoss(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEALTH_BULLET);}
// float:getGrenadeMaxDamage();
static cell AMX_NATIVE_CALL getGrenadeMaxDamage(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEALTH_GRENADE_MAX);}
// float:getArmor();
static cell AMX_NATIVE_CALL getArmor(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::getCurrentBot()->getArmor());
}
// float:getMaxArmor();
static cell AMX_NATIVE_CALL getMaxArmor(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::ARMOR_MAX);}
// int:getOwned();
static cell AMX_NATIVE_CALL getOwned(AMX *amx, cell *param) {amx;param;
  GTBot* bot = GTBot::getCurrentBot();
  if(bot->hasWeapon()) return ID_ITEM_WEAPON;
  if(bot->hasSign()) return ID_ITEM_SIGN;
  return ID_ITEM_NONE;
}
// int:getTouched();
static cell AMX_NATIVE_CALL getTouched(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getTouchedID();
}
// float:getDropAmount(int:item);
static cell AMX_NATIVE_CALL getDropAmount(AMX *amx, cell *param) {
  amx;param;
  amx;param;
  switch(param[1]) {
    case ID_ITEM_MEDIKIT:  return SLInterpreter::float2Cell(GTBot::HEALTH_DROP_MAX);
    case ID_ITEM_FOOD:     return SLInterpreter::float2Cell(GTBot::ENERGY_DROP_MAX);
    case ID_ITEM_ARMOR:    return SLInterpreter::float2Cell(GTBot::ARMOR_DROP_MAX);
    case ID_ITEM_BULLETS:  return SLInterpreter::float2Cell(GTWeapon::BULLET_DROP_MAX);
    case ID_ITEM_GRENADES: return SLInterpreter::float2Cell(GTWeapon::GRENADE_DROP_MAX);
  }
  return SLInterpreter::float2Cell(-1);
}
// bool:drop(int:item);
bool GTBot::drop(int itemID) {
  switch(itemID) {
    case ID_ITEM_MEDIKIT: {
      float v = getHealth();
      if(v <= GTBot::HEALTH_DROP_MAX) return false;
      setHealth(v-GTBot::HEALTH_DROP_MAX);
      v = GTBot::HEALTH_DROP_MAX;
      GTPowerup* p = NULL;
      GTItems& items = GTArena::get()->getItems();
      for(int ct = 0; ct < items.getSize(); ct++) {
        GTItem* i = items.getElement(ct);
        if(i && i->getClassID() == ID_ITEM_MEDIKIT) {
          GTPowerup* theP = dynamic_cast<GTPowerup*>(i);
          if(!theP->isExhausted())
            continue;
          theP->setValue(v);
          p = theP;
          break;
        }
      }
      if(!p) {
        p = new GTMedikit(v);
        items.addElement(dynamic_cast<DSSortableObject*>(p));
      }
      p->set(getX(),getY()+GTBot::SIZE_X,getZ());
      return true;
    }
    case ID_ITEM_FOOD: {
      float v = getEnergy();
      if(v <= GTBot::ENERGY_DROP_MAX) return false;
      setEnergy(v-GTBot::ENERGY_DROP_MAX);
      v = GTBot::ENERGY_DROP_MAX;
      GTPowerup* p = NULL;
      GTItems& items = GTArena::get()->getItems();
      for(int ct = 0; ct < items.getSize(); ct++) {
        GTItem* i = items.getElement(ct);
        if(i && i->getClassID() == ID_ITEM_FOOD) {
          GTPowerup* theP = dynamic_cast<GTPowerup*>(i);
          if(!theP->isExhausted())
            continue;
          theP->setValue(v);
          p = theP;
          break;
        }
      }
      if(!p) {
        p = new GTFood(v);
        items.addElement(dynamic_cast<DSSortableObject*>(p));
      }
      p->set(getX(),getY()+GTBot::SIZE_X,getZ());
      return true;
    }
    case ID_ITEM_ARMOR: {
      float v = getArmor();
      if(v < GTBot::ARMOR_DROP_MAX) return false;
      setArmor(v-GTBot::ARMOR_DROP_MAX);
      v = GTBot::ARMOR_DROP_MAX;
      GTPowerup* p = NULL;
      GTItems& items = GTArena::get()->getItems();
      for(int ct = 0; ct < items.getSize(); ct++) {
        GTItem* i = items.getElement(ct);
        if(i && i->getClassID() == ID_ITEM_ARMOR) {
          GTPowerup* theP = dynamic_cast<GTPowerup*>(i);
          if(!theP->isExhausted())
            continue;
          theP->setValue(v);
          p = theP;
          break;
        }
      }
      if(!p) {
        p = new GTArmor(v);
        items.addElement(dynamic_cast<DSSortableObject*>(p));
      }
      p->set(getX(),getY()+GTBot::SIZE_X,getZ());
      return true;
    }
    case ID_ITEM_BULLETS: {
      if(!hasWeapon()) break;
      float v = getBulletsCount();
      if(v < GTWeapon::BULLET_DROP_MAX) return false;
      getWeapon()->setBulletsCount(v-GTWeapon::BULLET_DROP_MAX);
      v = GTWeapon::BULLET_DROP_MAX;
      GTPowerup* p = NULL;
      GTItems& items = GTArena::get()->getItems();
      for(int ct = 0; ct < items.getSize(); ct++) {
        GTItem* i = items.getElement(ct);
        if(i && i->getClassID() == ID_ITEM_BULLETS) {
          GTPowerup* theP = dynamic_cast<GTPowerup*>(i);
          if(!theP->isExhausted())
            continue;
          theP->setValue(v);
          p = theP;
          break;
        }
      }
      if(!p) {
        p = new GTBullets(v);
        items.addElement(dynamic_cast<DSSortableObject*>(p));
      }
      p->set(getX(),getY()+GTBot::SIZE_X,getZ());
      return true;
    }
    case ID_ITEM_GRENADES: {
      if(!hasWeapon()) break;
      float v = getGrenadesCount();
      if(v < GTWeapon::GRENADE_DROP_MAX) return false;
      getWeapon()->setGrenadesCount(v-GTWeapon::GRENADE_DROP_MAX);
      v = GTWeapon::GRENADE_DROP_MAX;
      GTPowerup* p = NULL;
      GTItems& items = GTArena::get()->getItems();
      for(int ct = 0; ct < items.getSize(); ct++) {
        GTItem* i = items.getElement(ct);
        if(i && i->getClassID() == ID_ITEM_GRENADES) {
          GTPowerup* theP = dynamic_cast<GTPowerup*>(i);
          if(!theP->isExhausted())
            continue;
          theP->setValue(v);
          p = theP;
          break;
        }
      }
      if(!p) {
        p = new GTGrenades(v);
        items.addElement(dynamic_cast<DSSortableObject*>(p));
      }
      p->set(getX(),getY()+GTBot::SIZE_X,getZ());
      return true;
    }
    case ID_ITEM_WEAPON: {
      if(!hasWeapon()) break;
      if(setTorsoAttitude(GTBot::DROP))
        return true;
    }
    case ID_ITEM_SIGN: {
      if(!hasSign()) break;
      if(GTArena::get()->getGoalIndex() == ID_GOAL_TERMINATE_CHIEF) break;
      if(setTorsoAttitude(GTBot::DROP))
        return true;
    }
  }
  return false;
}

static cell AMX_NATIVE_CALL drop(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->drop(param[1])? 1: 0;
}
// bool:raise(int:item);
bool GTBot::raise(int itemID) {
  GTItem* touched = getItemTouched();
  if(touched == NULL)
    return false;
  if(itemID >= 0 && itemID != touched->getClassID())
    return false;
  switch(touched->getClassID()) {
    case ID_ITEM_MEDIKIT: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(touched);
      float v = p->getValue();
      float diff = GTBot::HEALTH_MAX-getHealth();
      if(diff >= v) {
        setHealth(getHealth()+v);
        if(p->cantRespawn()) {
          p->setValue(0);
          p->setExhausted(true);
        } else {
          p->setValue(GTPowerup::MEDIKIT_VALUE_INIT);
          p->setRespawnCountdown(GTPowerup::MEDIKIT_RESPAWN_TIME);
        }
        setTouched(ID_ITEM_NONE,NULL);
      } else {
        setHealth(GTBot::HEALTH_MAX);
        p->setValue(p->getValue()-diff);
      }
      return true;
    }
    case ID_ITEM_FOOD: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(touched);
      float v = p->getValue();
      float diff = GTBot::ENERGY_MAX-getEnergy();
      if(diff >= v) {
        setEnergy(getEnergy()+v);
        if(p->cantRespawn()) {
          p->setValue(0);
          p->setExhausted(true);
        } else {
          p->setValue(GTPowerup::FOOD_VALUE_INIT);
          p->setRespawnCountdown(GTPowerup::FOOD_RESPAWN_TIME);
        }
        setTouched(ID_ITEM_NONE,NULL);
      } else {
        setEnergy(GTBot::ENERGY_MAX);
        p->setValue(p->getValue()-diff);
      }
      return true;
    }
    case ID_ITEM_ARMOR: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(touched);
      float v = p->getValue();
      float diff = GTBot::ARMOR_MAX-getArmor();
      if(diff >= v) {
        setArmor(getArmor()+v);
        if(p->cantRespawn()) {
          p->setValue(0);
          p->setExhausted(true);
        } else {
          p->setValue(GTPowerup::ARMOR_VALUE_INIT);
          p->setRespawnCountdown(GTPowerup::ARMOR_RESPAWN_TIME);
        }
        setTouched(ID_ITEM_NONE,NULL);
      } else {
        setArmor(GTBot::ARMOR_MAX);
        p->setValue(p->getValue()-diff);
      }
      return true;
    }
    case ID_ITEM_BULLETS: {
      if(!hasWeapon()) break;
      GTPowerup* p = dynamic_cast<GTPowerup*>(touched);
      float v = p->getValue();
      float diff = GTWeapon::BULLET_LOAD_MAX-getBulletsCount();
      if(diff >= v) {
        getWeapon()->setBulletsCount(getBulletsCount()+v);
        if(p->cantRespawn()) {
          p->setValue(0);
          p->setExhausted(true);
        } else {
          p->setValue(GTPowerup::BULLETS_VALUE_INIT);
          p->setRespawnCountdown(GTPowerup::BULLETS_RESPAWN_TIME);
        }
        setTouched(ID_ITEM_NONE,NULL);
      } else {
        getWeapon()->setBulletsCount(GTWeapon::BULLET_LOAD_MAX);
        p->setValue(p->getValue()-diff);
      }
      return true;
    }
    case ID_ITEM_GRENADES: {
      if(!hasWeapon()) break;
      GTPowerup* p = dynamic_cast<GTPowerup*>(touched);
      float v = p->getValue();
      float diff = GTWeapon::GRENADE_LOAD_MAX-getGrenadesCount();
      if(diff >= v) {
        getWeapon()->setGrenadesCount(getGrenadesCount()+v);
        if(p->cantRespawn()) {
          p->setValue(0);
          p->setExhausted(true);
        } else {
          p->setValue(GTPowerup::GRENADES_VALUE_INIT);
          p->setRespawnCountdown(GTPowerup::GRENADES_RESPAWN_TIME);
        }
        setTouched(ID_ITEM_NONE,NULL);
      } else {
        getWeapon()->setGrenadesCount(GTWeapon::GRENADE_LOAD_MAX);
        p->setValue(p->getValue()-diff);
      }
      return true;
    }
    case ID_ITEM_SIGN:
    case ID_ITEM_WEAPON:
    {
      if(hasWeapon() || hasSign()) break;
      if(setTorsoAttitude(GTBot::RAISE)) {
        GTHoldable* p = dynamic_cast<GTHoldable*>(touched);
        setHold(p);
        setTouched(ID_ITEM_NONE,NULL);
        return true;
      }
    }
  }
  return false;
}

static cell AMX_NATIVE_CALL raise(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->raise(param[1])? 1: 0;
}
// float:getDirection();
static cell AMX_NATIVE_CALL getDirection(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(GTBot::getCurrentBot()->getLegsAngle().getCurrent());
}
// float:getRotSpeed();
static cell AMX_NATIVE_CALL getRotSpeed(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::SPEED_ROTATION);}
// float:getTorsoYaw();
static cell AMX_NATIVE_CALL getTorsoYaw(AMX *amx, cell *param) {amx;param;
  return
    SLInterpreter::float2Cell(GTBot::getCurrentBot()->getTorsoAngles().getYaw().getCurrent());
}
// float:getTorsoMinYaw();
static cell AMX_NATIVE_CALL getTorsoMinYaw(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::TORSO_YAW_MIN);}
// float:getTorsoMaxYaw();
static cell AMX_NATIVE_CALL getTorsoMaxYaw(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::TORSO_YAW_MAX);}
// float:getTorsoPitch();
static cell AMX_NATIVE_CALL getTorsoPitch(AMX *amx, cell *param) {amx;param;
  return SLInterpreter::float2Cell(
    GTBot::getCurrentBot()->getTorsoAngles().getPitch().getCurrent()
  );
}
// float:getTorsoMinPitch();
static cell AMX_NATIVE_CALL getTorsoMinPitch(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::TORSO_PITCH_MIN);}
// float:getTorsoMaxPitch();
static cell AMX_NATIVE_CALL getTorsoMaxPitch(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::TORSO_PITCH_MAX);}
// float:getTorsoRotSpeed();
static cell AMX_NATIVE_CALL getTorsoRotSpeed(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::TORSO_SPEED_ROT);}
// float:getHeadYaw();
static cell AMX_NATIVE_CALL getHeadYaw(AMX *amx, cell *param) {amx;param;
  return
    SLInterpreter::float2Cell(GTBot::getCurrentBot()->getHeadAngles().getYaw().getCurrent());
}
// float:getHeadMinYaw();
static cell AMX_NATIVE_CALL getHeadMinYaw(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_YAW_MIN);}
// float:getHeadMaxYaw();
static cell AMX_NATIVE_CALL getHeadMaxYaw(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_YAW_MAX);}
// float:getHeadPitch();
static cell AMX_NATIVE_CALL getHeadPitch(AMX *amx, cell *param) {amx;param;
  return
    SLInterpreter::float2Cell(GTBot::getCurrentBot()->getHeadAngles().getPitch().getCurrent());
}
// float:getHeadMinPitch();
static cell AMX_NATIVE_CALL getHeadMinPitch(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_PITCH_MIN);}
// float:getHeadMaxPitch();
static cell AMX_NATIVE_CALL getHeadMaxPitch(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_PITCH_MAX);}
// float:getHeadRotSpeed();
static cell AMX_NATIVE_CALL getHeadRotSpeed(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_SPEED_ROT);}
// float:getAngleOfView();
static cell AMX_NATIVE_CALL getAngleOfView(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::HEAD_ANGLE_OF_VIEW);}
// float:getSensorsRange();
static cell AMX_NATIVE_CALL getSensorsRange(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTBot::SENSORS_DISTANCE_MAX*BSP_SCENE_SCALE_INV);}
// bool:shootBullet();
static cell AMX_NATIVE_CALL shootBullet(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->shootBullet()? 1: 0;
}
// float:getBulletSpeed();
static cell AMX_NATIVE_CALL getBulletSpeed(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTWeapon::BULLET_SPEED);}
// int:getBulletLoad();
static cell AMX_NATIVE_CALL getBulletLoad(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getBulletsCount();
}
// int:getBulletMaxLoad();
static cell AMX_NATIVE_CALL getBulletMaxLoad(AMX *amx, cell *param)
  {amx;param; return GTWeapon::BULLET_LOAD_MAX;}
// bool:launchGrenade();
static cell AMX_NATIVE_CALL launchGrenade(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->launchGrenade()? 1: 0;
}
// float:getGrenadeSpeed();
static cell AMX_NATIVE_CALL getGrenadeSpeed(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTWeapon::GRENADE_SPEED);}
// int:getGrenadeLoad();
static cell AMX_NATIVE_CALL getGrenadeLoad(AMX *amx, cell *param) {amx;param;
  return GTBot::getCurrentBot()->getGrenadesCount();
}
// int:getGrenadeMaxLoad();
static cell AMX_NATIVE_CALL getGrenadeMaxLoad(AMX *amx, cell *param)
  {amx;param; return GTWeapon::GRENADE_LOAD_MAX;}
// float:getGrenadeDelay();
static cell AMX_NATIVE_CALL getGrenadeDelay(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTWeapon::GRENADE_EXPL_DELAY);}
// float:getGrenadeMaxRange();
static cell AMX_NATIVE_CALL getGrenadeMaxRange(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTWeapon::GRENADE_RANGE_MAX);}
// float:getExplosionTimeLen();
static cell AMX_NATIVE_CALL getExplosionTimeLen(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTWeapon::GRENADE_EXPL_DURATION);}
// float:getGravity();
static cell AMX_NATIVE_CALL getGravity(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTArena::WORLD_GRAVITY);}
// float:getGroundElasticity();
static cell AMX_NATIVE_CALL getGroundElasticity(AMX *amx, cell *param)
  {amx;param; return SLInterpreter::float2Cell(GTArena::GROUND_RESTITUTION);}

// natives
#define FUNC(NAME) {#NAME,NAME}
AMX_NATIVE_INFO botsNatives[] = {
  FUNC(getTimeout),
  FUNC(getGoal),
  FUNC(getPlay),
  FUNC(getTeams),
  FUNC(getMates),
  FUNC(getKilledEnemies),
  FUNC(getKilledFriends),
  FUNC(getGoalLocation),
  FUNC(getGoalSize),
  FUNC(getTargetSize),
  FUNC(getTargetMaxSpeed),
  FUNC(getTime),
  FUNC(getTicksCount),
  FUNC(getSimulationStep),
  FUNC(getCPUPeriod),
  FUNC(getTimeNeededFor),
  FUNC(getTimeForRespawn),
  FUNC(getTimeLostTo),
  FUNC(getMemorySize),
  FUNC(getID),
  FUNC(getLocation),
  FUNC(getSize),
  FUNC(getHeight),
  FUNC(getGunHeight),
  FUNC(getGunLength),
  FUNC(isStanding),
  FUNC(isCrouched),
  FUNC(isWalking),
  FUNC(isWalkingcr),
  FUNC(isWalkingbk),
  FUNC(isRunning),
  FUNC(stand),
  FUNC(crouch),
  FUNC(walk),
  FUNC(walkcr),
  FUNC(walkbk),
  FUNC(run),
  FUNC(rotate),
  FUNC(isRotating),
  FUNC(rotateTorso),
  FUNC(isTorsoRotating),
  FUNC(rotateHead),
  FUNC(isHeadRotating),
  FUNC(bendTorso),
  FUNC(isTorsoBending),
  FUNC(bendHead),
  FUNC(isHeadBending),
  FUNC(wait),
  FUNC(say),
  FUNC(speak),
  FUNC(listen),
  FUNC(hear),
  FUNC(getMaxKickSpeed),
  FUNC(getKickSpeed),
  FUNC(setKickSpeed),
  FUNC(getWalkSpeed),
  FUNC(getWalkcrSpeed),
  FUNC(getWalkbkSpeed),
  FUNC(getRunSpeed),
  FUNC(getFallMaxSpeed),
  FUNC(watch),
  FUNC(sight),
  FUNC(aim),
  FUNC(getEnergy),
  FUNC(getMaxEnergy),
  FUNC(getRunEnergyLoss),
  FUNC(getStandEnergyGain),
  FUNC(getHealth),
  FUNC(getMaxHealth),
  FUNC(getBulletHealthLoss),
  FUNC(getGrenadeMaxDamage),
  FUNC(getArmor),
  FUNC(getMaxArmor),
  FUNC(getOwned),
  FUNC(getTouched),
  FUNC(getDropAmount),
  FUNC(drop),
  FUNC(raise),
  FUNC(getDirection),
  FUNC(getRotSpeed),
  FUNC(getTorsoYaw),
  FUNC(getTorsoMinYaw),
  FUNC(getTorsoMaxYaw),
  FUNC(getTorsoPitch),
  FUNC(getTorsoMinPitch),
  FUNC(getTorsoMaxPitch),
  FUNC(getTorsoRotSpeed),
  FUNC(getHeadYaw),
  FUNC(getHeadMinYaw),
  FUNC(getHeadMaxYaw),
  FUNC(getHeadPitch),
  FUNC(getHeadMinPitch),
  FUNC(getHeadMaxPitch),
  FUNC(getHeadRotSpeed),
  FUNC(getAngleOfView),
  FUNC(getSensorsRange),
  FUNC(shootBullet),
  FUNC(getBulletSpeed),
  FUNC(getBulletLoad),
  FUNC(getBulletMaxLoad),
  FUNC(launchGrenade),
  FUNC(getGrenadeSpeed),
  FUNC(getGrenadeLoad),
  FUNC(getGrenadeMaxLoad),
  FUNC(getGrenadeDelay),
  FUNC(getGrenadeMaxRange),
  FUNC(getExplosionTimeLen),
  FUNC(getGravity),
  FUNC(getGroundElasticity),
  {0,0}
};

//
// GTBotBrain
//

GTBotBrain::GTBotBrain(): timerCountdown(0), ticksCount(0) {
}

int GTBotBrain::MEMORY_SIZE    = 32768;
int GTBotBrain::CPU_FREQUENCY  = 10000;
float GTBotBrain::SIMULATION_TIME_STEP = 0.01f;

bool GTBotBrain::load(char* scriptName, unsigned int randomSeed) {
  setCPUFrequency(CPU_FREQUENCY);
  char* newName = NULL;
  if(!strstr(scriptName,".amx")) {
    newName = new char[5+strlen(scriptName)+5];
    strcat(strcat(strcpy(newName,"bots\\"),scriptName),".amx");
    scriptName = newName;
  }
  SLInterpreter::load(scriptName,MEMORY_SIZE);
  setRandomSeed(randomSeed);
  if(newName)
    delete newName;
  if(isLoaded() && registerNatives(botsNatives)) {
    initMain();
    return isRunning();
  }
  return false;
}

//
// GTAngle
//
GTAngle::GTAngle(): currentAngle(0), requiredAngle(0), rotationSpeed(0) {
}

//
// GTItem
//
GTItem::~GTItem() {
}

//
// GTExhaustable
//
GTExhaustable::GTExhaustable(): exhausted(false) {
}

//
// GTTarget
//
GTTarget::GTTarget(): countdown(0) {
}

float GTTarget::SIZE = 0.3125f; // SI
float GTTarget::MAX_SPEED = 15; // SI

//
// GTSign
//
GTSign::GTSign(): owner(NULL) {
}

//
// GTWeapon
//
GTWeapon::GTWeapon():
  bulletsCount(BULLET_LOAD_INIT), grenadesCount(GRENADE_LOAD_INIT)
{}

float GTWeapon::LENGTH                = 30;
float GTWeapon::HEIGHT                = 18;
float GTWeapon::BULLET_SPEED          = 30; // SI
float GTWeapon::BULLET_LOAD_MAX       = 100;
float GTWeapon::BULLET_LOAD_INIT      = 50;
float GTWeapon::BULLET_DROP_MAX       = 50;
float GTWeapon::GRENADE_SPEED         = 15; // SI
float GTWeapon::GRENADE_EXPL_DELAY    = 3;
float GTWeapon::GRENADE_EXPL_DURATION = 1;
float GTWeapon::GRENADE_RANGE_MAX     = 5; // SI
float GTWeapon::GRENADE_LOAD_MAX      = 3;
float GTWeapon::GRENADE_LOAD_INIT     = 1;
float GTWeapon::GRENADE_DROP_MAX      = 3;

//
// GTPowerup
//
GTPowerup::GTPowerup(float v, bool r): respawnCountdown(r? 0: -1) {
  setValue(v);
}

float GTPowerup::MEDIKIT_VALUE_INIT    =  50;
float GTPowerup::FOOD_VALUE_INIT       =  50;
float GTPowerup::ARMOR_VALUE_INIT      = 100;
float GTPowerup::BULLETS_VALUE_INIT    =  50;
float GTPowerup::GRENADES_VALUE_INIT   =   3;
float GTPowerup::MEDIKIT_RESPAWN_TIME  =  10;
float GTPowerup::FOOD_RESPAWN_TIME     =  15;
float GTPowerup::ARMOR_RESPAWN_TIME    =  20;
float GTPowerup::BULLETS_RESPAWN_TIME  =  10;
float GTPowerup::GRENADES_RESPAWN_TIME =  10;

GTMedikit::GTMedikit(bool r, float v): GTPowerup(v,r) {}
GTFood::GTFood(bool r, float v): GTPowerup(v,r) {}
GTArmor::GTArmor(bool r, float v): GTPowerup(v,r) {}
GTBullets::GTBullets(bool r, float v): GTPowerup(v,r) {}
GTGrenades::GTGrenades(bool r, float v): GTPowerup(v,r) {}

//
// GTBot
//

GTBot::GTBot(GLTeamMate* tm):
  legsAttitude(IDLE), requiredLegsAttitude(IDLE), legsCountdown(0),
  torsoAttitude(STAND), requiredTorsoAttitude(STAND), torsoCountdown(0),
  touchedID(ID_ITEM_NONE), teamID(0), mateID(0), teamMate(tm), verticalSpeed(0),
  kickSpeed(0), energy(ENERGY_INIT), health(HEALTH_INIT), armor(ARMOR_INIT),
  killedEnemies(0), killedFriends(0), hold(NULL), shooting(false),
  shootingWhat(ID_ITEM_NONE), itemTouched(NULL), talkingCountdown(0),
  talkingAbout(0), speakingOnRadio(false), speakingChannel(0)
{}

GTBot* GTBot::currentBot = NULL;

float GTBot::SIZE_X          = 18;
float GTBot::SIZE_Y          = 24;
float GTBot::SIZE_Y_CROUCHED = 18;
float GTBot::SIZE_Z          = 18;
float GTBot::SPACING         = 56;
float GTBot::TIME_LOST_TO_SIGHT  = 0.01f;
float GTBot::TIME_LOST_TO_AIM    = 0.04f;
float GTBot::TIME_LOST_TO_HEAR   = 0.04f;
float GTBot::TIME_LOST_TO_WATCH  = 0.04f;
float GTBot::TIME_LOST_TO_LISTEN = 0.04f;
float GTBot::TIME_NEEDED_TO_SAY   = 0.5f;
float GTBot::TIME_NEEDED_TO_SPEAK = 0.25f;
float GTBot::TIME_NEEDED_TO_MOVE  = 1;
float GTBot::TIME_NEEDED_TO_DROP  = 0.5f;
float GTBot::TIME_NEEDED_TO_SHOOT = 0.5f;
float GTBot::KICK_SPEED_MAX     = 5; // SI
float GTBot::SPEED_VERTICAL_MAX = 7.5f; // SI
float GTBot::SPEED_ROTATION     = 1.5708f;
float GTBot::SPEED_WALKCR       = 2.5f; // SI
float GTBot::SPEED_WALKBK       =-2.5f; // SI
float GTBot::SPEED_WALK         = 2.5f; // SI
float GTBot::SPEED_RUN          = 5;    // SI
float GTBot::ENERGY_MAX         = 100;
float GTBot::ENERGY_INIT        = 50;
float GTBot::ENERGY_RUN         = 2;
float GTBot::ENERGY_STAND       = 1;
float GTBot::ENERGY_DROP_MAX    = 50;
float GTBot::HEALTH_MAX         = 100;
float GTBot::HEALTH_INIT        = 100;
float GTBot::HEALTH_BULLET      = 50;
float GTBot::HEALTH_GRENADE_MAX = 150;
float GTBot::HEALTH_DROP_MAX    = 50;
float GTBot::ARMOR_MAX          = 100;
float GTBot::ARMOR_INIT         = 0;
float GTBot::ARMOR_DROP_MAX     = 100;
float GTBot::TORSO_YAW_MAX      = 1.047f;
float GTBot::TORSO_YAW_MIN      =-1.047f;
float GTBot::TORSO_PITCH_MAX    = 0.7854f;
float GTBot::TORSO_PITCH_MIN    =-0.7854f;
float GTBot::TORSO_SPEED_ROT    = 1.5708f;
float GTBot::HEAD_YAW_MAX       = 1.047f;
float GTBot::HEAD_YAW_MIN       =-1.047f;
float GTBot::HEAD_PITCH_MAX     = 0.7854f;
float GTBot::HEAD_PITCH_MIN     =-0.7854f;
float GTBot::HEAD_SPEED_ROT     = 1.5708f;
float GTBot::HEAD_ANGLE_OF_VIEW = 0.5236f;
float GTBot::HEAD_COS_ANGLE_OF_VIEW = 0.866f;
float GTBot::SENSORS_DISTANCE_MAX   = 6400;

bool GTBot::setTorsoAttitude(TorsoAttitude ta) {
  switch(torsoAttitude) {
    case STAND:
      break;
    case ATTACK:
      if(ta != STAND) return false;
      break;
    case DROP:
      if(ta != STAND) return false;
      break;
    case RAISE:
      if(ta != STAND) return false;
      break;
    default:
      return false;
  }
  requiredTorsoAttitude = ta;
  return true;
}

bool GTBot::updateTorsoAttitude() {
  talkingCountdown -= SIMULATION_TIME_STEP;
  if((torsoCountdown -= SIMULATION_TIME_STEP) < 0) {
    if(torsoAttitude != requiredTorsoAttitude) {
      TorsoAttitude required = requiredTorsoAttitude;
      switch(requiredTorsoAttitude) {
        case ATTACK: {
          shooting = true;
          torsoCountdown = TIME_NEEDED_TO_SHOOT;
          requiredTorsoAttitude = STAND;
          break;
        }
        case DROP: {
          torsoCountdown = TIME_NEEDED_TO_DROP;
          requiredTorsoAttitude = STAND;
        }
        case RAISE: {
          torsoCountdown = TIME_NEEDED_TO_DROP;
          requiredTorsoAttitude = STAND;
          break;
        }
        case STAND: {
          if(torsoAttitude == DROP)
            setHold(NULL);
          break;
        }
      }
      torsoAttitude = required;
      return true;
    }
  } else if(torsoAttitude == ATTACK) {
    setFlashing(torsoCountdown >= TIME_NEEDED_TO_SHOOT-0.1f);
  }
  return false;
}

bool GTBot::setLegsAttitude(LegsAttitude la) {
  switch(legsAttitude) {
    case WALKCR:
      if(la != IDLECR) return false;
      break;
    case WALK:
      if(la != IDLE && la != RUN) return false;
      break;
    case RUN:
      if(la != WALK || getEnergy() < ENERGY_RUN) return false;
      break;
    case WALKBK:
      if(la != IDLE) return false;
      break;
    case IDLE:
      switch(la) {
        case WALK:
        case IDLECR:
        case WALKBK:
          break;
        default:
          return false;
      }
      break;
    case IDLECR:
      if(la != WALKCR && la != IDLE) return false;
      break;
    default:
      return false;
  }
  requiredLegsAttitude = la;
  return true;
}

bool GTBot::updateLegsAttitude() {
  if(
    (legsCountdown -= SIMULATION_TIME_STEP) < 0 &&
    legsAttitude != requiredLegsAttitude
  ) {
    legsAttitude = requiredLegsAttitude;
    legsCountdown = TIME_NEEDED_TO_MOVE;
    return true;
  }
  return false;
}

float GTBot::getLegsSpeed() {
  switch(legsAttitude) {
    case WALKCR:
      return SPEED_WALKCR;
    case WALK:
      return SPEED_WALK;
    case RUN:
      return SPEED_RUN;
    case WALKBK:
      return SPEED_WALKBK;
    case IDLE:
    case IDLECR:
    default:
      return  0;
  }
}

void GTBot::setHold(GTHoldable* h) {
  if(hold) {
    hold->setExhausted(false);
    if(hold->getClassID() == ID_ITEM_SIGN) {
      GTSign* s = dynamic_cast<GTSign*>(hold);
      s->setOwner(NULL);
    }
    hold->set(
      getX()+cos(getLegsAngle().getCurrent())*SIZE_X,
      getY()+(isCrouched()? (SIZE_Y_CROUCHED-1): (SIZE_Y-1)),
      getZ()-sin(getLegsAngle().getCurrent())*SIZE_X
    );
  }
  GLTeamMate* tm = getTeamMate();
  if((hold = h) != NULL) {
    hold->setExhausted(true);
    if(hold->getClassID() == ID_ITEM_SIGN) {
      GTSign* s = dynamic_cast<GTSign*>(hold);
      s->setOwner(this);
    }
    if(tm) {
      switch(hold->getClassID()) {
        case ID_ITEM_WEAPON: {
          tm->setStatus(GLTeamMate::HAS_WEAPON);
          return;
        }
        case ID_ITEM_SIGN: {
          tm->setStatus(GLTeamMate::HAS_SIGN);
          return;
        }
      }
    } else
      return;
  }
  if(tm)
    tm->setStatus(GLTeamMate::NORMAL);
}

void GTBot::update() {
  updateLegsAttitude();
  updateTorsoAttitude();
  switch(legsAttitude) {
    case WALKCR:
    case WALK:
    case WALKBK:
      legsAngle.updateAngle();
      break;
    case RUN:
      legsAngle.updateAngle();
      setEnergy(getEnergy()-ENERGY_RUN*SIMULATION_TIME_STEP);
      if(getEnergy() <= 0) {
        setEnergy(0);
        if(getLegsAttitude() == GTBot::RUN)
          forceLegsAttitude(GTBot::WALK);
      }
      break;
    case IDLE:
      legsAngle.updateAngle();
      setEnergy(getEnergy()+ENERGY_STAND*SIMULATION_TIME_STEP);
      if(getEnergy() > ENERGY_MAX)
        setEnergy(ENERGY_MAX);
      break;
    default:
      break;
  }
  torsoAngles.updateAngles();
  headAngles.updateAngles();
  execute();
}

//
// GTAmmo
//

//
// GTGrenade
//
GTGrenade::GTGrenade(): exploded(false) {
  setDelay();
}

//
// GTItems
//
GTItems::GTItems(int cap): DSSortedArray<GTItem>(cap) {
}

bool GTItems::getWeaponStatus(int& idx, M3Vector& pos, int& type, int& attrib) {
  int index = -1;
  for(int itemCt = idx; itemCt < getSize(); itemCt++) {
    GTItem* item = getElement(itemCt);
    if(item) {
      switch(item->getClassID()) {
        case ID_ITEM_WEAPON: {
          GTWeapon* weapon = dynamic_cast<GTWeapon*>(item);
          if(weapon->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*weapon));
          index = itemCt+1;
          type = GLWeaponData::ID_WEAPON;
          attrib = 1*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_SIGN: {
          GTSign* sign = dynamic_cast<GTSign*>(item);
          if(sign->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*sign));
          index = itemCt+1;
          type = GLWeaponData::ID_SIGN;
          attrib = 1*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
      }
    }
  }
  idx = index;
  return index >= 0;
};

bool GTItems::getPowerupStatus(
  int& idx, M3Vector& pos, int& type, int& attrib
) {
  const float RESPAWN_DROP_SPEED = 5*BSP_SCENE_SCALE;
  int index = -1;
  for(int itemCt = idx; itemCt < getSize(); itemCt++) {
    GTItem* item = getElement(itemCt);
    if(item) {
      switch(item->getClassID()) {
        case ID_ITEM_MEDIKIT: {
          GTMedikit* medikit = dynamic_cast<GTMedikit*>(item);
          if(medikit->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*medikit));
          if(!medikit->isActive()) pos.setY(
            pos.getY()+RESPAWN_DROP_SPEED*medikit->getRespawnCountdown()
          );
          index = itemCt+1;
          type = GLPowerupData::ID_MEDIKIT;
          attrib = 0.5f*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_FOOD: {
          GTFood* food = dynamic_cast<GTFood*>(item);
          if(food->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*food));
          if(!food->isActive()) pos.setY(
            pos.getY()+RESPAWN_DROP_SPEED*food->getRespawnCountdown()
          );
          index = itemCt+1;
          type = GLPowerupData::ID_FOOD;
          attrib = 0.5f*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_ARMOR: {
          GTArmor* armor = dynamic_cast<GTArmor*>(item);
          if(armor->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*armor));
          if(!armor->isActive()) pos.setY(
            pos.getY()+RESPAWN_DROP_SPEED*armor->getRespawnCountdown()
          );
          index = itemCt+1;
          type = GLPowerupData::ID_ARMOR;
          attrib = 0.5f*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_BULLETS: {
          GTBullets* bullets = dynamic_cast<GTBullets*>(item);
          if(bullets->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*bullets));
          if(!bullets->isActive()) pos.setY(
            pos.getY()+RESPAWN_DROP_SPEED*bullets->getRespawnCountdown()
          );
          index = itemCt+1;
          type = GLPowerupData::ID_BULLETS;
          attrib = 0.5f*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_GRENADES: {
          GTGrenades* grenades = dynamic_cast<GTGrenades*>(item);
          if(grenades->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*grenades));
          if(!grenades->isActive()) pos.setY(
            pos.getY()+RESPAWN_DROP_SPEED*grenades->getRespawnCountdown()
          );
          index = itemCt+1;
          type = GLPowerupData::ID_GRENADES;
          attrib = 0.5f*BSP_SCENE_SCALE;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_TARGET: {
          GTTarget* target = dynamic_cast<GTTarget*>(item);
          if(target->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*target));
          index = itemCt+1;
          type = GLPowerupData::ID_TARGET;
          attrib = int(GTTarget::SIZE*BSP_SCENE_SCALE);
          itemCt = getSize();
          break;
        }
      }
    }
  }
  idx = index;
  return index >= 0;
};

bool GTItems::getAmmoStatus(int& idx, M3Vector& pos, int& type, int& attrib) {
  int index = -1;
  for(int itemCt = idx; itemCt < getSize(); itemCt++) {
    GTItem* item = getElement(itemCt);
    if(item) {
      switch(item->getClassID()) {
        case ID_ITEM_BULLET: {
          GTBullet* bullet = dynamic_cast<GTBullet*>(item);
          if(bullet->isExhausted())
            continue;
          pos.set(dynamic_cast<const M3Vector&>(*bullet));
          index = itemCt+1;
          type = GLAmmoData::ID_BULLET;
          itemCt = getSize();
          break;
        }
        case ID_ITEM_GRENADE: {
          GTGrenade* grenade = dynamic_cast<GTGrenade*>(item);
          if(grenade->isExhausted())
            continue;
          if(grenade->isExploded()) {
            attrib = int(
              15.95f*grenade->getCountdown()/GTWeapon::GRENADE_EXPL_DURATION+1
            );
            if(!grenade->wasExplosionNotified())
              attrib = -attrib;
          } else {
            attrib = 0;
          }
          pos.set(dynamic_cast<const M3Vector&>(*grenade));
          index = itemCt+1;
          type = GLAmmoData::ID_GRENADE;
          itemCt = getSize();
          break;
        }
      }
    }
  }
  idx = index;
  return index >= 0;
};

//
// GTArena
//

GTArena::GTArena(
  unsigned int seed, int goal, int play, float timeout, GLBsp& iBsp, int* starts,
  char** botNames, int teamsCt, int matesCt, GLTeams* teams
):
  realTime(0), randomSeed(seed), goalIndex(goal), playIndex(play), winner(-1),
  matchDuration(timeout), bsp(&iBsp), items(teamsCt*matesCt*(1+1+6)),
  bots(teamsCt*matesCt), signs(teamsCt), target(NULL),
  teamsCount(teamsCt), matesCount(matesCt)
{
  if(arena == NULL)
    arena = this;
  if(teams)
    teams->setWeaponData(getItems());
  if(play == ID_PLAY_SOCCER) {
    target = new GTTarget();
    target->set(0,2*(2*GTBot::SIZE_Y),0);
    items.addElement(dynamic_cast<DSSortableObject*>(target));
  }
  for(int idx = 0; idx < bsp->getMedikitPositionsCount(); idx++) {
    BSPVector& vec = bsp->getMedikitPosition(idx);
    GTMedikit* item = new GTMedikit(true);
    item->set(vec.x,vec.y+GTBot::SIZE_Y,vec.z);
    items.addElement(dynamic_cast<DSSortableObject*>(item));
  }
  for(int idx = 0; idx < bsp->getFoodPositionsCount(); idx++) {
    BSPVector& vec = bsp->getFoodPosition(idx);
    GTFood* item = new GTFood(true);
    item->set(vec.x,vec.y+GTBot::SIZE_Y,vec.z);
    items.addElement(dynamic_cast<DSSortableObject*>(item));
  }
  for(int idx = 0; idx < bsp->getArmorPositionsCount(); idx++) {
    BSPVector& vec = bsp->getArmorPosition(idx);
    GTArmor* item = new GTArmor(true);
    item->set(vec.x,vec.y+GTBot::SIZE_Y,vec.z);
    items.addElement(dynamic_cast<DSSortableObject*>(item));
  }
  for(int idx = 0; idx < bsp->getBulletsPositionsCount(); idx++) {
    BSPVector& vec = bsp->getBulletsPosition(idx);
    GTBullets* item = new GTBullets(true);
    item->set(vec.x,vec.y+GTBot::SIZE_Y,vec.z);
    items.addElement(dynamic_cast<DSSortableObject*>(item));
  }
  for(int idx = 0; idx < bsp->getGrenadesPositionsCount(); idx++) {
    BSPVector& vec = bsp->getGrenadesPosition(idx);
    GTGrenades* item = new GTGrenades(true);
    item->set(vec.x,vec.y+GTBot::SIZE_Y,vec.z);
    items.addElement(dynamic_cast<DSSortableObject*>(item));
  }
  for(int tid = 0; tid < teamsCount; tid++) {
    float angle = 0;
    float radius = 0;
    for(int ct = 0; ct < matesCount; ct++) {
      GLTeamMate* tm = teams? teams->getTeamMate(tid,ct): NULL;
      GTBot* bot = new GTBot(tm);
      bots.addElement(bot);
      GTHoldable* hold = NULL;
      if(ct || goal == ID_GOAL_TERMINATE_TEAM) {
        if(play == ID_PLAY_FIGHT)
          hold = new GTWeapon();
      } else {
        hold = new GTSign();
        signs.addElement(dynamic_cast<GTSign*>(hold));
      }
      if(hold) {
        items.addElement(dynamic_cast<DSSortableObject*>(hold));
        bot->setHold(hold);
      }
      items.addElement(dynamic_cast<DSSortableObject*>(bot));
      bot->getLegsAngle().setSpeed(GTBot::SPEED_ROTATION);
      bot->getHeadAngles().setSpeed(GTBot::HEAD_SPEED_ROT);
      bot->getTorsoAngles().setSpeed(GTBot::TORSO_SPEED_ROT);
      bot->setTorsoAttitude(GTBot::STAND);
      bot->setLegsAttitude(GTBot::IDLE);
      bot->setEnergy(GTBot::ENERGY_INIT);
      bot->setHealth(GTBot::HEALTH_INIT);
      bot->setArmor(GTBot::ARMOR_INIT);
      bot->setTeamID(tid);
      bot->setMateID(ct);
      BSPVector& start = bsp->getStartingPosition(corner[tid] = starts[tid]);
      BSPVector extent(GTBot::SIZE_X,GTBot::SIZE_Y,GTBot::SIZE_Z);
      for(;;) {
        BSPVector vel(radius*cos(angle),0,radius*sin(angle));
        BSPVector finalPos(start.x+vel.x,start.y,start.z+vel.z);
        BSPVector pos = start;
        bsp->checkCollision(pos,vel,extent);
        if(
          pos.x == finalPos.x && pos.y == finalPos.y && pos.z == finalPos.z
        ) {
          bot->set(pos.x,pos.y,pos.z);             
          bot->setLegsAngle(2*M_PI*random(LRAND_MAX)/LRAND_MAX);
          break;
        } else {
          if(
            radius == 0 ||
            ((angle += GTBot::SPACING/radius) >= float(2*M_PI-GTBot::SPACING/radius))
          ) {
            angle = 0;
            radius += GTBot::SPACING;
            if(radius > GTBot::SPACING*10)
              break;
          }
        }
      }
      angle += GTBot::SPACING/radius;
      if(angle >= float(2*M_PI-GTBot::SPACING/radius)) {
        angle = 0;
        radius += GTBot::SPACING;
        if(radius > GTBot::SPACING*10)
          break;
      }
      bot->load(botNames[tid],seed);
    }
  }
}

GTArena* GTArena::arena = NULL;

float GTArena::WORLD_GRAVITY = -9.81f; // SI
float GTArena::GROUND_RESTITUTION = 0.8f;
float GTArena::ARENA_SIZE = 4208;
float GTArena::GOAL_SIZE = 7.5f; // SI

GTArena::~GTArena() {
  if(arena == this) arena = NULL;
}

int GTArena::update() {
  realTime += GTBotBrain::SIMULATION_TIME_STEP;
  const float WEAPON_GRENADE_RANGE_MAX_BSP =
    GTWeapon::GRENADE_RANGE_MAX*BSP_SCENE_SCALE;
  const float WEAPON_GRENADE_RANGE_MAX_BSP2 =
    WEAPON_GRENADE_RANGE_MAX_BSP*WEAPON_GRENADE_RANGE_MAX_BSP;
  const BSPVector botExtent(GTBot::SIZE_X,GTBot::SIZE_Y,GTBot::SIZE_Z);
  const int TARGET_SIZE2 = GTTarget::SIZE*BSP_SCENE_SCALE/2;
  BSPVector targetExtent(TARGET_SIZE2,TARGET_SIZE2,TARGET_SIZE2);
  items.quickSort(0,items.getSize()-1);
  for(int ct = 0; ct < getBotsSize(); ct++) {
    GTBot* bot = bots.getElement(ct);
    if(bot->isDead())
      continue;
    bot->update();
  }
  for(int itemCt = 0; itemCt < items.getSize(); itemCt++) {
    GTItem* item = items.getElement(itemCt);
    if(item) {
      switch(item->getClassID()) {
        case ID_ITEM_WARRIOR: {
          GTBot* bot = dynamic_cast<GTBot*>(item);
          if(bot->isDead())
            continue;
          M3Vector& botPos = *bot;
          BSPVector pos(botPos.getX(),botPos.getY(),botPos.getZ());
          const float speed =
            bot->getLegsSpeed()*BSP_SCENE_SCALE*GTBotBrain::SIMULATION_TIME_STEP;
          float velY =
            bot->getVerticalSpeed()+WORLD_GRAVITY*BSP_SCENE_SCALE*
            GTBotBrain::SIMULATION_TIME_STEP;
          BSPVector vel(
             cos(bot->getLegsAngle().getCurrent())*speed,
             velY*GTBotBrain::SIMULATION_TIME_STEP,
            -sin(bot->getLegsAngle().getCurrent())*speed
          );
          BSPVector end(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
          bsp->slideCollision(pos,vel,botExtent);
          if(
            pos.y != end.y && velY < -GTBot::SPEED_VERTICAL_MAX*BSP_SCENE_SCALE
          ) {
            bot->setHealth(0);
            bot->setHold(NULL);
            bot->forceLegsAttitude(GTBot::LDEATH);
            bot->forceTorsoAttitude(GTBot::TDEATH);
            continue;
          }
          velY = pos.y >= botPos.getY()?
            0: ((pos.y-botPos.getY())*(1.0f/GTBotBrain::SIMULATION_TIME_STEP));
          bot->setVerticalSpeed(velY);
          if(
            pos.x == botPos.getX() &&
            pos.y == botPos.getY() &&
            pos.z == botPos.getZ()
          ) continue;
          bot->setTouched(ID_ITEM_NONE,NULL);
          bool collision = false;
          for(int ct = itemCt-1; ct >= 0; ct--) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X*2)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) < GTBot::SIZE_Y
                ) {
                  int id =
                    ID_ITEM_WARRIOR |
                    (bot->getTeamID() == otherBot->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    );
                  bot->setTouched(id,otherBot);
                  otherBot->setTouched(id,bot);
                  collision = true;
                  if(getPlayIndex() == ID_PLAY_RACE) {
                    if(bot->getHealth() > otherBot->getHealth()) {
                      if(otherBot->getTeamID() == bot->getTeamID())
                        bot->setKilledFriends(bot->getKilledFriends()+1);
                      else
                        bot->setKilledEnemies(bot->getKilledEnemies()+1);
                      otherBot->setHealth(0);
                      otherBot->setHold(NULL);
                      otherBot->forceLegsAttitude(GTBot::LDEATH);
                      otherBot->forceTorsoAttitude(GTBot::TDEATH);
                    } else if(otherBot->getHealth() > bot->getHealth()) {
                      if(otherBot->getTeamID() == bot->getTeamID())
                        bot->setKilledFriends(bot->getKilledFriends()+1);
                      else
                        bot->setKilledEnemies(bot->getKilledEnemies()+1);
                      bot->setHealth(0);
                      bot->setHold(NULL);
                      bot->forceLegsAttitude(GTBot::LDEATH);
                      bot->forceTorsoAttitude(GTBot::TDEATH);
                    }
                  }
                }
                break;
              }
              case ID_ITEM_BULLET: {
                GTBullet* bullet = dynamic_cast<GTBullet*>(otherItem);
                if(bullet->isExhausted())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  bot->setTouched(
                    ID_ITEM_BULLET |
                    (bot->getTeamID() == bullet->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), bullet
                  );
                  float loss;
                  if(bot->getArmor()) {
                    loss = GTBot::HEALTH_BULLET*
                      (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX;
                    bot->setArmor(bot->getArmor()-GTBot::HEALTH_BULLET);
                    if(bot->getArmor() < 0) bot->setArmor(0);
                  } else {
                    loss = GTBot::HEALTH_BULLET;
                  }
                  bot->setHealth(bot->getHealth()-loss);
                  if(bot->getHealth() <= 0) {
                    int t = bullet->getTeamID();
                    int m = bullet->getMateID();
                    GTBot* killer = bots.getElement(t*matesCount+m);
                    if(killer->getTeamID() == bot->getTeamID())
                      killer->setKilledFriends(killer->getKilledFriends()+1);
                    else
                      killer->setKilledEnemies(killer->getKilledEnemies()+1);
                    bot->setHealth(0);
                    bot->setHold(NULL);
                    bot->forceLegsAttitude(GTBot::LDEATH);
                    bot->forceTorsoAttitude(GTBot::TDEATH);
                  }
                  bullet->setExhausted(true);
                }
                break;
              }
              case ID_ITEM_GRENADE: {
                GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
                if(grenade->isExhausted() || grenade->isExploded())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  bot->setTouched(
                    ID_ITEM_GRENADE |
                    (bot->getTeamID() == grenade->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), grenade
                  );
                  for(int ct2 = ct-1; ct2 >= 0; ct2--) {
                    GTItem* targetItem = items.getElement(ct2);
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        M3Vector& targetPos = *targetItem;
                        float dx, dy, dz;
                        if(
                          (dx = fabs(targetPos.getX()-item->getX())) >
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          ct2 = -1;
                          continue;
                        }
                        if(
                          (dz = fabs(targetPos.getZ()-item->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-item->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              bot->setHealth(bot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX
                              );
                              bot->setArmor(bot->getArmor()-loss);
                              if(bot->getArmor() < 0) bot->setArmor(0);
                            } else {
                              bot->setHealth(bot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  for(int ct2 = ct+1; ct2 < items.getSize(); ct2++) {
                    GTItem* targetItem = items.getElement(ct2);
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        M3Vector& targetPos = *targetItem;
                        float dx, dy, dz;
                        if(
                          (dx = fabs(targetPos.getX()-item->getX())) >
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          ct2 = items.getSize();
                          continue;
                        }
                        if(
                          (dz = fabs(targetPos.getZ()-item->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-item->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              bot->setHealth(bot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX
                              );
                              bot->setArmor(bot->getArmor()-loss);
                              if(bot->getArmor() < 0) bot->setArmor(0);
                            } else {
                              bot->setHealth(bot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  grenade->setExploded(true);
                }
                break;
              }
              case ID_ITEM_MEDIKIT:
              case ID_ITEM_FOOD:
              case ID_ITEM_ARMOR:
              case ID_ITEM_BULLETS:
              case ID_ITEM_GRENADES:
              {
                GTPowerup* otherP = dynamic_cast<GTPowerup*>(otherItem);
                if(otherP->isExhausted() || !otherP->isActive())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  int id = otherP->getClassID();
                  bot->setTouched(id,otherItem);
                }
                break;
              }
              case ID_ITEM_WEAPON:
              case ID_ITEM_SIGN:
              {
                GTExhaustable* otherP = dynamic_cast<GTExhaustable*>(otherItem);
                if(otherP->isExhausted())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  int id = otherP->getClassID();
                  bot->setTouched(id,otherItem);
                }
                break;
              }
              case ID_ITEM_TARGET:
              {
                GTTarget* target = dynamic_cast<GTTarget*>(otherItem);
                if(target->isExhausted())
                  continue;
                float normalX, normalY, normalZ;
                if(
                  fabs(normalX = (otherPos.getX()-pos.x)) < GTBot::SIZE_X &&
                  fabs(normalZ = (otherPos.getZ()-pos.z)) < GTBot::SIZE_Z &&
                  fabs(normalY = (otherPos.getY()-pos.y)) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  target->setMateID(bot->getMateID());
                  target->setTeamID(bot->getTeamID());
                  bot->setTouched(ID_ITEM_TARGET,otherItem);
                  M3Vector& targetVel = target->getVelocity();
                  M3Vector normal(normalX,normalY,normalZ);
                  const float botSpeed = bot->getLegsSpeed();
                  M3Vector botVel(
                     cos(bot->getLegsAngle().getCurrent())*botSpeed,
                     bot->getVerticalSpeed(),
                    -sin(bot->getLegsAngle().getCurrent())*botSpeed
                  );
                  if(normalY < 0) {
                    normal.setY(0);
                    normal.normalize().scale(
                      cos(bot->getTorsoAngles().getPitch().getCurrent())
                    );
                    normal.setY(
                      sin(bot->getTorsoAngles().getPitch().getCurrent())
                    );
                    M3Vector hitVel = normal;
                    botVel.add(hitVel.scale(bot->getKickSpeed()));
                  } else {
                    normal.normalize();
                  }
                  float dotVN = botVel.subtract(targetVel).dot(normal);
                  if(dotVN > 0)
                  	targetVel.add(normal.scale(2*dotVN));
                }
                break;
              }
            }
          }
          for(int ct = itemCt+1; ct < items.getSize(); ct++) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X*2)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z*2 &&
                  fabs(otherPos.getY()-pos.y) < GTBot::SIZE_Y*2
                ) {
                  int id =
                    ID_ITEM_WARRIOR |
                    (bot->getTeamID() == otherBot->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    );
                  bot->setTouched(id,otherBot);
                  otherBot->setTouched(id,bot);
                  collision = true;
                  if(getPlayIndex() == ID_PLAY_RACE) {
                    if(bot->getHealth() > otherBot->getHealth()) {
                      if(bot->getTeamID() == otherBot->getTeamID())
                        bot->setKilledFriends(bot->getKilledFriends()+1);
                      else
                        bot->setKilledEnemies(bot->getKilledEnemies()+1);
                      otherBot->setHealth(0);
                      otherBot->setHold(NULL);
                      otherBot->forceLegsAttitude(GTBot::LDEATH);
                      otherBot->forceTorsoAttitude(GTBot::TDEATH);
                    } else if(otherBot->getHealth() > bot->getHealth()) {
                      if(otherBot->getTeamID() == bot->getTeamID())
                        otherBot->setKilledFriends(
                          otherBot->getKilledFriends()+1
                        );
                      else
                        otherBot->setKilledEnemies(
                          otherBot->getKilledEnemies()+1
                        );
                      bot->setHealth(0);
                      bot->setHold(NULL);
                      bot->forceLegsAttitude(GTBot::LDEATH);
                      bot->forceTorsoAttitude(GTBot::TDEATH);
                    }
                  }
                }
                break;
              }
              case ID_ITEM_BULLET: {
                GTBullet* bullet = dynamic_cast<GTBullet*>(otherItem);
                if(bullet->isExhausted())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  bot->setTouched(
                    ID_ITEM_BULLET |
                    (bot->getTeamID() == bullet->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), bullet
                  );
                  float loss;
                  if(bot->getArmor()) {
                    loss = GTBot::HEALTH_BULLET*
                      (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX;
                    bot->setArmor(bot->getArmor()-GTBot::HEALTH_BULLET);
                    if(bot->getArmor() < 0) bot->setArmor(0);
                  } else {
                    loss = GTBot::HEALTH_BULLET;
                  }
                  bot->setHealth(bot->getHealth()-loss);
                  if(bot->getHealth() <= 0) {
                    int t = bullet->getTeamID();
                    int m = bullet->getMateID();
                    GTBot* killer = bots.getElement(t*matesCount+m);
                    if(killer->getTeamID() == bot->getTeamID())
                      killer->setKilledFriends(killer->getKilledFriends()+1);
                    else
                      killer->setKilledEnemies(killer->getKilledEnemies()+1);
                    bot->setHealth(0);
                    bot->setHold(NULL);
                    bot->forceLegsAttitude(GTBot::LDEATH);
                    bot->forceTorsoAttitude(GTBot::TDEATH);
                  }
                  bullet->setExhausted(true);
                }
                break;
              }
              case ID_ITEM_GRENADE: {
                GTGrenade* grenade = dynamic_cast<GTGrenade*>(otherItem);
                if(grenade->isExhausted() || grenade->isExploded())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  bot->setTouched(
                    ID_ITEM_GRENADE |
                    (bot->getTeamID() == grenade->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), grenade
                  );
                  for(int ct2 = ct-1; ct2 >= 0; ct2--) {
                    GTItem* targetItem = items.getElement(ct2);
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        M3Vector& targetPos = *targetItem;
                        float dx, dy, dz;
                        if(
                          (dx = fabs(targetPos.getX()-grenade->getX())) >
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          ct2 = -1;
                          continue;
                        }
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              bot->setHealth(bot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX
                              );
                              bot->setArmor(bot->getArmor()-loss);
                              if(bot->getArmor() < 0) bot->setArmor(0);
                            } else {
                              bot->setHealth(bot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  for(int ct2 = ct+1; ct2 < items.getSize(); ct2++) {
                    GTItem* targetItem = items.getElement(ct2);
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        M3Vector& targetPos = *targetItem;
                        float dx, dy, dz;
                        if(
                          (dx = fabs(targetPos.getX()-grenade->getX())) >
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          ct2 = items.getSize();
                          continue;
                        }
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              bot->setHealth(bot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-bot->getArmor())/GTBot::ARMOR_MAX
                              );
                              bot->setArmor(bot->getArmor()-loss);
                              if(bot->getArmor() < 0) bot->setArmor(0);
                            } else {
                              bot->setHealth(bot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  grenade->setExploded(true);
                }
                break;
              }
              case ID_ITEM_MEDIKIT:
              case ID_ITEM_FOOD:
              case ID_ITEM_ARMOR:
              case ID_ITEM_BULLETS:
              case ID_ITEM_GRENADES:
              {
                GTPowerup* otherP = dynamic_cast<GTPowerup*>(otherItem);
                if(otherP->isExhausted() || !otherP->isActive())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  int id = otherP->getClassID();
                  bot->setTouched(id,otherItem);
                }
                break;
              }
              case ID_ITEM_WEAPON:
              case ID_ITEM_SIGN:
              {
                GTExhaustable* otherP = dynamic_cast<GTExhaustable*>(otherItem);
                if(otherP->isExhausted())
                  continue;
                if(
                  fabs(otherPos.getX()-pos.x) < GTBot::SIZE_X &&
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  int id = otherP->getClassID();
                  bot->setTouched(id,otherItem);
                }
                break;
              }
              case ID_ITEM_TARGET:
              {
                GTTarget* target = dynamic_cast<GTTarget*>(otherItem);
                if(target->isExhausted())
                  continue;
                float normalX, normalY, normalZ;
                if(
                  fabs(normalX = (otherPos.getX()-pos.x)) < GTBot::SIZE_X &&
                  fabs(normalZ = (otherPos.getZ()-pos.z)) < GTBot::SIZE_Z &&
                  fabs(normalY = (otherPos.getY()-pos.y)) <
                    (bot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  target->setMateID(bot->getMateID());
                  target->setTeamID(bot->getTeamID());
                  bot->setTouched(ID_ITEM_TARGET,otherItem);
                  M3Vector& targetVel = target->getVelocity();
                  M3Vector normal(normalX,normalY,normalZ);
                  const float botSpeed = bot->getLegsSpeed();
                  M3Vector botVel(
                     cos(bot->getLegsAngle().getCurrent())*botSpeed,
                     bot->getVerticalSpeed(),
                    -sin(bot->getLegsAngle().getCurrent())*botSpeed
                  );
                  if(normalY < 0) {
                    normal.setY(0);
                    normal.normalize().scale(
                      cos(bot->getTorsoAngles().getPitch().getCurrent())
                    );
                    normal.setY(
                      sin(bot->getTorsoAngles().getPitch().getCurrent())
                    );
                    M3Vector hitVel = normal;
                    botVel.add(hitVel.scale(bot->getKickSpeed()));
                  } else {
                    normal.normalize();
                  }
                  float dotVN = botVel.subtract(targetVel).dot(normal);
                  if(dotVN > 0)
                  	targetVel.add(normal.scale(2*dotVN));
                }
                break;
              }
            }
          }
          if(collision && (!bot->isDead())) {
            bot->forceLegsAttitude(GTBot::IDLE);
            bot->setVerticalSpeed(0);
          } else {
            if(getPlayIndex() == ID_PLAY_RACE) {
              M3Vector start = botPos;
              start.normalize();
              M3Vector end(pos.x,pos.y,pos.z);
              end.normalize();
              float increment = start.dot(end);
              if(fabs(increment) > 1)
                increment = increment > 0? 1: -1;
              increment = float(acos(increment)*100*M_1_PI);
              if(start.getZ()*end.getX() < start.getX()*end.getZ()) {
                bot->setHealth(bot->getHealth()-increment);
                if(bot->getHealth() <= 0) {
                  bot->setHealth(0);
                  bot->setHold(NULL);
                  bot->forceLegsAttitude(GTBot::LDEATH);
                  bot->forceTorsoAttitude(GTBot::TDEATH);
                }
              } else {
                bot->setHealth(bot->getHealth()+increment);
              }
            }
            botPos.set(pos.x,pos.y,pos.z);
          }
          break;
        }
        case ID_ITEM_BULLET: {
          GTBullet* bullet = dynamic_cast<GTBullet*>(item);
          if(bullet->isExhausted())
            continue;
          M3Vector& bulletPos = *bullet;
          BSPVector pos(bulletPos.getX(),bulletPos.getY(),bulletPos.getZ());
          M3Vector& bulletVel = bullet->getVelocity();
          BSPVector vel(
            bulletVel.getX()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            bulletVel.getY()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            bulletVel.getZ()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE)
          );
          BSPVector end(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
          bsp->checkCollision(pos,vel);
          if(pos.x != end.x || pos.y != end.y || pos.z != end.z){
            bullet->setExhausted(true);
            continue;
          }
          for(int ct = itemCt-1; ct >= 0; ct--) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  otherBot->setTouched(
                    ID_ITEM_BULLET |
                    (otherBot->getTeamID() == bullet->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), bullet
                  );
                  float loss;
                  if(otherBot->getArmor()) {
                    loss = GTBot::HEALTH_BULLET*
                      (GTBot::ARMOR_MAX-otherBot->getArmor())/GTBot::ARMOR_MAX;
                    otherBot->setArmor(otherBot->getArmor()-GTBot::HEALTH_BULLET);
                    if(otherBot->getArmor() < 0) otherBot->setArmor(0);
                  } else {
                    loss = GTBot::HEALTH_BULLET;
                  }
                  otherBot->setHealth(otherBot->getHealth()-loss);
                  if(otherBot->getHealth() <= 0) {
                    int t = bullet->getTeamID();
                    int m = bullet->getMateID();
                    GTBot* killer = bots.getElement(t*matesCount+m);
                    if(killer->getTeamID() == otherBot->getTeamID())
                      killer->setKilledFriends(killer->getKilledFriends()+1);
                    else
                      killer->setKilledEnemies(killer->getKilledEnemies()+1);
                    otherBot->setHealth(0);
                    otherBot->setHold(NULL);
                    otherBot->forceLegsAttitude(GTBot::LDEATH);
                    otherBot->forceTorsoAttitude(GTBot::TDEATH);
                  }
                  bullet->setExhausted(true);
                  ct = -1; // exit
                }
                break;
              }
            }
          }
          for(int ct = itemCt+1; ct < items.getSize(); ct++) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  otherBot->setTouched(
                    ID_ITEM_BULLET |
                    (otherBot->getTeamID() == bullet->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), bullet
                  );
                  float loss;
                  if(otherBot->getArmor()) {
                    loss = GTBot::HEALTH_BULLET*
                      (GTBot::ARMOR_MAX-otherBot->getArmor())/GTBot::ARMOR_MAX;
                    otherBot->setArmor(otherBot->getArmor()-GTBot::HEALTH_BULLET);
                    if(otherBot->getArmor() < 0) otherBot->setArmor(0);
                  } else {
                    loss = GTBot::HEALTH_BULLET;
                  }
                  otherBot->setHealth(otherBot->getHealth()-loss);
                  if(otherBot->getHealth() <= 0) {
                    int t = bullet->getTeamID();
                    int m = bullet->getMateID();
                    GTBot* killer = bots.getElement(t*matesCount+m);
                    if(killer->getTeamID() == otherBot->getTeamID())
                      killer->setKilledFriends(killer->getKilledFriends()+1);
                    else
                      killer->setKilledEnemies(killer->getKilledEnemies()+1);
                    otherBot->setHealth(0);
                    otherBot->setHold(NULL);
                    otherBot->forceLegsAttitude(GTBot::LDEATH);
                    otherBot->forceTorsoAttitude(GTBot::TDEATH);
                  }
                  bullet->setExhausted(true);
                  ct = items.getSize(); // exit
                }
                break;
              }
            }
          }
          bulletPos.set(pos.x,pos.y,pos.z);
          break;
        }
        case ID_ITEM_GRENADE: {
          GTGrenade* grenade = dynamic_cast<GTGrenade*>(item);
          if(grenade->isExhausted())
            continue;
          grenade->setCountdown(
            grenade->getCountdown()-GTBotBrain::SIMULATION_TIME_STEP
          );
          if(grenade->getCountdown() <= 0) {
            if(grenade->isExploded()) {
              grenade->setExhausted(true);
            } else {
              for(int ct2 = itemCt-1; ct2 >= 0; ct2--) {
                GTItem* targetItem = items.getElement(ct2);
                M3Vector& targetPos = *targetItem;
                float dx, dy, dz;
                if(
                  (dx = fabs(targetPos.getX()-grenade->getX())) >
                  WEAPON_GRENADE_RANGE_MAX_BSP
                ) break;
                switch(targetItem->getClassID()) {
                  case ID_ITEM_WARRIOR: {
                    GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                    if(targetBot->isDead())
                      continue;
                    if(
                      (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                      WEAPON_GRENADE_RANGE_MAX_BSP &&
                      (dy = fabs(targetPos.getY()-grenade->getY())) <
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) {
                      float dist2 = dx*dx+dy*dy+dz*dz;
                      if(
                        dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                      ) {
                        float loss =
                          GTBot::HEALTH_GRENADE_MAX*
                          (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                          /WEAPON_GRENADE_RANGE_MAX_BSP2;
                        if(targetBot->getArmor()) {
                          targetBot->setHealth(targetBot->getHealth()-loss*
                            (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                          );
                          targetBot->setArmor(targetBot->getArmor()-loss);
                          if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                        } else {
                          targetBot->setHealth(targetBot->getHealth()-loss);
                        }
                        if(targetBot->getHealth() <= 0) {
                          int t = grenade->getTeamID();
                          int m = grenade->getMateID();
                          GTBot* killer = bots.getElement(t*matesCount+m);
                          if(killer->getTeamID() == targetBot->getTeamID())
                            killer->setKilledFriends(
                              killer->getKilledFriends()+1
                            );
                          else
                            killer->setKilledEnemies(
                              killer->getKilledEnemies()+1
                            );
                          targetBot->setHealth(0);
                          targetBot->setHold(NULL);
                          targetBot->forceLegsAttitude(GTBot::LDEATH);
                          targetBot->forceTorsoAttitude(GTBot::TDEATH);
                        }
                      }
                    }
                    break;
                  }
                }
              }
              for(int ct2 = itemCt+1; ct2 < items.getSize(); ct2++) {
                GTItem* targetItem = items.getElement(ct2);
                M3Vector& targetPos = *targetItem;
                float dx, dy, dz;
                if(
                  (dx = fabs(targetPos.getX()-grenade->getX())) >
                  WEAPON_GRENADE_RANGE_MAX_BSP
                ) break;
                switch(targetItem->getClassID()) {
                  case ID_ITEM_WARRIOR: {
                    GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                    if(targetBot->isDead())
                      continue;
                    if(
                      (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                      WEAPON_GRENADE_RANGE_MAX_BSP &&
                      (dy = fabs(targetPos.getY()-grenade->getY())) <
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) {
                      float dist2 = dx*dx+dy*dy+dz*dz;
                      if(
                        dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                      ) {
                        float loss =
                          GTBot::HEALTH_GRENADE_MAX*
                          (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                          /WEAPON_GRENADE_RANGE_MAX_BSP2;
                        if(targetBot->getArmor()) {
                          targetBot->setHealth(targetBot->getHealth()-loss*
                            (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                          );
                          targetBot->setArmor(targetBot->getArmor()-loss);
                          if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                        } else {
                          targetBot->setHealth(targetBot->getHealth()-loss);
                        }
                        if(targetBot->getHealth() <= 0) {
                          int t = grenade->getTeamID();
                          int m = grenade->getMateID();
                          GTBot* killer = bots.getElement(t*matesCount+m);
                          if(killer->getTeamID() == targetBot->getTeamID())
                            killer->setKilledFriends(
                              killer->getKilledFriends()+1
                            );
                          else
                            killer->setKilledEnemies(
                              killer->getKilledEnemies()+1
                            );
                          targetBot->setHealth(0);
                          targetBot->setHold(NULL);
                          targetBot->forceLegsAttitude(GTBot::LDEATH);
                          targetBot->forceTorsoAttitude(GTBot::TDEATH);
                        }
                      }
                    }
                    break;
                  }
                }
              }
              grenade->setExploded(true);
            }
            continue;
          }
          if(grenade->isExploded())
            continue;
          M3Vector& grenadePos = *grenade;
          BSPVector pos(grenadePos.getX(),grenadePos.getY(),grenadePos.getZ());
          M3Vector& grenadeVel = grenade->getVelocity();
          grenadeVel.setY(grenadeVel.getY()+
            GTBotBrain::SIMULATION_TIME_STEP*GTArena::WORLD_GRAVITY
          );
          BSPVector vel(
            grenadeVel.getX()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            grenadeVel.getY()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            grenadeVel.getZ()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE)
          );
          BSPVector end(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
          bsp->checkCollision(pos,vel);
          if(pos.x != end.x || pos.y != end.y || pos.z != end.z) {
            BSPVector& normal = bsp->getCollisionNormal();
            grenadeVel.scale(GTArena::GROUND_RESTITUTION);
            float velDotNorm2 = -2*(
              grenadeVel.getX()*normal.x+
              grenadeVel.getY()*normal.y+
              grenadeVel.getZ()*normal.z
            );
            grenadeVel.set(
              grenadeVel.getX()+velDotNorm2*normal.x,
              grenadeVel.getY()+velDotNorm2*normal.y,
              grenadeVel.getZ()+velDotNorm2*normal.z
            );
            pos.y += 0.001f*BSP_SCENE_SCALE;
          }
          for(int ct = itemCt-1; ct >= 0; ct--) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  otherBot->setTouched(
                    ID_ITEM_GRENADE |
                    (otherBot->getTeamID() == grenade->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), grenade
                  );
                  for(int ct2 = itemCt-1; ct2 >= 0; ct2--) {
                    GTItem* targetItem = items.getElement(ct2);
                    M3Vector& targetPos = *targetItem;
                    float dx, dy, dz;
                    if(
                      (dx = fabs(targetPos.getX()-grenade->getX())) >
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) break;
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              targetBot->setHealth(targetBot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                              );
                              targetBot->setArmor(targetBot->getArmor()-loss);
                              if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                            } else {
                              targetBot->setHealth(targetBot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  for(int ct2 = itemCt+1; ct2 < items.getSize(); ct2++) {
                    GTItem* targetItem = items.getElement(ct2);
                    M3Vector& targetPos = *targetItem;
                    float dx, dy, dz;
                    if(
                      (dx = fabs(targetPos.getX()-grenade->getX())) >
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) break;
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              targetBot->setHealth(targetBot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                              );
                              targetBot->setArmor(targetBot->getArmor()-loss);
                              if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                            } else {
                              targetBot->setHealth(targetBot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  grenade->setExploded(true);
                  ct = -1; // exit
                }
                break;
              }
            }
          }
          for(int ct = itemCt+1; ct < items.getSize(); ct++) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            if(fabs(otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  otherBot->setTouched(
                    ID_ITEM_GRENADE |
                    (otherBot->getTeamID() == grenade->getTeamID()?
                      ID_ITEM_FRIEND: ID_ITEM_ENEMY
                    ), grenade
                  );
                  for(int ct2 = itemCt-1; ct2 >= 0; ct2--) {
                    GTItem* targetItem = items.getElement(ct2);
                    M3Vector& targetPos = *targetItem;
                    float dx, dy, dz;
                    if(
                      (dx = fabs(targetPos.getX()-grenade->getX())) >
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) break;
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              targetBot->setHealth(targetBot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                              );
                              targetBot->setArmor(targetBot->getArmor()-loss);
                              if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                            } else {
                              targetBot->setHealth(targetBot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  for(int ct2 = itemCt+1; ct2 < items.getSize(); ct2++) {
                    GTItem* targetItem = items.getElement(ct2);
                    M3Vector& targetPos = *targetItem;
                    float dx, dy, dz;
                    if(
                      (dx = fabs(targetPos.getX()-grenade->getX())) >
                      WEAPON_GRENADE_RANGE_MAX_BSP
                    ) break;
                    switch(targetItem->getClassID()) {
                      case ID_ITEM_WARRIOR: {
                        GTBot* targetBot = dynamic_cast<GTBot*>(targetItem);
                        if(targetBot->isDead())
                          continue;
                        if(
                          (dz = fabs(targetPos.getZ()-grenade->getZ())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP &&
                          (dy = fabs(targetPos.getY()-grenade->getY())) <
                          WEAPON_GRENADE_RANGE_MAX_BSP
                        ) {
                          float dist2 = dx*dx+dy*dy+dz*dz;
                          if(
                            dist2 < WEAPON_GRENADE_RANGE_MAX_BSP2
                          ) {
                            float loss =
                              GTBot::HEALTH_GRENADE_MAX*
                              (WEAPON_GRENADE_RANGE_MAX_BSP2-dist2)
                              /WEAPON_GRENADE_RANGE_MAX_BSP2;
                            if(targetBot->getArmor()) {
                              targetBot->setHealth(targetBot->getHealth()-loss*
                                (GTBot::ARMOR_MAX-targetBot->getArmor())/GTBot::ARMOR_MAX
                              );
                              targetBot->setArmor(targetBot->getArmor()-loss);
                              if(targetBot->getArmor() < 0) targetBot->setArmor(0);
                            } else {
                              targetBot->setHealth(targetBot->getHealth()-loss);
                            }
                            if(targetBot->getHealth() <= 0) {
                              int t = grenade->getTeamID();
                              int m = grenade->getMateID();
                              GTBot* killer = bots.getElement(t*matesCount+m);
                              if(killer->getTeamID() == targetBot->getTeamID())
                                killer->setKilledFriends(
                                  killer->getKilledFriends()+1
                                );
                              else
                                killer->setKilledEnemies(
                                  killer->getKilledEnemies()+1
                                );
                              targetBot->setHealth(0);
                              targetBot->setHold(NULL);
                              targetBot->forceLegsAttitude(GTBot::LDEATH);
                              targetBot->forceTorsoAttitude(GTBot::TDEATH);
                            }
                          }
                        }
                        break;
                      }
                    }
                  }
                  grenade->setExploded(true);
                  ct = items.getSize(); // exit
                }
                break;
              }
            }
          }
          grenadePos.set(pos.x,pos.y,pos.z);
          break;
        }
        case ID_ITEM_MEDIKIT:
        case ID_ITEM_FOOD:
        case ID_ITEM_ARMOR:
        case ID_ITEM_BULLETS:
        case ID_ITEM_GRENADES:
        {
          GTPowerup* p = dynamic_cast<GTPowerup*>(item);
          if(p->isExhausted() || p->cantRespawn())
            continue;
          p->setRespawnCountdown(p->getRespawnCountdown()-GTBotBrain::SIMULATION_TIME_STEP);
          if(p->getRespawnCountdown() < 0)
            p->setRespawnCountdown(0);
          break;
        }
        case ID_ITEM_TARGET:
        {
          GTTarget* target = dynamic_cast<GTTarget*>(item);
          if(target->isExhausted())
            continue;
          if(target->getCountdown() > 0) {
            target->setCountdown(
              target->getCountdown()-GTBotBrain::SIMULATION_TIME_STEP
            );
          }
          M3Vector& targetPos = *target;
          BSPVector pos(targetPos.getX(),targetPos.getY(),targetPos.getZ());
          M3Vector& targetVel = target->getVelocity();
          targetVel.setY(targetVel.getY()+
            GTBotBrain::SIMULATION_TIME_STEP*GTArena::WORLD_GRAVITY
          );
         	float targetSpeed = targetVel.norm2();
         	if(targetSpeed > GTTarget::MAX_SPEED*GTTarget::MAX_SPEED)
	       		targetVel.normalize().scale(GTTarget::MAX_SPEED);
          BSPVector vel(
            targetVel.getX()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            targetVel.getY()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE),
            targetVel.getZ()*(GTBotBrain::SIMULATION_TIME_STEP*BSP_SCENE_SCALE)
          );
          BSPVector end(pos.x+vel.x,pos.y+vel.y,pos.z+vel.z);
          bsp->checkCollision(pos,vel,targetExtent);
          if(pos.x != end.x || pos.y != end.y || pos.z != end.z) {
            BSPVector& normal = bsp->getCollisionNormal();
            targetVel.scale(GTArena::GROUND_RESTITUTION);
            float velDotNorm2 = -2*(
              targetVel.getX()*normal.x+
              targetVel.getY()*normal.y+
              targetVel.getZ()*normal.z
            );
            targetVel.set(
              targetVel.getX()+velDotNorm2*normal.x,
              targetVel.getY()+velDotNorm2*normal.y,
              targetVel.getZ()+velDotNorm2*normal.z
            );
	          pos.y += 0.0025f*BSP_SCENE_SCALE;
          }
          if(pos.y < 0)
          	pos.y = 1.0f*BSP_SCENE_SCALE;
          for(int ct = itemCt-1; ct >= 0; ct--) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            float normalX, normalY, normalZ;
            if(fabs(normalX = otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(normalZ = otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(normalY = otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  GTTarget* target = dynamic_cast<GTTarget*>(item);
                  target->setMateID(otherBot->getMateID());
                  target->setTeamID(otherBot->getTeamID());
                  otherBot->setTouched(ID_ITEM_TARGET,target);
                  M3Vector& targetVel = target->getVelocity();
                  M3Vector normal(normalX,normalY,normalZ);
                  const float botSpeed = otherBot->getLegsSpeed();
                  M3Vector botVel(
                     cos(otherBot->getLegsAngle().getCurrent())*botSpeed,
                     otherBot->getVerticalSpeed(),
                    -sin(otherBot->getLegsAngle().getCurrent())*botSpeed
                  );
                  if(normalY < 0) {
                    normal.setY(0);
                    normal.normalize().scale(
                      cos(otherBot->getTorsoAngles().getPitch().getCurrent())
                    );
                    normal.setY(
                      sin(otherBot->getTorsoAngles().getPitch().getCurrent())
                    );
                    M3Vector hitVel = normal;
                    botVel.add(hitVel.scale(otherBot->getKickSpeed()));
                  } else {
                    normal.normalize();
                  }
                  float dotVN = botVel.subtract(targetVel).dot(normal);
                  if(dotVN > 0)
                    targetVel.add(normal.scale(2*dotVN));
                  ct = -1; // exit
                }
                break;
              }
            }
          }
          for(int ct = itemCt+1; ct < items.getSize(); ct++) {
            GTItem* otherItem = items.getElement(ct);
            M3Vector& otherPos = *otherItem;
            float normalX, normalY, normalZ;
            if(fabs(normalX = otherPos.getX()-pos.x) > GTBot::SIZE_X)
              break;
            switch(otherItem->getClassID()) {
              case ID_ITEM_WARRIOR: {
                GTBot* otherBot = dynamic_cast<GTBot*>(otherItem);
                if(otherBot->isDead())
                  continue;
                if(
                  fabs(normalZ = otherPos.getZ()-pos.z) < GTBot::SIZE_Z &&
                  fabs(normalY = otherPos.getY()-pos.y) <
                    (otherBot->isCrouched()? GTBot::SIZE_Y_CROUCHED: GTBot::SIZE_Y)
                ) {
                  GTTarget* target = dynamic_cast<GTTarget*>(item);
                  target->setMateID(otherBot->getMateID());
                  target->setTeamID(otherBot->getTeamID());
                  otherBot->setTouched(ID_ITEM_TARGET,target);
                  M3Vector& targetVel = target->getVelocity();
                  M3Vector normal(normalX,normalY,normalZ);
                  const float botSpeed = otherBot->getLegsSpeed();
                  M3Vector botVel(
                     cos(otherBot->getLegsAngle().getCurrent())*botSpeed,
                     otherBot->getVerticalSpeed(),
                    -sin(otherBot->getLegsAngle().getCurrent())*botSpeed
                  );
                  if(normalY < 0) {
                    normal.setY(0);
                    normal.normalize().scale(
                      cos(otherBot->getTorsoAngles().getPitch().getCurrent())
                    );
                    normal.setY(
                      sin(otherBot->getTorsoAngles().getPitch().getCurrent())
                    );
                    M3Vector hitVel = normal;
                    botVel.add(hitVel.scale(otherBot->getKickSpeed()));
                  } else {
                    normal.normalize();
                  }
                  float dotVN = botVel.subtract(targetVel).dot(normal);
                  if(dotVN > 0)
                    targetVel.add(normal.scale(2*dotVN));
                  ct = items.getSize(); // exit
                }
                break;
              }
            }
          }
          targetPos.set(pos.x,pos.y,pos.z);
          const float RADIUS = GTArena::GOAL_SIZE*BSP_SCENE_SCALE*0.5f;
          const float RADIUS2 = RADIUS*RADIUS;
          for(int ct = 0; ct < teamsCount; ct++) {
            BSPVector& theGoal = bsp->getStartingPosition(corner[ct]);
            float dx = targetPos.getX()-theGoal.x;
            float dy = targetPos.getY()-theGoal.y;
            float dz = targetPos.getZ()-theGoal.z;
            if(RADIUS2 >= dx*dx+dy*dy+dz*dz) {
              target->setCountdown(2*GTWeapon::GRENADE_EXPL_DELAY);
              GTGrenade* grenade = NULL;
              for(
                int itemCt2 = 0; !grenade && itemCt2 < items.getSize(); itemCt2++
              ) {
                GTItem* item2 = items.getElement(itemCt2);
                if(item2) {
                  switch(item2->getClassID()) {
                    case ID_ITEM_GRENADE: {
                      GTGrenade* theGrenade = dynamic_cast<GTGrenade*>(item2);
                      if(!theGrenade->isExhausted())
                        continue;
                      theGrenade->setExhausted(false);
                      grenade = theGrenade;
                      break;
                    }
                    default:
                      break;
                  }
                }
              }
              if(!grenade) {
                grenade = new GTGrenade();
                items.addElement(dynamic_cast<DSSortableObject*>(grenade));
              }
              M3Vector& vel = target->getVelocity();
              grenade->getVelocity().set(vel.getX(),vel.getY(),vel.getZ());
              grenade->set(target->getX(),target->getY(),target->getZ());
              grenade->setCountdown(GTWeapon::GRENADE_EXPL_DELAY);
              grenade->setTeamID(target->getTeamID());
              grenade->setMateID(target->getMateID());
              target->set(0,2*(2*GTBot::SIZE_Y),0);
              target->getVelocity().set(0,0,0);
              const int OFFSET = matesCount*ct;
              int nearest = -1;
              float minDist2 = 4*ARENA_SIZE*ARENA_SIZE;
              for(int botCt = OFFSET; botCt < OFFSET+matesCount; botCt++) {
                GTBot* theBot = getBot(botCt);
                if(!theBot->isDead()) {
                  float dx = theBot->getX()-theGoal.x;
                  float dy = theBot->getY()-theGoal.y;
                  float dz = theBot->getZ()-theGoal.z;
                  float dist2 = dx*dx+dy*dy+dz*dz;
                  if(minDist2 > dist2) {
                    minDist2 = dist2;
                    nearest = botCt;
                  }
                }
              }
              if(nearest >= 0) {
                int t = target->getTeamID();
                int m = target->getMateID();
                GTBot* killer = bots.getElement(t*matesCount+m);
                GTBot* theBot = getBot(nearest);
                if(killer->getTeamID() == theBot->getTeamID())
                  killer->setKilledFriends(killer->getKilledFriends()+1);
                else
                  killer->setKilledEnemies(killer->getKilledEnemies()+1);
                theBot->setHealth(0);
                theBot->setHold(NULL);
                theBot->forceLegsAttitude(GTBot::LDEATH);
                theBot->forceTorsoAttitude(GTBot::TDEATH);
              }
              break;
            }
          }
          break;
        }
      }
    }
  }
  for(int itemCt = 0; itemCt < items.getSize(); itemCt++) {
    GTItem* item = items.getElement(itemCt);
    if(item) {
      switch(item->getClassID()) {
        case ID_ITEM_WARRIOR: {
          GTBot* bot = dynamic_cast<GTBot*>(item);
          if(bot->isDead() || !bot->isShooting())
            continue;
          bot->setShooting(false);
          switch(bot->getShootingWhat()) {
            case ID_ITEM_BULLET: {
              GTBullet* bullet = NULL;
              bot->getWeapon()->setBulletsCount(bot->getBulletsCount()-1);
              for(
                int itemCt2 = 0; !bullet && itemCt2 < items.getSize(); itemCt2++
              ) {
                GTItem* item2 = items.getElement(itemCt2);
                if(item2) {
                  switch(item2->getClassID()) {
                    case ID_ITEM_BULLET: {
                      GTBullet* theBullet = dynamic_cast<GTBullet*>(item2);
                      if(!theBullet->isExhausted())
                        continue;
                      theBullet->setExhausted(false);
                      bullet = theBullet;
                      break;
                    }
                    default:
                      break;
                  }
                }
              }
              if(!bullet) {
                bullet = new GTBullet();
                items.addElement(dynamic_cast<DSSortableObject*>(bullet));
              }
              float yaw = bot->getLegsAngle().getCurrent()+
                bot->getTorsoAngles().getYaw().getCurrent();
              float pitch = bot->getTorsoAngles().getPitch().getCurrent();
              float cosPitch = cos(pitch);
              bullet->getVelocity().set(
                cosPitch*cos(yaw),sin(pitch),-cosPitch*sin(yaw)
              );
              M3Vector& botPos = *bot;
              bullet->set(
                botPos.getX()+bullet->getVelocity().getX()*GTWeapon::LENGTH,
                bot->getWeaponY()+bullet->getVelocity().getY()*GTWeapon::LENGTH,
                botPos.getZ()+bullet->getVelocity().getZ()*GTWeapon::LENGTH
              );
              bullet->getVelocity().scale(GTWeapon::BULLET_SPEED);
              float botSpeed = bot->getLegsSpeed();
              if(botSpeed) {
                bullet->getVelocity().add(
                   cos(bot->getLegsAngle().getCurrent())*botSpeed,
                   bot->getVerticalSpeed()*BSP_SCENE_SCALE_INV,
                  -sin(bot->getLegsAngle().getCurrent())*botSpeed
                );
              }
              bullet->setTeamID(bot->getTeamID());
              bullet->setMateID(bot->getMateID());
              break;
            }
            case ID_ITEM_GRENADE: {
              GTGrenade* grenade = NULL;
              bot->getWeapon()->setGrenadesCount(bot->getGrenadesCount()-1);
              for(
                int itemCt2 = 0; !grenade && itemCt2 < items.getSize(); itemCt2++
              ) {
                GTItem* item2 = items.getElement(itemCt2);
                if(item2) {
                  switch(item2->getClassID()) {
                    case ID_ITEM_GRENADE: {
                      GTGrenade* theGrenade = dynamic_cast<GTGrenade*>(item2);
                      if(!theGrenade->isExhausted())
                        continue;
                      theGrenade->setExhausted(false);
                      grenade = theGrenade;
                      break;
                    }
                    default:
                      break;
                  }
                }
              }
              if(!grenade) {
                grenade = new GTGrenade();
                items.addElement(dynamic_cast<DSSortableObject*>(grenade));
              }
              float yaw = bot->getLegsAngle().getCurrent()+
                bot->getTorsoAngles().getYaw().getCurrent();
              float pitch = bot->getTorsoAngles().getPitch().getCurrent();
              float cosPitch = cos(pitch);
              grenade->getVelocity().set(
                cosPitch*cos(yaw),sin(pitch),-cosPitch*sin(yaw)
              );
              M3Vector& botPos = *bot;
              grenade->set(
                botPos.getX()+grenade->getVelocity().getX()*GTWeapon::LENGTH,
                bot->getWeaponY()+grenade->getVelocity().getY()*GTWeapon::LENGTH,
                botPos.getZ()+grenade->getVelocity().getZ()*GTWeapon::LENGTH
              );
              grenade->getVelocity().scale(GTWeapon::GRENADE_SPEED);
              float botSpeed = bot->getLegsSpeed();
              if(botSpeed) {
                grenade->getVelocity().add(
                   cos(bot->getLegsAngle().getCurrent())*botSpeed,
                   bot->getVerticalSpeed()*BSP_SCENE_SCALE_INV,
                  -sin(bot->getLegsAngle().getCurrent())*botSpeed
                );
              }
              grenade->setTeamID(bot->getTeamID());
              grenade->setMateID(bot->getMateID());
              break;
            }
          }
          break;
        }
      }
    }
  }
  if(getPlayIndex() == ID_PLAY_RACE) {
    float maxHealth = 0;
    for(int ct = 0; ct < getBotsSize(); ct++) {
      GTBot* bot = bots.getElement(ct);
      if(bot->isDead())
        continue;
      if(bot->getHealth() > maxHealth)
        maxHealth = bot->getHealth();
    }
    if(maxHealth > GTBot::HEALTH_MAX) {
      float decrement = maxHealth - GTBot::HEALTH_MAX;
      for(int ct = 0; ct < getBotsSize(); ct++) {
        GTBot* bot = bots.getElement(ct);
        float health = bot->getHealth()-decrement;
        if(health <= 0) {
          bot->setHealth(0);
          bot->setHold(NULL);
          bot->forceLegsAttitude(GTBot::LDEATH);
          bot->forceTorsoAttitude(GTBot::TDEATH);
        } else {
          bot->setHealth(health);
        }
      }
    }
  }
  if(winner >= 0)
    return -2;
  if(realTime >= matchDuration)
    return winner = 4;
  switch(goalIndex) {
    case ID_GOAL_TERMINATE_CHIEF: {
      int aliveAdder = 0;
      int deadAdder = 0;
      for(int ct = 0; ct < teamsCount; ct++) {
        if(bots.getElement(ct*matesCount)->isDead())
          deadAdder += ct;
        else if((++aliveAdder) >= 2)
          return -1;
      }
      winner = aliveAdder == 1? (teamsCount*(teamsCount-1)/2-deadAdder): 4;
      return winner;
    }
    case ID_GOAL_TERMINATE_TEAM: {
      int aliveAdder = 0;
      int deadAdder = 0;
      for(int ct = 0; ct < teamsCount; ct++) {
        int offset = ct*matesCount;
        int m;
        for(m = 0; m < matesCount; m++) {
          if(!bots.getElement(offset+m)->isDead()) {
            if((++aliveAdder) == 2)
              return -1;
            break;
          }
        }
        if(m == matesCount)
          deadAdder += ct;
      }
      winner = aliveAdder == 1? (teamsCount*(teamsCount-1)/2-deadAdder): 4;
      return winner;
    }
    case ID_GOAL_CAPTURE_SIGN: {
      int aliveAdder = 0;
      int deadAdder = 0;
      for(int ct = 0; ct < teamsCount; ct++) {
        int offset = ct*matesCount;
        int m;
        for(m = 0; m < matesCount; m++) {
          if(!bots.getElement(offset+m)->isDead()) {
            if((++aliveAdder) == 2) {
              GTSign* sign = signs.getElement(0);
              if(!sign->isOwned())
                return -1;
              int lastOwner = sign->getOwner()->getTeamID();
              for(int ct = 1; ct < teamsCount; ct++) {
                sign = signs.getElement(ct);
                if(!sign->isOwned())
                  return -1;
                if(sign->getOwner()->getTeamID() != lastOwner)
                  return -1;
              }
              return winner = lastOwner;
            }
            break;
          }
        }
        if(m == matesCount)
          deadAdder += ct;
      }
      winner = aliveAdder == 1? (teamsCount*(teamsCount-1)/2-deadAdder): 4;
      return winner;
    }
  }
}
