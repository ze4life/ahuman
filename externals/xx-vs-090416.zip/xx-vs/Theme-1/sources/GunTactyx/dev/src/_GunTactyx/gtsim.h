#ifndef GTSIM_H
#define GTSIM_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "apocalyx/slinterpreter.h"
#include "apocalyx/glteams.h"
#include "apocalyx/glbsp.h"

enum SimulationConstants {
  I_BOT_MEMORY_SIZE = 0,
  I_BOT_CPU_FREQUENCY,
  I_SIMULATION_TIME_STEP,
  I_POWERUP_MEDIKIT_VALUE_INIT,
  I_POWERUP_FOOD_VALUE_INIT,
  I_POWERUP_ARMOR_VALUE_INIT,
  I_POWERUP_BULLETS_VALUE_INIT,
  I_POWERUP_GRENADES_VALUE_INIT,
  I_POWERUP_MEDIKIT_RESPAWN_TIME,
  I_POWERUP_FOOD_RESPAWN_TIME,
  I_POWERUP_ARMOR_RESPAWN_TIME,
  I_POWERUP_BULLETS_RESPAWN_TIME,
  I_POWERUP_GRENADES_RESPAWN_TIME,
  I_BOT_SIZE_X,
  I_BOT_SIZE_Y,
  I_BOT_SIZE_Y_CROUCHED,
  I_BOT_SIZE_Z,
  I_BOT_SPACING,
  I_BOT_TIME_LOST_TO_SIGHT,
  I_BOT_TIME_LOST_TO_AIM,
  I_BOT_TIME_LOST_TO_HEAR,
  I_BOT_TIME_LOST_TO_WATCH,
  I_BOT_TIME_LOST_TO_LISTEN,
  I_BOT_TIME_NEEDED_TO_SAY,
  I_BOT_TIME_NEEDED_TO_SPEAK,
  I_BOT_TIME_NEEDED_TO_MOVE,
  I_BOT_TIME_NEEDED_TO_DROP,
  I_BOT_TIME_NEEDED_TO_SHOOT,
  I_BOT_KICK_SPEED_MAX,
  I_BOT_SPEED_VERTICAL_MAX,
  I_BOT_SPEED_ROTATION,
  I_BOT_SPEED_WALKCR,
  I_BOT_SPEED_WALKBK,
  I_BOT_SPEED_WALK,
  I_BOT_SPEED_RUN,
  I_BOT_ENERGY_MAX,
  I_BOT_ENERGY_INIT,
  I_BOT_ENERGY_RUN,
  I_BOT_ENERGY_STAND,
  I_BOT_ENERGY_DROP_MAX,
  I_BOT_HEALTH_MAX,
  I_BOT_HEALTH_INIT,
  I_BOT_HEALTH_BULLET,
  I_BOT_HEALTH_GRENADE_MAX,
  I_BOT_HEALTH_DROP_MAX,
  I_BOT_ARMOR_MAX,
  I_BOT_ARMOR_INIT,
  I_BOT_ARMOR_DROP_MAX,
  I_BOT_TORSO_YAW_MAX,
  I_BOT_TORSO_YAW_MIN,
  I_BOT_TORSO_PITCH_MAX,
  I_BOT_TORSO_PITCH_MIN,
  I_BOT_TORSO_SPEED_ROT,
  I_BOT_HEAD_YAW_MAX,
  I_BOT_HEAD_YAW_MIN,
  I_BOT_HEAD_PITCH_MAX,
  I_BOT_HEAD_PITCH_MIN,
  I_BOT_HEAD_SPEED_ROT,
  I_BOT_HEAD_ANGLE_OF_VIEW,
  I_BOT_SENSORS_DISTANCE_MAX,
  I_WEAPON_LENGTH,
  I_WEAPON_HEIGHT,
  I_WEAPON_BULLET_SPEED,
  I_WEAPON_BULLET_LOAD_MAX,
  I_WEAPON_BULLET_LOAD_INIT,
  I_WEAPON_BULLET_DROP_MAX,
  I_WEAPON_GRENADE_SPEED,
  I_WEAPON_GRENADE_EXPL_DELAY,
  I_WEAPON_GRENADE_EXPL_DURATION,
  I_WEAPON_GRENADE_RANGE_MAX,
  I_WEAPON_GRENADE_LOAD_MAX,
  I_WEAPON_GRENADE_LOAD_INIT,
  I_WEAPON_GRENADE_DROP_MAX,
  I_WORLD_GRAVITY,
  I_ARENA_SIZE,
  I_GOAL_SIZE,
  I_TARGET_SIZE,
  I_TARGET_MAX_SPEED,
  I_GROUND_RESTITUTION,
};

//
// GTBotBrain
//
class GTBotBrain: public SLInterpreter {
public:
  static int MEMORY_SIZE;
  static int CPU_FREQUENCY;
  static float SIMULATION_TIME_STEP;
protected:
  int timerCountdown;
  int ticksCount;
public:
  GTBotBrain();
  bool load(char* scriptName, unsigned int randomSeed = 0);
  static void decreaseTimer(int ticks) {amx_timer -= ticks;}
  int execute() {
    if(!isRunning())
      return AMX_ERR_NONE;
    int ticks = int(GTBotBrain::SIMULATION_TIME_STEP*CPU_FREQUENCY+0.5f);
    ticksCount += ticks;
    timerCountdown += ticks;
    if(timerCountdown < 0) {
      return AMX_ERR_SLEEP;
    } else {
      int ret = execMain(timerCountdown);
      timerCountdown = amx_timer+1;
      return ret;
    }
  }
  int getTicksCount() {return ticksCount;}
};

//
// GTAngle
//
class GTAngle {
private:
  float currentAngle;
  float requiredAngle;
  float rotationSpeed;
public:
  GTAngle();
  float getCurrent() {return currentAngle;}
  void setCurrent(float c) {currentAngle = c;}
  void addCurrent(float c) {currentAngle += c;}
  float getRequired() {return requiredAngle;}
  void setRequired(float r) {requiredAngle = r;}
  void addRequired(float r) {requiredAngle += r;}
  float getSpeed() {return rotationSpeed;}
  void setSpeed(float s) {rotationSpeed = s;}
  void updateAngle() {
    float diff = getRequired()-getCurrent();
    if(diff) {
      float rotAngle = GTBotBrain::SIMULATION_TIME_STEP*getSpeed();
      if(diff > 0) {
        if(rotAngle > diff) rotAngle = diff;
        addCurrent(rotAngle);
      } else {
        if(-rotAngle < diff) rotAngle = -diff;
        addCurrent(-rotAngle);
      }
    }
  }
};

//
// GTYawPitchAngle
//
class GTYawPitchAngles {
private:
  GTAngle yawAngle;
  GTAngle pitchAngle;
public:
  GTAngle& getYaw() {return yawAngle;}
  GTAngle& getPitch() {return pitchAngle;}
  void setSpeed(float s) {yawAngle.setSpeed(s); pitchAngle.setSpeed(s);}
  void updateAngles() {
    yawAngle.updateAngle();
    pitchAngle.updateAngle();
  }
};

//
// GTItem
//
#define ID_ACTION_MOVE   0
#define ID_ACTION_DROP   1
#define ID_ACTION_SHOOT  2
#define ID_ACTION_SAY    3
#define ID_ACTION_HEAR   4
#define ID_ACTION_SIGHT  5
#define ID_ACTION_AIM    6
#define ID_ACTION_WATCH  7
#define ID_ACTION_SPEAK  8
#define ID_ACTION_LISTEN 9

#define ID_ITEM_NONE     0x0000
#define ID_ITEM_FRIEND   0x0001
#define ID_ITEM_ENEMY    0x0002
#define ID_ITEM_WARRIOR  0x0004
#define ID_ITEM_WEAPON   0x0008
#define ID_ITEM_BULLET   0x0010
#define ID_ITEM_GRENADE  0x0020
#define ID_ITEM_MEDIKIT  0x0040
#define ID_ITEM_FOOD     0x0080
#define ID_ITEM_ARMOR    0x0100
#define ID_ITEM_BULLETS  0x0200
#define ID_ITEM_GRENADES 0x0400
#define ID_ITEM_SIGN     0x0800
#define ID_ITEM_TARGET   0x1000

#define ID_GOAL_TERMINATE_CHIEF 0
#define ID_GOAL_TERMINATE_TEAM  1
#define ID_GOAL_CAPTURE_SIGN    2

#define ID_PLAY_FIGHT  0
#define ID_PLAY_SOCCER 1
#define ID_PLAY_RACE   2

#define ID_SOUND_NONE   0x00
#define ID_SOUND_SHOT   0x01
#define ID_SOUND_LAUNCH 0x02
#define ID_SOUND_BOOM   0x03

#define ID_ATTRIBUTE_NONE       0x00
#define ID_ATTRIBUTE_HAS_WEAPON 0x01
#define ID_ATTRIBUTE_HAS_SIGN   0x02

class GTItem: public M3Vector, public DSSortableObject {
public:
  virtual ~GTItem();
  virtual int getClassID() = 0;
  float getSortIndex() {return getX();}
};

//
// GTExhaustable
//
class GTExhaustable: public GTItem {
private:
  bool exhausted;
public:
  GTExhaustable();
  void setExhausted(bool e) {exhausted = e;}
  bool isExhausted() {return exhausted;}
};

//
// GTHoldable
//
class GTHoldable: public GTExhaustable {
};

//
// GTSign
//
class GTBot;

class GTSign: public GTHoldable {
private:
  GTBot* owner;
public:
  GTSign();
  void setOwner(GTBot* o) {owner = o;}
  GTBot* getOwner() {return owner;}
  bool isOwned() {return owner != NULL;}
  virtual int getClassID() {return ID_ITEM_SIGN;}
};

//
// GTWeapon
//
class GTWeapon: public GTHoldable {
public:
  static float LENGTH;
  static float HEIGHT;
  static float BULLET_SPEED; // SI
  static float BULLET_LOAD_MAX;
  static float BULLET_LOAD_INIT;
  static float BULLET_DROP_MAX;
  static float GRENADE_SPEED; // SI
  static float GRENADE_EXPL_DELAY;
  static float GRENADE_EXPL_DURATION;
  static float GRENADE_RANGE_MAX; // SI
  static float GRENADE_LOAD_MAX;
  static float GRENADE_LOAD_INIT;
  static float GRENADE_DROP_MAX;
private:
  int bulletsCount;
  int grenadesCount;
public:
  GTWeapon();
  int getBulletsCount() {return bulletsCount;}
  void setBulletsCount(int b) {bulletsCount = b;}
  int getGrenadesCount() {return grenadesCount;}
  void setGrenadesCount(int g) {grenadesCount = g;}
  virtual int getClassID() {return ID_ITEM_WEAPON;}
};

//
// GTPowerup
//
class GTPowerup: public GTExhaustable {
public:
  static float MEDIKIT_VALUE_INIT;
  static float FOOD_VALUE_INIT;
  static float ARMOR_VALUE_INIT;
  static float BULLETS_VALUE_INIT;
  static float GRENADES_VALUE_INIT;
  static float MEDIKIT_RESPAWN_TIME;
  static float FOOD_RESPAWN_TIME;
  static float ARMOR_RESPAWN_TIME;
  static float BULLETS_RESPAWN_TIME;
  static float GRENADES_RESPAWN_TIME;
private:
  float respawnCountdown;
  float value;
public:
  GTPowerup(float v = 0, bool respawnable = false);
  float getRespawnCountdown() {return respawnCountdown;}
  void setRespawnCountdown(float r) {respawnCountdown = r;}
  bool isActive() {return respawnCountdown <= 0;}
  bool cantRespawn() {return respawnCountdown < 0;}
  void setValue(float v) {setExhausted(v <= 0); value = v;}
  float getValue() {return value;}
};

//
// GTMedikit
//
class GTMedikit: public GTPowerup {
public:
  GTMedikit(bool respawnable = false, float v = MEDIKIT_VALUE_INIT);
  virtual int getClassID() {return ID_ITEM_MEDIKIT;}
};

//
// GTFood
//
class GTFood: public GTPowerup {
public:
  GTFood(bool respawnable = false, float v = FOOD_VALUE_INIT);
  virtual int getClassID() {return ID_ITEM_FOOD;}
};

//
// GTArmor
//
class GTArmor: public GTPowerup {
public:
  GTArmor(bool respawnable = false, float v = ARMOR_VALUE_INIT);
  virtual int getClassID() {return ID_ITEM_ARMOR;}
};

//
// GTBullets
//
class GTBullets: public GTPowerup {
public:
  GTBullets(bool respawnable = false, float v = BULLETS_VALUE_INIT);
  virtual int getClassID() {return ID_ITEM_BULLETS;}
};

//
// GTGrenades
//
class GTGrenades: public GTPowerup {
public:
  GTGrenades(bool respawnable = false, float v = GRENADES_VALUE_INIT);
  virtual int getClassID() {return ID_ITEM_GRENADES;}
};

//
// GTBot
//
class GTBot: public GTItem, public GTBotBrain {
public:
  static float SIZE_X;
  static float SIZE_Y;
  static float SIZE_Y_CROUCHED;
  static float SIZE_Z;
  static float SPACING;
  static float TIME_LOST_TO_SIGHT;
  static float TIME_LOST_TO_AIM;
  static float TIME_LOST_TO_HEAR;
  static float TIME_LOST_TO_WATCH;
  static float TIME_LOST_TO_LISTEN;
  static float TIME_NEEDED_TO_SAY;
  static float TIME_NEEDED_TO_SPEAK;
  static float TIME_NEEDED_TO_MOVE;
  static float TIME_NEEDED_TO_DROP;
  static float TIME_NEEDED_TO_SHOOT;
  static float KICK_SPEED_MAX; // SI
  static float SPEED_VERTICAL_MAX; // SI
  static float SPEED_ROTATION;
  static float SPEED_WALKCR; // SI
  static float SPEED_WALKBK; // SI
  static float SPEED_WALK; // SI
  static float SPEED_RUN;    // SI
  static float ENERGY_MAX;
  static float ENERGY_INIT;
  static float ENERGY_RUN;
  static float ENERGY_STAND;
  static float ENERGY_DROP_MAX;
  static float HEALTH_MAX;
  static float HEALTH_INIT;
  static float HEALTH_BULLET;
  static float HEALTH_GRENADE_MAX;
  static float HEALTH_DROP_MAX;
  static float ARMOR_MAX;
  static float ARMOR_INIT;
  static float ARMOR_DROP_MAX;
  static float TORSO_YAW_MAX;
  static float TORSO_YAW_MIN;
  static float TORSO_PITCH_MAX;
  static float TORSO_PITCH_MIN;
  static float TORSO_SPEED_ROT;
  static float HEAD_YAW_MAX;
  static float HEAD_YAW_MIN;
  static float HEAD_PITCH_MAX;
  static float HEAD_PITCH_MIN;
  static float HEAD_SPEED_ROT;
  static float HEAD_ANGLE_OF_VIEW;
  static float HEAD_COS_ANGLE_OF_VIEW;
  static float SENSORS_DISTANCE_MAX;
public:
  enum TorsoAttitude {TDEATH = 0, ATTACK, DROP, RAISE, STAND};
  enum LegsAttitude {LDEATH = 0, WALKCR, WALK, RUN, WALKBK, IDLE, IDLECR};
private:
  static GTBot* currentBot;
  bool shooting;
  int shootingWhat;
  bool flashing;
  int talkingAbout;
  int speakingChannel;
  bool speakingOnRadio;
  float talkingCountdown;
  float kickSpeed;
  float verticalSpeed;
  float legsCountdown;
  LegsAttitude legsAttitude;
  LegsAttitude requiredLegsAttitude;
  GTAngle legsAngle;
  float torsoCountdown;
  TorsoAttitude torsoAttitude;
  TorsoAttitude requiredTorsoAttitude;
  GTYawPitchAngles torsoAngles;
  GTYawPitchAngles headAngles;
  GLTeamMate* teamMate;
private:
  int teamID;
  int mateID;
  float energy;
  float health;
  float armor;
  int killedEnemies;
  int killedFriends;
  GTHoldable* hold;
  int touchedID;
  GTItem* itemTouched;
public:
  int getTeamID() {return teamID;}
  void setTeamID(int id) {teamID = id;}
  int getMateID() {return mateID;}
  void setMateID(int id) {mateID = id;}
  int getKilledEnemies() {return killedEnemies;}
  void setKilledEnemies(int k) {killedEnemies = k;}
  int getKilledFriends() {return killedFriends;}
  void setKilledFriends(int k) {killedFriends = k;}
  int getTouchedID() {return touchedID;}
  GTItem* getItemTouched() {return itemTouched;}
  void setTouched(int id, GTItem* t) {touchedID = id; itemTouched = t;}
  float getEnergy() {return energy;}
  void setEnergy(float e) {energy = e;}
  float getHealth() {return health;}
  void setHealth(float h) {health = h;}
  float getArmor() {return armor;}
  void setArmor(float a) {armor = a;}
  float getBulletsCount()
    {return hasWeapon()? getWeapon()->getBulletsCount(): 0;}
  float getGrenadesCount()
    {return hasWeapon()? getWeapon()->getGrenadesCount(): 0;}
  GTHoldable* getHold() {return hold;}
  bool hasWeapon() {return hold && hold->getClassID() == ID_ITEM_WEAPON;}
  bool hasSign() {return hold && hold->getClassID() == ID_ITEM_SIGN;}
  GTWeapon* getWeapon() {return hasWeapon()? dynamic_cast<GTWeapon*>(hold): NULL;}
  GTSign* getSign() {return hasSign()? dynamic_cast<GTSign*>(hold): NULL;}
  void setHold(GTHoldable* h);
protected:
  static void setCurrentBot(GTBot* b) {currentBot = b;}
public:
  static GTBot* getCurrentBot() {return currentBot;}
public:
  GTBot(GLTeamMate* tm);
  GLTeamMate* getTeamMate() {return teamMate;}
  bool isTalking() {return talkingCountdown > 0;}
  bool isSpeakingOnRadio() {return speakingOnRadio;}
  void setSpeakingOnRadio(bool r) {speakingOnRadio = r;}
  void setTalkingCountdown(float c) {talkingCountdown = c;}
  int getTalkingAbout() {return talkingAbout;}
  void setTalkingAbout(int w) {talkingAbout = w;}
  int getSpeakingChannel() {return speakingChannel;}
  void setSpeakingChannel(int c) {speakingChannel = c;}
  bool isSaying() {return isTalking() && !isSpeakingOnRadio();}
  bool isSpeaking() {return isTalking() && isSpeakingOnRadio();}
  bool isShotHeard() {return (torsoAttitude == ATTACK);}
  bool isShooting() {return shooting;}
  void setShooting(bool s) {shooting = s;}
  void setShootingWhat(int what) {shootingWhat = what;}
  int getShootingWhat() {return shootingWhat;}
  bool isFlashing() {return flashing;}
  void setFlashing(bool f) {flashing = f;}
  float getKickSpeed() {return kickSpeed;}
  float getVerticalSpeed() {return verticalSpeed;}
  void setKickSpeed(float ks) {kickSpeed = ks;}
  void setVerticalSpeed(float vs) {verticalSpeed = vs;}
  bool isDead() {return (legsAttitude == LDEATH);}
  LegsAttitude getLegsAttitude() {return legsAttitude;}
  bool isCrouched()
    {return legsAttitude == GTBot::IDLECR || legsAttitude == GTBot::WALKCR;}
  float getHalfHeight() {return isCrouched()? SIZE_Y_CROUCHED: SIZE_Y;}
  float getCenterY()
    {return getY()-(isCrouched()? (SIZE_Y-SIZE_Y_CROUCHED): 0);}
  float getEyeY()
    {return getY()+(isCrouched()? (2*SIZE_Y_CROUCHED-SIZE_Y): SIZE_Y);}
  float getWeaponY() {return getCenterY()+GTWeapon::HEIGHT;}
  void forceLegsAttitude(LegsAttitude la)
    {requiredLegsAttitude = legsAttitude = la;}
  bool setLegsAttitude(LegsAttitude la);
  bool canLegsChange() {return legsCountdown < 0;}
  bool updateLegsAttitude();
  float getLegsSpeed();
  GTAngle& getLegsAngle() {return legsAngle;}
  void setLegsAngle(float la) {
    legsAngle.setCurrent(la); legsAngle.setRequired(la);
  }
  TorsoAttitude getTorsoAttitude() {return torsoAttitude;}
  void forceTorsoAttitude(TorsoAttitude ta)
    {requiredTorsoAttitude = torsoAttitude = ta;}
  bool setTorsoAttitude(TorsoAttitude ta);
  bool canTorsoChange() {return torsoCountdown < 0;}
  bool updateTorsoAttitude();
  GTYawPitchAngles& getTorsoAngles() {return torsoAngles;}
  GTYawPitchAngles& getHeadAngles() {return headAngles;}
  bool raise(int itemID);
  bool drop(int itemID = ID_ITEM_WEAPON);
  bool say(int word);
  bool shootBullet() {
    if(!hasWeapon()) return false;
    int bullets = getBulletsCount();
    if(bullets <= 0) return false;
    bool attacks = setTorsoAttitude(GTBot::ATTACK);
    if(attacks)
      setShootingWhat(ID_ITEM_BULLET);
    return attacks;
  }
  bool launchGrenade() {
    if(!hasWeapon()) return false;
    int grenades = getGrenadesCount();
    if(grenades <= 0) return false;
    bool attacks = setTorsoAttitude(GTBot::ATTACK);
    if(attacks)
      setShootingWhat(ID_ITEM_GRENADE);
    return attacks;
  }
  void update();
  int execute() {
    setCurrentBot(this);
    return GTBotBrain::execute();
  }
  virtual int getClassID() {return ID_ITEM_WARRIOR;}
};

//
// GTAmmo
//
class GTAmmo: public GTExhaustable {
private:
  int teamID;
  int mateID;
  M3Vector velocity;
public:
  int getTeamID() {return teamID;}
  void setTeamID(int id) {teamID = id;}
  int getMateID() {return mateID;}
  void setMateID(int id) {mateID = id;}
  M3Vector& getVelocity() {return velocity;}
};

//
// GTTarget
//
class GTTarget: public GTAmmo {
public:
  static float SIZE;
  static float MAX_SPEED;
  float countdown;
public:
  GTTarget();
  void setCountdown(float c) {countdown = c;}
  float getCountdown() {return countdown;}
  virtual int getClassID() {return ID_ITEM_TARGET;}
};

//
// GTBullet
//
class GTBullet: public GTAmmo {
public:
  virtual int getClassID() {return ID_ITEM_BULLET;}
};

//
// GTGrenade
//
class GTGrenade: public GTAmmo {
private:
  bool exploded;
  bool explosionNotified;
  float countdown;
public:
  GTGrenade();
  float getCountdown() {return countdown;}
  void setCountdown(float c) {countdown = c;}
  void setDelay(float d = GTWeapon::GRENADE_EXPL_DELAY) {setCountdown(d);}
  void setDuration(
    float d = GTWeapon::GRENADE_EXPL_DURATION
  ) {setCountdown(d);}
  void setExhausted(bool e)
    {GTAmmo::setExhausted(e); setExploded(false); if(!e) setDelay();}
  void setExploded(bool e)
    {explosionNotified = false; exploded = e; if(e) setDuration();}
  bool isExploded() {return exploded;}
  bool wasExplosionNotified()
    {bool en = explosionNotified; explosionNotified = true; return en;}
  virtual int getClassID() {return ID_ITEM_GRENADE;}
};

//
// GTItems
//
class GTItems:
  public DSSortedArray<GTItem>, public GLWeaponData,
  public GLPowerupData, public GLAmmoData
{
public:
  GTItems(int cap);
  bool getWeaponStatus(int& idx, M3Vector& pos, int& type, int& attrib);
  bool getPowerupStatus(int& idx, M3Vector& pos, int& type, int& attrib);
  bool getAmmoStatus(int& idx, M3Vector& pos, int& type, int& attrib);
};

//
// GTArena
//
#define BSP_SCENE_SCALE     32
#define BSP_SCENE_SCALE_INV (1.0f/BSP_SCENE_SCALE)

class GTArena {
public:
  static float WORLD_GRAVITY; // SI
  static float GROUND_RESTITUTION;
  static float ARENA_SIZE;
  static float GOAL_SIZE;
private:
  unsigned int randomSeed;
  int teamsCount;
  int matesCount;
  float realTime;
  float matchDuration;
  int goalIndex;
  int playIndex;
  int winner;
  int corner[4];
  GTItems items;
  DSArray<GTSign,false> signs;
  DSArray<GTBot,false> bots;
  GTTarget* target;
public:
  float getRealTime() {return realTime;}
  float getMatchDuration() {return matchDuration;}
  int getGoalIndex() {return goalIndex;}
  int getPlayIndex() {return playIndex;}
  GTItems& getItems() {return items;}
  int getItemsSize() {return items.getSize();}
  GTItem* getItem(int idx) {return items.getElement(idx);}
  GTSign* getSign(int idx) {return signs.getElement(idx);}
  GTBot* getBot(int idx) {return bots.getElement(idx);}
  int getBotsSize() {return bots.getSize();}
  GTTarget* getTarget() {return target;}
  unsigned int getRandomSeed() {return randomSeed;}
  int getTeamsCount() {return teamsCount;}
  int getMatesCount() {return matesCount;}
protected:
  static GTArena* arena;
  GLBsp* bsp;
public:
  GTArena(
    unsigned int randomSeed, int goal, int play, float timeout, GLBsp& iBsp,
    int* start, char** botNames, int teamsCt, int matesCt, GLTeams* teams = NULL
  );
  ~GTArena();
  static GTArena* get() {return arena;}
  GLBsp* getBsp() {return bsp;}
  BSPVector& getCorner(int teamID)
    {return bsp->getStartingPosition(corner[teamID]);}
  int update();
};

#endif // GTSIM_H
