/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glrenderer.h"

#include "_stdlib.h" // for randomize()

#include <math.h>
#include <float.h>

//
// globals (for extensions)
//

int TEXTURE_CLAMP_MODE;

#ifdef USE_OGLES
#else // !USE_OGLES

bool IS_STENCIL_AVAILABLE = false;

bool IS_MULTITEXTURING_ENABLED = false;
int MULTITEXTURE_UNITS = 0;

PFNGLMULTITEXCOORD1FARBPROC glMultiTexCoord1fARB = NULL;
PFNGLMULTITEXCOORD2FARBPROC glMultiTexCoord2fARB = NULL;
PFNGLMULTITEXCOORD2FVARBPROC glMultiTexCoord2fvARB = NULL;
PFNGLMULTITEXCOORD3FARBPROC glMultiTexCoord3fARB = NULL;
PFNGLMULTITEXCOORD4FARBPROC glMultiTexCoord4fARB = NULL;
PFNGLACTIVETEXTUREARBPROC glActiveTextureARB = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC glClientActiveTextureARB = NULL;

bool IS_TEXTURE_ENV_ADD_SUPPORTED = false;
bool IS_TEXTURE_ENV_COMBINE_SUPPORTED = false;
bool IS_TEXTURE_CUBE_MAP_SUPPORTED = false;

bool IS_DRAW_RANGE_ELEMENTS_SUPPORTED = false;
PFNGLDRAWRANGEELEMENTSEXTPROC glDrawRangeElementsEXT = NULL;

bool IS_MULTI_DRAW_ARRAYS_SUPPORTED = false;
PFNGLMULTIDRAWARRAYSEXTPROC glMultiDrawArraysEXT = NULL;
PFNGLMULTIDRAWELEMENTSEXTPROC glMultiDrawElementsEXT = NULL;

bool IS_VERTEX_BUFFER_SUPPORTED = false;
PFNGLGENBUFFERSARBPROC glGenBuffersARB = NULL;
PFNGLBINDBUFFERARBPROC glBindBufferARB = NULL;
PFNGLBUFFERDATAARBPROC glBufferDataARB = NULL;
PFNGLDELETEBUFFERSARBPROC glDeleteBuffersARB = NULL;
PFNGLMAPBUFFERARBPROC glMapBufferARB = NULL;
PFNGLUNMAPBUFFERARBPROC glUnmapBufferARB = NULL;
PFNGLENABLEVERTEXATTRIBARRAYARBPROC glEnableVertexAttribArrayARB = NULL;
PFNGLDISABLEVERTEXATTRIBARRAYARBPROC glDisableVertexAttribArrayARB = NULL;
PFNGLVERTEXATTRIBPOINTERARBPROC glVertexAttribPointerARB = NULL;

bool IS_VERTEX_PROGRAM_SUPPORTED = false;
bool IS_FRAGMENT_PROGRAM_SUPPORTED = false;
PFNGLGETPROGRAMIVARBPROC glGetProgramivARB = NULL;
PFNGLGENPROGRAMSARBPROC glGenProgramsARB = NULL;
PFNGLBINDPROGRAMARBPROC glBindProgramARB = NULL;
PFNGLPROGRAMSTRINGARBPROC glProgramStringARB = NULL;
PFNGLDELETEPROGRAMSARBPROC glDeleteProgramsARB = NULL;
PFNGLPROGRAMLOCALPARAMETER4FARBPROC glProgramLocalParameter4fARB = NULL;
PFNGLPROGRAMENVPARAMETER4FARBPROC glProgramEnvParameter4fARB = NULL;
PFNGLPROGRAMLOCALPARAMETER4FVARBPROC glProgramLocalParameter4fvARB = NULL;

bool ARE_SHADER_OBJECTS_SUPPORTED = false;
PFNGLFOGCOORDPOINTERPROC glFogCoordPointer = NULL;
PFNGLSECONDARYCOLORPOINTERPROC glSecondaryColorPointer = NULL;
bool IS_VERTEX_SHADER_SUPPORTED = false;
bool IS_FRAGMENT_SHADER_SUPPORTED = false;
PFNGLDELETEOBJECTARBPROC glDeleteObjectARB = NULL;
PFNGLDETACHOBJECTARBPROC glDetachObjectARB = NULL;
PFNGLCREATESHADEROBJECTARBPROC glCreateShaderObjectARB = NULL;
PFNGLSHADERSOURCEARBPROC glShaderSourceARB = NULL;
PFNGLCOMPILESHADERARBPROC glCompileShaderARB = NULL;
PFNGLCREATEPROGRAMOBJECTARBPROC glCreateProgramObjectARB = NULL;
PFNGLATTACHOBJECTARBPROC glAttachObjectARB = NULL;
PFNGLLINKPROGRAMARBPROC glLinkProgramARB = NULL;
PFNGLUSEPROGRAMOBJECTARBPROC glUseProgramObjectARB = NULL;
PFNGLVALIDATEPROGRAMARBPROC glValidateProgramARB = NULL;
PFNGLUNIFORM1FARBPROC glUniform1fARB = NULL;
PFNGLUNIFORM2FARBPROC glUniform2fARB = NULL;
PFNGLUNIFORM3FARBPROC glUniform3fARB = NULL;
PFNGLUNIFORM4FARBPROC glUniform4fARB = NULL;
PFNGLUNIFORM1IARBPROC glUniform1iARB = NULL;
PFNGLUNIFORM2IARBPROC glUniform2iARB = NULL;
PFNGLUNIFORM3IARBPROC glUniform3iARB = NULL;
PFNGLUNIFORM4IARBPROC glUniform4iARB = NULL;
PFNGLUNIFORMMATRIX2FVARBPROC glUniformMatrix2fvARB = NULL;
PFNGLUNIFORMMATRIX3FVARBPROC glUniformMatrix3fvARB = NULL;
PFNGLUNIFORMMATRIX4FVARBPROC glUniformMatrix4fvARB = NULL;
PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB = NULL;
PFNGLGETINFOLOGARBPROC glGetInfoLogARB = NULL;
PFNGLGETUNIFORMLOCATIONARBPROC glGetUniformLocationARB = NULL;
PFNGLGETUNIFORMFVARBPROC glGetUniformfvARB = NULL;
PFNGLGETUNIFORMIVARBPROC glGetUniformivARB = NULL;

#ifndef USE_GLFW
BOOL (APIENTRY *wglSwapIntervalEXT)(int) = NULL;
#endif // !USE_GLFW

#ifndef USE_GLFW
bool isSubString(char* src, const char* search) {
  int maxpos = strlen(search)-1;
  for(unsigned int ct = 0; ct < strlen(src); ct++) {
    if((ct == 0) || ((ct > 1) && (src[ct-1] == ' '))) {
      int pos = 0;
      while (src[ct] != ' ') {
        if(src[ct] == search[pos]) pos++;
        if((pos > maxpos) && (src[ct+1] == ' ')) return true;
        ct++;
      }
    }
  }
  return false;
}
#endif // !USE_GLFW

#endif //! USE_OGLES

//
// GLRenderer
//

GLRenderer::GLRenderer()
#ifdef USE_OGLES
#else // !USE_OGLES
  : videoModes(NULL), videoModesCount(0)
#endif // !USE_OGLES
{
#ifdef __MINGW32__
#elif !defined(__linux__) // !__MINGW32__ && !__linux__
  _control87(MCW_EM,MCW_EM);
#endif // !__MINGW32__ && !__linux__
  randomize();
#ifdef USE_OGLES
#elif defined(USE_GLFW)
  const int MAX_MODES = 40;
  videoModes = new GLFWvidmode[MAX_MODES];
  videoModesCount = glfwGetVideoModes(videoModes,MAX_MODES);
  GLFWvidmode* newVideoModes = new GLFWvidmode[videoModesCount];
  memcpy(newVideoModes,videoModes,videoModesCount*sizeof(GLFWvidmode));
  delete videoModes;
  videoModes = newVideoModes;
#endif // USE_GLFW
}

GLRenderer::~GLRenderer() {
#ifdef USE_OGLES
#else // !USE_OGLES
  if(videoModes)
    delete videoModes;
#endif // !USE_OGLES
}

//
//#define GPU_DEBUG

#ifdef GPU_DEBUG
#include <stdio.h>
#define GPU_INIT \
  int val[4]; FILE* f = fopen("GPU.txt","w");
#define GPU_PROP(X) \
  val[0] = -1; glGetIntegerv(X,val); \
  fprintf(f,"\n   %d\t"#X,val[0]);
#define GPU_VERTEX(X) \
  val[0] = -1; glGetProgramivARB(GL_VERTEX_PROGRAM_ARB,X,val); \
  fprintf(f,"\nVP %d\t"#X,val[0]);
#define GPU_FRAGMENT(X) \
  val[0] = -1; glGetProgramivARB(GL_FRAGMENT_PROGRAM_ARB,X,val); \
  fprintf(f,"\nFP %d\t"#X,val[0]);
#define GPU_FINAL \
  fclose(f);
#endif // GPU_DEBUG

bool GLRenderer::initializeRenderer() {
#ifdef USE_OGLES
  TEXTURE_CLAMP_MODE = GL_CLAMP_TO_EDGE;
#else // !USE_OGLES
  TEXTURE_CLAMP_MODE =
    (strcmp("1.2",(char*)glGetString(GL_VERSION)) <= 0)?
    GL_CLAMP_TO_EDGE: GL_CLAMP;
#ifndef USE_GLFW
  char* extensions = (char*)glGetString(GL_EXTENSIONS);
#ifdef GPU_DEBUG
  GPU_INIT;
#endif
  IS_MULTITEXTURING_ENABLED = isSubString(extensions,"GL_ARB_multitexture");
  if(IS_MULTITEXTURING_ENABLED) {
    glGetIntegerv(GL_MAX_TEXTURE_UNITS_ARB,&MULTITEXTURE_UNITS);
#ifdef GPU_DEBUG
    GPU_PROP(GL_MAX_TEXTURE_UNITS_ARB);
#endif
    glMultiTexCoord1fARB = (PFNGLMULTITEXCOORD1FARBPROC)
      wglGetProcAddress("glMultiTexCoord1fARB");
    glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC)
      wglGetProcAddress("glMultiTexCoord2fARB");
    glMultiTexCoord2fvARB = (PFNGLMULTITEXCOORD2FVARBPROC)
      wglGetProcAddress("glMultiTexCoord2fvARB");
    glMultiTexCoord3fARB = (PFNGLMULTITEXCOORD3FARBPROC)
      wglGetProcAddress("glMultiTexCoord3fARB");
    glMultiTexCoord4fARB = (PFNGLMULTITEXCOORD4FARBPROC)
      wglGetProcAddress("glMultiTexCoord4fARB");
    glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC)
      wglGetProcAddress("glActiveTextureARB");
    glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)
      wglGetProcAddress("glClientActiveTextureARB");
  }
  IS_TEXTURE_ENV_ADD_SUPPORTED =
    isSubString(extensions,"GL_ARB_texture_env_add");
  IS_TEXTURE_ENV_COMBINE_SUPPORTED =
    isSubString(extensions,"GL_ARB_texture_env_combine");
  IS_TEXTURE_CUBE_MAP_SUPPORTED =
    isSubString(extensions,"GL_ARB_texture_cube_map");
  IS_DRAW_RANGE_ELEMENTS_SUPPORTED =
    isSubString(extensions,"GL_EXT_draw_range_elements");
  if(IS_DRAW_RANGE_ELEMENTS_SUPPORTED) {
  	glDrawRangeElementsEXT = (PFNGLDRAWRANGEELEMENTSEXTPROC)
      wglGetProcAddress("glDrawRangeElementsEXT");
  }
  IS_MULTI_DRAW_ARRAYS_SUPPORTED =
    isSubString(extensions,"GL_EXT_multi_draw_arrays");
  if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
  	glMultiDrawArraysEXT = (PFNGLMULTIDRAWARRAYSEXTPROC)
  		wglGetProcAddress("glMultiDrawArraysEXT");
	  glMultiDrawElementsEXT = (PFNGLMULTIDRAWELEMENTSEXTPROC)
      wglGetProcAddress("glMultiDrawElementsEXT");
  }
  IS_VERTEX_BUFFER_SUPPORTED =
    isSubString(extensions,"GL_ARB_vertex_buffer_object");
  if(IS_VERTEX_BUFFER_SUPPORTED) {
    glGenBuffersARB = (PFNGLGENBUFFERSARBPROC)
      wglGetProcAddress("glGenBuffersARB");
    glBindBufferARB = (PFNGLBINDBUFFERARBPROC)
      wglGetProcAddress("glBindBufferARB");
    glBufferDataARB = (PFNGLBUFFERDATAARBPROC)
      wglGetProcAddress("glBufferDataARB");
    glDeleteBuffersARB = (PFNGLDELETEBUFFERSARBPROC)
      wglGetProcAddress("glDeleteBuffersARB");
    glMapBufferARB = (PFNGLMAPBUFFERARBPROC)
      wglGetProcAddress("glMapBufferARB");
    glUnmapBufferARB = (PFNGLUNMAPBUFFERARBPROC)
      wglGetProcAddress("glUnmapBufferARB");
    glEnableVertexAttribArrayARB = (PFNGLENABLEVERTEXATTRIBARRAYARBPROC)
      wglGetProcAddress("glEnableVertexAttribArrayARB");
    glDisableVertexAttribArrayARB = (PFNGLDISABLEVERTEXATTRIBARRAYARBPROC)
      wglGetProcAddress("glDisableVertexAttribArrayARB");
    glVertexAttribPointerARB = (PFNGLVERTEXATTRIBPOINTERARBPROC)
      wglGetProcAddress("glVertexAttribPointerARB");
  }
  IS_VERTEX_PROGRAM_SUPPORTED =
    isSubString(extensions,"GL_ARB_vertex_program");
  if(IS_VERTEX_PROGRAM_SUPPORTED) {
    glGetProgramivARB = (PFNGLGETPROGRAMIVARBPROC)
      wglGetProcAddress("glGetProgramivARB");
    glGenProgramsARB = (PFNGLGENPROGRAMSARBPROC)
      wglGetProcAddress("glGenProgramsARB");
    glBindProgramARB = (PFNGLBINDPROGRAMARBPROC)
      wglGetProcAddress("glBindProgramARB");
    glProgramStringARB = (PFNGLPROGRAMSTRINGARBPROC)
      wglGetProcAddress("glProgramStringARB");
    glDeleteProgramsARB = (PFNGLDELETEPROGRAMSARBPROC)
      wglGetProcAddress("glDeleteProgramsARB");
    glProgramLocalParameter4fARB = (PFNGLPROGRAMLOCALPARAMETER4FARBPROC)
      wglGetProcAddress("glProgramLocalParameter4fARB");
    glProgramEnvParameter4fARB = (PFNGLPROGRAMENVPARAMETER4FARBPROC)
      wglGetProcAddress("glProgramEnvParameter4fARB");
    glProgramLocalParameter4fvARB = (PFNGLPROGRAMLOCALPARAMETER4FVARBPROC)
      wglGetProcAddress("glProgramLocalParameter4fvARB");
#ifdef GPU_DEBUG
    GPU_PROP(GL_MAX_VERTEX_ATTRIBS_ARB);
    GPU_PROP(GL_MAX_PROGRAM_MATRICES_ARB);
    GPU_PROP(GL_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_INSTRUCTIONS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_TEMPORARIES_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_PARAMETERS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_ATTRIBS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB);
    GPU_VERTEX(GL_MAX_PROGRAM_ENV_PARAMETERS_ARB);
#endif // GPU_DEBUG
  }
  IS_FRAGMENT_PROGRAM_SUPPORTED =
    isSubString(extensions,"GL_ARB_fragment_program");
  if(IS_FRAGMENT_PROGRAM_SUPPORTED) {
#ifdef GPU_DEBUG
    GPU_FRAGMENT(GL_MAX_PROGRAM_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_TEMPORARIES_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_PARAMETERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_ATTRIBS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_ENV_PARAMETERS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_TEX_INDIRECTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB);
    GPU_FRAGMENT(GL_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB);
    GPU_PROP(GL_MAX_TEXTURE_COORDS_ARB);
    GPU_PROP(GL_MAX_TEXTURE_IMAGE_UNITS_ARB);
#endif // GPU_DEBUG
  }
  ARE_SHADER_OBJECTS_SUPPORTED =
    isSubString(extensions,"GL_ARB_shader_objects");
  if(ARE_SHADER_OBJECTS_SUPPORTED) {
    glFogCoordPointer = (PFNGLFOGCOORDPOINTERPROC)
      wglGetProcAddress("glFogCoordPointer");
    glSecondaryColorPointer = (PFNGLSECONDARYCOLORPOINTERPROC)
      wglGetProcAddress("glSecondaryColorPointer");
    glDeleteObjectARB = (PFNGLDELETEOBJECTARBPROC)
      wglGetProcAddress("glDeleteObjectARB");
    glDetachObjectARB = (PFNGLDETACHOBJECTARBPROC)
      wglGetProcAddress("glDetachObjectARB");
    glCreateShaderObjectARB = (PFNGLCREATESHADEROBJECTARBPROC)
      wglGetProcAddress("glCreateShaderObjectARB");
    glShaderSourceARB = (PFNGLSHADERSOURCEARBPROC)
      wglGetProcAddress("glShaderSourceARB");
    glCompileShaderARB = (PFNGLCOMPILESHADERARBPROC)
      wglGetProcAddress("glCompileShaderARB");
    glCreateProgramObjectARB = (PFNGLCREATEPROGRAMOBJECTARBPROC)
      wglGetProcAddress("glCreateProgramObjectARB");
    glAttachObjectARB = (PFNGLATTACHOBJECTARBPROC)
      wglGetProcAddress("glAttachObjectARB");
    glLinkProgramARB = (PFNGLLINKPROGRAMARBPROC)
      wglGetProcAddress("glLinkProgramARB");
    glUseProgramObjectARB = (PFNGLUSEPROGRAMOBJECTARBPROC)
      wglGetProcAddress("glUseProgramObjectARB");
    glValidateProgramARB = (PFNGLVALIDATEPROGRAMARBPROC)
      wglGetProcAddress("glValidateProgramARB");
    glUniform1fARB = (PFNGLUNIFORM1FARBPROC)
      wglGetProcAddress("glUniform1fARB");
    glUniform2fARB = (PFNGLUNIFORM2FARBPROC)
      wglGetProcAddress("glUniform2fARB");
    glUniform3fARB = (PFNGLUNIFORM3FARBPROC)
      wglGetProcAddress("glUniform3fARB");
    glUniform4fARB = (PFNGLUNIFORM4FARBPROC)
      wglGetProcAddress("glUniform4fARB");
    glUniform1iARB = (PFNGLUNIFORM1IARBPROC)
      wglGetProcAddress("glUniform1iARB");
    glUniform2iARB = (PFNGLUNIFORM2IARBPROC)
      wglGetProcAddress("glUniform2iARB");
    glUniform3iARB = (PFNGLUNIFORM3IARBPROC)
      wglGetProcAddress("glUniform3iARB");
    glUniform4iARB = (PFNGLUNIFORM4IARBPROC)
      wglGetProcAddress("glUniform4iARB");
    glUniformMatrix2fvARB = (PFNGLUNIFORMMATRIX2FVARBPROC)
      wglGetProcAddress("glUniformMatrix2fvARB");
    glUniformMatrix3fvARB = (PFNGLUNIFORMMATRIX3FVARBPROC)
      wglGetProcAddress("glUniformMatrix3fvARB");
    glUniformMatrix4fvARB = (PFNGLUNIFORMMATRIX4FVARBPROC)
      wglGetProcAddress("glUniformMatrix4fvARB");
    glGetObjectParameterivARB = (PFNGLGETOBJECTPARAMETERIVARBPROC)
      wglGetProcAddress("glGetObjectParameterivARB");
    glGetInfoLogARB = (PFNGLGETINFOLOGARBPROC)
      wglGetProcAddress("glGetInfoLogARB");
    glGetUniformLocationARB = (PFNGLGETUNIFORMLOCATIONARBPROC)
      wglGetProcAddress("glGetUniformLocationARB");
    glGetUniformfvARB = (PFNGLGETUNIFORMFVARBPROC)
      wglGetProcAddress("glGetUniformfvARB");
    glGetUniformivARB = (PFNGLGETUNIFORMIVARBPROC)
      wglGetProcAddress("glGetUniformivARB");
  }
  IS_VERTEX_SHADER_SUPPORTED =
    isSubString(extensions,"GL_ARB_vertex_shader");
  if(IS_VERTEX_SHADER_SUPPORTED) {
#ifdef GPU_DEBUG
    GPU_PROP(GL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB);
    GPU_PROP(GL_MAX_VARYING_FLOATS_ARB);
#endif // GPU_DEBUG
  }
  IS_FRAGMENT_SHADER_SUPPORTED =
    isSubString(extensions,"GL_ARB_fragment_shader");
  if(IS_FRAGMENT_SHADER_SUPPORTED) {
#ifdef GPU_DEBUG
    GPU_PROP(GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB);
#endif // GPU_DEBUG
  }
#ifdef GPU_DEBUG
  GPU_FINAL;
#endif
  wglSwapIntervalEXT =
    (BOOL(APIENTRY*)(int))wglGetProcAddress("wglSwapIntervalEXT");
#else // USE_GLFW
  IS_MULTITEXTURING_ENABLED = glfwExtensionSupported("GL_ARB_multitexture");
  if(IS_MULTITEXTURING_ENABLED) {
    glGetIntegerv(GL_MAX_TEXTURE_UNITS_ARB,&MULTITEXTURE_UNITS);
    glMultiTexCoord1fARB = (PFNGLMULTITEXCOORD1FARBPROC)
      glfwGetProcAddress("glMultiTexCoord1fARB");
    glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC)
      glfwGetProcAddress("glMultiTexCoord2fARB");
    glMultiTexCoord2fvARB = (PFNGLMULTITEXCOORD2FVARBPROC)
      glfwGetProcAddress("glMultiTexCoord2fvARB");
    glMultiTexCoord3fARB = (PFNGLMULTITEXCOORD3FARBPROC)
      glfwGetProcAddress("glMultiTexCoord3fARB");
    glMultiTexCoord4fARB = (PFNGLMULTITEXCOORD4FARBPROC)
      glfwGetProcAddress("glMultiTexCoord4fARB");
    glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC)
      glfwGetProcAddress("glActiveTextureARB");
    glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)
      glfwGetProcAddress("glClientActiveTextureARB");
  }
  IS_TEXTURE_ENV_ADD_SUPPORTED =
    glfwExtensionSupported("GL_ARB_texture_env_add");
  IS_TEXTURE_ENV_COMBINE_SUPPORTED =
    glfwExtensionSupported("GL_ARB_texture_env_combine");
  IS_TEXTURE_CUBE_MAP_SUPPORTED =
    glfwExtensionSupported("GL_ARB_texture_cube_map");
  IS_DRAW_RANGE_ELEMENTS_SUPPORTED =
    glfwExtensionSupported("GL_EXT_draw_range_elements");
  if(IS_DRAW_RANGE_ELEMENTS_SUPPORTED) {
  	glDrawRangeElementsEXT = (PFNGLDRAWRANGEELEMENTSEXTPROC)
      glfwGetProcAddress("glDrawRangeElementsEXT");
  }
  IS_MULTI_DRAW_ARRAYS_SUPPORTED =
    glfwExtensionSupported("GL_EXT_multi_draw_arrays");
  if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
  	glMultiDrawArraysEXT = (PFNGLMULTIDRAWARRAYSEXTPROC)
  		glfwGetProcAddress("glMultiDrawArraysEXT");
	  glMultiDrawElementsEXT = (PFNGLMULTIDRAWELEMENTSEXTPROC)
      glfwGetProcAddress("glMultiDrawElementsEXT");
  }
  IS_VERTEX_BUFFER_SUPPORTED =
    glfwExtensionSupported("GL_ARB_vertex_buffer_object");
  if(IS_VERTEX_BUFFER_SUPPORTED) {
    glGenBuffersARB = (PFNGLGENBUFFERSARBPROC)
      glfwGetProcAddress("glGenBuffersARB");
    glBindBufferARB = (PFNGLBINDBUFFERARBPROC)
      glfwGetProcAddress("glBindBufferARB");
    glBufferDataARB = (PFNGLBUFFERDATAARBPROC)
      glfwGetProcAddress("glBufferDataARB");
    glDeleteBuffersARB = (PFNGLDELETEBUFFERSARBPROC)
      glfwGetProcAddress("glDeleteBuffersARB");
    glMapBufferARB = (PFNGLMAPBUFFERARBPROC)
      glfwGetProcAddress("glMapBufferARB");
    glUnmapBufferARB = (PFNGLUNMAPBUFFERARBPROC)
      glfwGetProcAddress("glUnmapBufferARB");
    glEnableVertexAttribArrayARB = (PFNGLENABLEVERTEXATTRIBARRAYARBPROC)
      glfwGetProcAddress("glEnableVertexAttribArrayARB");
    glDisableVertexAttribArrayARB = (PFNGLDISABLEVERTEXATTRIBARRAYARBPROC)
      glfwGetProcAddress("glDisableVertexAttribArrayARB");
    glVertexAttribPointerARB = (PFNGLVERTEXATTRIBPOINTERARBPROC)
      glfwGetProcAddress("glVertexAttribPointerARB");
  }
  IS_VERTEX_PROGRAM_SUPPORTED =
    glfwExtensionSupported("GL_ARB_vertex_program");
  if(IS_VERTEX_PROGRAM_SUPPORTED) {
    glGetProgramivARB = (PFNGLGETPROGRAMIVARBPROC)
      glfwGetProcAddress("glGetProgramivARB");
    glGenProgramsARB = (PFNGLGENPROGRAMSARBPROC)
      glfwGetProcAddress("glGenProgramsARB");
    glBindProgramARB = (PFNGLBINDPROGRAMARBPROC)
      glfwGetProcAddress("glBindProgramARB");
    glProgramStringARB = (PFNGLPROGRAMSTRINGARBPROC)
      glfwGetProcAddress("glProgramStringARB");
    glDeleteProgramsARB = (PFNGLDELETEPROGRAMSARBPROC)
      glfwGetProcAddress("glDeleteProgramsARB");
    glProgramLocalParameter4fARB = (PFNGLPROGRAMLOCALPARAMETER4FARBPROC)
      glfwGetProcAddress("glProgramLocalParameter4fARB");
    glProgramEnvParameter4fARB = (PFNGLPROGRAMENVPARAMETER4FARBPROC)
      glfwGetProcAddress("glProgramEnvParameter4fARB");
    glProgramLocalParameter4fvARB = (PFNGLPROGRAMLOCALPARAMETER4FVARBPROC)
      glfwGetProcAddress("glProgramLocalParameter4fvARB");
  }
  IS_FRAGMENT_PROGRAM_SUPPORTED =
    glfwExtensionSupported("GL_ARB_fragment_program");
  if(IS_FRAGMENT_PROGRAM_SUPPORTED) {
    //
  }
  ARE_SHADER_OBJECTS_SUPPORTED =
    glfwExtensionSupported("GL_ARB_shader_objects");
  if(ARE_SHADER_OBJECTS_SUPPORTED) {
    glFogCoordPointer = (PFNGLFOGCOORDPOINTERPROC)
      glfwGetProcAddress("glFogCoordPointer");
    glSecondaryColorPointer = (PFNGLSECONDARYCOLORPOINTERPROC)
      glfwGetProcAddress("glSecondaryColorPointer");
    glDeleteObjectARB = (PFNGLDELETEOBJECTARBPROC)
      glfwGetProcAddress("glDeleteObjectARB");
    glDetachObjectARB = (PFNGLDETACHOBJECTARBPROC)
      glfwGetProcAddress("glDetachObjectARB");
    glCreateShaderObjectARB = (PFNGLCREATESHADEROBJECTARBPROC)
      glfwGetProcAddress("glCreateShaderObjectARB");
    glShaderSourceARB = (PFNGLSHADERSOURCEARBPROC)
      glfwGetProcAddress("glShaderSourceARB");
    glCompileShaderARB = (PFNGLCOMPILESHADERARBPROC)
      glfwGetProcAddress("glCompileShaderARB");
    glCreateProgramObjectARB = (PFNGLCREATEPROGRAMOBJECTARBPROC)
      glfwGetProcAddress("glCreateProgramObjectARB");
    glAttachObjectARB = (PFNGLATTACHOBJECTARBPROC)
      glfwGetProcAddress("glAttachObjectARB");
    glLinkProgramARB = (PFNGLLINKPROGRAMARBPROC)
      glfwGetProcAddress("glLinkProgramARB");
    glUseProgramObjectARB = (PFNGLUSEPROGRAMOBJECTARBPROC)
      glfwGetProcAddress("glUseProgramObjectARB");
    glValidateProgramARB = (PFNGLVALIDATEPROGRAMARBPROC)
      glfwGetProcAddress("glValidateProgramARB");
    glUniform1fARB = (PFNGLUNIFORM1FARBPROC)
      glfwGetProcAddress("glUniform1fARB");
    glUniform2fARB = (PFNGLUNIFORM2FARBPROC)
      glfwGetProcAddress("glUniform2fARB");
    glUniform3fARB = (PFNGLUNIFORM3FARBPROC)
      glfwGetProcAddress("glUniform3fARB");
    glUniform4fARB = (PFNGLUNIFORM4FARBPROC)
      glfwGetProcAddress("glUniform4fARB");
    glUniform1iARB = (PFNGLUNIFORM1IARBPROC)
      glfwGetProcAddress("glUniform1iARB");
    glUniform2iARB = (PFNGLUNIFORM2IARBPROC)
      glfwGetProcAddress("glUniform2iARB");
    glUniform3iARB = (PFNGLUNIFORM3IARBPROC)
      glfwGetProcAddress("glUniform3iARB");
    glUniform4iARB = (PFNGLUNIFORM4IARBPROC)
      glfwGetProcAddress("glUniform4iARB");
    glUniformMatrix2fvARB = (PFNGLUNIFORMMATRIX2FVARBPROC)
      glfwGetProcAddress("glUniformMatrix2fvARB");
    glUniformMatrix3fvARB = (PFNGLUNIFORMMATRIX3FVARBPROC)
      glfwGetProcAddress("glUniformMatrix3fvARB");
    glUniformMatrix4fvARB = (PFNGLUNIFORMMATRIX4FVARBPROC)
      glfwGetProcAddress("glUniformMatrix4fvARB");
    glGetObjectParameterivARB = (PFNGLGETOBJECTPARAMETERIVARBPROC)
      glfwGetProcAddress("glGetObjectParameterivARB");
    glGetInfoLogARB = (PFNGLGETINFOLOGARBPROC)
      glfwGetProcAddress("glGetInfoLogARB");
    glGetUniformLocationARB = (PFNGLGETUNIFORMLOCATIONARBPROC)
      glfwGetProcAddress("glGetUniformLocationARB");
    glGetUniformfvARB = (PFNGLGETUNIFORMFVARBPROC)
      glfwGetProcAddress("glGetUniformfvARB");
    glGetUniformivARB = (PFNGLGETUNIFORMIVARBPROC)
      glfwGetProcAddress("glGetUniformivARB");
  }
  IS_VERTEX_SHADER_SUPPORTED =
    glfwExtensionSupported("GL_ARB_vertex_shader");
  if(IS_VERTEX_SHADER_SUPPORTED) {
    //
  }
  IS_FRAGMENT_SHADER_SUPPORTED =
    glfwExtensionSupported("GL_ARB_fragment_shader");
  if(IS_FRAGMENT_SHADER_SUPPORTED) {
    //
  }
#endif // USE_GLFW
#endif // !USE_OGLES
  applyVSync();
  glShadeModel(GL_SMOOTH);
#ifdef USE_OGLES
  glClearDepthf(1);
#else // !USE_OGLES
  glClearDepth(1);
#endif // !USE_OGLES
  glClearColor(0,0,0,1);
  glClearStencil(0);
  glClear(GL_STENCIL_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_LIGHTING);
  glEnable(GL_CULL_FACE);
  glDisable(GL_BLEND);
  glEnable(GL_TEXTURE_2D);
#ifdef USE_OGLES
#else // !USE_OGLES
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);
  glDisable(GL_POLYGON_SMOOTH);
  glHint(GL_POLYGON_SMOOTH_HINT,GL_NICEST);
  glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER,1);
#endif // !USE_OGLES
  glDisable(GL_LINE_SMOOTH);
  glDisable(GL_POINT_SMOOTH);
  glDisable(GL_COLOR_MATERIAL);
  glDepthFunc(GL_LEQUAL);
  glDepthMask(GL_TRUE);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  glAlphaFunc(GL_GREATER,0);
  glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
  glHint(GL_FOG_HINT,GL_NICEST);
  glHint(GL_LINE_SMOOTH_HINT,GL_NICEST);
  glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);
  glCullFace(GL_BACK);
  glFrontFace(GL_CCW);
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
  glLightModelf(GL_LIGHT_MODEL_TWO_SIDE,GL_FALSE);
  glMatrixMode(GL_TEXTURE);
  glLoadIdentity();
  glMatrixMode(GL_MODELVIEW);
  camera = new GLCamera();
  camera->setViewport(0,0,getWidth(),getHeight());
  world = new GLWorld();
  overlay = new GLOverlay();
  return true;
}

void GLRenderer::applyVSync() {
#ifdef USE_OGLES
#elif defined(USE_GLFW)
  glfwSwapInterval(vSyncOn? 1: 0);
#else // !USE_OGLES && !USE_GLFW
  wglSwapIntervalEXT? wglSwapIntervalEXT(vSyncOn? 1: 0): vSyncOn = true;
#endif // USE_GLFW
}

void GLRenderer::finalizeRenderer() {
  if(overlay) {
    delete overlay;
    overlay = NULL;
  }
  if(world) {
    delete world;
    world = NULL;
  }
  if(camera) {
    delete camera;
    camera = NULL;
  }
}

void GLRenderer::executeRendering() {
  world->render(getCamera());
  if(isMainOverlayDrawn() || (!overlay->isEmpty())) {
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glViewport(0,0,getWidth(),getHeight());
#ifdef USE_OGLES
    glOrthof(0,getWidth(),0,getHeight(),-1,getCamera().getClipPlaneFar());
#else // !USE_OGLES
    glOrtho(0,getWidth(),0,getHeight(),-1,getCamera().getClipPlaneFar());
#endif // !USE_OGLES
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    if(!overlay->isEmpty()) {
      glLoadIdentity();
      overlay->render(getCamera());
    }
    if(isMainOverlayDrawn()) {
      glLoadIdentity();
      drawMainOverlay();
    }
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
  }
};

