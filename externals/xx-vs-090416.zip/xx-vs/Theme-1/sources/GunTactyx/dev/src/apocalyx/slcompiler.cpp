/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

#define NO_MAIN
#define SC_FUNC static
#define SC_VDEFINE static
#define SC_SKIP_VDECL

#include "small/sc.h"

#include "small/scvars.c"
#include "small/sc1.c"
#include "small/sc2.c"
#include "small/sc3.c"
#include "small/sc4.c"
#include "small/sc5.c"
#include "small/sc6.c"
#include "small/sc7.c"
#include "small/sclist.c"
#include "small/scexpand.c"

extern "C" {
  int sc_vprintf(const char *message, va_list argptr);
  int sc_printf(const char *message, ...);
}

int sc_error(
  int number, char *message, char *filename,
  int firstline, int lastline, va_list argptr
) {
  static char *prefix[3] = {"Error","Fatal","Warning"};
  if(number != 0) {
    char *pre = prefix[number/100];
    if(firstline >= 0)
      sc_printf(
        "%s(%d -- %d) %s [%03d]: ",filename,firstline,lastline,pre,number
      );
    else
      sc_printf("%s(%d) %s [%03d]: ",filename,lastline,pre,number)
    ;
  }
  sc_vprintf(message,argptr);
  return 0;
}

void *sc_opensrc(char *filename) {
  return fopen(filename,"rt");
}

void sc_closesrc(void *handle) {
  if(handle) fclose((FILE*)handle);
}

void sc_resetsrc(void *handle, void *position) {
  if(handle) fsetpos((FILE*)handle,(fpos_t *)position);
}

char *sc_readsrc(void *handle, char *target, int maxchars) {
  return fgets(target,maxchars,(FILE*)handle);
}

void *sc_getpossrc(void *handle) {
  static fpos_t lastpos;
  fgetpos((FILE*)handle,&lastpos);
  return &lastpos;
}

int sc_eofsrc(void *handle) {
  return feof((FILE*)handle);
}

void *sc_openasm(char *filename) {
  return fopen(filename,"w+t");
}

void sc_closeasm(void *handle, int deletefile) {
  fclose((FILE*)handle);
  if(deletefile) unlink(outfname);
}

void sc_resetasm(void *handle) {
  fflush((FILE*)handle);
  fseek((FILE*)handle,0,SEEK_SET);
}

int sc_writeasm(void *handle, char *st) {
  return fputs(st,(FILE*)handle) >= 0;
}

char *sc_readasm(void *handle, char *target, int maxchars) {
  return fgets(target,maxchars,(FILE*)handle);
}

void *sc_openbin(char *filename) {
  return fopen(filename,"wb");
}

void sc_closebin(void *handle, int deletefile) {
  fclose((FILE*)handle);
  if(deletefile) unlink(binfname);
}

void sc_resetbin(void *handle) {
  fflush((FILE*)handle);
  fseek((FILE*)handle,0,SEEK_SET);
}

int sc_writebin(void *handle,void *buffer,int size) {
  return fwrite(buffer,1,size,(FILE*)handle) == size;
}

long sc_lengthbin(void *handle) {
  return ftell((FILE*)handle);
}

#endif // USE_CONSOLE && USE_SMALL

