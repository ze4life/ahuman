#ifndef GLTEAMS_H
#define GLTEAMS_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_BSP

#include "glmodel.h"
#include "glscenery.h"

//
// GLYawPitchAngles
//
class GLYawPitchAngles {
private:
  M3Reference transform;
  float pitch;
  float yaw;
public:
  float* getTransform() {return transform.getTransform();}
  float getPitch() {return pitch;}
  float getYaw() {return yaw;}
  void setAngles(float y, float p) {yaw = y; pitch = p; updateRotations();}
  void addAngles(
    float& y, float& p,
    float maxY = 0, float minY = 0, float maxP = 0, float minP = 0
  ) {
    float oldY = yaw;
    yaw += y;
    y = 0;
    if(maxY) {
      if(yaw > maxY) {
        y = yaw-maxY;
        yaw = maxY;
      } else {
        if(minY) {
          if(yaw < minY) {
            y = yaw-minY;
            yaw = minY;
          }
        } else {
          if(yaw < -maxY) {
            y = yaw+maxY;
            yaw = -maxY;
          }
        }
      }
    }
    float oldP = pitch;
    pitch += p;
    p = 0;
    if(maxP) {
      if(pitch > maxP) {
        p = pitch-maxP;
        pitch = maxP;
      } else {
        if(minP) {
          if(pitch < minP) {
            p = pitch-minP;
            pitch = minP;
          }
        } else {
          if(pitch < -maxP) {
            p = pitch+maxP;
            pitch = -maxP;
          }
        }
      }
    }
    if(yaw != oldY || pitch != oldP)
      updateRotations();
  }
protected:
  void updateRotations() {
    M3RotationY rot(-pitch);
    M3RotationZ rotZ(-yaw);
    rot.multiply(rotZ);
    transform.set(rot);
  }
public:
  GLYawPitchAngles();
};

//
// GLAnimationManager
//
class GLAnimationManager {
public:
  int currFrame;
  int nextFrame;
  float lastUpdate;
  float interpolation;
  int currAnimation;
  int stopAnimation;
public:
  GLAnimationManager();
  int getStoppedAnimation()
    {int a = stopAnimation; stopAnimation = -1; return a;}
  int getCurrentAnimation() {return currAnimation;}
  void setAnimation(GLModel& model, int anim) {
    lastUpdate = GLModel::getAnimationTime() < 0?
      GLWin::getElapsedTime(): GLModel::getAnimationTime();
    currAnimation = anim;
    stopAnimation = -1;
    GLAnimationData& animation = model.bone->animations[currAnimation];
    if(currFrame < 0) {
      currFrame = animation.firstFrame;
      nextFrame = currFrame+1;
      if(nextFrame > animation.lastFrame)
        nextFrame = currFrame;
    } else {
      nextFrame = animation.firstFrame;
      if(currFrame == nextFrame) {
        nextFrame = currFrame+1;
        if(nextFrame > animation.lastFrame)
          nextFrame = currFrame;
      }
    }
  }
};

//
// GLTeamMate
//
class GLTeamMate: public GLObject {
// status
public:
  enum Status {NORMAL = 0, HAS_SIGN, HAS_WEAPON, HAS_WEAPON2};
private:
  Status status;
  bool dead;
public:
  Status getStatus() {return status;}
  void setStatus(Status s) {status = s;}
  bool isDead() {return dead;}
  void setDead(bool d) {dead = d;}
// flash
private:
  bool flashShown;
public:
  bool isFlashShown() {return flashShown;}
  void setFlashShown(bool fs) {flashShown = fs;}
// head
private:
  GLYawPitchAngles headAngles;
public:
  GLYawPitchAngles& getHeadAngles() {return headAngles;}
// torso
private:
  GLYawPitchAngles torsoAngles;
  GLAnimationManager torsoAnimation;
  int lastTorsoAnimation;
public:
  GLYawPitchAngles& getTorsoAngles() {return torsoAngles;}
  GLAnimationManager& getTorsoAnimation() {return torsoAnimation;}
  void setTorsoAnimation(GLBot* bot, int anim)
    {getTorsoAnimation().setAnimation(bot->getUpper(),anim);}
  void setLastTorsoAnimation(int ta) {lastTorsoAnimation = ta;}
  int getLastTorsoAnimation() {return lastTorsoAnimation;}
// legs
private:
  GLAnimationManager legsAnimation;
public:
  GLAnimationManager& getLegsAnimation() {return legsAnimation;}
  void setLegsAnimation(GLBot* bot, int anim)
    {getLegsAnimation().setAnimation(bot->getLower(),anim);}
// whole
private:
  float modelTransform[16];
public:
  void saveTransform() {glGetFloatv(GL_MODELVIEW_MATRIX,modelTransform);}
  void loadTransform() {glLoadMatrixf(modelTransform);}
  float* getModelTransform() {return modelTransform;}
private:
  void* genericData;
public:
  GLTeamMate(GLBot* bot);
  void setGenericData(void* gd) {genericData = gd;}
  void* getGenericData() {return genericData;}
  GLModel& writeLegsAnimationData(GLBot* bot) {
    GLModel& legs = bot->getLower();
    legs.currFrame = legsAnimation.currFrame;
    legs.nextFrame = legsAnimation.nextFrame;
    legs.lastUpdate = legsAnimation.lastUpdate;
    legs.interpolation = legsAnimation.interpolation;
    legs.currAnimation = legsAnimation.currAnimation;
    legs.stopAnimation = legsAnimation.stopAnimation;
    return legs;
  }
  GLModel& writeTorsoAnimationData(GLBot* bot) {
    GLModel& torso = bot->getUpper();
    torso.currFrame = torsoAnimation.currFrame;
    torso.nextFrame = torsoAnimation.nextFrame;
    torso.lastUpdate = torsoAnimation.lastUpdate;
    torso.interpolation = torsoAnimation.interpolation;
    torso.currAnimation = torsoAnimation.currAnimation;
    torso.stopAnimation = torsoAnimation.stopAnimation;
    return torso;
  }
  void updateLegsFrames(GLBot* bot) {
    GLModel& legs = writeLegsAnimationData(bot);
    legs.updateFrame();
    legsAnimation.currFrame = legs.currFrame;
    legsAnimation.nextFrame = legs.nextFrame;
    legsAnimation.lastUpdate = legs.lastUpdate;
    legsAnimation.interpolation = legs.interpolation;
    legsAnimation.currAnimation = legs.currAnimation;
    legsAnimation.stopAnimation = legs.stopAnimation;
  }
  void updateTorsoFrames(GLBot* bot) {
    GLModel& torso = writeTorsoAnimationData(bot);
    torso.updateFrame();
    torsoAnimation.currFrame = torso.currFrame;
    torsoAnimation.nextFrame = torso.nextFrame;
    torsoAnimation.lastUpdate = torso.lastUpdate;
    torsoAnimation.interpolation = torso.interpolation;
    torsoAnimation.currAnimation = torso.currAnimation;
    torsoAnimation.stopAnimation = torso.stopAnimation;
  }
  void updateFrames(GLBot* bot) {
    updateLegsFrames(bot);
    updateTorsoFrames(bot);
  }
  virtual void render(GLCamera& camera) {}
};

//
// GLWeaponData
//
class GLWeaponData: virtual public Void {
public:
  enum WeaponID {
    ID_SIGN = 0, ID_WEAPON, ID_WEAPON2
  };
  virtual bool getWeaponStatus(
    int& idx, M3Vector& pos, int& type, int& attrib
  ) = 0;
};

//
// GLPowerupData
//
class GLPowerupData: virtual public Void {
public:
  enum PowerupID {
    ID_MEDIKIT = 0, ID_FOOD, ID_ARMOR, ID_BULLETS, ID_GRENADES, ID_TARGET
  };
  virtual bool getPowerupStatus(
    int& idx, M3Vector& pos, int& type, int& attrib
  ) = 0;
};

//
// GLAmmoData
//
class GLAmmoData: virtual public Void {
public:
  enum AmmoID {
    ID_BULLET = 0, ID_GRENADE, ID_BULLET2, ID_GRENADE2
  };
  virtual bool getAmmoStatus(
    int& idx, M3Vector& pos, int& type, int& attrib
  ) = 0;
};

//
// GLTeams
//
class GLTeams: public GLFurniture {
private:
  GLDisplayList* flashLists;
  GLDisplayList* weaponLists;
  GLDisplayList signList;
  GLDisplayList torsoList;
  GLDisplayList headList;
public:
  GLDisplayList& getFlashList(int idx) {return flashLists[idx];}
  GLDisplayList& getWeaponList(int idx) {return weaponLists[idx];}
  GLDisplayList& getSignList() {return signList;}
  GLDisplayList& getTorsoList() {return torsoList;}
  GLDisplayList& getHeadList() {return headList;}
protected:
  GLBot* bot;
  int teamsCount;
  int weaponsCount;
  GLWeaponData* weaponData;
  DSSortedArray<GLTeamMate>** team;
  GLBasicMaterial** bodyMaterials;
  GLBasicMaterial** torsoMaterials;
  GLBasicMaterial** weaponMaterials;
  GLTexture** flashTextures;
  GLBasicMaterial* signMaterial;
  GLTexture* shadowTexture;
  float shadowHeight;
  float shadowWidth;
  int defaultTorsoFrame;
  float lodDistance;
protected:
  void renderBodies(GLCamera& c, GLScenery& s);
  void renderLegs(GLCamera& c, GLScenery& s);
  void renderTorsos(GLCamera& c, GLScenery& s);
  void renderWeapons(GLCamera& c, GLScenery& s);
  void renderHeads(GLCamera& c, GLScenery& s);
  void renderFlashes(GLCamera& c, GLScenery& s);
  void renderDropped(GLCamera& c, GLScenery& s);
public:
  GLTeams(
    int iTeamsCount, int iTeamMates, GLBot& iBot,
    GLBasicMaterial** iBodyMaterials, GLBasicMaterial** iTorsoMaterials,
    GLModel& iSign, int iWeaponsCount, GLModel** iWeapon, GLModel** iFlash,
    float lod, GLTexture* iShadowTexture = NULL, float iShadowWidth = 0,
    float iShadowHeight = 0
  );
  ~GLTeams();
  GLBot* getBotModel() {return bot;}
  void setWeaponData(GLWeaponData& wd) {weaponData = &wd;}
  int getTeamsCount() {return teamsCount;}
  int getTeamMatesCount(int tid) {return team[tid]->getSize();}
  GLTeamMate* getTeamMate(int tid, int idx) {return team[tid]->getElement(idx);}
  int getWeaponsCount() {return weaponsCount;}
  float getLodDistance() {return lodDistance;}
  bool isGTLodDistance(float dist) {return dist >= lodDistance;}
  virtual void initRender(GLCamera& camera, GLScenery& scenery);
  virtual void render(GLCamera& camera, GLScenery& scenery);
};

//
// GLPowerups
//
class GLPowerups: public GLFurniture {
private:
  GLDisplayList medikitList;
  GLDisplayList foodList;
  GLDisplayList armorList;
  GLDisplayList bulletsList;
  GLDisplayList grenadesList;
  GLDisplayList targetList;
public:
  GLDisplayList& getMedikitList() {return medikitList;}
  GLDisplayList& getFoodList() {return foodList;}
  GLDisplayList& getArmorList() {return armorList;}
  GLDisplayList& getBulletsList() {return bulletsList;}
  GLDisplayList& getGrenadesList() {return grenadesList;}
  GLDisplayList& getTargetList() {return targetList;}
protected:
  GLPowerupData* powerupData;
  GLBasicMaterial* medikitMaterial;
  GLBasicMaterial* foodMaterial;
  GLBasicMaterial* armorMaterial;
  GLBasicMaterial* bulletsMaterial;
  GLBasicMaterial* grenadesMaterial;
  GLBasicMaterial* targetMaterial;
  GLTexture* shadowTexture;
public:
  GLPowerups(
    GLModel& iMedikit, GLModel& iFood, GLModel& iArmor, GLModel& iBullets,
    GLModel& iGrenades, GLModel& iTarget, GLPowerupData& pd,
    GLTexture* iShadowTexture = NULL
  );
  ~GLPowerups();
  void setPowerupData(GLPowerupData& pd) {powerupData = &pd;}
  virtual void initRender(GLCamera& camera, GLScenery& scenery) {}
  virtual void render(GLCamera& camera, GLScenery& scenery);
};

//
// GLAmmo
//
class GLAmmo: public GLFurniture {
private:
  int weaponsCount;
  float* halfSize;
  float* halfExplSize;
  GLColor* bulletsColor;
  GLColor* grenadesColor;
  GLTexture** texture;
  GLTexture** explTexture;
#ifdef USE_SOUND
  FM3DSample** explSample;
  bool* isSoundEnabled;
#endif // USE_SOUND
  GLAmmoData* ammoData;
public:
  GLAmmo(
    int iWeaponsCount, float* hSize, float* hExplSize, GLTexture** txt,
    GLTexture** explTxt,
#ifdef USE_SOUND
    FM3DSample** explSample, bool* soundEnabled,
#endif // USE_SOUND
    GLAmmoData& ad
  );
  ~GLAmmo();
  void setBulletsColor(int idx, float r, float g, float b)
    {bulletsColor[idx].set(r,g,b);}
  void setGrenadesColor(int idx, float r, float g, float b)
    {grenadesColor[idx].set(r,g,b);}
  void setAmmoData(GLAmmoData& ad) {ammoData = &ad;}
  virtual void initRender(GLCamera& camera, GLScenery& scenery) {}
  virtual void render(GLCamera& camera, GLScenery& scenery);
};

#endif // USE_BSP

#endif // GLTEAMS_H
