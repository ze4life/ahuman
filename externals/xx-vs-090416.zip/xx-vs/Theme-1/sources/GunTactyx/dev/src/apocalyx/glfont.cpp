/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glfont.h"

//
// GLFont
//

GLFont::GLFont(int h, int w, int s):
  height(h), width(w), spacing(s? s: (w? w: h>>1))
{
#ifdef USE_OGLES
#else // !USE_OGLES
  listBase = glGenLists(getListLength());
#endif // !USE_OGLES
}

GLFont::~GLFont() {
#ifdef USE_OGLES
#else // !USE_OGLES
  glDeleteLists(getListBase(),getListLength());
#endif // !USE_OGLES
}

void GLFont::destroyObject() {
  delete this;
}

//
// GLTexturedFont
//
GLTexturedFont::GLTexturedFont(int h, int w, int s, GLTexture* txt):
  GLFont(h,w,s), texture(txt->acquireReference())
#ifdef USE_OGLES
#else // !USE_OGLES
  , listOffset(32)
#endif // !USE_OGLES
{
#ifdef USE_OGLES
#else // !USE_OGLES
  const float charSide = 16/256.0f;
	for(int ct = 0; ct < getListLength(); ct++) {
		float charX = (ct%16)*charSide;
		float charY = 1-(ct/16)*charSide;
		glNewList(getListBase()+ct,GL_COMPILE);
		glBegin(GL_QUADS);
		glTexCoord2f(charX,charY-charSide);
		glVertex2i(0,0);
		glTexCoord2f(charX+charSide,charY-charSide);
		glVertex2i(getWidth()-1,0);
		glTexCoord2f(charX+charSide,charY);
		glVertex2i(getWidth()-1,getHeight()-1);
		glTexCoord2f(charX,charY);
		glVertex2i(0,getHeight()-1);
		glEnd();
		glTranslatef(getSpacing(),0,0);
		glEndList();
	}
#endif // !USE_OGLES
}

GLTexturedFont::~GLTexturedFont() {
  if(texture) texture->releaseReference();
}

#ifdef USE_OGLES

void GLTexturedFont::drawText(int length, const char* text) {
  const float charSide = 16/256.0f;
	for(int ct = 0; ct < length; ct++) {
    int theChar = int((unsigned char*)&text[ct]);
		float charX = (theChar%16)*charSide;
		float charY = (theChar/16)*charSide;
    const int VERT_COUNT = 4;
    const int COMP_COUNT = 2;
    float vertexes[COMP_COUNT*VERT_COUNT] = {
      0,getHeight()-1, getWidth()-1,getHeight()-1, 0,0, getWidth()-1,0,
    };
    float texCoords[COMP_COUNT*VERT_COUNT] = {
      charX,charY-charSide, charX+charSide,charY-charSide,
      charX,charY, charX+charSide,charY,
    };
    glVertexPointer(COMP_COUNT,GL_FLOAT,COMP_COUNT*sizeof(float),vertexes);
    glTexCoordPointer(COMP_COUNT,GL_FLOAT,COMP_COUNT*sizeof(float),texCoords);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glDrawArrays(GL_TRIANGLE_STRIP,0,VERT_COUNT);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		glTranslatef(getSpacing(),0,0);
	}
}

#endif // USE_OGLES

#if !defined(USE_GLFW) && !defined(USE_OGLES)

//
// GLBitmapFont
//

GLBitmapFont::GLBitmapFont(
  HDC hDC, const char* face, int h, int w, int weight, bool italic
):
  GLFont(h,w)
{
  HGDIOBJ oldFont = GetCurrentObject(hDC,OBJ_FONT);
  HFONT font = CreateFont(
    getHeight(), getWidth(), 0, 0, weight, italic, FALSE, FALSE,
    ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
    ANTIALIASED_QUALITY, VARIABLE_PITCH, face
  );
  SelectObject(hDC,font);
  wglUseFontBitmaps(hDC,0,getListLength(),getListBase());
  DeleteObject(font);
  SelectObject(hDC,oldFont);
}

//
// GLOutlineFont
//

GLOutlineFont::GLOutlineFont(
  HDC hDC, const char* face, int h, int w, float depth, int weight, bool italic
):
  GLFont(h,w)
{
  HGDIOBJ oldFont = GetCurrentObject(hDC,OBJ_FONT);
  HFONT font = CreateFont(
    getHeight(), getWidth(), 0, 0, weight, italic, FALSE, FALSE,
    ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
    ANTIALIASED_QUALITY, VARIABLE_PITCH, face
  );
  SelectObject(hDC,font);
  wglUseFontOutlines(
    hDC,0,getListLength(),getListBase(),
    0.0f,depth,WGL_FONT_POLYGONS,glyphMetricsFloat
  );
  DeleteObject(font);
  SelectObject(hDC,oldFont);
}

//
// GLText
//

GLText::GLText(const char* txt, GLOutlineFont* fnt, GLBasicMaterial* mat):
  text(txt), font(dynamic_cast<GLOutlineFont*>(fnt->acquireReference())),
  GLBasicMaterialOwner(mat)
{
  computeMaxRadius();
}

GLText::~GLText() {
  font->releaseReference();
}

void GLText::computeMaxRadius() {
  float w = 0;
  for(unsigned int ct = 0; ct < strlen(text); ct++)
    w += font->getCellWidth(text[ct]);
  setMaxRadius(w*0.5f);
}

void GLText::render(GLCamera& camera) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  font->setPosition(-getMaxRadius(),0,0);
  glPushMatrix();
  GLBasicMaterial* basMat = getBasicMaterial();
  basMat->applyColor();
  glDisable(GL_TEXTURE_2D);
  font->initialize();
  font->drawText(strlen(text),text);
  glEnable(GL_TEXTURE_2D);
  glPopMatrix();
  GLMaterial* mat = getMaterial();
  if(mat && mat->hasEnvironment()) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE,GL_ONE);
    mat->enableEnvironment(camera);
    font->drawText(strlen(text),text);
    mat->disableEnvironment();
    glDisable(GL_BLEND);
  }
  basMat->unapplyColor();
  glFrontFace(GL_CCW);
  glPopMatrix();
}

#endif // !USE_GLFW && !USE_OGLES
