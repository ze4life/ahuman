#ifndef GLRENDERER_H
#define GLRENDERER_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glworld.h"
#include "gloverlay.h"
#include "glfont.h"

//
// GLRenderer
//
#if !defined(USE_GLFW) && !defined(USE_OGLES)
struct VideoMode {
  int width;
  int height;
  int colorDepth;
};
#endif // !USE_GLFW && !USE_OGLES

class GLRenderer {
private:
  bool vSyncOn;
  int width;
  int height;
  int frequency;
  int videoModesCount;
  int currentVideoMode;
#ifdef USE_OGLES
#elif defined(USE_GLFW)
  GLFWvidmode* videoModes;
  int redDepth;
  int greenDepth;
  int blueDepth;
  bool fullscreenOn;
#else // !USE_GLFW && !USE_OGLES
  VideoMode* videoModes;
  int colorDepth;
#endif // !USE_GLFW && !USE_OGLES
  int depthDepth;
  int stencilDepth;
protected:
  void setVSyncOn(bool b) {vSyncOn = b;}
  void applyVSync();
  void setWidth(int w) {width = w;}
  void setHeight(int h) {height = h;}
  void setFrequency(int f) {frequency = f;}
  int getVideoModesCount() {return videoModesCount;}
  int getCurrentVideoMode() {return currentVideoMode;}
  void setCurrentVideoMode(int idx) {currentVideoMode = idx;}
#ifdef USE_OGLES
#elif defined(USE_GLFW)
  GLFWvidmode* getVideoMode(int idx)
    {return idx < videoModesCount? &videoModes[idx]: NULL;}
  void setRedDepth(int cd) {redDepth = cd;}
  void setGreenDepth(int cd) {greenDepth = cd;}
  void setBlueDepth(int cd) {blueDepth = cd;}
  bool getFullscreenOn() {return fullscreenOn;}
#else // !USE_GLFW && !USE_OGLES
  VideoMode* getVideoMode(int idx)
    {return idx < videoModesCount? &videoModes[idx]: NULL;}
  void setVideoModes(int count, VideoMode* pointer) {
    videoModesCount = count;
    if(videoModes) delete videoModes;
    videoModes = pointer;
  }
  void setColorDepth(int cd) {colorDepth = cd;}
#endif // !USE_GLFW && !USE_OGLES
  void setDepthDepth(int dd) {depthDepth = dd;}
  void setStencilDepth(int sd) {stencilDepth = sd;}
  void setSize(int w, int h) {setWidth(w); setHeight(h);}
public:
  bool isVSyncOn() {return vSyncOn;}
  int getWidth() {return width;}
  int getHeight() {return height;}
  int getFrequency() {return frequency;}
#ifdef USE_OGLES
#elif defined(USE_GLFW)
  int getRedDepth() {return redDepth;}
  int getGreenDepth() {return greenDepth;}
  int getBlueDepth() {return blueDepth;}
#else // !USE_GLFW && !USE_OGLES
  int getColorDepth() {return colorDepth;}
#endif // !USE_GLFW && !USE_OGLES
  int getDepthDepth() {return depthDepth;}
  int getStencilDepth() {return stencilDepth;}
private:
  GLWorld* world;
  GLOverlay* overlay;
  GLCamera* camera;
public:
  GLRenderer();
  ~GLRenderer();
  bool initializeRenderer();
  void finalizeRenderer();
  void executeRendering();
  virtual void drawMainOverlay() {};
  virtual GLFont* getMainOverlayFont() {return NULL;}
  virtual bool isMainOverlayDrawn() {return false;}
  GLCamera* setCamera(GLCamera* newCamera)
    {GLCamera* oldCamera = camera; camera = newCamera; return oldCamera;}
  GLCamera& getCamera() {return *camera;}
  void setPerspective(float fov, float zn, float zf)
  	{camera->setPerspective(fov,zn,zf);}
  void setViewport(float x, float y, float w, float h)
  	{camera->setViewport(x,y,w,h);}
  void updateAspect()
    {if(camera) camera->updateAspect((float)width,(float)height);}
  GLWorld& getWorld() {return *world;}
  GLOverlay& getOverlay() {return *overlay;}
};

#endif // GLRENDERER_H
