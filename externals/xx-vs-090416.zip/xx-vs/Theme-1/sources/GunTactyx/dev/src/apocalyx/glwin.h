#ifndef GLWIN_H
#define GLWIN_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "exception.h"
#include "glrenderer.h"

#ifdef USE_SJGUI
#include "sjgui/sjgui.h"
#endif // USE_SJGUI

//
// keyboard
//
#ifdef USE_OGLES

#define KEY_SPACE     32
#define KEY_ESCAPE    27
#define KEY_F1        (0x100|GLUT_KEY_F1 )
#define KEY_F2        (0x100|GLUT_KEY_F2 )
#define KEY_F3        (0x100|GLUT_KEY_F3 )
#define KEY_F4        (0x100|GLUT_KEY_F4 )
#define KEY_F5        (0x100|GLUT_KEY_F5 )
#define KEY_F6        (0x100|GLUT_KEY_F6 )
#define KEY_F7        (0x100|GLUT_KEY_F7 )
#define KEY_F8        (0x100|GLUT_KEY_F8 )
#define KEY_F9        (0x100|GLUT_KEY_F9 )
#define KEY_F10       (0x100|GLUT_KEY_F10)
#define KEY_F11       (0x100|GLUT_KEY_F11)
#define KEY_F12       (0x100|GLUT_KEY_F12)
#define KEY_UP        (0x100|GLUT_KEY_UP   )
#define KEY_DOWN      (0x100|GLUT_KEY_DOWN )
#define KEY_LEFT      (0x100|GLUT_KEY_LEFT )
#define KEY_RIGHT     (0x100|GLUT_KEY_RIGHT)
#undef KEY_LSHIFT
#undef KEY_RSHIFT
#undef KEY_SHIFT
#undef KEY_LCTRL
#undef KEY_RCTRL
#undef KEY_CTRL
#define KEY_TAB       9
#define KEY_RETURN    10
#define KEY_BACK      8
#define KEY_INSERT    (0x100|GLUT_KEY_INSERT)
#undef KEY_DELETE
#define KEY_PRIOR     (0x100|GLUT_KEY_PAGE_UP  )
#define KEY_NEXT      (0x100|GLUT_KEY_PAGE_DOWN)
#define KEY_HOME      (0x100|GLUT_KEY_HOME)
#define KEY_END       (0x100|GLUT_KEY_END )
#undef KEY_NUMPAD0
#undef KEY_NUMPAD1
#undef KEY_NUMPAD2
#undef KEY_NUMPAD3
#undef KEY_NUMPAD4
#undef KEY_NUMPAD5
#undef KEY_NUMPAD6
#undef KEY_NUMPAD7
#undef KEY_NUMPAD8
#undef KEY_NUMPAD9
#undef KEY_DIVIDE
#undef KEY_MULTIPLY
#undef KEY_SUBTRACT
#undef KEY_ADD
#undef KEY_DECIMAL

#elif defined(USE_GLFW)

#define KEY_SPACE     GLFW_KEY_SPACE
#define KEY_ESCAPE    GLFW_KEY_ESC
#define KEY_F1        GLFW_KEY_F1
#define KEY_F2        GLFW_KEY_F2
#define KEY_F3        GLFW_KEY_F3
#define KEY_F4        GLFW_KEY_F4
#define KEY_F5        GLFW_KEY_F5
#define KEY_F6        GLFW_KEY_F6
#define KEY_F7        GLFW_KEY_F7
#define KEY_F8        GLFW_KEY_F8
#define KEY_F9        GLFW_KEY_F9
#define KEY_F10       GLFW_KEY_F10
#define KEY_F11       GLFW_KEY_F11
#define KEY_F12       GLFW_KEY_F12
#define KEY_UP        GLFW_KEY_UP
#define KEY_DOWN      GLFW_KEY_DOWN
#define KEY_LEFT      GLFW_KEY_LEFT
#define KEY_RIGHT     GLFW_KEY_RIGHT
#define KEY_LSHIFT    GLFW_KEY_LSHIFT
#define KEY_RSHIFT    GLFW_KEY_RSHIFT
#define KEY_SHIFT     GLFW_KEY_RSHIFT
#define KEY_LCTRL     GLFW_KEY_LCTRL
#define KEY_RCTRL     GLFW_KEY_RCTRL
#define KEY_CTRL      GLFW_KEY_RCTRL
#define KEY_TAB       GLFW_KEY_TAB
#define KEY_RETURN    GLFW_KEY_ENTER
#define KEY_BACK      GLFW_KEY_BACKSPACE
#define KEY_INSERT    GLFW_KEY_INSERT
#define KEY_DELETE    GLFW_KEY_DEL
#define KEY_PRIOR     GLFW_KEY_PAGEUP
#define KEY_NEXT      GLFW_KEY_PAGEDOWN
#define KEY_HOME      GLFW_KEY_HOME
#define KEY_END       GLFW_KEY_END
#define KEY_NUMPAD0   GLFW_KEY_KP_0
#define KEY_NUMPAD1   GLFW_KEY_KP_1
#define KEY_NUMPAD2   GLFW_KEY_KP_2
#define KEY_NUMPAD3   GLFW_KEY_KP_3
#define KEY_NUMPAD4   GLFW_KEY_KP_4
#define KEY_NUMPAD5   GLFW_KEY_KP_5
#define KEY_NUMPAD6   GLFW_KEY_KP_6
#define KEY_NUMPAD7   GLFW_KEY_KP_7
#define KEY_NUMPAD8   GLFW_KEY_KP_8
#define KEY_NUMPAD9   GLFW_KEY_KP_9
#define KEY_DIVIDE    GLFW_KEY_KP_DIVIDE
#define KEY_MULTIPLY  GLFW_KEY_KP_MULTIPLY
#define KEY_SUBTRACT  GLFW_KEY_KP_SUBTRACT
#define KEY_ADD       GLFW_KEY_KP_ADD
#define KEY_DECIMAL   GLFW_KEY_KP_DECIMAL

#else // !USE_OGLES && !USE_GLFW

#define KEY_SPACE     VK_SPACE
#define KEY_ESCAPE    VK_ESCAPE
#define KEY_F1        VK_F1
#define KEY_F2        VK_F2
#define KEY_F3        VK_F3
#define KEY_F4        VK_F4
#define KEY_F5        VK_F5
#define KEY_F6        VK_F6
#define KEY_F7        VK_F7
#define KEY_F8        VK_F8
#define KEY_F9        VK_F9
#define KEY_F10       VK_F10
#define KEY_F11       VK_F11
#define KEY_F12       VK_F12
#define KEY_UP        VK_UP
#define KEY_DOWN      VK_DOWN
#define KEY_LEFT      VK_LEFT
#define KEY_RIGHT     VK_RIGHT
#define KEY_LSHIFT    VK_SHIFT
#define KEY_RSHIFT    VK_SHIFT
#define KEY_SHIFT     VK_SHIFT
#define KEY_LCTRL     VK_CTRL
#define KEY_RCTRL     VK_CTRL
#define KEY_CTRL      VK_CTRL
#define KEY_TAB       VK_TAB
#define KEY_RETURN    VK_RETURN
#define KEY_BACK      VK_BACK
#define KEY_INSERT    VK_INSERT
#define KEY_DELETE    VK_DELETE
#define KEY_PRIOR     VK_PRIOR
#define KEY_NEXT      VK_NEXT
#define KEY_HOME      VK_HOME
#define KEY_END       VK_END
#define KEY_NUMPAD0   VK_NUMPAD0
#define KEY_NUMPAD1   VK_NUMPAD1
#define KEY_NUMPAD2   VK_NUMPAD2
#define KEY_NUMPAD3   VK_NUMPAD3
#define KEY_NUMPAD4   VK_NUMPAD4
#define KEY_NUMPAD5   VK_NUMPAD5
#define KEY_NUMPAD6   VK_NUMPAD6
#define KEY_NUMPAD7   VK_NUMPAD7
#define KEY_NUMPAD8   VK_NUMPAD08
#define KEY_NUMPAD9   VK_NUMPAD09
#define KEY_DIVIDE    VK_DIVIDE
#define KEY_MULTIPLY  VK_MULTIPLY
#define KEY_SUBTRACT  VK_SUBTRACT
#define KEY_ADD       VK_ADD
#define KEY_DECIMAL   VK_DECIMAL

#endif // !USE_OGLES && !USE_GLFW

//
// GLWin
//
class GLWin: public GLRenderer {
#ifdef USE_OGLES
private:
  int winID;
#elif defined(USE_GLFW)
#else // !USE_GLFW && !USE_OGLES
	int lastMouseWheel;
private:
  HDC hDC;
  HWND hWnd;
  HGLRC hRC;
  HINSTANCE hInstance;
public:
  HDC getHDC() {return hDC;}
  HWND getHWND() {return hWnd;}
  HINSTANCE getHInstance() {return hInstance;}
private:
  bool active;
protected:
  void setActive(bool value) {active = value;}
public:
  bool isActive() {return active;}
#endif // !USE_GLFW && !USE_OGLES
private:
  bool running;
  bool paused;
public:
  void setPaused(bool value) {paused = value;}
  void exit() {running = false;}
  bool isRunning() {return running;}
  bool isPaused() {return paused;}
private:
  int mouseKeys;
  int mouseDX, mouseDY;
  int centerX, centerY;
  int mouseWheel;
  bool mouseAcquired;
  bool keys[512];
public:
  bool isMouseAcquired() {return mouseAcquired;}
  void keyDown(int key) {keys[key] = true;}
  void keyUp(int key) {keys[key] = false;}
  bool isKeyPressed(int key) {return keys[key];}
  int getMouseDX() {int dx = mouseDX; mouseDX = 0; return dx;}
  int getMouseDY() {int dy = mouseDY; mouseDY = 0; return dy;}
#ifdef USE_OGLES
  int getMouseWheel() {return 0;}
  enum GlutMouseKeys {
    OGLES_LEFT = 1, OGLES_MIDDLE = 2, OGLES_RIGHT = 4,
    OGLES_SHIFT = 8, OGLES_CTRL = 16
  };
  bool isControlPressed() {return bool(mouseKeys & OGLES_CTRL);}
  bool isShiftPressed() {return bool(mouseKeys & OGLES_SHIFT);}
  bool isLeftButtonPressed() {return bool(mouseKeys & OGLES_LEFT);}
  bool isMiddleButtonPressed() {return bool(mouseKeys & OGLES_MIDDLE);}
  bool isRightButtonPressed() {return bool(mouseKeys & OGLES_RIGHT);}
  void centerMouse() {}
  void acquireMouse(bool b) {
    if((mouseAcquired = b) == true) {
      glutSetCursor(GLUT_CURSOR_NONE);
      centerMouse();
    } else {
      glutSetCursor(GLUT_CURSOR_RIGHT_ARROW);
    }
  }
#elif defined(USE_GLFW)
private:
	int lastMouseWheel;
public:
  int getMouseWheel()
  	{int mw = mouseWheel-lastMouseWheel; lastMouseWheel = mouseWheel; return mw;}
  bool isControlPressed() {return keys[GLFW_KEY_LCTRL] || keys[GLFW_KEY_RCTRL];}
  bool isShiftPressed() {return keys[GLFW_KEY_LSHIFT] || keys[GLFW_KEY_RSHIFT];}
  bool isLeftButtonPressed() {return mouseKeys & (1<<GLFW_MOUSE_BUTTON_LEFT);}
  bool isMiddleButtonPressed() {return mouseKeys & (1<<GLFW_MOUSE_BUTTON_MIDDLE);}
  bool isRightButtonPressed() {return mouseKeys & (1<<GLFW_MOUSE_BUTTON_RIGHT);}
  void centerMouse() {glfwSetMousePos(0,0);}
  void acquireMouse(bool b) {
    if((mouseAcquired = b) == true) {
      glfwDisable(GLFW_MOUSE_CURSOR);
      centerMouse();
    } else {
      glfwEnable(GLFW_MOUSE_CURSOR);
    }
  }
#else // !USE_OGLES && !USE_GLFW
  int getMouseWheel() {int mw = mouseWheel; mouseWheel = 0; return mw;}
  bool isControlPressed() {return mouseKeys & MK_CONTROL;}
  bool isShiftPressed() {return mouseKeys & MK_SHIFT;}
  bool isLeftButtonPressed() {return mouseKeys & MK_LBUTTON;}
  bool isMiddleButtonPressed() {return mouseKeys & MK_MBUTTON;}
  bool isRightButtonPressed() {return mouseKeys & MK_RBUTTON;}
  void acquireMouse(bool b)
    {ShowCursor(!(mouseAcquired = b)); if(b) centerMouse();}
  void centerMouse() {
    POINT pt; pt.x = centerX; pt.y = centerY;
    MapWindowPoints(hWnd,NULL,&pt,1);
    SetCursorPos(pt.x,pt.y);
  }
#endif // !USE_OGLES && !USE_GLFW
private:
  bool fullscreen;
  int fullWidth;
  int fullHeight;
protected:
  void setFullscreen(bool value) {fullscreen = value;}
  void setFullWidth(int w) {setWidth(fullWidth = w);}
  void setFullHeight(int h) {setHeight(fullHeight = h);}
  void setFullSize(int w, int h) {setFullWidth(w); setFullHeight(h);}
public:
  bool isFullscreen() {return fullscreen;}
  int getFullWidth() {return fullWidth;}
  int getFullHeight() {return fullHeight;}
#if !defined(USE_GLFW) && !defined(USE_OGLES)
private:
  unsigned short oldGammaCorrections[256*3];
  float gammaCorrection;
public:
  float getGammaCorrection() {return gammaCorrection;}
  bool setGammaCorrection(float gamma);
#endif // USE_GLFW
private:
  char* setupFileName;
public:
  const char* getSetupFileName()
    {return setupFileName? setupFileName: "setup.ini";}
  void setSetupFileName(char* sfn) {
    if(setupFileName) delete setupFileName;
    setupFileName = sfn;
  }
#ifdef USE_OGLES
  void swapBuffers() {glutSwapBuffers();}
#elif defined(USE_GLFW)
  void swapBuffers() {glfwSwapBuffers();}
#else // !USE_OGLES && !USE_GLFW
  void swapBuffers() {SwapBuffers(getHDC());}
#endif // !USE_OGLES && !USE_GLFW
private:
  GLFont* mainOverlayFont;
public:
  GLFont* getMainOverlayFont() {return mainOverlayFont;}
  void setMainOverlayFont(GLFont* font) {
    if(mainOverlayFont) mainOverlayFont->releaseReference();
    mainOverlayFont = font? font->acquireReference(): NULL;
  }
public:
  enum HelpMode {HIDDEN_HELP, REDUCED_HELP, USER_HELP, FULL_HELP};
private:
  HelpMode helpMode;
  bool showFramerate;
  bool showVideoModes;
public:
  HelpMode getHelpMode() {return helpMode;}
  void setHelpMode(HelpMode hm) {helpMode = hm;}
  bool isVideoModesShown() {return showVideoModes;}
  void setShowVideoModes(bool value) {showVideoModes = value;}
  bool isFramerateShown() {return showFramerate;}
  void setShowFramerate(bool value) {showFramerate = value;}
#ifdef USE_CONSOLE
private:
  bool showConsole;
  float consoleOffset;
public:
  bool isConsoleShown() {return showConsole;}
  void setShowConsole(bool value) {showConsole = value;}
#endif // USE_CONSOLE
#ifdef USE_SJGUI
private:
  sjgui::CWnd gui;
public:
  sjgui::CWnd& getGui() {return gui;}
  int convertGuiKey(int key);
#endif // USE_SJGUI
protected:
  void drawMainOverlay();
  bool isMainOverlayDrawn() {return mainOverlayFont && (
	  (getHelpMode() != HIDDEN_HELP) || isFramerateShown() || isVideoModesShown()
#ifdef USE_CONSOLE
    || isConsoleShown() || (consoleOffset < getWidth())
#endif // USE_CONSOLE
  );}
  virtual const char* getHelpLine(int line) {return NULL;}
private:
  static float timeStep;
  static float invTimeStep;
  static float elapsedTime;
public:
  static float getTimeStep() {return timeStep;}
  static float getInvTimeStep() {return invTimeStep;}
  static float getElapsedTime() {return elapsedTime;}
#if !defined(USE_GLFW) && !defined(USE_OGLES)
private:
  static float ticksPeriod;
public:
  static float getTicksPeriod() {return ticksPeriod;}
#endif // !USE_GLFW && !USE_OGLES
protected:
  bool createWindow();
  void destroyWindow();
  void resizeWindow(GLsizei w, GLsizei h);
protected:
  void shutdown(char* message) {destroyWindow(); showError(message);}
#if !defined(USE_GLFW) && !defined(USE_OGLES)
  static int askQuestion(char* message)
    {return MessageBox(NULL,message,"Please, answer.",MB_YESNO|MB_ICONQUESTION);}
  static void showError(char* message)
    {MessageBox(NULL,message,"ERROR",MB_OK|MB_ICONERROR);}
  static void showMessage(char* message)
    {MessageBox(NULL,message,"INFO",MB_OK|MB_ICONINFORMATION);}
#else // USE_GLFW || USE_OGLES
  static void showError(char* message) {printf("ERROR: %s",message);}
  static void showMessage(char* message) {printf("MESSAGE: %s",message);}
#endif // USE_GLFW || USE_OGLES
public:
#ifdef USE_OGLES
  friend int main (int argc, char * argv[]);
  friend void ::keyCallback(unsigned char key, int x, int y);
  friend void ::keyUpCallback(unsigned char key, int x, int y);
  friend void ::specialCallback(int key, int x, int y);
  friend void ::specialUpCallback(int key, int x, int y);
  friend void ::mouseCallback(int button, int state, int x, int y);
  friend void ::motionCallback(int x, int y);
  friend void ::passiveMotionCallback(int x, int y);
  friend void ::reshape(int w, int h);
  friend void ::windowStatus(int state);
  friend void ::display();
  friend void ::idle();
#elif defined(USE_GLFW)
  friend int main (int argc, char * argv[]);
  friend void GLFWCALL ::keyCallback(int key, int action);
  friend void GLFWCALL ::mouseButtonCallback(int button, int action);
  friend void GLFWCALL ::mousePosCallback(int x, int y);
  friend void GLFWCALL ::windowSizeCallback(int width, int height);
#else // !USE_OGLES && !USE_GLFW
  friend BOOL CALLBACK ::InitDlgProc(HWND hw, UINT msg, WPARAM wp, LPARAM lp);
  friend LRESULT CALLBACK ::WndProc(HWND hw, UINT um, WPARAM wp, LPARAM lp);
  friend int WINAPI ::WinMain(HINSTANCE hi, HINSTANCE hpi, LPSTR cl, int cs);
#endif // !USE_OGLES && !USE_GLFW
protected:
  GLWin() throw(ExceptionThrown);
  virtual ~GLWin();
  // instance of the derived class (not defined in this module)
  static GLWin* newInstance(char* initStr) throw(ExceptionThrown);
  // All these methods must be implemented by the application to make the
  // engine work. You must derive a new class from the GLWin, an instance
  // of which you must get through newInstance().
  virtual char* getTitle() {return "";}
  virtual bool initializeScene() = 0; // scene init (called on win mode change)
  virtual void finalizeScene() = 0; // scene final (called on win mode change)
  virtual void keyDownEvent(int key) {}; // notifies key down events
  virtual void updateScene() = 0; // scene update
private:
  static GLWin* window;
public:
  void setTitle(const char* title) {
#ifdef USE_OGLES
    glutSetWindowTitle(title);
#elif defined(USE_GLFW)
    glfwSetWindowTitle(title);
#else // !USE_OGLES && !USE_GLFW
    SetWindowText(hWnd,title);
#endif // !USE_OGLES && !USE_GLFW
  }
  static GLWin& get() {return *window;}
};

#endif // GLWIN_H
