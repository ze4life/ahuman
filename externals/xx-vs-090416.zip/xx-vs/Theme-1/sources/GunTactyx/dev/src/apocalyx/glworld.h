#ifndef GLWORLD_H
#define GLWORLD_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "globject.h"
#include "glshadow.h"
#include "glbackground.h"
#include "glcloudlayer.h"
#include "glterrain.h"
#include "glscenery.h"
#include "gllight.h"
#include "glfog.h"
#ifdef USE_SOUND
#include "glsound.h"
#endif

//
// GLWorld
//
class GLWorld: public GLFog {
private:
  DSArray<GLBackground> backgrounds;
  DSArray<GLCloudLayer> cloudLayers;
  DSSortedArray<GLObject> opaqueObjects;
  DSSortedArray<GLObject> transparentObjects;
  DSArray<GLShadow> shadows;
  int shadowVolumesCount;
#ifdef USE_SOUND
  DSSortedArray<GLSoundSource> soundSources;
#endif
  DSSortedArray<GLObject> lights;
  GLScenery* scenery;
  GLTerrain* terrain;
  GLMoonLight* moon;
  GLSunLight* sun;
  GLColor ambient;
  GLColor clear;
public:
  GLWorld();
  ~GLWorld();
  int getOpaqueObjectsCount() {return opaqueObjects.getSize();}
  int getTransparentObjectsCount() {return transparentObjects.getSize();}
  GLObject* getOpaqueObject(int idx)
    {return opaqueObjects.getElement(idx);}
  GLObject* getTransparentObject(int idx)
    {return transparentObjects.getElement(idx);}
  GLShadow* getShadow(int idx)
    {return shadows.getElement(idx);}
  void addObject(GLObject* object) {
    (object->isTransparent()? transparentObjects: opaqueObjects).addElement(
      static_cast<DSSortableObject*>(object)
    );
  }
  bool removeOpaqueObject(GLObject* o) {
#ifdef USE_SOUND
    removeSoundSource(o);
#endif
    removeShadow(o); return opaqueObjects.removeElement(o);
  }
  bool removeTransparentObject(GLObject* o) {
#ifdef USE_SOUND
    removeSoundSource(o);
#endif
    removeShadow(o); return transparentObjects.removeElement(o);
  }
  bool removeObject(GLObject* o) {
#ifdef USE_SOUND
    removeSoundSource(o);
#endif
    removeShadow(o); 
    return (opaqueObjects.removeElement(o) || transparentObjects.removeElement(o));
  }
  void deleteObjects() {
    transparentObjects.deleteElements();
    opaqueObjects.deleteElements();
    deleteShadows();
#ifdef USE_SOUND
    deleteSoundSources();
#endif
  }
  int getShadowsCount() {return shadows.getSize();}
  int getShadowVolumesCount() {return shadowVolumesCount;}
  void addShadow(GLShadow* shadow) {
    if(shadow->getMode() == GLShadow::SHADOW_VOLUME) shadowVolumesCount++;
    shadows.addElement(shadow);
  }
  bool removeShadow(GLShadow* s) {
    bool ret = shadows.removeElement(s);
    if(ret && (s->getMode() == GLShadow::SHADOW_VOLUME)) shadowVolumesCount--;
    return ret;
  }
  bool removeShadow(GLObject* o);
  void deleteShadows() {shadows.deleteElements(); shadowVolumesCount = 0;}
#ifdef USE_SOUND
  int getSoundSourcesCount() {return soundSources.getSize();}
  GLSoundSource* getSoundSource(int idx) {return soundSources.getElement(idx);}
  void addSoundSource(GLSoundSource* soundSource) {
    soundSources.addElement(static_cast<DSSortableObject*>(soundSource));
    soundSource->setVelocityToZero();
  }
  void removeSoundSource(GLSoundSource* s) {soundSources.removeElement(s);}
  bool removeSoundSource(GLObject* o);
  void deleteSoundSources() {soundSources.deleteElements();}
#endif
  int getLightsCount() {return lights.getSize();}
  GLLight* getLight(int idx)
    {return dynamic_cast<GLLight*>(lights.getElement(idx));}
  void addLight(GLLight* light)
    {lights.addElement(static_cast<DSSortableObject*>(light));}
  void removeLight(GLLight* light) {lights.removeElement(light);}
  void deleteLights() {lights.deleteElements();}
  void removeEnvironment();
  void empty() {deleteObjects(); deleteLights(); removeEnvironment();}
  GLBackground* getBackground(int idx = 0) {return backgrounds.getElement(idx);}
  void setBackground(GLBackground* bg, bool deleteOld = true);
  void addBackground(GLBackground* bg) {backgrounds.addElement(bg);}
  void removeBackground(int idx) {backgrounds.removeElement(idx);}
  void removeBackground(GLBackground* b) {backgrounds.removeElement(b);}
  GLCloudLayer* getCloudLayer(int idx = 0) {return cloudLayers.getElement(idx);}
  void setCloudLayer(GLCloudLayer* cl, bool deleteOld = true);
  void addCloudLayer(GLCloudLayer* cl) {cloudLayers.addElement(cl);}
  void removeCloudLayer(int idx) {cloudLayers.removeElement(idx);}
  void removeCloudLayer(GLCloudLayer* cl) {cloudLayers.removeElement(cl);}
  void setScenery(GLScenery* s);
  GLScenery* getScenery() {return scenery;}
  void setTerrain(GLTerrain* t);
  GLTerrain* getTerrain() {return terrain;}
  void setSun(GLSunLight* s);
  GLSunLight* getSun() {return sun;}
  void setMoon(GLMoonLight* m);
  GLMoonLight* getMoon() {return moon;}
  void setAmbient(float r, float g, float b) {ambient.set(r,g,b);}
  void setClear(float r, float g, float b) {clear.set(r,g,b);}
  void render(GLCamera& camera);
};

#endif // GLWORLD_H
