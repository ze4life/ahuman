#ifndef GLSHADOW_H
#define GLSHADOW_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gltexture.h"
#include "glcamera.h"

#include "void.h"

class GLShadow;
class GLShadowed;
class GLShadowedDelegate;

//
// GLShadow
//
class GLShadow: virtual public Void {
public:
  enum ShadowMode {QUAD_SHADOW,PLANAR_SHADOW,SHADOW_VOLUME};
private:
  ShadowMode mode;
  float maxRadius;
  float halfWidth;
  float halfHeight;
  GLTexture* texture;
  GLObject* object;
public:
  GLShadow(GLObject& object, float w = 0, float h = 0, GLTexture* txt = NULL);
  ~GLShadow();
  void cast(GLCamera& c, GLShadowed& s);
  bool checkClip(GLCamera& camera);
  void setMode(ShadowMode m) {mode = m;}
  ShadowMode getMode() {return mode;}
  bool isQuadShadow() {return mode == QUAD_SHADOW;}
  bool isPlanarShadow() {return mode == PLANAR_SHADOW;}
  bool isShadowVolume() {return mode == SHADOW_VOLUME;}
  GLObject& getObject() {return *object;}
  float getPositionX() {return object->getPositionX();}
  float getPositionY() {return object->getPositionY();}
  float getPositionZ() {return object->getPositionZ();}
  void setMaxRadius(float r) {maxRadius = r;}
  float getMaxRadius() {return maxRadius;}
  void setSize(float w, float h) {halfWidth = w*0.5f; halfHeight = h*0.5f;}
  float getHalfWidth() {return halfWidth;}
  float getHalfHeight() {return halfHeight;}
  GLTexture* getTexture() {return texture;}
  void setTexture(GLTexture* tex) {
    if(texture) texture->releaseReference();
    if(tex) tex->acquireReference();
    texture = tex;
  }
};

//
// GLShadowedDelegate
//

class GLShadowedDelegate: virtual public Void {
private:
  GLShadowed* shadowedDelegator;
public:
  GLShadowedDelegate();
  GLShadowed* getShadowedDelegator() {return shadowedDelegator;}
  void setShadowedDelegator(GLShadowed* s) {shadowedDelegator = s;}
  virtual float getPlane(M3Vector& pos, M3Vector& dir, M3Vector& normal) = 0;
  virtual bool includes(float x, float y, float z) = 0;
};

//
// GLShadowed
//

class GLShadowed: public GLShadowedDelegate {
protected:
  float offset;
  float intensity;
  float fadeDistance;
  float invFadeDistance;
  M3Vector staticLightDirection;
  DSArray<GLShadowedDelegate,false> delegates;
private:
  bool shadowed;
  bool shadowsStatic;
public:
  GLShadowed();
  void setShadowed(bool s) {shadowed = s;}
  bool isShadowed() {return shadowed;}
  void setShadowsStatic(bool s) {shadowsStatic = s;}
  bool areShadowsStatic() {return shadowsStatic;}
  void setShadowOffset(float o) {offset = o;}
  float getShadowOffset() {return offset;}
  void setShadowIntensity(float i) {intensity = i;}
  float getShadowIntensity() {return intensity;}
  void setShadowFadeDistance(float d)
    {fadeDistance = d; invFadeDistance = (d <= 0? 1: 1.0f/d);}
  float getShadowFadeDistance() {return fadeDistance;}
  float getInvShadowFadeDistance() {return invFadeDistance;}
  virtual bool getDynamicLightDirection(M3Vector& dir) {return false;}
  M3Vector& getStaticLightDirection() {return staticLightDirection;}
  void setStaticLightDirection(float dirX, float dirY, float dirZ)
    {staticLightDirection.set(dirX,dirY,dirZ);}
  void addDelegate(GLShadowedDelegate* sd)
    {sd->setShadowedDelegator(this); delegates.addElement(sd);}
  void removeDelegate(GLShadowedDelegate* sd)
    {sd->setShadowedDelegator(NULL); delegates.removeElement(sd);}
  GLShadowedDelegate* getShadowedDelegate(float x, float y, float z);
  virtual float getPlane(M3Vector& pos, M3Vector& dir, M3Vector& normal) {
    if(dir.getY()) pos.subtract((normal = dir).scale(pos.getY()/dir.getY()));
    else pos.setY(0);
    normal.set(0,1,0); return 0;
  }
  virtual bool includes(float x, float y, float z) {return true;}
};

#endif // GLSHADOW_H
