#ifndef DATAREAD_H
#define DATAREAD_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifndef USE_GLFW
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif // USE_GLFW
#include <math.h>
#include <stdio.h>

#include "exception.h"

#include "void.h"

#include "globject.h"
#ifdef USE_SOUND
#include "fmsound.h"
#endif

extern "C" {
#include "zlib/unzip.h"
#include "jpeg/jpeglib.h"
#include "png/png.h"
}
                  
class DRJpegReader;
class DRPngReader;
class DRTgaReader;
#ifndef __linux__
class DRResource;
class DRJpegResource;
class DRPngResource;
#ifdef USE_SOUND
class DRSoundResource;
#ifdef USE_MUSIC
class DRMusicResource;
#endif // USE_MUSIC
#endif // USE_SOUND
#endif // __linux__
class DRFile;
class DRDataFile;
class DRZipFile;
#ifdef USE_DATA_FILE
class DRJpegFile;
class DRPngFile;
class DRTgaFile;
class DRMeshFile;
class DRBasicModelFile;
class DRModelFile;
class DRAdvancedModelFile;
class DRBotFile;
class DRBspFile;
class DRSampleFile;
class DRMusicFile;
#endif // USE_DATA_FILE
class DRData;
class DRImage;
class DRJpegImage;
class DRPngImage;
class DRTgaImage;

class GLTexture;
class GLAnimatedTexture;
class GLCubeMapTexture;
class GLBasicMesh;
class GLMesh;
#ifdef USE_EMBOSS
class GLBumpedTexture;
class GLBumpedMesh;
#endif // USE_EMBOSS
class GLBasicModel;
class GLModel;
#ifdef USE_CAL3D
class GLAdvancedModel;
#endif // USE_CAL3D
class GLBot;
#ifdef USE_BSP
class GLBsp;
#endif // USE_BSP

class GLVertexProgram;
class GLFragmentProgram;

//
// DRJpegReader
//
class DRJpegReader {
protected:
  jpeg_decompress_struct cinfo;
  jpeg_error_mgr jerr;
public:
  DRJpegReader();
  static DRJpegImage* readImage(
    jpeg_decompress_struct* cinfo,
    jpeg_source_mgr* src,
    void (*init_source)(j_decompress_ptr cinfo),
    unsigned char (*fill_input_buffer)(j_decompress_ptr cinfo),
    void (*skip_input_data)(j_decompress_ptr cinfo,long),
    void (*term_source)(j_decompress_ptr cinfo),
    int alphaColor = -1, int tolerance = 0
  );
};

//
// DRPngReader
//
class DRPngReader {
private:
  unsigned char* readPointer;
protected:
  static void pngWarning(png_structp png_ptr, png_const_charp message);
  static void pngError(png_structp png_ptr, png_const_charp message);
  static void pngReadData(png_structp ptr, png_bytep data, png_size_t len);
public:
  DRPngReader();
  void setReadPointer(unsigned char* rp) {readPointer = rp;}
  unsigned char* getReadPointer() {return readPointer;}
  void moveReadPointer(int step) {readPointer += step;}
  DRPngImage* readImage() throw(ExceptionThrown);
};

//
// DRTgaReader
//
class DRTgaReader {
private:
  unsigned char* readPointer;
protected:
  DRTgaImage* getUncompressedTrueColorTGA(DRData* data);
	DRTgaImage* getCompressedTrueColorTGA(DRData* data);
  DRTgaImage* getUncompressed8BitTGA(DRData* data);
public:
  DRTgaReader();
  void setReadPointer(unsigned char* rp) {readPointer = rp;}
  unsigned char* getReadPointer() {return readPointer;}
  void moveReadPointer(int step) {readPointer += step;}
  DRTgaImage* readImage(DRData* data);
};

//
// DRMeshReader
//
class DRMeshReader {
#ifdef USE_DATA_FILES
private:
	const char* path;
  FILE* readFile;
protected:
  static void seekDataFromFile(DRMeshReader* reader, int offset);
  static int dataLengthFromFile(DRMeshReader* reader);
  static DRImage* readImageFromFile(DRMeshReader* reader, char* imageName);
  static DRData* readDataFromFile(DRMeshReader* reader, char* bufferName);
  static void readBufferFromFile
    (DRMeshReader* reader, void* buffer, int bytesToBeRead, int* bytesRead);
public:
  DRMeshReader(FILE* fileHandle, const char* pth = NULL);
  const char* getPath() {return path;}
#endif // USE_DATA_FILES
private:
  DRZipFile* zipFile;
  unsigned char* bufferPointer;
  unsigned char* bufferStart;
  int bufferLength;
protected:
  static void seekDataFromZip(DRMeshReader* reader, int offset);
  static int dataLengthFromZip(DRMeshReader* reader);
  static DRImage* readImageFromZip(DRMeshReader* reader, char* imageName);
  static DRData* readDataFromZip(DRMeshReader* reader, char* bufferName);
  static void readBufferFromZip
    (DRMeshReader* reader, void* buffer, int bytesToBeRead, int* bytesRead);
private:
  int chunkPointer;
  int chunkEndPointer;
  void (*seekDataPtr)(DRMeshReader* reader, int offset);
  int (*dataLengthPtr)(DRMeshReader* reader);
  DRImage* (*readImagePtr)(DRMeshReader* reader, char* imageName);
  DRData* (*readDataPtr)(DRMeshReader* reader, char* bufferName);
  void (*readBufferPtr)
    (DRMeshReader* reader, void* buffer, int bytesToBeRead, int* bytesRead);
protected:
  void seekData(int offset) {seekDataPtr(this,offset);}
  int dataLength() {return dataLengthPtr(this);}
  DRImage* readImage(char* imageName) {return readImagePtr(this,imageName);}
  DRData* readData(char* bufferName) {return readDataPtr(this,bufferName);}
  void readBuffer(void* buffer, int bytesToBeRead, int* bytesRead)
    {readBufferPtr(this,buffer,bytesToBeRead,bytesRead);}
protected:
  unsigned short getChunkID();
  int getChunkEndPointer() {return chunkEndPointer;}
  unsigned short readUShort();
  unsigned char readUChar();
  float readFloat();
  void read(char* string);
  void read(float* array, int arrayLength);
  void read(unsigned short* array, int arrayLength);
  void skip();
  void restore();
  bool isMoreDataAvailable(int endPointer) {return chunkPointer < endPointer;}
  enum tags {
    MAIN3DS       = 0x4d4d,
    EDIT3DS       = 0x3d3d,
    OBJECT3DS     = 0x4000,
    TRIMESH       = 0x4100,
    VERTEXLIST    = 0x4110,
    FACELIST      = 0x4120,
    MATERIALLIST  = 0x4130,
    MAPPINGLIST   = 0x4140,
    LOCALMATRIX   = 0x4160,
    MATERIALS     = 0xAFFF,
    MATERIALNAME  = 0xA000,
    MATAMBIENT    = 0xA010,
    MATDIFFUSE    = 0xA020,
    MATSPECULAR   = 0xA030,
    MATSHININESS  = 0xA040,
    MATTEXTURE    = 0xA200,
    MATTEXNAME    = 0xA300,
    MATCOLOR_F    = 0x0010,
    MATCOLOR      = 0x0011,
    PERCENTAGE_I  = 0x0030,
    PERCENTAGE_F  = 0x0031,
  };
public:
  DRMeshReader(DRZipFile* zip);
  enum MeshType {TYPE_BASIC, TYPE_SHADER, TYPE_NORMAL
#ifdef USE_EMBOSS
  	, TYPE_BUMPED
#endif // USE_EMBOSS
  };
  enum MeshFormat {FMT_3DS, FMT_OBJ};
  GLObjects* readMeshes(MeshFormat fmt = FMT_3DS, MeshType mt = TYPE_NORMAL);
};

#ifndef __linux__
//
// DRResource
//
class DRResource {
private:
  HRSRC resource;
public:
  DRResource(int id) throw(ExceptionThrown);
  DRResource(char* name) throw(ExceptionThrown);
  ~DRResource();
  LPBYTE getPointer() throw(ExceptionThrown);
  int getSize() {return SizeofResource(NULL,resource);}
};

//
// DRJpegResource
//
class DRJpegResource: public DRResource, protected DRJpegReader {
public:
  DRJpegResource(int id) throw(ExceptionThrown);
  DRJpegImage* getImage(int alphaColor = -1, int tol = 0);
};

//
// DRPngResource
//
class DRPngResource: public DRResource, protected DRPngReader {
public:
  DRPngResource(int id) throw(ExceptionThrown);
  DRPngImage* getImage();
};

#ifdef USE_SOUND
//
// DRSoundResource
//
class DRSoundResource: public DRResource {
public:
  DRSoundResource(int id) throw(ExceptionThrown);
  FM3DSample* get3DSoundSample();
  FMSample* getSoundSample();
};

#ifdef USE_MUSIC

//
// DRMusicResource
//
class DRMusicResource: public DRResource {
public:
  DRMusicResource(int id) throw(ExceptionThrown);
  FMMusic* getMusic();
};

#endif // USE_MUSIC
#endif // USE_SOUND

#endif // __linux__

//
// DRZipFile
//
class DRZipFile:
  protected DRJpegReader, protected DRPngReader, virtual public Void
{
private:
#ifdef USE_DATA_FILES
	char* virtualPath;
#endif // USE_DATA_FILES
  unzFile fileHandler;
  unsigned char* zipBuffer;
  int zipBufferLength;
public:
  DRZipFile(const char* zipFileName, bool zipped = true) throw(ExceptionThrown);
  ~DRZipFile();
#ifdef USE_DATA_FILES
  const char* getVirtualPath() {return virtualPath;}
#endif // USE_DATA_FILES
  unsigned char* getZipBuffer() {return zipBuffer;}
  int getZipBufferLength() {return zipBufferLength;}
  bool createZipBuffer(const char* fileName);
  void deleteZipBuffer(bool deleteBuffer = true);
  bool gotoFirstFile() {return unzGoToFirstFile(fileHandler) == UNZ_OK;}
  bool gotoNextFile() {return unzGoToNextFile(fileHandler) == UNZ_OK;}
  bool findZippedFile(const char* fileName)
    {return unzLocateFile(fileHandler,fileName,0) == UNZ_OK;}
  void getZippedFileName(char* name, int len)
    {unzGetCurrentFileInfo(fileHandler,NULL,name,len,NULL,0,NULL,0);}
  int getZippedFileSize() {
    unz_file_info ufi;
    unzGetCurrentFileInfo(fileHandler,&ufi,NULL,0,NULL,0,NULL,0);
    return ufi.uncompressed_size;
  }
  bool openZippedFile()
    {return unzOpenCurrentFile(fileHandler) == UNZ_OK;}
  bool closeZippedFile()
    {return unzCloseCurrentFile(fileHandler) != UNZ_CRCERROR;}
  int readZippedFile()
    {return unzReadCurrentFile(fileHandler,zipBuffer,zipBufferLength);}
  DRData* getData(const char* fileName);
  DRImage* getImage(const char* fileName);
  DRJpegImage* getJpegImage(
    const char* fileName, int alphaColor = -1, int tol = 0
  );
  DRPngImage* getPngImage(const char* fileName);
  DRTgaImage* getTgaImage(const char* fileName);
  GLTexture* getTexture(
    const char* fileName, bool repeat = false, bool doMipmaps = true,
    int textureDim = GL_TEXTURE_2D
  );
  GLAnimatedTexture* getAnimatedTexture(
    int filesCount, const char** fileNames, float duration, bool repeat = false,
    bool doMipmaps = true
  );
  GLCubeMapTexture* getCubeMapTexture(
    const char** fileNames, bool doMipmaps = true
  );
  GLObjects* getMeshes(
    const char* fileName, DRMeshReader::MeshType mt = DRMeshReader::TYPE_NORMAL
  );
  GLBasicMesh* getBasicMesh(const char* fileName);
  GLMesh* getShaderMesh(const char* fileName);
  GLMesh* getMesh(const char* fileName);
#ifdef USE_EMBOSS
  GLBumpedTexture* getBumpedTexture(const char* fileName, bool repeat = false);
  GLBumpedMesh* getBumpedMesh(const char* fileName);
#endif // USE_EMBOSS
protected:
  bool loadBasicModel(
    GLBasicModel* mdl, const char* md2, const char* img = NULL,
    const char* alphaImg = NULL
  );
  bool loadModel(
    GLModel* mdl, const char* md3, const char* img = NULL,
    const char* alphaImg = NULL
  );
public:
  GLBasicModel* getBasicModel(
    const char* md2, const char* img = NULL, const char* alphaImg = NULL
  );
  GLModel* getModel(
    const char* md3, const char* img = NULL, const char* alphaImg = NULL,
    bool ownsCache = false
  );
#ifdef USE_CAL3D
  GLAdvancedModel* getAdvancedModel(const char* modelName, bool useHW = false);
#endif // USE_CAL3D
  GLBot* getBot(const char* modelName, bool ownsCaches = false);
#ifdef USE_BSP
  GLBsp* getLevel(
    const char* levelName, float gamma = 1, DRZipFile* texturesZip = NULL
  );
#endif // USE_BSP
#ifdef USE_OGLES
#else // !USE_OGLES
  GLVertexProgram* getVertexProgram(const char* programName);
  GLFragmentProgram* getFragmentProgram(const char* programName);
#endif // !USE_OGLES
#ifdef USE_SOUND
  FM3DSample* get3DSoundSample(const char* fileName);
  FMSample* getSoundSample(const char* fileName);
#ifdef USE_MUSIC
  FMMusic* getMusic(const char* fileName);
#endif // USE_MUSIC
#endif
};

//
// DRFile
//
class DRFile: virtual public Void {
protected:
  char* fileName;
  FILE* file;
public:
  DRFile(const char* filNam, const char* pth = NULL);
  ~DRFile();
  bool openFile();
  void closeFile();
  FILE* getFileHandle() {return file;}
};

//
// DRDataFile
//
class DRDataFile: public DRFile {
public:
  DRDataFile(const char* filNam);
  DRData* getData();
};

//
// DRData
//
class DRData {
protected:
  int size;
  unsigned char* buffer;
  bool ownsBuffer;
public:
  DRData(int sz, unsigned char* buf, bool ob = true);
  ~DRData();
  int getSize() const {return size;}
  unsigned char* getBuffer() {return buffer;}
  void setOwnsBuffer(bool ob) {ownsBuffer = ob;}
  bool getOwnsBuffer() {return ownsBuffer;}
};

//
// DRDataStream
//
class DRDataStream: public DRData {
public:
  enum {DEFAULT_INCREMENT = 10240};
private:
  bool writeable;
  int increment;
  int capacity;
  int pointer;
public:
  DRDataStream(int inc = DEFAULT_INCREMENT);
  DRDataStream(int siz, const char* buf);
  bool isWriteable() {return writeable;}
  int getIncrement() {return increment;}
  int getCapacity() {return capacity;}
  bool modifyCapacity(int cap);
  DRDataStream* open(const char* mode);
  int write(const void* ptr, int siz, int items);
  int read(void* ptr, int siz, int items);
  int seek(int offset, int whence);
  int tell() {return pointer;}
  int close();
};

//
// DRImage
//
class DRImage: virtual public Void {
private:
  bool hasAlpha;
  bool grayScale;
  bool ownsBuffer;
  unsigned char* buffer;
  int width;
  int height;
protected:
  DRImage(
    int w, int h, unsigned char* b, bool ha = false,
    bool gs = false, bool ob = true
  );
public:
  DRImage(bool ha = false, bool gs = false, bool ob = true);
  ~DRImage();
  static DRImage* getScreenshot(int x, int y, int w, int h);
  bool saveAsPng(const char* fileName, bool useFilters = false);
  bool resample(int newW, int newH);
#ifdef USE_DATA_FILES
  static DRImage* getImageFromFile(const char* imageName);
  static GLTexture* getTextureFromFile(
    const char* imageName, bool repeat = false, bool doMipmaps = true,
    int textureDim = GL_TEXTURE_2D
  );
#endif // USE_DATA_FILES
  void showSplash(float waitForSeconds);
  void setBuffer(unsigned char* b)
    {if(buffer) delete buffer; buffer = b;}
  void setWidth(int w) {width = w;}
  void setHeight(int h) {height = h;}
  void setHasAlpha(bool ha) {hasAlpha = ha;}
  void setGrayScale(bool gs) {grayScale = gs;}
  bool getOwnsBuffer() {return ownsBuffer;}
  unsigned char* getBuffer() {return buffer;}
  int getWidth() const {return width;}
  int getHeight() const {return height;}
  bool getHasAlpha() {return hasAlpha;}
  bool isGrayScale() {return grayScale;}
  void addAlpha(DRImage& img, int threshold = -1, int cutoff = 0);
  void addAlpha(unsigned char alpha);
  static void setGammaCorrection(
    unsigned char* b, int w, int h, float gamma,
    bool hasAlphaChannel = false, bool isGrayScale = false
  );
  void setGammaCorrection(float gamma)
    {setGammaCorrection(buffer,width,height,gamma,hasAlpha,grayScale);}
  void convertTo111A(float grayShade = 1, bool invert = false);
  void convertToRGBA(bool invert = false);
  void convertToRGB();
  void convertToBump(float scaleSide, float scaleHeight);
  void convertGray2111A(float grayShade = 1) {convertTo111A(grayShade);}
  void convertGray2RGBA() {convertToRGBA();}
  void convertGray2RGBmA() {convertToRGBA(true);}
  void convertGray2RGB() {convertToRGB();}
  void convertGray2Bump(float scaleSide, float scaleHeight)
    {convertToBump(scaleSide,scaleHeight);}
};

//
// DRJpegImage
//
class DRJpegImage: public DRImage {
public:
  DRJpegImage(int alphaColor = -1, bool ownsBuffer = true);
};

//
// DRPngImage
//
class DRPngImage: public DRImage {
public:
  DRPngImage(bool ha = false, bool ds = false, bool ob = true);
};

//
// DRTgaImage
//
class DRTgaImage: public DRImage {
public:
  DRTgaImage(bool ha = false, bool ds = false, bool ob = true);
};

#ifdef USE_DATA_FILES

//
// DRJpegFile
//
class DRJpegFile: public DRFile, protected DRJpegReader {
public:
  DRJpegFile(const char* filNam);
  DRJpegImage* getImage(int alphaColor = -1, int tol = 0);
};

//
// DRPngFile
//
class DRPngFile: public DRDataFile, protected DRPngReader {
public:
  DRPngFile(const char* filNam);
  DRPngImage* getImage();
};

//
// DRTgaFile
//
class DRTgaFile: public DRDataFile, public DRTgaReader {
public:
  DRTgaFile(const char* filNam);
  DRTgaImage* getImage();
};

//
// DRMeshFile
//
class DRMeshFile: public DRFile {
private:
	const char* path;
public:
  DRMeshFile(const char* filNam, const char* pth = NULL);
  GLObjects* getMeshes(
  	DRMeshReader::MeshType meshType = DRMeshReader::TYPE_NORMAL
  );
  GLBasicMesh* getBasicMesh();
  GLMesh* getShaderMesh();
  GLMesh* getMesh();
#ifdef USE_EMBOSS
  GLBumpedMesh* getBumpedMesh();
#endif // USE_EMBOSS
};

//
// DRBasicModelFile
//
class DRBasicModelFile: public DRFile {
public:
  DRBasicModelFile(const char* filNam);
  GLBasicModel* getBasicModel(
  	const char* imageName = NULL, const char* alphaName = NULL
  );
};

//
// DRModelFile
//
class DRModelFile: public DRFile {
public:
  DRModelFile(const char* filNam);
  GLModel* getModel(const char* imageName = NULL, const char* alphaName = NULL);
};

#ifdef USE_CAL3D

//
// DRAdvancedModelFile
//
class DRAdvancedModelFile: public DRFile {
public:
  DRAdvancedModelFile(const char* filNam);
  GLAdvancedModel* getAdvancedModel(bool useHW = false);
};

#endif // USE_CAL3D

//
// DRBotFile
//
class DRBotFile: public DRFile {
private:
	const char* path;
public:
  DRBotFile(const char* pth, const char* filNam);
  GLBot* getBot(bool ownsCache = false);
};

#ifdef USE_BSP

//
// DRBspFile
//
class DRBspFile: public DRFile {
private:
	const char* path;
public:
  DRBspFile(const char* pth, const char* filNam);
  GLBsp* getLevel(float gamaCorrection = 1);
};

#endif // USE_BSP

#ifdef USE_SOUND

//
// DRSampleFile
//
class DRSampleFile: public DRDataFile {
public:
  DRSampleFile(const char* filNam);
  FMSample* getSample();
  FM3DSample* getSample3D();
};

#ifdef USE_MUSIC

//
// DRMusicFile
//
class DRMusicFile: public DRDataFile {
public:
  DRMusicFile(const char* filNam);
  FMMusic* getMusic();
};

#endif // USE_MUSIC
#endif // USE_SOUND

#endif // USE_DATA_FILES

#endif //DATAREAD_H
