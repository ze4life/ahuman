#ifndef GLCAMERA_H
#define GLCAMERA_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "math3d.h"

//
// GLFrustum
//
class GLFrustum {
protected:
  float clipPlaneNear;
  float clipPlaneFar;
  float frustum[6][4];
#ifdef USE_OGLES
  float projectionMatrix[16];
  float modelMatrix[16];
public:
  float* getProjectionMatrix() {return projectionMatrix;};
  float* getModelMatrix() {return modelMatrix;}
#else // !USE_OGLES
  double projectionMatrix[16];
  double modelMatrix[16];
public:
  double* getProjectionMatrix() {return projectionMatrix;};
  double* getModelMatrix() {return modelMatrix;}
#endif // !USE_OGLES
public:
  GLFrustum();
  float getPlane(int plane, int coo) {return frustum[plane][coo];}
  float getClipPlaneNear() {return clipPlaneNear;}
  float getClipPlaneFar() {return clipPlaneFar;}
  void update();
  float dot(int p, float x, float y, float z)
    {return getPlane(p,0)*x+getPlane(p,1)*y+getPlane(p,2)*z+getPlane(p,3);}
  bool isPointVisible(float x, float y, float z) {
  	return !(
      (dot(0,x,y,z) <= 0) || (dot(1,x,y,z) <= 0) || (dot(2,x,y,z) <= 0) ||
      (dot(3,x,y,z) <= 0) || (dot(4,x,y,z) <= 0) || (dot(5,x,y,z) <= 0)
    );
  }
  bool isSphereVisible(float x, float y, float z, float radius) {
  	return !(
      (dot(0,x,y,z) <= -radius) || (dot(1,x,y,z) <= -radius) ||
      (dot(2,x,y,z) <= -radius) || (dot(3,x,y,z) <= -radius) ||
      (dot(4,x,y,z) <= -radius) || (dot(5,x,y,z) <= -radius)
    );
  }
  bool isBoxVisible(
    float minX, float minY, float minZ, float maxX, float maxY, float maxZ
  );
};

//
// GLNearestLight
//
class GLNearestLight {
public:
  bool isDirectional;
  M3Vector vector;
};

//
// GLCamera
//
class GLCamera: public M3Reference, public GLFrustum {
private:
  bool ortho;
  float viewX;
  float viewY;
  float viewWidth;
  float viewHeight;
  bool useScissor;
  bool mainView;
  M3Float horizontalViewX;
  M3Float horizontalViewZ;
  float fieldOfView;
  bool renderingShadows;
  bool renderingReflections;
  bool renderingTransparencies;
  GLNearestLight nearestLight;
  M3Vector lastApplyPosition;
  int intValue;
public:
  GLCamera();
  void saveView();
  void restoreView();
  float getViewX() {return viewX;}
  float getViewY() {return viewY;}
  float getViewWidth() {return viewWidth;}
  float getViewHeight() {return viewHeight;}
  bool isMainView() {return mainView;}
  void setMainView(bool b) {mainView = b;}
  bool isScissorUsed() {return useScissor;}
  void setViewport(float x, float y, float w, float h);
  void setDimension(float w, float h);
  void setLocation(float x, float y);
  void setOrtho(float zf = 1);
  bool isOrtho() {return ortho;}
  void setPerspective(float fov, float zn, float zf);
  void updateAspect(float w, float h);
  void setRenderingShadows(bool rs) {renderingShadows = rs;}
  bool isRenderingShadows() {return renderingShadows;}
  void setRenderingReflections(bool rr) {renderingReflections = rr;}
  bool isRenderingReflections() {return renderingReflections;}
  void setRenderingTransparencies(bool rt) {renderingTransparencies = rt;}
  bool isRenderingTransparencies() {return renderingTransparencies;}
  void setNearestLight(float dirX, float dirY, float dirZ) {
    nearestLight.isDirectional = true; nearestLight.vector.set(dirX,dirY,dirZ);
  }
  void setNearestLight(bool isDir, const M3Vector& vec)
    {nearestLight.isDirectional = isDir; nearestLight.vector = vec;}
  bool isNearestLightDirectional() {return nearestLight.isDirectional;}
  M3Vector& getNearestLightVector() {return nearestLight.vector;}
  M3Float getHorizontalViewX() {return horizontalViewX;}
  M3Float getHorizontalViewZ() {return horizontalViewZ;}
  void setIntValue(int v) {intValue = v;}
  int getIntValue() {return intValue;}
  void setVelocityToZero()
    {lastApplyPosition.set(getPositionX(),getPositionY(),-getPositionZ());}
  void applyPerspective();
  void applyTransform();
  void applyRotation();
  void applyOrtho();
};

#endif // GLCAMERA_H
