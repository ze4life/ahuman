#ifndef GLSHADER_H
#define GLSHADER_H

/*
  Copyright (C) 2001-2005 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"

#include "gltexture.h"

#include "dataread.h"
#include "datamanager.h"

#ifdef USE_OGLES
#else // !USE_OGLES

//
// GLShader
//
class GLShader: public DMReference {
protected:
  GLhandleARB shaderID;
  bool compiled;
public:
  GLhandleARB getID() {return shaderID;}
  bool isCompiled() {return compiled;}
  void getInfo(int maxLen, char* info)
    {glGetInfoLogARB(shaderID,maxLen,NULL,info);}
  bool compile(const char* asciiSource) {
    glShaderSourceARB(shaderID,1,&asciiSource,NULL);
    glCompileShaderARB(shaderID);
    int ret;
    glGetObjectParameterivARB(shaderID,GL_OBJECT_COMPILE_STATUS_ARB,&ret);
    return (compiled = (ret == TRUE));
  }
  bool compile(DRData* data) {
    int len = data->getSize();
    glShaderSourceARB(shaderID,1,(const char**)data->getBuffer(),&len);
    glCompileShaderARB(shaderID);
    int ret;
    glGetObjectParameterivARB(shaderID,GL_OBJECT_COMPILE_STATUS_ARB,&ret);
    return (compiled = (ret == TRUE));
  }
  virtual void destroyObject();
protected:
  GLShader(const char* asciiSource, int target);
  GLShader(DRData* data, int target);
  virtual GLShader* acquireReference()
    {return dynamic_cast<GLShader*>(DMReference::acquireReference());}
};

//
// GLVertexShader
//
class GLVertexShader: public GLShader {
public:
  static bool isSupported() {return IS_VERTEX_SHADER_SUPPORTED;}
  GLVertexShader(const char* asciiSource);
  GLVertexShader(DRData* data);
  virtual GLVertexShader* acquireReference()
    {return dynamic_cast<GLVertexShader*>(GLShader::acquireReference());}
};

//
// GLFragmentShader
//
class GLFragmentShader: public GLShader {
public:
  static bool isSupported() {return IS_FRAGMENT_SHADER_SUPPORTED;}
  GLFragmentShader(const char* asciiSource);
  GLFragmentShader(DRData* data);
  virtual GLFragmentShader* acquireReference()
    {return dynamic_cast<GLFragmentShader*>(GLShader::acquireReference());}
};

//
// GLShaderProgram
//
class GLShaderProgram: public DMReference {
protected:
  GLhandleARB programID;
public:
  static bool areShaderObjectsSupported() {return ARE_SHADER_OBJECTS_SUPPORTED;}
  GLhandleARB getID() {return programID;}
  void getInfo(int maxLen, char* info)
    {glGetInfoLogARB(programID,maxLen,NULL,info);}
  void attachShader(GLShader* s) {glAttachObjectARB(programID,s->getID());}
  void detachShader(GLShader* s) {glDetachObjectARB(programID,s->getID());}
  bool link() {
    glLinkProgramARB(programID);
    int ret;
    glGetObjectParameterivARB(programID,GL_OBJECT_LINK_STATUS_ARB,&ret);
    return (ret == TRUE);
  }
  bool validate() {
    glValidateProgramARB(programID);
    int ret;
    glGetObjectParameterivARB(programID,GL_OBJECT_VALIDATE_STATUS_ARB,&ret);
    return (ret == TRUE);
  }
  static void useFixedPipeline()
    {if(ARE_SHADER_OBJECTS_SUPPORTED) glUseProgramObjectARB(0);}
  void apply() {glUseProgramObjectARB(programID);}
  int getUniformLocation(const char* name)
    {return glGetUniformLocationARB(programID,name);}
  static void setUniform(int idx, float x)
    {glUniform1fARB(idx,x);}
  static void setUniform(int idx, float x, float y)
    {glUniform2fARB(idx,x,y);}
  static void setUniform(int idx, float x, float y, float z)
    {glUniform3fARB(idx,x,y,z);}
  static void setUniform(int idx, float x, float y, float z, float w)
    {glUniform4fARB(idx,x,y,z,w);}
  static void setUniform(int idx, int x)
    {glUniform1iARB(idx,x);}
  static void setUniform(int idx, int x, int y)
    {glUniform2iARB(idx,x,y);}
  static void setUniform(int idx, int x, int y, int z)
    {glUniform3iARB(idx,x,y,z);}
  static void setUniform(int idx, int x, int y, int z, int w)
    {glUniform4iARB(idx,x,y,z,w);}
  static void setUniformMatrix2(int idx, int count, float* mat)
    {glUniformMatrix2fvARB(idx,count,FALSE,mat);}
  static void setUniformMatrix3(int idx, int count, float* mat)
    {glUniformMatrix3fvARB(idx,count,FALSE,mat);}
  static void setUniformMatrix4(int idx, int count, float* mat)
    {glUniformMatrix4fvARB(idx,count,FALSE,mat);}
  static void setUniform(int idx, GLTexture* t)
    {setUniform(idx,int(t->getID()));}
  virtual void destroyObject();
  GLShaderProgram(const char* vertexSource, const char* fragmentSource);
  GLShaderProgram();
  virtual GLShaderProgram* acquireReference()
    {return dynamic_cast<GLShaderProgram*>(DMReference::acquireReference());}
};

#endif // !USE_OGLES

#endif // GLSHADER_H
