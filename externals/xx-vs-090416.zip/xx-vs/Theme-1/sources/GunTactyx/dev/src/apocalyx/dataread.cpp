/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "dataread.h"
#include "glconsole.h"
#include "glmesh.h"
#include "glmodel.h"
#ifdef USE_BSP
#include "glbsp.h"
#endif // USE_BSP
#include "glprogram.h"

#ifdef USE_SOUND
#include "fmsound.h"
#endif

#ifdef USE_CAL3D
#include <strstrea.h>
#include "cal3d/cal3d.h"
#endif // USE_CAL3D

#include "datasets.inc"

#include "jpeg/jerror.h"

#include <io.h> // for filelength()
#include <dir.h> // for MAX_PATH
#include <mem.h> // for memcpy()
#include <stdlib.h> // for atoi()
#include <ctype.h> // for isalpha()

//
// Jpeg Aux (common)
//
METHODDEF(void) my_output_message(j_common_ptr cinfo) {
  char buffer[JMSG_LENGTH_MAX];
  (*cinfo->err->format_message)(cinfo, buffer);
  Exception::showError(buffer,"JPEG");
}

//
// Jpeg Aux (ZIP)
//
typedef struct {
  struct jpeg_source_mgr pub;
  DRZipFile* zipFile;
  const char* zippedFileName;
} my_source_mgr_zip;

METHODDEF(void) init_source_zip(j_decompress_ptr cinfo) {
  my_source_mgr_zip* src = (my_source_mgr_zip*)cinfo->src;
  src->zipFile->createZipBuffer(src->zippedFileName);
}

METHODDEF(boolean) fill_input_buffer_zip(j_decompress_ptr cinfo) {
  my_source_mgr_zip* src = (my_source_mgr_zip*)cinfo->src;
  src->pub.next_input_byte = src->zipFile->getZipBuffer();
  src->pub.bytes_in_buffer = (size_t)src->zipFile->getZipBufferLength();
  return TRUE;
}

METHODDEF(void) skip_input_data_zip(j_decompress_ptr cinfo, long num_bytes) {
  my_source_mgr_zip* src = (my_source_mgr_zip*)cinfo->src;
  if(num_bytes > 0) {
    while(num_bytes > (long) src->pub.bytes_in_buffer) {
      num_bytes -= (long) src->pub.bytes_in_buffer;
      fill_input_buffer_zip(cinfo);
    }
    src->pub.next_input_byte += (size_t)num_bytes;
    src->pub.bytes_in_buffer -= (size_t)num_bytes;
  }
}

METHODDEF(void) term_source_zip(j_decompress_ptr cinfo) {
  my_source_mgr_zip* src = (my_source_mgr_zip*)cinfo->src;
  src->zipFile->deleteZipBuffer();
}

#ifndef __linux__

//
// Jpeg Aux (Resource)
//
typedef struct {
  struct jpeg_source_mgr pub;
  DRResource* resource;
} my_source_mgr_res;

METHODDEF(void) init_source_res(j_decompress_ptr cinfo) {
  cinfo;
}

METHODDEF(boolean) fill_input_buffer_res(j_decompress_ptr cinfo) {
  my_source_mgr_res* src = (my_source_mgr_res*)cinfo->src;
  try {
    src->pub.next_input_byte = src->resource->getPointer();
  } catch(Exception& e) {
    return FALSE;
  }
  src->pub.bytes_in_buffer = src->resource->getSize();
  return TRUE;
}

METHODDEF(void) skip_input_data_res(j_decompress_ptr cinfo, long num_bytes) {
  my_source_mgr_res* src = (my_source_mgr_res*)cinfo->src;
  if(num_bytes > 0) {
    src->pub.next_input_byte += (size_t)num_bytes;
    src->pub.bytes_in_buffer -= (size_t)num_bytes;
  }
}

METHODDEF(void) term_source_res(j_decompress_ptr cinfo) {
	cinfo;
}

#endif __linux__

#ifdef USE_DATA_FILES

//
// Jpeg Aux (File)
//
#define MAX_FILE_BUFFER 4096

typedef struct {
  struct jpeg_source_mgr pub;
  DRFile* file;
  unsigned char buffer[MAX_FILE_BUFFER];
  boolean start_of_file;
} my_source_mgr_fil;

METHODDEF(void) init_source_fil(j_decompress_ptr cinfo) {
  my_source_mgr_fil* src = (my_source_mgr_fil*)cinfo->src;
  src->file->openFile();
  src->start_of_file = TRUE;
}

METHODDEF(boolean) fill_input_buffer_fil(j_decompress_ptr cinfo) {
  my_source_mgr_fil* src = (my_source_mgr_fil*)cinfo->src;
  size_t nbytes =
    fread(src->buffer,1,MAX_FILE_BUFFER,src->file->getFileHandle());
  if(nbytes <= 0) {
    if (src->start_of_file)
      ERREXIT(cinfo, JERR_INPUT_EMPTY);
    WARNMS(cinfo, JWRN_JPEG_EOF);
    src->buffer[0] = (unsigned char)0xFF;
    src->buffer[1] = (unsigned char)JPEG_EOI;
    nbytes = 2;
  }
  src->pub.next_input_byte = src->buffer;
  src->pub.bytes_in_buffer = nbytes;
  src->start_of_file = FALSE;
  return TRUE;
}

METHODDEF(void) skip_input_data_fil(j_decompress_ptr cinfo, long num_bytes) {
  my_source_mgr_fil* src = (my_source_mgr_fil*)cinfo->src;
  if(num_bytes > 0) {
    while(num_bytes > (long)src->pub.bytes_in_buffer) {
      num_bytes -= (long) src->pub.bytes_in_buffer;
      fill_input_buffer_fil(cinfo);
    }
    src->pub.next_input_byte += (size_t)num_bytes;
    src->pub.bytes_in_buffer -= (size_t)num_bytes;
  }
}

METHODDEF(void) term_source_fil(j_decompress_ptr cinfo) {
  my_source_mgr_fil* src = (my_source_mgr_fil*)cinfo->src;
  src->file->closeFile();
}

#endif // USE_DATA_FILES

//
// DRJpegReader
//
DRJpegReader::DRJpegReader() {
  cinfo.err = jpeg_std_error(&jerr);
  jerr.output_message = my_output_message;
}

DRJpegImage* DRJpegReader::readImage(
  jpeg_decompress_struct* cinfo, jpeg_source_mgr* src,
  void (*init_source)(j_decompress_ptr cinfo),
  unsigned char (*fill_input_buffer)(j_decompress_ptr cinfo),
  void (*skip_input_data)(j_decompress_ptr cinfo,long),
  void (*term_source)(j_decompress_ptr cinfo),
  int alphaColor, int tolerance
) {
  DRJpegImage* jpegImage = new DRJpegImage();
  jpegImage->setHasAlpha(alphaColor >= 0);
  jpeg_create_decompress(cinfo);
  cinfo->src = src;
  src->init_source = init_source;
  src->fill_input_buffer = fill_input_buffer;
  src->skip_input_data = skip_input_data;
  src->resync_to_restart = jpeg_resync_to_restart;
  src->term_source = term_source;
  src->bytes_in_buffer = 0;
  src->next_input_byte = NULL;
  jpeg_read_header(cinfo,TRUE);
  jpeg_start_decompress(cinfo);
  jpegImage->setWidth(cinfo->output_width);
  jpegImage->setHeight(cinfo->output_height);
  int components = cinfo->output_components;
  if(jpegImage->getHasAlpha()) components++;
  int row_stride = cinfo->output_width*components;
  unsigned char** jpegBuffer = new unsigned char*[cinfo->output_height];
  unsigned char* buffer = new unsigned char[row_stride*cinfo->output_height];
  for(
    unsigned int ct = 0, ctBuf = cinfo->output_height-1;
    ct < cinfo->output_height;
    ct++, ctBuf--
  )
    jpegBuffer[ctBuf] = &buffer[ct*row_stride];
  char alphaRed, alphaGreen, alphaBlue;
  if(jpegImage->getHasAlpha()) {
    alphaRed = (char)(alphaColor>>16);
    alphaGreen = (char)((alphaColor>>8)&0xff);
    alphaBlue = (char)(alphaColor&0xff);
  }
  while(cinfo->output_scanline < cinfo->output_height) {
    int line = cinfo->output_scanline;
    jpeg_read_scanlines(cinfo,&jpegBuffer[line],1);
    if(jpegImage->getHasAlpha()) {
      int ct4 = (jpegImage->getWidth()-1)*4;
      int ct3 = (jpegImage->getWidth()-1)*3;
      for(; ct3 >= 0; ct3 -= 3, ct4 -= 4) {
        unsigned char r = jpegBuffer[line][ct3  ];
        unsigned char g = jpegBuffer[line][ct3+1];
        unsigned char b = jpegBuffer[line][ct3+2];
        jpegBuffer[line][ct4  ] = r;
        jpegBuffer[line][ct4+1] = g;
        jpegBuffer[line][ct4+2] = b;
        jpegBuffer[line][ct4+3] = (
          alphaRed-tolerance   <= r && r <= alphaRed+tolerance   &&
          alphaGreen-tolerance <= g && g <= alphaGreen+tolerance &&
          alphaBlue-tolerance  <= b && b <= alphaBlue+tolerance
        )? (unsigned char)0x00: (unsigned char)0xff;
      }
    }
  }
  delete jpegBuffer;
  jpegImage->setBuffer(buffer);
  jpeg_finish_decompress(cinfo);
  jpeg_destroy_decompress(cinfo);
  return jpegImage;
}

//
// DRPngReader
//
DRPngReader::DRPngReader(): readPointer(NULL) {
}

void DRPngReader::pngWarning(png_structp png_ptr, png_const_charp message) {
  png_ptr;
  Exception::showWarning(message,"PNG");
}

void DRPngReader::pngError(png_structp png_ptr, png_const_charp message) {
  png_ptr;
  Exception::showError(message,"PNG");
}

void DRPngReader::pngReadData(
  png_structp png_ptr, png_bytep data, png_size_t length
) {
  DRPngReader* pr = reinterpret_cast<DRPngReader*>(png_get_io_ptr(png_ptr));
  memcpy(data,pr->getReadPointer(),length);
  pr->moveReadPointer(length);
}

DRPngImage* DRPngReader::readImage() throw(ExceptionThrown) {
  png_structp read_ptr = png_create_read_struct(
    PNG_LIBPNG_VER_STRING, (png_voidp)NULL,
    (png_error_ptr)pngError, (png_error_ptr)pngWarning
  );
  if(!read_ptr) Exception::throws("png_create_read_struct");
    png_infop read_info_ptr = png_create_info_struct(read_ptr);
  if(!read_info_ptr) {
    png_destroy_read_struct(&read_ptr,(png_infopp)NULL,(png_infopp)NULL);
    Exception::throws("png_create_info_struct (read_info_ptr)");
  }
  png_infop end_info_ptr = png_create_info_struct(read_ptr);
  if(!end_info_ptr) {
    png_destroy_read_struct(&read_ptr,&read_info_ptr,(png_infopp)NULL);
    Exception::throws("png_create_info_struct (end_info_ptr)");
  }
  if(setjmp(read_ptr->jmpbuf)) {
    png_destroy_read_struct(&read_ptr, &read_info_ptr, &end_info_ptr);
    Exception::throws("PNG Read Error");
  }
  png_set_read_fn(read_ptr, (png_voidp)this, (png_rw_ptr)pngReadData);
  png_read_info(read_ptr, read_info_ptr);
  unsigned long width, height;
  int bits, mode;
    png_get_IHDR(
    read_ptr, read_info_ptr, &width, &height, &bits, &mode, NULL, NULL, NULL
  );
  if(bits != 8) {
    Exception::showError("PNG bit depth not supported","PNG Error");
    Exception::throws("PNG");
  }
  DRPngImage* pngImage;
  int components;
  int paletteEntries;
  png_color_struct* palette = NULL;
  int transpEntries;
  png_bytep transp = NULL;
  switch(mode) {
    case PNG_COLOR_TYPE_PALETTE: {
      png_get_PLTE(read_ptr,read_info_ptr,&palette,&paletteEntries);
      png_get_tRNS(read_ptr,read_info_ptr,&transp,&transpEntries,NULL);
      if(transpEntries != 0) {
        pngImage = new DRPngImage(true);
        components = 4;
      } else {
        pngImage = new DRPngImage(false);
        components = 3;
      }
      break;
    }
    case PNG_COLOR_TYPE_RGB: {
      pngImage = new DRPngImage(false);
      components = 3;
      break;
    }
    case PNG_COLOR_TYPE_GRAY: {
      pngImage = new DRPngImage(false,true);
      components = 1;
      break;
    }
    case PNG_COLOR_TYPE_GRAY_ALPHA:
    case PNG_COLOR_TYPE_RGB_ALPHA: {
      pngImage = new DRPngImage(true);
      components = 4;
      break;
    }
    default:
      Exception::showError("PNG format not supported","PNG Error");
      Exception::throws("PNG");
  }
  pngImage->setWidth(width);
  pngImage->setHeight(height);
  int row_stride = width*components;
  png_bytep* pngBuffer = new png_bytep[height];
  unsigned char* buffer = new unsigned char[row_stride*height];
  for(unsigned int ct = 0, ctBuf = height-1; ct < height; ct++, ctBuf--)
    pngBuffer[ctBuf] = &buffer[ct*row_stride];
  png_read_image(read_ptr,pngBuffer);
  png_read_end(read_ptr,NULL);
  switch(mode) {
    case PNG_COLOR_TYPE_PALETTE: {
      for(unsigned int ct = 0; ct < height; ct++) {
        int ct1 = width-1;
        for(int ct3 = ct1*components; ct3 >= 0; ct3 -= components, ct1--) {
      	  unsigned char idx = pngBuffer[ct][ct1];
          pngBuffer[ct][ct3  ] = palette[idx].red;
          pngBuffer[ct][ct3+1] = palette[idx].green;
          pngBuffer[ct][ct3+2] = palette[idx].blue;
          if(transp && idx < transpEntries)
            pngBuffer[ct][ct3+3] = transp[idx];
          else
            pngBuffer[ct][ct3+3] = 0xff;
        }
      }
      break;
    }
    case PNG_COLOR_TYPE_GRAY: {
      for(unsigned int ct = 0; ct < height; ct++) {
        for(int ct1 = width-1; ct1 >= 0; ct1--) {
      	  pngBuffer[ct][ct1] = pngBuffer[ct][ct1];
      	}
      }
      break;
    }
    case PNG_COLOR_TYPE_GRAY_ALPHA: {
      for(unsigned int ct = 0; ct < height; ct++) {
        int ct2 = width+width-2;
        for(int ct4 = (width-1)*4; ct4 >= 0; ct4 -= 4, ct2 -=2) {
      	  unsigned char index = pngBuffer[ct][ct2  ];
          unsigned char alpha = pngBuffer[ct][ct2+1];
          pngBuffer[ct][ct4  ] = index;
          pngBuffer[ct][ct4+1] = index;
          pngBuffer[ct][ct4+2] = index;
          pngBuffer[ct][ct4+3] = alpha;
        }
      }
      break;
    }
    case PNG_COLOR_TYPE_RGB_ALPHA: {
      for(unsigned int ct = 0; ct < height; ct++) {
        for(int ct4 = (width-1)*4; ct4 >= 0; ct4 -= 4) {
          unsigned char r = pngBuffer[ct][ct4  ];
      	  unsigned char g = pngBuffer[ct][ct4+1];
          unsigned char b = pngBuffer[ct][ct4+2];
          unsigned char a = pngBuffer[ct][ct4+3];
          pngBuffer[ct][ct4  ] = r;
          pngBuffer[ct][ct4+1] = g;
          pngBuffer[ct][ct4+2] = b;
          pngBuffer[ct][ct4+3] = a;
      	}
      }
      break;
    }
    case PNG_COLOR_TYPE_RGB: {
      for(unsigned int ct = 0; ct < height; ct++) {
        for(int ct3 = (width-1)*3; ct3 >= 0; ct3 -= 3) {
          unsigned char r = pngBuffer[ct][ct3  ];
          unsigned char g = pngBuffer[ct][ct3+1];
          unsigned char b = pngBuffer[ct][ct3+2];
          pngBuffer[ct][ct3  ] = r;
          pngBuffer[ct][ct3+1] = g;
          pngBuffer[ct][ct3+2] = b;
      	}
      }
      break;
    }
    default:
      break;
  }
  png_destroy_read_struct(&read_ptr,&read_info_ptr,&end_info_ptr);
  delete pngBuffer;
  pngImage->setBuffer(buffer);
  return pngImage;
}

//
// DRTgaReader
//
DRTgaReader::DRTgaReader(): readPointer(NULL) {
}

DRTgaImage* DRTgaReader::readImage(DRData* data) {
  unsigned char	UNC_RGB_TGA[12] = {0,0,2,0,0,0,0,0,0,0,0,0};
  unsigned char	COM_RGB_TGA[12] = {0,0,10,0,0,0,0,0,0,0,0,0};
  unsigned char	UNC_8_TGA[12]   = {0,1,1,0,0,0,1,24,0,0,0,0};
  setReadPointer(data->getBuffer());
  if(memcmp(UNC_RGB_TGA,getReadPointer(),sizeof(UNC_RGB_TGA)) == 0)
    return getUncompressedTrueColorTGA(data);
  else if(memcmp(COM_RGB_TGA,getReadPointer(),sizeof(COM_RGB_TGA)) == 0)
    return getCompressedTrueColorTGA(data);
  else if(memcmp(UNC_8_TGA,getReadPointer(),sizeof(UNC_8_TGA)) == 0)
    return getUncompressed8BitTGA(data);
  return NULL;
}

DRTgaImage* DRTgaReader::getUncompressed8BitTGA(DRData* data) {
  setReadPointer(data->getBuffer());
  moveReadPointer(12);
	int width = getReadPointer()[1]*256+getReadPointer()[0];
	int height = getReadPointer()[3]*256+getReadPointer()[2];
  moveReadPointer(6);
  const int PALETTE_ENTRIES = 256*3;
	unsigned char* palette = getReadPointer();
  moveReadPointer(PALETTE_ENTRIES);
  const int INDICES_SIZE = width*height;
  unsigned char* indices = getReadPointer();
  moveReadPointer(INDICES_SIZE);
  unsigned char* buffer = new unsigned char[width*height*3];
	for(int row = 0; row < height; row++) {
		for(int col = 0; col < width; col++) {
      const int index8 = row*width+col;
      const int indexRGB = index8*3;
			buffer[indexRGB+0] = palette[indices[index8]*3+2];
			buffer[indexRGB+1] = palette[indices[index8]*3+1];
			buffer[indexRGB+2] = palette[indices[index8]*3+0];
		}
	}
  DRTgaImage* tgaImage = new DRTgaImage();
  tgaImage->setWidth(width);
  tgaImage->setHeight(height);
  tgaImage->setBuffer(buffer);
	return tgaImage;
}

DRTgaImage* DRTgaReader::getUncompressedTrueColorTGA(DRData* data) {
  setReadPointer(data->getBuffer());
  moveReadPointer(12);
	int width = getReadPointer()[1]*256+getReadPointer()[0];
	int height = getReadPointer()[3]*256+getReadPointer()[2];
	int bpp = getReadPointer()[4];
  if(bpp != 24 && bpp != 32)
    return NULL;
  moveReadPointer(6);
  int bytesPerPixel = bpp>>3;
	int	imageSize = width*height*bytesPerPixel;
	unsigned char* buffer = new unsigned char[imageSize];
  memcpy(buffer,getReadPointer(),imageSize);
	for(int ct = 0; ct < imageSize; ct += bytesPerPixel)
		buffer[ct] ^= buffer[ct+2] ^= buffer[ct] ^= buffer[ct+2];
  DRTgaImage* tgaImage = new DRTgaImage(bytesPerPixel == 4);
  tgaImage->setWidth(width);
  tgaImage->setHeight(height);
  tgaImage->setBuffer(buffer);
	return tgaImage;
}

DRTgaImage* DRTgaReader::getCompressedTrueColorTGA(DRData* data) {
  setReadPointer(data->getBuffer());
  moveReadPointer(12);
	int width = getReadPointer()[1]*256+getReadPointer()[0];
	int height = getReadPointer()[3]*256+getReadPointer()[2];
	int bpp = getReadPointer()[4];
  if(bpp != 24 && bpp != 32)
    return NULL;
  moveReadPointer(6);
  int bytesPerPixel = bpp>>3;
	int	imageSize = width*height*bytesPerPixel;
	unsigned char* buffer = new unsigned char[imageSize];
  memcpy(buffer,getReadPointer(),imageSize);
	int pixelCount = height*width;
	int currentPixel = 0;
	int currentByte	= 0;
	unsigned char* colorBuffer;
	do {
		unsigned char chunkHeader = *getReadPointer();
    moveReadPointer(1);
		if(chunkHeader < 128) {
			chunkHeader++;
			for(int ct = 0; ct < chunkHeader; ct++) {
        colorBuffer = getReadPointer();
        moveReadPointer(bytesPerPixel);
				buffer[currentByte  ] = colorBuffer[2];
				buffer[currentByte+1] = colorBuffer[1];
				buffer[currentByte+2] = colorBuffer[0];
				if(bytesPerPixel == 4)
					buffer[currentByte+3] = colorBuffer[3];
				currentByte += bytesPerPixel;
				currentPixel++;
			}
		} else {
			chunkHeader -= 127;
      colorBuffer = getReadPointer();
      moveReadPointer(bytesPerPixel);
			for(int ct = 0; ct < chunkHeader; ct++) {
				buffer[currentByte  ] = colorBuffer[2];
				buffer[currentByte+1] = colorBuffer[1];
				buffer[currentByte+2] = colorBuffer[0];
				if(bytesPerPixel == 4)
					buffer[currentByte+3] = colorBuffer[3];
				currentByte += bytesPerPixel;
				currentPixel++;
			}
		}
	} while(currentPixel < pixelCount);
  DRTgaImage* tgaImage = new DRTgaImage(bytesPerPixel == 4);
  tgaImage->setWidth(width);
  tgaImage->setHeight(height);
  tgaImage->setBuffer(buffer);
	return tgaImage;
}

//
// DRMeshReader
//

DRMeshReader::DRMeshReader(DRZipFile* zip):
  zipFile(zip), chunkPointer(0), chunkEndPointer(0)
#ifdef USE_DATA_FILES
  , readFile(NULL)
#endif // USE_DATA_FILES
{
  bufferPointer = bufferStart = zip->getZipBuffer();
  bufferLength = zip->getZipBufferLength();
  readBufferPtr = &readBufferFromZip;
  seekDataPtr = &seekDataFromZip;
  dataLengthPtr = &dataLengthFromZip;
  readImagePtr = &readImageFromZip;
  readDataPtr = &readDataFromZip;
}

void DRMeshReader::readBufferFromZip(
  DRMeshReader* reader, void* buffer, int bytesToBeRead, int* bytesRead
) {
  memcpy(buffer,reader->bufferPointer,bytesToBeRead);
  reader->bufferPointer += bytesToBeRead;
  *bytesRead = bytesToBeRead;
}

void DRMeshReader::seekDataFromZip(DRMeshReader* reader, int offset) {
  reader->bufferPointer = reader->bufferStart+offset;
}

int DRMeshReader::dataLengthFromZip(DRMeshReader* reader) {
  return reader->bufferLength;
}

DRImage* DRMeshReader::readImageFromZip(DRMeshReader* reader, char* imageName) {
  return reader->zipFile->getImage(imageName);
}

DRData* DRMeshReader::readDataFromZip(DRMeshReader* reader, char* dataName) {
  return reader->zipFile->getData(dataName);
}

#ifdef USE_DATA_FILES

DRMeshReader::DRMeshReader(FILE* fileHandle, const char* pth):
  path(pth), zipFile(NULL), bufferPointer(NULL), bufferStart(NULL),
  bufferLength(0), readFile(fileHandle), chunkPointer(0), chunkEndPointer(0)
{
  readBufferPtr = &readBufferFromFile;
  seekDataPtr = &seekDataFromFile;
  dataLengthPtr = &dataLengthFromFile;
  readImagePtr = &readImageFromFile;
  readDataPtr = &readDataFromFile;
}

void DRMeshReader::seekDataFromFile(DRMeshReader* reader, int offset) {
  fseek(reader->readFile,offset,SEEK_SET);
}

int DRMeshReader::dataLengthFromFile(DRMeshReader* reader) {
  return filelength(fileno(reader->readFile));
}

void DRMeshReader::readBufferFromFile(
  DRMeshReader* reader, void* buffer, int bytesToBeRead, int* bytesRead
) {
  *bytesRead = fread(buffer,1,bytesToBeRead,reader->readFile);
}

DRImage* DRMeshReader::readImageFromFile(DRMeshReader* reader, char* imageName) {
	if(reader->getPath()) {
  	char theImageName[MAX_PATH];
    strcat(strcpy(theImageName,reader->getPath()),imageName);
  	return DRImage::getImageFromFile(theImageName);
  } else {
	  return DRImage::getImageFromFile(imageName);
  }
}

DRData* DRMeshReader::readDataFromFile(DRMeshReader* reader, char* bufferName) {
	if(reader->getPath()) {
  	char theBufferName[MAX_PATH];
    strcat(strcpy(theBufferName,reader->getPath()),bufferName);
		DRDataFile file(theBufferName);
  	return file.getData();
  } else {
		DRDataFile file(bufferName);
  	return file.getData();
  }
}

#endif // USE_DATA_FILES

unsigned short DRMeshReader::getChunkID() {
  unsigned short id;
  int chunkLength;
  int size;
  readBuffer(&id,2,&size);
  readBuffer(&chunkLength,4,&size);
  chunkEndPointer = chunkPointer+chunkLength;
  chunkPointer += 6;
  return id;
}

void DRMeshReader::skip() {
  seekData(chunkPointer = chunkEndPointer);
}

void DRMeshReader::restore() {
  seekData(chunkPointer = 6);
}

unsigned short DRMeshReader::readUShort() {
  unsigned short uShort;
  int size;
  readBuffer(&uShort,2,&size);
  chunkPointer += 2;
  return uShort;
}

unsigned char DRMeshReader::readUChar() {
  unsigned char uChar;
  int size;
  readBuffer(&uChar,1,&size);
  chunkPointer++;
  return uChar;
}

float DRMeshReader::readFloat() {
  float theFloat;
  int size;
  readBuffer(&theFloat,4,&size);
  chunkPointer += 4;
  return theFloat;
}

void DRMeshReader::read(char* string) {
  int size;
  int ct = 0;
  do {
    readBuffer(&string[ct],1,&size);
    chunkPointer++;
  } while(string[ct++] != '\0');
}

void DRMeshReader::read(float* array, int arrayLength) {
  int size;
  arrayLength *= 4;
  readBuffer(array,arrayLength,&size);
  chunkPointer += arrayLength;
}

void DRMeshReader::read(unsigned short* array, int arrayLength) {
  int size;
  arrayLength *= 2;
  readBuffer(array,arrayLength,&size);
  chunkPointer += arrayLength;
}

// Material info for OBJ files
struct MaterialInfo {
 	GLBasicMaterial* material;
	char* name;
  int facesCount;
  int facesIndex;
  unsigned short* faceIndexes;
};

GLObjects* DRMeshReader::readMeshes(MeshFormat meshFmt, MeshType meshType) {
if(meshFmt == FMT_3DS) {
  const int INC_OBJECTS_COUNT = 8;
  const int MAX_NAME_LENGTH = 64;
  DSArray<char> materialNames(INC_OBJECTS_COUNT);
  DSArray<GLBasicMaterial,false> materials(INC_OBJECTS_COUNT);
  GLObjects* meshes = new GLObjects();
  int fileSize = dataLength();
  if(fileSize == 0xFFFFFFFF) return NULL;
  if(getChunkID() != MAIN3DS) return NULL;
  while(isMoreDataAvailable(fileSize)) {
    switch(getChunkID()) {
      case EDIT3DS: {
        int editEnd = getChunkEndPointer();
        while(isMoreDataAvailable(editEnd)) {
          switch(getChunkID()) {
            case MATERIALS: {
              int materialEnd = getChunkEndPointer();
              GLBasicMaterial *lastMaterial = NULL;
              while(isMoreDataAvailable(materialEnd)) {
                switch(getChunkID()) {
                  case MATERIALNAME: {
                    char* materialName = new char[MAX_NAME_LENGTH];
                    read(materialName);
                    materialNames.addElement(materialName);
                    switch(meshType) {
                      default:
                      case TYPE_BASIC:
                        lastMaterial = (new GLBasicMaterial())->acquireReference();
                        break;
                      case TYPE_SHADER:
                        lastMaterial = (new GLShaderMaterial())->acquireReference();
                        break;
                      case TYPE_NORMAL:
                        lastMaterial = (new GLMaterial())->acquireReference();
                        break;
#ifdef USE_EMBOSS
                      case TYPE_BUMPED:
                        lastMaterial = (new GLBumpedMaterial())->acquireReference();
                        break;
#endif // USE_EMBOSS
                    }
                    materials.addElement(lastMaterial);
                    break;
                  }
                  case MATAMBIENT: {
                    float r, g, b;
                    switch(getChunkID()) {
                      case MATCOLOR: {
                        r = readUChar()/255.0f;
                        g = readUChar()/255.0f;
                        b = readUChar()/255.0f;
                        break;
                      }
                      case MATCOLOR_F: {
                        r = readFloat();
                        g = readFloat();
                        b = readFloat();
                        break;
                      }
                      default: {
                        r = g = b = 1;
                        break;
                      }
                    }
                    lastMaterial->setAmbient(r,g,b);
                    break;
                  }
                  case MATDIFFUSE: {
                    float r, g, b;
                    switch(getChunkID()) {
                      case MATCOLOR: {
                        r = readUChar()/255.0f;
                        g = readUChar()/255.0f;
                        b = readUChar()/255.0f;
                        break;
                      }
                      case MATCOLOR_F: {
                        r = readFloat();
                        g = readFloat();
                        b = readFloat();
                        break;
                      }
                      default: {
                        r = g = b = 1;
                        break;
                      }
                    }
                    lastMaterial->setDiffuse(r,g,b);
                    break;
                  }
                  case MATSPECULAR: {
                    float r, g, b;
                    switch(getChunkID()) {
                      case MATCOLOR: {
                        r = readUChar()/255.0f;
                        g = readUChar()/255.0f;
                        b = readUChar()/255.0f;
                        break;
                      }
                      case MATCOLOR_F: {
                        r = readFloat();
                        g = readFloat();
                        b = readFloat();
                        break;
                      }
                      default: {
                        r = g = b = 1;
                        break;
                      }
                    }
                    lastMaterial->setSpecular(r,g,b);
                    break;
                  }
                  case MATSHININESS: {
                    float s;
                    switch(getChunkID()) {
                      case PERCENTAGE_I:
                        s = readUShort()*(128/100.0f);
                        break;
                      case PERCENTAGE_F:
                        s = readFloat()*(128/100.0f);
                        break;
                      default:
                        s = 128;
                        break;
                    }
                    lastMaterial->setShininess(s);
                    break;
                  }
                  case MATTEXTURE: {
                    break;
                  }
                  case MATTEXNAME: {
                    char textureName[MAX_NAME_LENGTH];
                    read(textureName);
                    DRImage* image = readImage(textureName);
                    if(image) {
                      GLTexture* texture = new GLTexture(*image,true);
                      lastMaterial->setDiffuseTexture(texture);
                      delete image;
                    }
                    break;
                  }
                  default: {
                    skip();
                    break;
                  }
                }
              }
              break;
            }
            default: {
              skip();
              break;
            }
          }
        }
        break;
      }
      default: {
        skip();
        break;
      }
    }
  }
  restore();
  while(isMoreDataAvailable(fileSize)) {
    switch(getChunkID()) {
      case EDIT3DS: {
        int editEnd = getChunkEndPointer();
        while(isMoreDataAvailable(editEnd)) {
          switch(getChunkID()) {
            case OBJECT3DS: {
              int objectEnd = getChunkEndPointer();
              char objectName[MAX_NAME_LENGTH];
              read(objectName);
              int verticesCount = 0;
              float* vertices = NULL;
              float* mappings = NULL;
              int facesCount = 0;
              unsigned short* faces = NULL;
              DSArray<GLBasicMaterial,false> facesMaterial(INC_OBJECTS_COUNT);
              DSArray<unsigned short> facesList(INC_OBJECTS_COUNT);
              while(isMoreDataAvailable(objectEnd)) {
                switch(getChunkID()) {
                  case TRIMESH: {
                    break;
                  }
                  case VERTEXLIST: {
                    verticesCount = readUShort();
                    int arrayLength = verticesCount*3;
                    vertices = new float[arrayLength];
                    read(vertices,arrayLength);
                    break;
                  }
                  case MAPPINGLIST: {
                    int mappingsCount = readUShort();
                    int arrayLength = mappingsCount+mappingsCount;
                    mappings = new float[arrayLength];
                    read(mappings,arrayLength);
                    break;
                  }
                  case FACELIST: {
                    facesCount = readUShort();
                    int arrayLength = facesCount*3;
                    faces = new unsigned short[arrayLength];
                    for(int ct = 0; ct < arrayLength; ct += 3) {
                      faces[ct  ] = readUShort();
                      faces[ct+1] = readUShort();
                      faces[ct+2] = readUShort();
                      readUShort();
                    }
                    break;
                  }
                  case MATERIALLIST: {
                    char materialName[MAX_NAME_LENGTH];
                    read(materialName);
                    for(int ct = 0; ct < materials.getSize(); ct++) {
                      if(
                        strcmp(materialName,materialNames.getElement(ct)) == 0
                      ) {
                        facesMaterial.addElement(materials.getElement(ct));
                        unsigned short facesCount = readUShort();
                        unsigned short* fList =
                          new unsigned short[facesCount+1];
                        fList[0] = facesCount;
                        read(fList+1,facesCount);
                        facesList.addElement(fList);
                        break;
                      }
                    }
                    break;
                  }
                  default: {
                    skip();
                    break;
                  }
                }
              }
              if(facesMaterial.getSize()) {
                GLVertices* theVertices;
                GLShape* supportShape; // to calculate normals over all faces
                if(meshType == TYPE_SHADER) {
                  theVertices = new GLShaderVertices(
                    verticesCount,vertices,NULL,mappings
                  );
                  // Now 'theVertices' owns 'vertices' and 'mappings': DON'T DELETE THEM!
                  supportShape = (new GLShaderShape(
                    *dynamic_cast<GLShaderVertices*>(theVertices),facesCount,faces
                  ))->acquireReference();
                } else {
                  theVertices = new GLVertices(
                    verticesCount,vertices,NULL,mappings
                  );
                  if(vertices) {
                    delete vertices;
                    vertices = NULL;
                  }
                  if(mappings) {
                    delete mappings;
                    mappings = NULL;
                  }
                  supportShape = (new GLShape(
                    *theVertices,facesCount,faces
                  ))->acquireReference();
                }
                // Now 'supportShape' owns 'faces': DON'T DELETE IT!
                supportShape->computeNormals();
                for(int ct = 0; ct < facesMaterial.getSize(); ct++) {
                  GLBasicMaterial* theMaterial = facesMaterial.getElement(ct);
                  unsigned short* theList = facesList.getElement(ct);
                  int theFacesCount = theList[0];
                  theList++;
                  unsigned short* theFaces =
                    new unsigned short[theFacesCount*3];
                  for(int listIter = 0; listIter < theFacesCount; listIter++) {
                    int listIter3 = listIter*3;
                    int idx3 = theList[listIter]*3;
                    theFaces[listIter3  ] = faces[idx3  ];
                    theFaces[listIter3+1] = faces[idx3+1];
                    theFaces[listIter3+2] = faces[idx3+2];
                  }
                  GLShape* theShape;
                  if(meshType == TYPE_SHADER) {
                    theShape = new GLShaderShape(
                      *dynamic_cast<GLShaderVertices*>(theVertices),
                      theFacesCount,theFaces
                    );
                  } else {
                    theShape = new GLShape(*theVertices,theFacesCount,theFaces);
                  }
                  // Now 'theShape' owns 'theFaces': DON'T DELETE IT!
                  switch(meshType) {
                    default:
                    case TYPE_BASIC:
                      meshes->addObject(new GLBasicMesh(*theShape,theMaterial));
                      break;
                    case TYPE_SHADER:
                    case TYPE_NORMAL:
                      meshes->addObject(
                        new GLMesh(*theShape,
                          dynamic_cast<GLMaterial*>(theMaterial))
                      );
                      break;
#ifdef USE_EMBOSS
                    case TYPE_BUMPED:
                      meshes->addObject(
                        new GLBumpedMesh(*theShape,
                          dynamic_cast<GLBumpedMaterial*>(theMaterial))
                      );
                      break;
#endif // USE_EMBOSS
                  }
                }
                supportShape->releaseReference();
              } else {
                for(int ct = 0; ct < materials.getSize(); ct++) {
                  if(
                    strcmp(" -- default --",materialNames.getElement(ct)) == 0
                  ) {
                    GLBasicMaterial* material = materials.getElement(ct);
                    GLShape* shape;
                    if(meshType == TYPE_SHADER) {
                      shape = new GLShaderShape(
                        verticesCount,vertices,NULL,mappings,facesCount,faces
                      );
                      // Now 'shape' owns 'vertices' and 'mappings': DON'T DELETE THEM!
                    } else {
                      shape = new GLShape(
                        verticesCount,vertices,NULL,mappings,facesCount,faces
                      );
                    }
                    // Now 'shape' owns 'faces': DON'T DELETE IT!
                    switch(meshType) {
                      default:
                      case TYPE_BASIC:
                        meshes->addObject(new GLBasicMesh(*shape,material));
                        break;
                      case TYPE_SHADER:
                      case TYPE_NORMAL:
                        meshes->addObject(
                          new GLMesh(*shape,dynamic_cast<GLMaterial*>(material))
                        );
                        break;
#ifdef USE_EMBOSS
                      case TYPE_BUMPED:
                        meshes->addObject(
                          new GLBumpedMesh(*shape,
                            dynamic_cast<GLBumpedMaterial*>(material))
                        );
                        break;
#endif // USE_EMBOSS
                    }
                    break;
                  }
                }
                if(meshType != TYPE_SHADER) {
                  if(vertices) {
                    delete vertices;
                    vertices = NULL;
                  }
                  if(mappings) {
                    delete mappings;
                    mappings = NULL;
                  }
                }
              }
              break;
            }
            default: {
              skip();
              break;
            }
          }
        }
        break;
      }
      default: {
        skip();
        break;
      }
    }
  }
  for(int ct = 0; ct < materials.getSize(); ct++)
    materials.getElement(ct)->releaseReference();
  return meshes;
} else if(meshFmt == FMT_OBJ) {
  const int MAX_NAME_LENGTH = 64;
  const int INC_MATERIALS_COUNT = 8;
  DSArray<MaterialInfo> materialsInfo(INC_MATERIALS_COUNT);
  GLObjects* meshes = new GLObjects();
	int stringLen = dataLength();
  char* stringBuffer = new char[stringLen+1];
  int bytesRead;
  readBuffer(stringBuffer,stringLen,&bytesRead);
  stringBuffer[stringLen] = '\0';
  int currentMaterial = 0;
  int verticesCount = 0;
  int texCoordsCount = 0;
  int normalsCount = 0;
  // first pass
 	char* stringPointer = stringBuffer;
  while(*stringPointer != '\0') {
	  switch(*stringPointer) {
  		case 'f': { // f
      	if(*(++stringPointer) == ' ')
        	(materialsInfo.getElement(currentMaterial)->facesCount)++;
    		break;
	    }
  		case 'm': { // mtllib
      	if(strncmp((++stringPointer),"tllib ",6) == 0) {
        	char libraryName[MAX_NAME_LENGTH];
          sscanf((stringPointer+6),"%s\n",libraryName);
          char* r = strrchr(libraryName,'\r'); if(r) *r = '\0';
          DRData* data = readData(libraryName);
					int libraryLen = data->getSize();
				  char* libraryBuffer = new char[libraryLen+1];
					memcpy(libraryBuffer,data->getBuffer(),libraryLen);
				  libraryBuffer[libraryLen] = '\0';
          delete data;
          GLBasicMaterial* lastMaterial = NULL;
          for(
          	char* libraryPointer = strtok(libraryBuffer,"\r\n");
            libraryPointer != NULL;
            libraryPointer = strtok(NULL,"\r\n")
          ) {
					  switch(*libraryPointer) {
				  		case 'n': { // newmtl
              	if(strncmp((++libraryPointer),"ewmtl ",6) == 0) {
				        	char materialName[MAX_NAME_LENGTH];
                  sscanf((libraryPointer += 6),"%s",materialName);
                  MaterialInfo* info = new MaterialInfo();
                  info->facesCount = 0;
                  info->faceIndexes = NULL;
                  info->name = new char[strlen(materialName)+1];
                  strcpy(info->name,materialName);
                  switch(meshType) {
                    default:
                    case TYPE_BASIC:
                      lastMaterial = (new GLBasicMaterial())->acquireReference();
                      break;
                    case TYPE_SHADER:
                      lastMaterial = (new GLShaderMaterial())->acquireReference();
                      break;
                    case TYPE_NORMAL:
                      lastMaterial = (new GLMaterial())->acquireReference();
                      break;
#ifdef USE_EMBOSS
                    case TYPE_BUMPED:
                      lastMaterial = (new GLBumpedMaterial())->acquireReference();
                      break;
#endif // USE_EMBOSS
                  }
                  info->material = lastMaterial;
                  materialsInfo.addElement(info);
                }
              	break;
              }
              case 'N': {
              	if(*(++libraryPointer) == 's') {
                  float shininess;
                	sscanf((libraryPointer += 2),"%f",&shininess);
                  if(lastMaterial)
                  	lastMaterial->setShininess(shininess);
                }
              	break;
              }
              case 'd': {
              	if(*(++libraryPointer) == ' ') {
                  float transparency;
                	sscanf((++libraryPointer),"%f",&transparency);
                  if(lastMaterial)
                  	lastMaterial->setTransparency(transparency);
                }
              	break;
              }
              case 'K': {
              	switch(*(++libraryPointer)) {
                	case 'd': {
	                  float r, g, b;
  	              	sscanf((libraryPointer += 2),"%f %f %f",&r,&g,&b);
    	              if(lastMaterial) {
                    	float alpha = lastMaterial->getDiffuse().getAlpha();
      	            	lastMaterial->setDiffuse(r,g,b,alpha);
                    }
                  	break;
                  }
                	case 'a': {
	                  float r, g, b;
  	              	sscanf((libraryPointer += 2),"%f %f %f",&r,&g,&b);
    	              if(lastMaterial) {
                    	float alpha = lastMaterial->getAmbient().getAlpha();
      	            	lastMaterial->setAmbient(r,g,b,alpha);
                    }
                  	break;
                  }
                	case 's': {
	                  float r, g, b;
  	              	sscanf((libraryPointer += 2),"%f %f %f",&r,&g,&b);
    	              if(lastMaterial) {
                    	float alpha = lastMaterial->getSpecular().getAlpha();
      	            	lastMaterial->setSpecular(r,g,b,alpha);
                    }
                  	break;
                  }
                	case 'e': {
	                  float r, g, b;
  	              	sscanf((libraryPointer += 2),"%f %f %f",&r,&g,&b);
    	              if(lastMaterial) {
                    	float alpha = lastMaterial->getEmissive().getAlpha();
      	            	lastMaterial->setEmissive(r,g,b,alpha);
                    }
                  	break;
                  }
                }
              }
              case 'm': {
                if(strncmp((++libraryPointer),"ap_Kd ",6) == 0) {
				        	char fileName[MAX_NAME_LENGTH];
				          sscanf((libraryPointer+6),"%s",fileName);
                  DRImage* image = readImage(fileName);
                  if(image) {
                    GLTexture* texture = new GLTexture(*image,true);
                    lastMaterial->setDiffuseTexture(texture);
                    delete image;
                  }
                } else if(strncmp(libraryPointer,"ap_Ks ",6) == 0) {
                	if(meshType != TYPE_BASIC) {
					        	char fileName[MAX_NAME_LENGTH];
					          sscanf((libraryPointer+6),"%s",fileName);
              	    DRImage* image = readImage(fileName);
                	  if(image) {
                  	  GLTexture* texture = new GLTexture(*image,true);
                    	dynamic_cast<GLMaterial*>(lastMaterial)->setGlossTexture(texture);
	                    delete image;
  	                }
                  }
                } else if(strncmp(libraryPointer,"ap_Bump ",8) == 0) {
                	switch(meshType) {
                  	case TYPE_SHADER: {
						        	char fileName[MAX_NAME_LENGTH];
						          sscanf((libraryPointer+8),"%s",fileName);
              		    DRImage* image = readImage(fileName);
                		  if(image) {
                  		  GLTexture* texture = new GLTexture(*image,true);
                    		dynamic_cast<GLMaterial*>(lastMaterial)->setEnvironmentTexture(texture);
	                    	delete image;
	  	                }
                    	break;
                    }
#ifdef USE_EMBOSS
                  	case TYPE_BUMPED: {
						        	char fileName[MAX_NAME_LENGTH];
						          sscanf((libraryPointer+8),"%s",fileName);
              		    DRImage* image = readImage(fileName);
                		  if(image) {
                  		  GLBumpedTexture* texture =
                        	new GLBumpedTexture(*image,true);
                    		dynamic_cast<GLBumpedMaterial*>(lastMaterial)->setBumpedTexture(texture);
	                    	delete image;
	  	                }
                    	break;
                    }
#endif // USE_EMBOSS
                  }
                }
              	break;
              }
            }
          }
          delete libraryBuffer;
        }
    		break;
	    }
  		case 'u': { // usemtl
      	if(strncmp((++stringPointer),"semtl ",6) == 0) {
        	char materialName[MAX_NAME_LENGTH];
          sscanf((stringPointer+6),"%s\n",materialName);
          char* r = strrchr(materialName,'\r'); if(r) *r = '\0';
          currentMaterial = 0;
				  for(int ct = 0; ct < materialsInfo.getSize(); ct++) {
				    MaterialInfo* info = materialsInfo.getElement(ct);
            if(strcmp(materialName,info->name) == 0) {
              currentMaterial = ct;
              break;
            }
				  }
        }
    		break;
	    }
  		case 'v': { // v vt vn
      	switch(*(++stringPointer)) {
        	case ' ': {
	        	verticesCount++;
            break;
          }
        	case 't': {
	        	texCoordsCount++;
            break;
          }
        	case 'n': {
	        	normalsCount++;
            break;
          }
        }
    		break;
	    }
  	}
    stringPointer = strchr(stringPointer,'\n');
    if(stringPointer == NULL)
    	break;
    stringPointer++;
  }
	// second pass
  currentMaterial = 0;
  float* vertices = new float[verticesCount*3];
  DSStaticArray<int>* vertIndices;
  if(texCoordsCount || normalsCount)
	  vertIndices = new DSStaticArray<int>(2*verticesCount);
  else
  	vertIndices = NULL;
  float* texCoords;
  DSStaticArray<int>* texIndices;
  if(texCoordsCount) {
  	texCoords = new float[texCoordsCount*2];
    texIndices = new DSStaticArray<int>(2*verticesCount);
  } else {
  	texCoords = NULL;
    texIndices = NULL;
  }
  float* normals;
  DSStaticArray<int>* normIndices;
  if(normalsCount) {
  	normals = new float[normalsCount*3];
    normIndices = new DSStaticArray<int>(2*verticesCount);
  } else {
  	normals = NULL;
    normIndices = NULL;
  }
  int verticesIndex = 0;
  int texCoordsIndex = 0;
  int normalsIndex = 0;
  for(
   	stringPointer = strtok(stringBuffer,"\r\n");
    stringPointer != NULL;
    stringPointer = strtok(NULL,"\r\n")
  ) {
	  switch(*stringPointer) {
  		case 'f': { // f
		    MaterialInfo* materialInfo = materialsInfo.getElement(currentMaterial);
      	if(texCoordsCount) {
        	if(normalsCount) {
	        	int vA, tA, nA;
  	      	int vB, tB, nB;
    	    	int vC, tC, nC;
      	  	sscanf((stringPointer += 2),"%i/%i/%i %i/%i/%i %i/%i/%i",
	      	  	&vA, &tA, &nA, &vB, &tB, &nB, &vC, &tC, &nC
          	);
	          int faceIndex = materialInfo->facesIndex;
  	        int theRealIndex = 0;
    	      for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
      	    	if(
        	    	(vertIndices->getElement(theRealIndex) == vA) &&
          	  	(texIndices->getElement(theRealIndex) == tA) &&
          	  	(normIndices->getElement(theRealIndex) == nA)
            	) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vA);
      	    	texIndices->addElement(tA);
      	    	normIndices->addElement(nA);
        	  }
          	materialInfo->faceIndexes[faceIndex*3  ] = (unsigned short)theRealIndex;
  	        theRealIndex = 0;
	          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
    	      	if(
        	    	(vertIndices->getElement(theRealIndex) == vB) &&
          	  	(texIndices->getElement(theRealIndex) == tB) &&
          	  	(normIndices->getElement(theRealIndex) == nB)
          	  ) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vB);
      	    	texIndices->addElement(tB);
      	    	normIndices->addElement(nB);
        	  }
          	materialInfo->faceIndexes[faceIndex*3+1] = (unsigned short)theRealIndex;
  	        theRealIndex = 0;
	          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
    	      	if(
        	    	(vertIndices->getElement(theRealIndex) == vC) &&
          	  	(texIndices->getElement(theRealIndex) == tC) &&
          	  	(normIndices->getElement(theRealIndex) == nC)
          	  ) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vC);
      	    	texIndices->addElement(tC);
      	    	normIndices->addElement(nC);
        	  }
	          materialInfo->faceIndexes[faceIndex*3+2] = (unsigned short)theRealIndex;
  	        materialInfo->facesIndex++;
          } else {
	        	int vA, tA;
  	      	int vB, tB;
    	    	int vC, tC;
      	  	sscanf((stringPointer += 2),"%i/%i/ %i/%i/ %i/%i/",
	      	  	&vA, &tA, &vB, &tB, &vC, &tC
          	);
	          int faceIndex = materialInfo->facesIndex;
  	        int theRealIndex = 0;
    	      for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
      	    	if(
        	    	(vertIndices->getElement(theRealIndex) == vA) &&
          	  	(texIndices->getElement(theRealIndex) == tA)
            	) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vA);
      	    	texIndices->addElement(tA);
        	  }
          	materialInfo->faceIndexes[faceIndex*3  ] = (unsigned short)theRealIndex;
  	        theRealIndex = 0;
	          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
    	      	if(
        	    	(vertIndices->getElement(theRealIndex) == vB) &&
          	  	(texIndices->getElement(theRealIndex) == tB)
          	  ) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vB);
      	    	texIndices->addElement(tB);
        	  }
          	materialInfo->faceIndexes[faceIndex*3+1] = (unsigned short)theRealIndex;
  	        theRealIndex = 0;
	          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
    	      	if(
        	    	(vertIndices->getElement(theRealIndex) == vC) &&
          	  	(texIndices->getElement(theRealIndex) == tC)
          	  ) break;
	          }
  	        if(theRealIndex == vertIndices->getSize()) {
    	      	vertIndices->addElement(vC);
      	    	texIndices->addElement(tC);
        	  }
	          materialInfo->faceIndexes[faceIndex*3+2] = (unsigned short)theRealIndex;
  	        materialInfo->facesIndex++;
          }
        } else if(normalsCount) {
        	int vA, nA;
        	int vB, nB;
        	int vC, nC;
        	sscanf((stringPointer += 2),"%i//%i %i//%i %i//%i",
	        	&vA, &nA, &vB, &nB, &vC, &nC
          );
          int faceIndex = materialInfo->facesIndex;
          int theRealIndex = 0;
          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
          	if(
            	(vertIndices->getElement(theRealIndex) == vA) &&
            	(normIndices->getElement(theRealIndex) == nA)
            ) break;
          }
          if(theRealIndex == vertIndices->getSize()) {
          	vertIndices->addElement(vA);
          	normIndices->addElement(nA);
          }
          materialInfo->faceIndexes[faceIndex*3  ] = (unsigned short)theRealIndex;
	        theRealIndex = 0;
          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
          	if(
            	(vertIndices->getElement(theRealIndex) == vB) &&
            	(normIndices->getElement(theRealIndex) == nB)
            ) break;
          }
          if(theRealIndex == vertIndices->getSize()) {
          	vertIndices->addElement(vB);
          	normIndices->addElement(nB);
          }
          materialInfo->faceIndexes[faceIndex*3+1] = (unsigned short)theRealIndex;
	        theRealIndex = 0;
          for(; theRealIndex < vertIndices->getSize(); theRealIndex++) {
          	if(
            	(vertIndices->getElement(theRealIndex) == vC) &&
            	(normIndices->getElement(theRealIndex) == nC)
            ) break;
          }
          if(theRealIndex == vertIndices->getSize()) {
          	vertIndices->addElement(vC);
          	normIndices->addElement(nC);
          }
          materialInfo->faceIndexes[faceIndex*3+2] = (unsigned short)theRealIndex;
          materialInfo->facesIndex++;
        } else {
        	int vA;
        	int vB;
        	int vC;
        	sscanf((stringPointer += 2),"%i// %i// %i//",
	        	&vA, &vB, &vC
          );
          int faceIndex = materialInfo->facesIndex;
          materialInfo->faceIndexes[faceIndex*3  ] = (unsigned short)vA;
          materialInfo->faceIndexes[faceIndex*3+1] = (unsigned short)vB;
          materialInfo->faceIndexes[faceIndex*3+2] = (unsigned short)vC;
          materialInfo->facesIndex++;
        }
	    }
  		case 'u': { // usemtl
      	if(strncmp((++stringPointer),"semtl ",6) == 0) {
        	char materialName[MAX_NAME_LENGTH];
          sscanf((stringPointer+6),"%s",materialName);
          currentMaterial = 0;
				  for(int ct = 0; ct < materialsInfo.getSize(); ct++) {
				    MaterialInfo* info = materialsInfo.getElement(ct);
            if(strcmp(materialName,info->name) == 0) {
              currentMaterial = ct;
              if(info->faceIndexes == NULL) {
              	info->faceIndexes = new unsigned short[info->facesCount*3];
                info->facesIndex = 0;
              }
              break;
            }
				  }
        }
    		break;
	    }
  		case 'v': { // v vt vn
      	switch(*(++stringPointer)) {
        	case ' ': {
          	sscanf((++stringPointer),"%f %f %f",
            	&vertices[verticesIndex*3  ],
              &vertices[verticesIndex*3+1],
              &vertices[verticesIndex*3+2]
            );
            verticesIndex++;
            break;
          }
        	case 't': {
          	sscanf((stringPointer += 2),"%f %f",
            	&texCoords[texCoordsIndex*2  ],&texCoords[texCoordsIndex*2+1]
            );
            texCoordsIndex++;
            break;
          }
        	case 'n': {
          	sscanf((stringPointer += 2),"%f %f %f",
            	&normals[normalsIndex*3  ],
              &normals[normalsIndex*3+1],
              &normals[normalsIndex*3+2]
            );
            normalsIndex++;
            break;
          }
        }
    		break;
	    }
  	}
  }
  // create
  if((texCoordsCount != 0) || (normalsCount != 0)) {
    int theRealVerticesCount = vertIndices->getSize();
    float* theRealVertices = new float[theRealVerticesCount*3];
    for(int ct = 0; ct < theRealVerticesCount; ct++) {
    	int theFakeIndex = vertIndices->getElement(ct)-1;
    	theRealVertices[ct*3  ] = vertices[theFakeIndex*3  ];
    	theRealVertices[ct*3+1] = vertices[theFakeIndex*3+1];
    	theRealVertices[ct*3+2] = vertices[theFakeIndex*3+2];
    }
    delete vertIndices;
    delete vertices;
    verticesCount = theRealVerticesCount;
    vertices = theRealVertices;
    if(texCoordsCount) {
	    float* theRealTexCoords = new float[theRealVerticesCount*2];
	    for(int ct = 0; ct < theRealVerticesCount; ct++) {
  	  	int theFakeIndex = texIndices->getElement(ct)-1;
    		theRealTexCoords[ct*2  ] = texCoords[theFakeIndex*2  ];
    		theRealTexCoords[ct*2+1] = texCoords[theFakeIndex*2+1];
  	  }
  	  delete texIndices;
	    delete texCoords;
	    texCoords = theRealTexCoords;
    }
    if(normalsCount) {
    	float* theRealNormals = new float[theRealVerticesCount*3];
	    for(int ct = 0; ct < theRealVerticesCount; ct++) {
  	  	int theFakeIndex = normIndices->getElement(ct)-1;
    		theRealNormals[ct*3  ] = normals[theFakeIndex*3  ];
    		theRealNormals[ct*3+1] = normals[theFakeIndex*3+1];
    		theRealNormals[ct*3+2] = normals[theFakeIndex*3+2];
  	  }
  	  delete normIndices;
	    delete normals;
      normals = theRealNormals;
    }
  }
  GLVertices* theVertices;
  if(meshType == TYPE_SHADER) {
 	  theVertices = new GLShaderVertices(verticesCount,vertices,normals,texCoords);
    // Now 'theVertices' owns 'vertices', 'normals' and 'texCoords': DON'T DELETE THEM!
  } else {
    theVertices = new GLVertices(verticesCount,vertices,normals,texCoords);
    if(vertices) {
      delete vertices;
      vertices = NULL;
    }
    if(normals) {
      delete normals;
      normals = NULL;
    }
    if(texCoords) {
      delete texCoords;
      texCoords = NULL;
    }
  }
  for(int ct = 0; ct < materialsInfo.getSize(); ct++) {
   	MaterialInfo* materialInfo = materialsInfo.getElement(ct);
    GLBasicMaterial* theMaterial = materialInfo->material;
   	int facesCount = materialInfo->facesCount;
    if(facesCount) {
     	unsigned short* faces = materialInfo->faceIndexes;
      GLShape* theShape;
      if(meshType == TYPE_SHADER) {
        theShape = (new GLShaderShape(
 	        *dynamic_cast<GLShaderVertices*>(theVertices),facesCount,faces
        ))->acquireReference();
      } else {
        theShape = (new GLShape(
        	*theVertices,facesCount,faces
        ))->acquireReference();
      }
      // Now 'theShape' owns 'faces': DON'T DELETE IT!
      if(normalsCount == 0)
	      theShape->computeNormals();
      switch(meshType) {
        default:
        case TYPE_BASIC:
          meshes->addObject(new GLBasicMesh(*theShape,theMaterial));
          break;
        case TYPE_SHADER:
        case TYPE_NORMAL:
          meshes->addObject(
            new GLMesh(*theShape,
            	dynamic_cast<GLMaterial*>(theMaterial))
          );
          break;
#ifdef USE_EMBOSS
        case TYPE_BUMPED:
          meshes->addObject(
            new GLBumpedMesh(*theShape,
              dynamic_cast<GLBumpedMaterial*>(theMaterial))
          );
          break;
#endif // USE_EMBOSS
      }
      theShape->releaseReference();
    }
  }
	delete stringBuffer;
  for(int ct = 0; ct < materialsInfo.getSize(); ct++) {
    MaterialInfo* info = materialsInfo.getElement(ct);
    if(info->name)
    	delete info->name;
    if(info->material)
    	info->material->releaseReference();
  }
  return meshes;
}
return NULL;
}

#ifndef __linux__

//
// DRResource
//
DRResource::DRResource(int id) throw(ExceptionThrown) {
  resource = FindResource(NULL,MAKEINTRESOURCE(id),
#if defined(__MINGW32__)
    RT_RCDATA
#else // !defined(__MINGW32__)
    MAKEINTRESOURCE(RT_RCDATA)
#endif // !defined(__MINGW32__)
	);
  if(resource == NULL) Exception::throws("FindResource");
}

DRResource::DRResource(char* name) throw(ExceptionThrown) {
  resource = FindResource(NULL,name,
#if defined(__MINGW32__)
    RT_RCDATA
#else // !defined(__MINGW32__)
    MAKEINTRESOURCE(RT_RCDATA)
#endif // !defined(__MINGW32__)
  );
  if(resource == NULL) Exception::throws("FindResource");
}

LPBYTE DRResource::getPointer() throw(ExceptionThrown) {
  HGLOBAL memory = LoadResource(NULL,resource);
  if(memory == NULL) Exception::throws("LoadResource");
  LPBYTE pointer = (LPBYTE)LockResource(memory);
  if(pointer == NULL) Exception::throws("LockResource");
  return pointer;
}

DRResource::~DRResource() {
}

#endif // __linux__

//
// DRFile
//
DRFile::DRFile(const char* filNam, const char* pth): fileName(NULL), file(NULL) {
	if(pth) {
		char tempName[MAX_PATH];
	  strcat(strcpy(tempName,pth),filNam);
    fileName = new char[strlen(tempName)+1];
    strcpy(fileName,tempName);
  } else {
    fileName = new char[strlen(filNam)+1];
    strcpy(fileName,filNam);
  }
}

DRFile::~DRFile() {
	if(fileName)
  	delete fileName;
	closeFile();
}

bool DRFile::openFile() {
  file = fopen(fileName,"rb");
  return file != NULL;
}

void DRFile::closeFile() {
  if(file != NULL) {
    fclose(file);
    file = NULL;
  }
}

//
// DRDataFile
//
DRDataFile::DRDataFile(const char* filNam): DRFile(filNam) {
}

DRData* DRDataFile::getData() {
  if(openFile()) {
    int size = (int)filelength(fileno(file));
    unsigned char* buffer = new unsigned char[size];
    size = fread(buffer,1,size,file);
    closeFile();
    return new DRData(size,buffer);
  }
  return NULL;
}

//
// DRZipFile
//
DRZipFile::DRZipFile(const char* zipFileName, bool zipped) throw(ExceptionThrown):
#ifdef USE_DATA_FILES
  virtualPath(NULL),
#endif // USE_DATA_FILES
  fileHandler(NULL), zipBuffer(NULL), zipBufferLength(0),
  DRJpegReader()
{
  if(zipFileName) {
#ifdef USE_DATA_FILES
  	if(zipped) {
#endif // USE_DATA_FILES
	    if((fileHandler = unzOpen(zipFileName)) == NULL) {
  	    char fileName[512];
    	  strcat(strcpy(fileName,zipFileName),".zip");
      	if((fileHandler = unzOpen(fileName)) == NULL)
        	Exception::throws("ZIP file not found.");
	    }
#ifdef USE_DATA_FILES
    } else {
    	virtualPath = new char[strlen(zipFileName)+1];
      strcpy(virtualPath,zipFileName);
    }
#endif // USE_DATA_FILES
  }
}

DRZipFile::~DRZipFile() {
#ifdef USE_DATA_FILES
	if(virtualPath)
  	delete virtualPath;
#endif // USE_DATA_FILES
  if(fileHandler)
    unzClose(fileHandler);
}

bool DRZipFile::createZipBuffer(const char* fileName) {
  if(findZippedFile(fileName) && openZippedFile()) {
    zipBufferLength = getZippedFileSize();
    zipBuffer = new unsigned char[zipBufferLength+1];
    readZippedFile();
    zipBuffer[zipBufferLength] = '\0';
    return true;
  }
  return false;
}

void DRZipFile::deleteZipBuffer(bool deleteBuffer) {
  if(zipBuffer) {
    if(deleteBuffer)
      delete zipBuffer;
    zipBuffer = NULL;
    zipBufferLength = 0;
  }
  closeZippedFile();
}

DRData* DRZipFile::getData(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),fileName);
  	DRDataFile file(theFileName);
    return file.getData();
  } else
#endif // USE_DATA_FILES
	if(createZipBuffer(fileName)) {
	  DRData* data = new DRData(zipBufferLength,zipBuffer);
  	deleteZipBuffer(false);
		return data;
  }
  return NULL;
}

DRImage* DRZipFile::getImage(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),fileName);
    return DRImage::getImageFromFile(theFileName);
  } else
#endif // USE_DATA_FILES
  if(strstr(fileName,".jpg")) {
    return getJpegImage(fileName);
  } else if(strstr(fileName,".png")) {
    return getPngImage(fileName);
  } else if(strstr(fileName,".tga")) {
    return getTgaImage(fileName);
  }
  return NULL;
}

GLTexture* DRZipFile::getTexture(
  const char* fileName, bool repeat, bool doMipmaps, int textureDim
) {
  DRImage* img = getImage(fileName);
  if(img) {
    GLTexture* txt = new GLTexture(*img,repeat,doMipmaps,textureDim);
    delete img;
    return txt;
  }
  return NULL;
}

GLAnimatedTexture* DRZipFile::getAnimatedTexture(
  int filesCount, const char** fileNames, float duration, bool repeat,
  bool doMipmaps
) {
  GLAnimatedTexture* txt = new GLAnimatedTexture(filesCount,duration);
  for(int ct = 0; ct < filesCount; ct++) {
    DRImage* img = getImage(fileNames[ct]);
    if(img) {
      txt->addTextureToFrame(ct,*img,repeat,doMipmaps);
      delete img;
    } else {
      delete txt;
      return NULL;
    }
  }
  return txt;
}

#ifndef USE_OGLES

GLCubeMapTexture* DRZipFile::getCubeMapTexture(
  const char** fileNames, bool doMipmaps
) {
  GLCubeMapTexture* txt = new GLCubeMapTexture();
  for(int ct = 0; ct < 6; ct++) {
    DRImage* img = getImage(fileNames[ct]);
    if(img) {
      txt->addTextureToDirection(ct,*img,doMipmaps);
      delete img;
    } else {
      delete txt;
      return NULL;
    }
  }
  return txt;
}

#endif // !USE_OGLES

#ifdef USE_EMBOSS

GLBumpedTexture* DRZipFile::getBumpedTexture(
  const char* fileName, bool repeat
) {
  DRImage* img = getImage(fileName);
  if(img) {
    GLBumpedTexture* txt = new GLBumpedTexture(*img,repeat);
    delete img;
    return txt;
  }
  return NULL;
}

#endif // USE_EMBOSS

DRJpegImage* DRZipFile::getJpegImage(
  const char* fileName, int alphaColor, int tolerance
) {
  if(!findZippedFile(fileName))
    return NULL;
  my_source_mgr_zip src;
  src.zipFile = this;
  src.zippedFileName = fileName;
  return DRJpegReader::readImage(
    &cinfo,&src.pub,
    init_source_zip,fill_input_buffer_zip,
    skip_input_data_zip,term_source_zip,
    alphaColor,tolerance
  );
}

DRPngImage* DRZipFile::getPngImage(const char* fileName) {
  if(createZipBuffer(fileName)) {
    setReadPointer(zipBuffer);
    DRPngImage* pi;
    try {
      pi = DRPngReader::readImage();
    } catch(Exception& e) {
      pi = NULL;
    }
    deleteZipBuffer();
    return pi;
  }
  return NULL;
}

DRTgaImage* DRZipFile::getTgaImage(const char* fileName) {
  DRData* data = getData(fileName);
  if(data) {
    DRTgaReader reader;
    DRTgaImage* img = reader.readImage(data);
    delete data;
    return img;
  }
  return NULL;
}

GLObjects* DRZipFile::getMeshes(
	const char* fileName, DRMeshReader::MeshType meshType
) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	DRMeshFile file(fileName,virtualPath);
    return file.getMeshes(meshType);
  } else
#endif // USE_DATA_FILES
	{
		DRMeshReader::MeshFormat fmt;
  	if(strstr(fileName,".3ds"))
	  	fmt = DRMeshReader::FMT_3DS;
  	else if(strstr(fileName,".obj"))
  		fmt = DRMeshReader::FMT_OBJ;
	  else
  		return NULL;
		if(createZipBuffer(fileName)) {
  		unsigned char* theZipBuffer = getZipBuffer();
  		DRMeshReader reader(this);
	    deleteZipBuffer(false);
  	  GLObjects* meshes = reader.readMeshes(fmt,meshType);
    	delete theZipBuffer;
	 	  return meshes;
  	}
  }
  return NULL;
}

GLBasicMesh* DRZipFile::getBasicMesh(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	DRMeshFile file(fileName,virtualPath);
    return file.getBasicMesh();
  } else
#endif // USE_DATA_FILES
	{
		DRMeshReader::MeshFormat fmt;
  	if(strstr(fileName,".3ds"))
  		fmt = DRMeshReader::FMT_3DS;
	  else if(strstr(fileName,".obj"))
  		fmt = DRMeshReader::FMT_OBJ;
	  else
  		return NULL;
	  if(createZipBuffer(fileName)) {
  		unsigned char* theZipBuffer = getZipBuffer();
 	  	DRMeshReader reader(this);
	    deleteZipBuffer(false);
  	 	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_BASIC);
    	delete theZipBuffer;
	    if(meshes) {
		 	  GLBasicMesh* mesh =
  		 	  dynamic_cast<GLBasicMesh*>(meshes->getFirstObject())->clone();
    		delete meshes;
		 	  return mesh;
  	  }
    }
  }
  return NULL;
}

GLMesh* DRZipFile::getShaderMesh(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	DRMeshFile file(fileName,virtualPath);
    return file.getShaderMesh();
  } else
#endif // USE_DATA_FILES
	{
		DRMeshReader::MeshFormat fmt;
  	if(strstr(fileName,".3ds"))
  		fmt = DRMeshReader::FMT_3DS;
	  else if(strstr(fileName,".obj"))
  		fmt = DRMeshReader::FMT_OBJ;
	  else
  		return NULL;
	  if(createZipBuffer(fileName)) {
  		unsigned char* theZipBuffer = getZipBuffer();
 	  	DRMeshReader reader(this);
	    deleteZipBuffer(false);
  	 	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_SHADER);
    	delete theZipBuffer;
	    if(meshes) {
		 	  GLMesh* mesh =
  		 	  dynamic_cast<GLMesh*>(meshes->getFirstObject())->clone();
    		delete meshes;
		 	  return mesh;
  	  }
    }
  }
  return NULL;
}

GLMesh* DRZipFile::getMesh(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	DRMeshFile file(fileName,virtualPath);
    return file.getMesh();
  } else
#endif // USE_DATA_FILES
	{
		DRMeshReader::MeshFormat fmt;
  	if(strstr(fileName,".3ds"))
  		fmt = DRMeshReader::FMT_3DS;
	  else if(strstr(fileName,".obj"))
  		fmt = DRMeshReader::FMT_OBJ;
	  else
  		return NULL;
	  if(createZipBuffer(fileName)) {
  		unsigned char* theZipBuffer = getZipBuffer();
 	  	DRMeshReader reader(this);
	    deleteZipBuffer(false);
  	 	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_NORMAL);
    	delete theZipBuffer;
	    if(meshes) {
		 	  GLMesh* mesh = dynamic_cast<GLMesh*>(fmt,meshes->getFirstObject())->clone();
  		 	delete meshes;
    		return mesh;
	    }
    }
 	}
  return NULL;
}

#ifdef USE_EMBOSS

GLBumpedMesh* DRZipFile::getBumpedMesh(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	DRMeshFile file(fileName,virtualPath);
    return file.getBumpedMesh();
  } else
#endif // USE_DATA_FILES
	{
		DRMeshReader::MeshFormat fmt;
  	if(strstr(fileName,".3ds"))
  		fmt = DRMeshReader::FMT_3DS;
	  else if(strstr(fileName,".obj"))
  		fmt = DRMeshReader::FMT_OBJ;
	  else
  		return NULL;
	  if(createZipBuffer(fileName)) {
  		unsigned char* theZipBuffer = getZipBuffer();
 	  	DRMeshReader reader(this);
	    deleteZipBuffer(false);
  	 	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_BUMPED);
    	delete theZipBuffer;
	    if(meshes) {
		 	  GLBumpedMesh* mesh =
  		 	  dynamic_cast<GLBumpedMesh*>(meshes->getFirstObject())->clone();
	    	delete meshes;
		 	  return mesh;
    	}
    }
  }
  return NULL;
}

#endif // USE_EMBOSS

bool DRZipFile::loadBasicModel(
  GLBasicModel* model, const char* md2Name, const char* imgName,
  const char* alphaImgName
) {
  if(strstr(md2Name,".md2") == NULL)
    return false;
  if(createZipBuffer(md2Name)) {
    unsigned char* modelZipBuffer = zipBuffer;
    MD2ModelHeader* header = (MD2ModelHeader*)modelZipBuffer;
    if((header->ident == *(int*)&"IDP2") && (header->version == 8)) {
      int framesCount  = header->num_frames;
      int vertexesCount = header->num_xyz;
      int commandsCount = header->num_glcmds;
      model->bone = new GLMD2Bone();
      model->bone->acquireReference();
      model->bone->framesCount = framesCount;
      GLMD2AnimatedShape& shape = model->bone->animatedShape;
      shape.vertexesCount = vertexesCount;
      shape.commands = new int[commandsCount];
      shape.vertex = new MD2FinalVertex[vertexesCount*framesCount];
      unsigned char* commands = modelZipBuffer+header->ofs_glcmds;
      memcpy(shape.commands,commands,commandsCount*sizeof(int));
      unsigned char* frameBuffer = modelZipBuffer+header->ofs_frames;
      for(int frameCt = 0; frameCt < framesCount; frameCt++) {
        MD2Frame* frame = (MD2Frame*)&frameBuffer[header->framesize*frameCt];
        int offset = frameCt*vertexesCount;
        for(int vertCt = 0; vertCt < vertexesCount; vertCt++) {
          shape.vertex[offset+vertCt].coord[0] = (signed short)(128*
            (frame->verts[vertCt].v[0]*frame->scale[0]+frame->translate[0]));
          shape.vertex[offset+vertCt].coord[1] = (signed short)(128*
            (frame->verts[vertCt].v[1]*frame->scale[1]+frame->translate[1]));
          shape.vertex[offset+vertCt].coord[2] = (signed short)(128*
            (frame->verts[vertCt].v[2]*frame->scale[2]+frame->translate[2]));
          shape.vertex[offset+vertCt].normal = (unsigned char)
            frame->verts[vertCt].lightnormalindex;
        }
      }
    }
    model->computeMaxRadius();
    deleteZipBuffer();
    if(imgName && isalpha(imgName[0])) {
      DRImage* image = getImage(imgName);
      if(alphaImgName) {
        DRImage* alphaImage = getImage(alphaImgName);
        image->addAlpha(*alphaImage);
        delete alphaImage;
        model->setTransparent(true);
      }
      GLMaterial* material = new GLMaterial();
      material->setDiffuseTexture(new GLTexture(*image));
      material->setShininess(64);
      delete image;
      model->setBasicMaterial(material);
    }
    return true;
  }
  return false;
}

bool DRZipFile::loadModel(
  GLModel* model, const char* md3Name, const char* imgName,
  const char* alphaImgName
) {
  if(createZipBuffer(md3Name)) {
    unsigned char* modelZipBuffer = zipBuffer;
    if(strstr(md3Name,".md3")) {
      MD3ModelHeader* header = (MD3ModelHeader*)modelZipBuffer;
      modelZipBuffer += sizeof(MD3ModelHeader);
      if((strncmp(header->id,"IDP3",4) == 0) && (header->version == 15)) {
        model->bone = new GLBone();
        model->bone->acquireReference();
        model->bone->framesCount = header->numBoneFrames;
        if(model->bone->framesCount == 1)
          model->currFrame = model->nextFrame = 0;
        modelZipBuffer += sizeof(MD3BoneFrame)*header->numBoneFrames;
        model->bone->linksCount = header->numTags;
        model->bone->linkNames = new char*[model->bone->linksCount];
        model->bone->transformsCount = header->numBoneFrames*header->numTags;
        model->bone->transforms =
          new MD3Transform[model->bone->transformsCount];
        MD3Tag* tags = (MD3Tag*)modelZipBuffer;
        modelZipBuffer += sizeof(MD3Tag)*model->bone->transformsCount;
        for(int ct = 0; ct < model->bone->linksCount; ct++) {
          model->bone->linkNames[ct] = new char[strlen(tags[ct].name)+1];
          strcpy(model->bone->linkNames[ct],tags[ct].name);
        }
        for(int ct = 0; ct < model->bone->transformsCount; ct++)
          model->bone->transforms[ct] = tags[ct].transform;
        model->links = new GLObject*[header->numTags];
        for(int ct = 0; ct < header->numTags; ct++) {
          model->links[ct] = NULL;
					float* r = model->bone->transforms[ct].rotation.matrix;
			    float val = r[0]*r[0]+r[3]*r[3]+r[6]*r[6];
					const float EPS = 0.0001f;
			    if((val > 1+EPS) || (val < 1-EPS)) {
				   	val = 1/sqrt(val);
						for(
            	int ct2 = 0;
              ct2 < model->bone->transformsCount;
              ct2 += header->numTags
            ) {
							r = model->bone->transforms[ct+ct2].rotation.matrix;
				     	r[0] *= val; r[1] *= val; r[2] *= val;
				     	r[3] *= val; r[4] *= val; r[5] *= val;
				     	r[6] *= val; r[7] *= val; r[8] *= val;
				    }
          }
        }
        model->bone->shapesCount = header->numMeshes;
        model->bone->shapes = new GLAnimatedShape[model->bone->shapesCount];
        unsigned char* meshOffsetInZip = modelZipBuffer;
        for(int ct = 0; ct < header->numMeshes; ct++) {
          int len;
          modelZipBuffer = meshOffsetInZip;
          MD3MeshHeader* meshHeader = (MD3MeshHeader*)modelZipBuffer;
          modelZipBuffer += sizeof(MD3MeshHeader);
          model->bone->shapes[ct].trianglesCount = meshHeader->numTriangles;
          model->bone->shapes[ct].vertexesCount = meshHeader->numVertexes;
          // modelZipBuffer += sizeof(MD3Skin)*meshHeader->numSkins;
          modelZipBuffer = meshOffsetInZip+meshHeader->triStart;
          len = meshHeader->numTriangles;
          model->bone->shapes[ct].triangle = new MD3Triangle[len];
#ifdef USE_OGLES
          struct IntTri {int vertex[3];};
          IntTri *intTri = (IntTri*)modelZipBuffer;
          MD3Triangle* md3Tri = model->bone->shapes[ct].triangle;
          for(int idx = 0; idx < len; idx++) {
            md3Tri[idx].vertex[0] = short(intTri[idx].vertex[0]);
            md3Tri[idx].vertex[1] = short(intTri[idx].vertex[1]);
            md3Tri[idx].vertex[2] = short(intTri[idx].vertex[2]);
          }
#else // !USE_OGLES
          memcpy(
            model->bone->shapes[ct].triangle,
            modelZipBuffer,sizeof(MD3Triangle)*len
          );
#endif // !USE_OGLES
          // modelZipBuffer += sizeof(MD3Triangle)*len;
          modelZipBuffer = meshOffsetInZip+meshHeader->texVectorStart;
          len = meshHeader->numVertexes;
          model->bone->shapes[ct].texCoord = new MD3TexCoord[len];
          memcpy(
            model->bone->shapes[ct].texCoord,
            modelZipBuffer,sizeof(MD3TexCoord)*len
          );
          for(int texCoo = 0; texCoo < len; texCoo++) {
            float t = model->bone->shapes[ct].texCoord[texCoo].coord[1];
            model->bone->shapes[ct].texCoord[texCoo].coord[1] = 1-t;
          }
          // modelZipBuffer += sizeof(MD3TexCoord)*len;
          modelZipBuffer = meshOffsetInZip+meshHeader->vertexStart;
          len = meshHeader->numVertexes*meshHeader->numMeshFrames;
          model->bone->shapes[ct].vertex = new MD3Vertex[len];
          memcpy(
            model->bone->shapes[ct].vertex,modelZipBuffer,sizeof(MD3Vertex)*len
          );
          // modelZipBuffer += sizeof(MD3Vertex)*len;
          meshOffsetInZip += meshHeader->meshSize;
        }
      }
    } else if(strstr(md3Name,".mdx")) {
      int numBoneFrames = *(int*)modelZipBuffer;
      modelZipBuffer += sizeof(int);
      int numTags = *(int*)modelZipBuffer;
      modelZipBuffer += sizeof(int);
      int numMeshes = *(int*)modelZipBuffer;
      modelZipBuffer += sizeof(int);
      model->bone = new GLBone();
      model->bone->acquireReference();
      model->bone->framesCount = numBoneFrames;
      if(model->bone->framesCount == 1)
        model->currFrame = model->nextFrame = 0;
      model->bone->linksCount = numTags;
      model->bone->linkNames = new char*[numTags];
      int numAnimations = *(int*)modelZipBuffer;
      modelZipBuffer += sizeof(int);
      model->bone->animationsCount = numAnimations;
      model->bone->animations = new GLAnimationData[numAnimations];
      for(int ct = 0; ct < numAnimations; ct++) {
        int first = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        int last = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        int back = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        int fps = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        model->bone->animations[ct].firstFrame = first;
        model->bone->animations[ct].lastFrame = last;
        model->bone->animations[ct].backFrames = back;
        model->bone->animations[ct].fps = fps;
        model->bone->animations[ct].invFPS = fps == 0? 1: 1.0f/fps;
      }
      model->bone->transformsCount = numBoneFrames*numTags;
      model->bone->transforms = new MD3Transform[model->bone->transformsCount];
      for(int ct = 0; ct < model->bone->linksCount; ct++) {
        char* tagName = (char*)modelZipBuffer;
        model->bone->linkNames[ct] = new char[strlen(tagName)+1];
        strcpy(model->bone->linkNames[ct],tagName);
        modelZipBuffer += 16;
      }
      MD3Transform* transform = (MD3Transform*)modelZipBuffer;
      modelZipBuffer += sizeof(MD3Transform)*model->bone->transformsCount;
      for(int ct = 0; ct < model->bone->transformsCount; ct++)
        model->bone->transforms[ct] = transform[ct];
      model->links = new GLObject*[numTags];
      for(int ct = 0; ct < numTags; ct++) {
        model->links[ct] = NULL;
				float* r = model->bone->transforms[ct].rotation.matrix;
		    float val = r[0]*r[0]+r[3]*r[3]+r[6]*r[6];
				const float EPS = 0.0001f;
		    if((val > 1+EPS) || (val < 1-EPS)) {
			   	val = 1/sqrt(val);
					for(
           	int ct2 = 0;
             ct2 < model->bone->transformsCount;
             ct2 += numTags
          ) {
						r = model->bone->transforms[ct+ct2].rotation.matrix;
			     	r[0] *= val; r[1] *= val; r[2] *= val;
			     	r[3] *= val; r[4] *= val; r[5] *= val;
			     	r[6] *= val; r[7] *= val; r[8] *= val;
			    }
	      }
      }
      model->bone->shapesCount = numMeshes;
      model->bone->shapes = new GLAnimatedShape[model->bone->shapesCount];
      for(int ct = 0; ct < numMeshes; ct++) {
        int numMeshFrames = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        int numTriangles = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        int numVertexes = *(int*)modelZipBuffer;
        modelZipBuffer += sizeof(int);
        model->bone->shapes[ct].trianglesCount = numTriangles;
        model->bone->shapes[ct].vertexesCount = numVertexes;
        model->bone->shapes[ct].triangle = new MD3Triangle[numTriangles];
        MD3Triangle* triangles = (MD3Triangle*)modelZipBuffer;
        modelZipBuffer += sizeof(MD3Triangle)*numTriangles;
        for(int triCt = 0; triCt < numTriangles; triCt++)
          model->bone->shapes[ct].triangle[triCt] = triangles[triCt];
        model->bone->shapes[ct].texCoord = new MD3TexCoord[numVertexes];
        MD3TexCoord* texCoords = (MD3TexCoord*)modelZipBuffer;
        modelZipBuffer += sizeof(MD3TexCoord)*numVertexes;
        for(int vertCt = 0; vertCt < numVertexes; vertCt++)
          model->bone->shapes[ct].texCoord[vertCt] = texCoords[vertCt];
        int len = numVertexes*numMeshFrames;
        model->bone->shapes[ct].vertex = new MD3Vertex[len];
        MD3Vertex* vertexes = (MD3Vertex*)modelZipBuffer;
        modelZipBuffer += sizeof(MD3Vertex)*len;
        for(int vertCt = 0; vertCt < len; vertCt++)
          model->bone->shapes[ct].vertex[vertCt] = vertexes[vertCt];
      }
    } else {
      deleteZipBuffer();
      return false;
    }
    model->computeMaxRadius();
    deleteZipBuffer();
    if(imgName && isalpha(imgName[0])) {
      DRImage* image = getImage(imgName);
      if(alphaImgName) {
        DRImage* alphaImage = getImage(alphaImgName);
        image->addAlpha(*alphaImage);
        delete alphaImage;
        model->setTransparent(true);
      }
      GLMaterial* material = new GLMaterial();
      material->setDiffuseTexture(new GLTexture(*image));
      material->setShininess(64);
      delete image;
      model->setMaterial(material);
    }
    return true;
  }
  return false;
}

GLBasicModel* DRZipFile::getBasicModel(
  const char* md2Name, const char* imgName, const char* alphaImgName
) {
  GLBasicModel* model = new GLBasicModel();
#ifdef USE_DATA_FILES
	if(virtualPath) {
		if(model->load(virtualPath,md2Name,imgName,alphaImgName))
    	return model;
  } else
#endif // USE_DATA_FILES
	  if(loadBasicModel(model,md2Name,imgName,alphaImgName))
  	  return model;
  delete model;
  return NULL;
}

GLModel* DRZipFile::getModel(
  const char* md3Name, const char* imgName, const char* alphaImgName,
  bool ownsCache
) {
  GLModel* model = new GLModel(ownsCache);
#ifdef USE_DATA_FILES
	if(virtualPath) {
		if(model->load(virtualPath,md3Name,imgName,alphaImgName))
    	return model;
  } else
#endif // USE_DATA_FILES
	  if(loadModel(model,md3Name,imgName,alphaImgName))
  	  return model;
  delete model;
  return NULL;
}

#ifdef USE_CAL3D

GLAdvancedModel* DRZipFile::getAdvancedModel(
  const char* modelName, bool useHW
) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),modelName);
    GLAdvancedCoreModel* coreModel = new GLAdvancedCoreModel();
    if(coreModel->load(theFileName)) {
	    GLAdvancedModel* model = new GLAdvancedModel(*coreModel,useHW);
  	  return model;
    }
    delete coreModel;
  } else
#endif // USE_DATA_FILES
 	if(createZipBuffer(modelName)) {
    GLAdvancedCoreModel* coreModel = new GLAdvancedCoreModel();
    char* cfgZipBuffer = (char*)zipBuffer;
    int cfgZipBufferLength = zipBufferLength;
    deleteZipBuffer(false);
    std::istrstream fileBuffer((const char*)cfgZipBuffer,cfgZipBufferLength);
    bool ret = true;
    for(; ret;) {
      std::string strBuffer;
      std::getline(fileBuffer,strBuffer);
      if(fileBuffer.eof())
        break;
      std::string::size_type pos;
      pos = strBuffer.find_first_not_of(" \t");
      if(
        (pos == std::string::npos) || (strBuffer[pos] == '\n') ||
        (strBuffer[pos] == '\r') || (strBuffer[pos] == 0)
      ) continue;
      if(strBuffer[pos] == '#')
        continue;
      std::string strKey;
      strKey = strBuffer.substr(pos, strBuffer.find_first_of(" =\t\n\r", pos) - pos);
      pos += strKey.size();
      pos = strBuffer.find_first_not_of(" \t", pos);
      if((pos == std::string::npos) || (strBuffer[pos] != '=')) {
        ret = false;
        break;
      }
      pos = strBuffer.find_first_not_of(" \t", pos + 1);
      std::string strData;
      strData = strBuffer.substr(pos, strBuffer.find_first_of("\n\r", pos) - pos);
      if(strKey == "skeleton") {
        if(createZipBuffer(strData.c_str())) {
          CalCoreSkeleton* coreSkeleton = CalLoader::loadCoreSkeleton(zipBuffer);
          deleteZipBuffer();
          if(coreSkeleton)
            coreModel->setCoreSkeleton(coreSkeleton);
          else
            ret = false;
        } else
          ret = false;
      } else if(strKey == "animation") {
        if(createZipBuffer(strData.c_str())) {
          CalCoreAnimation* coreAnimation = CalLoader::loadCoreAnimation(zipBuffer);
          deleteZipBuffer();
          if(coreAnimation)
            coreModel->addCoreAnimation(coreAnimation);
          else
            ret = false;
        } else
          ret = false;
      } else if(strKey == "mesh") {
        if(createZipBuffer(strData.c_str())) {
          CalCoreMesh* coreMesh = CalLoader::loadCoreMesh(zipBuffer);
          deleteZipBuffer();
          if(coreMesh)
            coreModel->addCoreMesh(coreMesh);
          else
            ret = false;
        } else
          ret = false;
      } else if(strKey == "material") {
        if(createZipBuffer(strData.c_str())) {
          CalCoreMaterial* coreMaterial = CalLoader::loadCoreMaterial(zipBuffer);
          deleteZipBuffer();
          if(coreMaterial)
            coreModel->addCoreMaterial(coreMaterial);
          else
            ret = false;
        } else
          ret = false;
      }
    }
    delete cfgZipBuffer;
    if(ret) {
      for(int mat = 0; mat < coreModel->getCoreMaterialCount(); mat++) {
        coreModel->createCoreMaterialThread(mat);
        coreModel->setCoreMaterialId(mat,0,mat);
        CalCoreMaterial *coreMaterial = coreModel->getCoreMaterial(mat);
        for(int map = 0; map < coreMaterial->getMapCount(); map++) {
          std::string strFilename = coreMaterial->getMapFilename(map);
          GLTexture* tex = getTexture(strFilename.c_str(),true);
          if(tex) {
            coreMaterial->setMapUserData(map,(Cal::UserData)tex);
            coreModel->addTexture(tex->acquireReference());
          }
        }
      }
      for(int meshId = 0; meshId < coreModel->getCoreMeshCount(); meshId++) {
        CalCoreMesh *mesh = coreModel->getCoreMesh(meshId);
        for(int subMeshId = 0; subMeshId < mesh->getCoreSubmeshCount(); subMeshId++) {
          CalCoreSubmesh *subMesh = mesh->getCoreSubmesh(subMeshId);
          std::vector<std::vector<CalCoreSubmesh::TextureCoordinate> >& texCoords =
            subMesh->getVectorVectorTextureCoordinate();
          for(int texId = 0; texId < texCoords.size(); texId++) {
            std::vector<CalCoreSubmesh::TextureCoordinate>& texCoord = texCoords[texId];
            for(int cooId = 0; cooId < texCoord.size(); cooId++) {
              CalCoreSubmesh::TextureCoordinate& coord = texCoord[cooId];
              coord.v = 1-coord.v;
            }
          }
        }
      }
      GLAdvancedModel* model = new GLAdvancedModel(*coreModel,useHW);
      return model;
    } else {
    	delete coreModel;
    }
  }
  return NULL;
}

#endif // USE_CAL3D

GLBot* DRZipFile::getBot(const char* modelName, bool ownsCaches) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	GLBot* bot = new GLBot(ownsCaches);
    if(bot->loadBot(virtualPath,modelName,ownsCaches))
    	return bot;
  } else
#endif // USE_DATA_FILES
  if(createZipBuffer(modelName)) {
    char* botZipBuffer = (char*)zipBuffer;
    int botZipBufferLength = zipBufferLength;
    deleteZipBuffer(false);
    const char* SEP = " \t,\r";
    char* readLine = botZipBuffer;
    char* nextLine = strchr(readLine,'\n')+1;
    GLBot* bot = new GLBot(ownsCaches);
    bool IS_MOD;
    int BOTH_ANIMS;
    int UPPER_ANIMS;
    int LOWER_ANIMS;
    if(strncmp(readLine,"MOD ",4) == 0) {
    	IS_MOD = true;
      char* tok;
      strtok(readLine,SEP);
      tok = strtok(NULL,SEP);
      BOTH_ANIMS = atoi(tok);
      tok = strtok(NULL,SEP);
      int UP_ANIMS = atoi(tok);
      tok = strtok(NULL,SEP);
      int LO_ANIMS = atoi(tok);
	    UPPER_ANIMS = BOTH_ANIMS+UP_ANIMS;
    	LOWER_ANIMS = BOTH_ANIMS+LO_ANIMS;
      readLine = nextLine;
	    nextLine = strchr(nextLine,'\n')+1;
    } else {
    	IS_MOD = false;
      BOTH_ANIMS  = GLBot::MAX_BOTH_ANIMATIONS;
  	  UPPER_ANIMS = GLBot::MAX_UPPER_ANIMATIONS;
	    LOWER_ANIMS = GLBot::MAX_LOWER_ANIMATIONS;
    }
    GLBasicMaterial* mat;
    char *md3Name, *imgName;
    md3Name = strtok(readLine,SEP);
    imgName = strtok(NULL,SEP);
    loadModel(bot,md3Name,imgName);
    mat = bot->getBasicMaterial();
    md3Name = strtok(NULL,SEP);
    imgName = strtok(NULL,SEP);
    bool isMD3 = (bool)strstr(md3Name,".md3");
    GLModel* upper = getModel(md3Name,imgName,NULL,ownsCaches);
    bot->setUpper(upper);
    if(imgName[0] == '*')
      upper->setBasicMaterial(mat);
    mat = upper->getBasicMaterial();
    md3Name = strtok(NULL,SEP);
    imgName = strtok(NULL,SEP);
    GLModel* head = getModel(md3Name,imgName,NULL,ownsCaches);
    if(imgName[0] == '*')
      head->setBasicMaterial(mat);
    bot->setHead(head);
    bot->setMaxRadius(
      bot->getMaxRadius()+upper->getMaxRadius()+head->getMaxRadius()
    );
    if(isMD3) {
      GLAnimationData* lowerAnimation =
        new GLAnimationData[LOWER_ANIMS];
      GLAnimationData* upperAnimation =
        new GLAnimationData[UPPER_ANIMS];
      int ct = 0;
      while(ct < BOTH_ANIMS) {
        readLine = nextLine;
        nextLine = strchr(readLine,'\n')+1;
        int first = atoi(strtok(readLine,SEP));
        lowerAnimation[ct].firstFrame = upperAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        lowerAnimation[ct].lastFrame = upperAnimation[ct].lastFrame =
          next < 0? -(first-next-1): (first+next-1);
        lowerAnimation[ct].backFrames = upperAnimation[ct].backFrames =
          atoi(strtok(NULL,SEP));
        if(lowerAnimation[ct].backFrames != 0) {
          lowerAnimation[ct].backFrames--;
          upperAnimation[ct].backFrames--;
        }
        char *val = strtok(NULL,SEP);
        lowerAnimation[ct].fps = upperAnimation[ct].fps = val? atoi(val): 1;
        lowerAnimation[ct].invFPS = upperAnimation[ct].invFPS =
          1.0f/upperAnimation[ct].fps;
        ct++;
      }
      while(ct < UPPER_ANIMS) {
        readLine = nextLine;
        nextLine = strchr(readLine,'\n')+1;
        int first = atoi(strtok(readLine,SEP));
        upperAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        upperAnimation[ct].lastFrame = next < 0? -(first-next-1): (first+next-1);
        upperAnimation[ct].backFrames = atoi(strtok(NULL,SEP));
        if(upperAnimation[ct].backFrames != 0)
          upperAnimation[ct].backFrames--;
        char *val = strtok(NULL,SEP);
        upperAnimation[ct].fps = val? atoi(val): 1;
        upperAnimation[ct].invFPS = 1.0f/upperAnimation[ct].fps;
        ct++;
      }
      ct = BOTH_ANIMS;
      while(ct < LOWER_ANIMS) {
        readLine = nextLine;
        nextLine = strchr(readLine,'\n')+1;
        int first = atoi(strtok(readLine,SEP));
        lowerAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        lowerAnimation[ct].lastFrame = next < 0? -(first-next-1): (first+next-1);
        lowerAnimation[ct].backFrames = atoi(strtok(NULL,SEP));
        if(lowerAnimation[ct].backFrames != 0)
          lowerAnimation[ct].backFrames--;
        char *val = strtok(NULL,SEP);
        lowerAnimation[ct].fps = val? atoi(val): 1;
        lowerAnimation[ct].invFPS = 1.0f/lowerAnimation[ct].fps;
        ct++;
      }
      if(!IS_MOD) {
	      int skip =
  	      lowerAnimation[BOTH_ANIMS].firstFrame-
    	    upperAnimation[BOTH_ANIMS].firstFrame;
      	for(int ct = BOTH_ANIMS; ct < LOWER_ANIMS; ct++) {
  	      lowerAnimation[ct].firstFrame -= skip;
    	    lowerAnimation[ct].lastFrame -= skip;
      	}
      }
      bot->setAnimations(LOWER_ANIMS,lowerAnimation);
      upper->setAnimations(UPPER_ANIMS,upperAnimation);
      if(!IS_MOD) {
	      bot->setLowerAnimation(GLBot::LEGS_IDLE);
  	    bot->setUpperAnimation(GLBot::TORSO_STAND);
      } else {
	      bot->setLowerAnimation(0);
  	    bot->setUpperAnimation(0);
      }
    }
    delete botZipBuffer;
    bot->link("tag_torso",upper);
    upper->link("tag_head",head);
    return bot;
  }
  return NULL;
}

#ifdef USE_BSP

static void getPosition(BSPVector& pos, char* entity) {
  char* value = strstr(entity,"\"origin\"")+10;
  char* mark = strchr(value,' ');
  *mark = '\0';
  pos.x = atoi(value);
  value = mark+1;
  mark = strchr(value,' ');
  *mark = '\0';
  pos.z = -atoi(value);
  value = mark+1;
  mark = strchr(value,'\"');
  *mark = '\0';
  pos.y = atoi(value);
}

GLBsp* DRZipFile::getLevel(
  const char* levelName, float gamma, DRZipFile* texturesZip
) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char fileName[MAX_PATH];
    strcat(strcpy(fileName,virtualPath),levelName);
    GLBsp* bsp = new GLBsp();
    if(bsp->load(NULL,fileName,gamma))
    	return bsp;
    delete bsp;
  } else
#endif // USE_DATA_FILES
  if(createZipBuffer(levelName)) {
    char* bspZipBuffer = (char*)zipBuffer;
    char* bspZipPointer = (char*)bspZipBuffer;
    deleteZipBuffer(false);
    GLBsp* bsp = new GLBsp();
    if(strstr(levelName,".bsp")) {
  	  bspZipPointer += sizeof(BSPHeader);
  	  BSPLump* lumps = (BSPLump*)bspZipPointer;
	  bspZipPointer = bspZipBuffer+lumps[BSPLump::ENTITIES_LUMP].offset;
      char* entities = (char*)bspZipPointer;
      char* entity = strtok(entities,"}");
      do {
        BSPVector bspPos;
        if(strstr(entity,"\"info_player_deathmatch\"")) {
          getPosition(bspPos,entity);
          bsp->startingPositions.addElement(bspPos);
        } else if(strstr(entity,"\"item_health\"")) {
          getPosition(bspPos,entity);
          bsp->medikitPositions.addElement(bspPos);
        } else if(strstr(entity,"\"item_regen\"")) {
          getPosition(bspPos,entity);
          bsp->foodPositions.addElement(bspPos);
        } else if(strstr(entity,"\"item_armor_body\"")) {
          getPosition(bspPos,entity);
          bsp->armorPositions.addElement(bspPos);
        } else if(strstr(entity,"\"ammo_bullets\"")) {
          getPosition(bspPos,entity);
          bsp->bulletsPositions.addElement(bspPos);
        } else if(strstr(entity,"\"ammo_grenades\"")) {
          getPosition(bspPos,entity);
          bsp->grenadesPositions.addElement(bspPos);
        } else if(strstr(entity,"\"weapon_machinegun\"")) {
          getPosition(bspPos,entity);
          bsp->weaponPositions.addElement(bspPos);
        }
        entity = strtok(NULL,"}");
      } while(entity);
    	bsp->vertexesCount =
        lumps[BSPLump::VERTEXES_LUMP].length/sizeof(BSPFullVertex);
  	  bsp->vertexes = new BSPVertex[bsp->vertexesCount];
	    bspZipPointer = bspZipBuffer+lumps[BSPLump::VERTEXES_LUMP].offset;
  	  for(int ct = 0; ct < bsp->vertexesCount; ct++)	{
        BSPFullVertex* fullVertex = (BSPFullVertex*)bspZipPointer;
	  	  bspZipPointer += sizeof(BSPFullVertex);
  	  	bsp->vertexes[ct].position.x = fullVertex->position.x;
	  	  bsp->vertexes[ct].position.y = fullVertex->position.z;
  		  bsp->vertexes[ct].position.z = -fullVertex->position.y;
    		bsp->vertexes[ct].textureCoord.u = fullVertex->textureCoord.u;
	    	bsp->vertexes[ct].textureCoord.v = -fullVertex->textureCoord.v;
		    bsp->vertexes[ct].lightmapCoord.u = fullVertex->lightmapCoord.u;
    		bsp->vertexes[ct].lightmapCoord.v = fullVertex->lightmapCoord.v;
	    }
	    bsp->meshVertexesCount =
        lumps[BSPLump::MESHVERTEXES_LUMP].length/sizeof(int);
	    bsp->meshVertexes = new int[bsp->meshVertexesCount];
  	  bspZipPointer = bspZipBuffer+lumps[BSPLump::MESHVERTEXES_LUMP].offset;
    	memcpy(bsp->meshVertexes,bspZipPointer,bsp->meshVertexesCount*sizeof(int));
    	int facesCount = lumps[BSPLump::FACES_LUMP].length/sizeof(BSPFace);
      bsp->faces = new DSArray<GLBspFace>(facesCount);
  	  bspZipPointer = bspZipBuffer+lumps[BSPLump::FACES_LUMP].offset;
    	BSPFace* faceData = (BSPFace*)bspZipPointer;
      for(int ct = 0; ct < facesCount; ct++) {
        GLBspFace* theFace = NULL;
        switch(faceData[ct].type) {
          case BSPFace::POLYGON: {
            GLBspPolygon* face = new GLBspPolygon();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            face->firstVertex = faceData[ct].firstVertex;
            face->vertexesCount = faceData[ct].vertexesCount;
            theFace = face;
            break;
          }
          case BSPFace::PATCH: {
            GLBspPatch* face = new GLBspPatch();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            int width = faceData[ct].patchSize[0];
            int height = faceData[ct].patchSize[1];
      	  	int widthCount = (width-1)/2;
    	  	  int heightCount = (height-1)/2;
        		face->patchesCount = widthCount*heightCount;
	    	    face->patches = new GLPatch[face->patchesCount];
        		for(int y = 0; y < heightCount; y++) {
    	    		for(int x = 0; x < widthCount; x++) {
    		    		for(int row = 0; row < 3; row++) {
    			    		for(int col = 0; col < 3; col++) {
    				    		face->patches[y*widthCount+x].controls[row*3+col] =
                      bsp->vertexes[
                        faceData[ct].firstVertex +
                        (y * 2 * width + x * 2)+
 									      row * width + col
                     ];
        					}
		        		}
    	    			face->patches[y*widthCount+x].tessellate(8);
    		    	}
  		      }
            theFace = face;
            break;
          }
          case BSPFace::MESH: {
            GLBspMesh* face = new GLBspMesh();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            face->firstVertex = faceData[ct].firstVertex;
            face->vertexesCount = faceData[ct].vertexesCount;
            face->firstMeshVertex = faceData[ct].firstMeshVertex;
            face->meshVertexesCount = faceData[ct].meshVertexesCount;
            theFace = face;
            break;
          }
          case BSPFace::BILLBOARD: {
            GLBspBillboard* face = new GLBspBillboard();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            theFace = face;
            break;
          }
        }
        bsp->faces->setElement(ct,theFace);
      }
  	  int texturesCount =
        lumps[BSPLump::TEXTURES_LUMP].length/sizeof(BSPTexture);
      bsp->textures = new DSArray<GLTexture,false>(texturesCount);
      bsp->textureIsHollow.resize(texturesCount);
      bsp->textureHasAlpha.resize(texturesCount);
      bspZipPointer = bspZipBuffer+lumps[BSPLump::TEXTURES_LUMP].offset;
    	BSPTexture* textureData = (BSPTexture*)bspZipPointer;
    	for(int ct = 0; ct < texturesCount; ct++)	{
        const int CONTENTS_SOLID = 0x00000001;
        const int CONTENTS_WINDOW = 0x00000002;
        const int CONTENTS_PLAYERCLIP = 0x00010000;
        const int CONTENTS_MONSTER = 0x02000000;
        const int IS_HOLLOW =
          CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER;
        if(textureData[ct].contents & IS_HOLLOW)
          bsp->textureIsHollow.set(ct);
        DRZipFile* zipFile = texturesZip? texturesZip: this;
        char fileName[MAX_PATH];
        strcat(strcpy(fileName,textureData[ct].name),".jpg");
        DRImage* image ;
        if(zipFile->findZippedFile(fileName)) {
          image = zipFile->getJpegImage(fileName);
        } else {
          strcat(strcpy(fileName,textureData[ct].name),".tga");
          if(zipFile->findZippedFile(fileName)) {
            image = zipFile->getTgaImage(fileName);
          } else {
            strcat(strcpy(fileName,textureData[ct].name),".png");
            if(zipFile->findZippedFile(fileName)) {
              image = zipFile->getPngImage(fileName);
            } else {
              image = NULL;
            }
          }
        }
        if(image) {
	        if(image->getHasAlpha())
  	        bsp->textureHasAlpha.set(ct);
          bsp->textures->setElement(
            ct,(new GLTexture(*image,true))->acquireReference()
          );
          delete image;
        } else {
          bsp->textures->setElement(ct,NULL);
        }
    	}
  	  int lightmapsCount =
        lumps[BSPLump::LIGHTMAPS_LUMP].length/sizeof(BSPLightmap);
      bsp->lightmaps = new DSArray<GLTexture,false>(lightmapsCount);
      bspZipPointer = bspZipBuffer+lumps[BSPLump::LIGHTMAPS_LUMP].offset;
  	  for(int ct = 0; ct < lightmapsCount; ct++) {
	  	  BSPLightmap* lightmapData = (BSPLightmap*)bspZipPointer;
        bspZipPointer += sizeof(BSPLightmap);
        if(gamma != 1)
          DRImage::setGammaCorrection(
            (BSPByte*)lightmapData->imageBits,128,128,gamma
          );
        GLTexture* txt = (new GLTexture(
          (BSPByte*)lightmapData->imageBits,128,128)
        )->acquireReference();
        bsp->lightmaps->setElement(ct,txt);
	    }
  	  bsp->nodesCount = lumps[BSPLump::NODES_LUMP].length/sizeof(BSPNode);
    	bsp->nodes = new BSPNode[bsp->nodesCount];
    	bspZipPointer = bspZipBuffer+lumps[BSPLump::NODES_LUMP].offset;
      memcpy(bsp->nodes,bspZipPointer,bsp->nodesCount*sizeof(BSPNode));
    	bsp->leavesCount = lumps[BSPLump::LEAVES_LUMP].length/sizeof(BSPLeaf);
      bsp->leaves = new BSPLeaf[bsp->leavesCount];
			bsp->leafCameraDists = new float[bsp->leavesCount];
			bsp->leafIndexes = new int[bsp->leavesCount];
	    for(int ct = 0; ct < bsp->leavesCount; ct++)
  	  	bsp->leafIndexes[ct] = ct+1;
      bspZipPointer = bspZipBuffer+lumps[BSPLump::LEAVES_LUMP].offset;
    	memcpy(bsp->leaves,bspZipPointer,bsp->leavesCount*sizeof(BSPLeaf));
    	for(int ct = 0; ct < bsp->leavesCount; ct++)	{
	    	int temp = bsp->leaves[ct].min.y;
		    bsp->leaves[ct].min.y = bsp->leaves[ct].min.z;
    		bsp->leaves[ct].min.z = -temp;
	    	temp = bsp->leaves[ct].max.y;
		    bsp->leaves[ct].max.y = bsp->leaves[ct].max.z;
  		  bsp->leaves[ct].max.z = -temp;
  	  }
    	bsp->leafFacesCount = lumps[BSPLump::LEAFFACES_LUMP].length/sizeof(int);
  	  bsp->leafFaces = new int[bsp->leafFacesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::LEAFFACES_LUMP].offset;
      memcpy(bsp->leafFaces,bspZipPointer,bsp->leafFacesCount*sizeof(int));
  	  bsp->brushesCount = lumps[BSPLump::BRUSHES_LUMP].length/sizeof(BSPBrush);
    	bsp->brushes = new BSPBrush[bsp->brushesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::BRUSHES_LUMP].offset;
      memcpy(bsp->brushes,bspZipPointer,bsp->brushesCount*sizeof(BSPBrush));
    	bsp->brushSidesCount =
        lumps[BSPLump::BRUSHSIDES_LUMP].length/sizeof(BSPBrushSide);
  	  bsp->brushSides = new BSPBrushSide[bsp->brushSidesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::BRUSHSIDES_LUMP].offset;
      memcpy(
        bsp->brushSides,bspZipPointer,bsp->brushSidesCount*sizeof(BSPBrushSide)
      );
	    bsp->leafBrushesCount = lumps[BSPLump::LEAFBRUSHES_LUMP].length/sizeof(int);
	    bsp->leafBrushes = new int[bsp->leafBrushesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::LEAFBRUSHES_LUMP].offset;
      memcpy(bsp->leafBrushes,bspZipPointer,bsp->leafBrushesCount*sizeof(int));
  	  bsp->planesCount = lumps[BSPLump::PLANES_LUMP].length/sizeof(BSPPlane);
    	bsp->planes = new BSPPlane[bsp->planesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::PLANES_LUMP].offset;
      memcpy(bsp->planes,bspZipPointer,bsp->planesCount*sizeof(BSPPlane));
    	for(int ct = 0; ct < bsp->planesCount; ct++)	{
	  	  float temp = bsp->planes[ct].normal.y;
		    bsp->planes[ct].normal.y = bsp->planes[ct].normal.z;
  		  bsp->planes[ct].normal.z = -temp;
  	  }
      bspZipPointer = bspZipBuffer+lumps[BSPLump::MODELS_LUMP].offset;
      memcpy(&bsp->staticModel,bspZipPointer,sizeof(BSPModel));
      bsp->lightVolumesGrid.x =
        int(floor(bsp->staticModel.max[0]/64)-ceil(bsp->staticModel.min[0]/64)+1);
      bsp->lightVolumesInvSizes.x =
        bsp->lightVolumesGrid.x/(bsp->staticModel.max[0]-bsp->staticModel.min[0]);
      bsp->lightVolumesGrid.y =
        int(floor(bsp->staticModel.max[2]/128)-ceil(bsp->staticModel.min[2]/128)+1);
      bsp->lightVolumesInvSizes.y =
        bsp->lightVolumesGrid.y/(bsp->staticModel.max[2]-bsp->staticModel.min[2]);
      bsp->lightVolumesGrid.z =
        int(floor(bsp->staticModel.max[1]/64)-ceil(bsp->staticModel.min[1]/64)+1);
      bsp->lightVolumesInvSizes.z =
        bsp->lightVolumesGrid.z/(bsp->staticModel.max[1]-bsp->staticModel.min[1]);
    	bsp->lightVolumesCount =
        int(lumps[BSPLump::LIGHTVOLUMES_LUMP].length/sizeof(BSPLightVolume));
  	  bsp->lightVolumes = new BSPLightVolume[bsp->lightVolumesCount];
      bspZipPointer = bspZipBuffer+lumps[BSPLump::LIGHTVOLUMES_LUMP].offset;
      memcpy(
        bsp->lightVolumes,bspZipPointer,
        bsp->lightVolumesCount*sizeof(BSPLightVolume)
      );
      for(int ct = 0; ct < bsp->lightVolumesCount; ct++) {
        GLColor::gammaCorrection(bsp->lightVolumes[ct].ambient,gamma);
        GLColor::gammaCorrection(bsp->lightVolumes[ct].directional,gamma);
      }
      bspZipPointer = bspZipBuffer+lumps[BSPLump::VISDATA_LUMP].offset;
    	if(lumps[BSPLump::VISDATA_LUMP].length) {
    		memcpy(&(bsp->clusters.clustersCount),bspZipPointer,sizeof(int));
        bspZipPointer += sizeof(int);
	  	  memcpy(&(bsp->clusters.bytesPerCluster),bspZipPointer,sizeof(int));
        bspZipPointer += sizeof(int);
    		int size = bsp->clusters.clustersCount*bsp->clusters.bytesPerCluster;
  	  	bsp->clusters.bitsets = new BSPByte[size];
        memcpy(bsp->clusters.bitsets,bspZipPointer,size*sizeof(BSPByte));
    	}	else {
        bsp->clusters.bitsets = NULL;
      }
    	bsp->facesDrawn.resize(facesCount);
    } else {
      char imageFileName[MAX_PATH];
      strcpy(imageFileName,levelName);
      char* fileNameExt = strstr(imageFileName,".bsx");
      int counter;
      BSPVector* pos;
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      pos = new BSPVector[counter];
      memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
      bspZipPointer += sizeof(BSPVector)*counter;
      for(int ct = 0; ct < counter; ct++)
        bsp->startingPositions.addElement(pos[ct]);
      delete pos;
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->medikitPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->foodPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->armorPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->bulletsPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->grenadesPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&counter,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(counter) {
        pos = new BSPVector[counter];
        memcpy(pos,bspZipPointer,sizeof(BSPVector)*counter);
        bspZipPointer += sizeof(BSPVector)*counter;
        for(int ct = 0; ct < counter; ct++)
          bsp->weaponPositions.addElement(pos[ct]);
        delete pos;
      }
      memcpy(&bsp->vertexesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(bsp->vertexes) delete bsp->vertexes;
    	bsp->vertexes = new BSPVertex[bsp->vertexesCount];
      memcpy(bsp->vertexes,bspZipPointer,bsp->vertexesCount*sizeof(BSPVertex));
      bspZipPointer += bsp->vertexesCount*sizeof(BSPVertex);
      memcpy(&bsp->meshVertexesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(bsp->meshVertexes) delete bsp->meshVertexes;
    	bsp->meshVertexes = new int[bsp->meshVertexesCount];
      memcpy(bsp->meshVertexes,bspZipPointer,bsp->meshVertexesCount*sizeof(int));
      bspZipPointer += bsp->meshVertexesCount*sizeof(int);
  	  int facesCount;
      memcpy(&facesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      if(bsp->faces) delete bsp->faces;
      bsp->faces = new DSArray<GLBspFace>(facesCount);
  	  BSPFace* faceData = new BSPFace[facesCount];
      memcpy(faceData,bspZipPointer,facesCount*sizeof(BSPFace));
      bspZipPointer += facesCount*sizeof(BSPFace);
      for(int ct = 0; ct < facesCount; ct++) {
        GLBspFace* theFace = NULL;
        switch(faceData[ct].type) {
          case BSPFace::POLYGON: {
            GLBspPolygon* face = new GLBspPolygon();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            face->firstVertex = faceData[ct].firstVertex;
            face->vertexesCount = faceData[ct].vertexesCount;
            theFace = face;
            break;
          }
          case BSPFace::PATCH: {
            GLBspPatch* face = new GLBspPatch();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            int width = faceData[ct].patchSize[0];
            int height = faceData[ct].patchSize[1];
        		int widthCount = (width-1)/2;
      	  	int heightCount = (height-1)/2;
    	  	  face->patchesCount = widthCount*heightCount;
  		      face->patches = new GLPatch[face->patchesCount];
      		  for(int y = 0; y < heightCount; y++) {
        			for(int x = 0; x < widthCount; x++) {
      	  			for(int row = 0; row < 3; row++) {
      		  			for(int col = 0; col < 3; col++) {
    	  		  			face->patches[y*widthCount+x].controls[row*3+col] =
                      bsp->vertexes[
                        faceData[ct].firstVertex +
                        (y * 2 * width + x * 2)+
							  		    row * width + col
                      ];
        					}
	  	      		}
      	  			face->patches[y*widthCount+x].tessellate(8);
    	  	  	}
  		      }
            theFace = face;
            break;
          }
          case BSPFace::MESH: {
            GLBspMesh* face = new GLBspMesh();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            face->firstVertex = faceData[ct].firstVertex;
            face->vertexesCount = faceData[ct].vertexesCount;
            face->firstMeshVertex = faceData[ct].firstMeshVertex;
            face->meshVertexesCount = faceData[ct].meshVertexesCount;
            theFace = face;
            break;
          }
          case BSPFace::BILLBOARD: {
            GLBspBillboard* face = new GLBspBillboard();
            face->textureID = faceData[ct].textureID;
            face->lightmapID = faceData[ct].lightmapID;
            theFace = face;
            break;
          }
        }
        bsp->faces->setElement(ct,theFace);
      }
      delete faceData;
    	int texturesCount;
      memcpy(&texturesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      bsp->textures = new DSArray<GLTexture,false>(texturesCount);
      bsp->textureIsHollow.resize(texturesCount);
      bsp->textureHasAlpha.resize(texturesCount);
    	BSPTexture* textureData = (BSPTexture*)bspZipPointer;
      for(int ct = 0; ct < texturesCount; ct++)	{
        const int CONTENTS_SOLID = 0x00000001;
        const int CONTENTS_WINDOW = 0x00000002;
        const int CONTENTS_PLAYERCLIP = 0x00010000;
        const int CONTENTS_MONSTER = 0x02000000;
        const int IS_HOLLOW =
          CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER;
        if(textureData[ct].contents & IS_HOLLOW)
          bsp->textureIsHollow.set(ct);
        DRZipFile* zipFile = texturesZip? texturesZip: this;
        char fileName[MAX_PATH];
        DRImage* image ;
        strcat(strcpy(fileName,textureData[ct].name),".tga");
        if(zipFile->findZippedFile(fileName)) {
          image = zipFile->getTgaImage(fileName);
        } else {
          strcat(strcpy(fileName,textureData[ct].name),".png");
          if(zipFile->findZippedFile(fileName)) {
            image = zipFile->getPngImage(fileName);
          } else {
            strcat(strcpy(fileName,textureData[ct].name),".jpg");
            if(zipFile->findZippedFile(fileName)) {
              image = zipFile->getJpegImage(fileName);
            } else {
              image = NULL;
            }
          }
        }
        if(image) {
	        if(image->getHasAlpha())
  	        bsp->textureHasAlpha.set(ct);
          bsp->textures->setElement(
            ct,(new GLTexture(*image,true))->acquireReference()
          );
          delete image;
        } else {
          bsp->textures->setElement(ct,NULL);
        }
    	}
      bspZipPointer += texturesCount*sizeof(BSPTexture);
  	  int lightmapsCount;
      memcpy(&lightmapsCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
      bsp->lightmaps = new DSArray<GLTexture,false>(lightmapsCount);
  	  for(int ct = 0; ct < lightmapsCount; ct++) {
        char strCt[6];
        itoa(ct,strCt,10);
        strcat(strcpy(fileNameExt,strCt),".jpg");
        DRImage* image;
        if(findZippedFile(imageFileName)) {
          image = getJpegImage(imageFileName);
        } else {
          strcat(strcpy(fileNameExt,strCt),".tga");
          if(findZippedFile(imageFileName)) {
            image = getTgaImage(imageFileName);
          } else {
            strcat(strcpy(fileNameExt,strCt),".png");
            if(findZippedFile(imageFileName)) {
              image = getPngImage(imageFileName);
            } else {
              image = NULL;
            }
          }
        }
        if(image) {
          image->setGammaCorrection(gamma);
          bsp->lightmaps->setElement(
            ct,(new GLTexture(*image,true))->acquireReference()
          );
          delete image;
        } else {
          bsp->lightmaps->setElement(ct,NULL);
        }
  	  }
      memcpy(&bsp->nodesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
  	  bsp->nodes = new BSPNode[bsp->nodesCount];
      memcpy(bsp->nodes,bspZipPointer,bsp->nodesCount*sizeof(BSPNode));
      bspZipPointer += bsp->nodesCount*sizeof(BSPNode);
      memcpy(&bsp->leavesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
  	  bsp->leaves = new BSPLeaf[bsp->leavesCount];
			bsp->leafCameraDists = new float[bsp->leavesCount];
			bsp->leafIndexes = new int[bsp->leavesCount];
	    for(int ct = 0; ct < bsp->leavesCount; ct++)
  	  	bsp->leafIndexes[ct] = ct+1;
      memcpy(bsp->leaves,bspZipPointer,bsp->leavesCount*sizeof(BSPLeaf));
      bspZipPointer += bsp->leavesCount*sizeof(BSPLeaf);
    	for(int ct = 0; ct < bsp->leavesCount; ct++)	{
	    	int temp = bsp->leaves[ct].min.y;
		    bsp->leaves[ct].min.y = bsp->leaves[ct].min.z;
  		  bsp->leaves[ct].min.z = -temp;
  	  	temp = bsp->leaves[ct].max.y;
	  	  bsp->leaves[ct].max.y = bsp->leaves[ct].max.z;
  	  	bsp->leaves[ct].max.z = -temp;
  	  }
      memcpy(&bsp->leafFacesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
  	  bsp->leafFaces = new int[bsp->leafFacesCount];
      memcpy(bsp->leafFaces,bspZipPointer,bsp->leafFacesCount*sizeof(int));
      bspZipPointer += bsp->leafFacesCount*sizeof(int);
      memcpy(&bsp->brushesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
  	  bsp->brushes = new BSPBrush[bsp->brushesCount];
      memcpy(bsp->brushes,bspZipPointer,bsp->brushesCount*sizeof(BSPBrush));
      bspZipPointer += bsp->brushesCount*sizeof(BSPBrush);
      memcpy(&bsp->brushSidesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
    	bsp->brushSides = new BSPBrushSide[bsp->brushSidesCount];
      memcpy(bsp->brushSides,bspZipPointer,bsp->brushSidesCount*sizeof(BSPBrushSide));
      bspZipPointer += bsp->brushSidesCount*sizeof(BSPBrushSide);
      memcpy(&bsp->leafBrushesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
    	bsp->leafBrushes = new int[bsp->leafBrushesCount];
      memcpy(bsp->leafBrushes,bspZipPointer,bsp->leafBrushesCount*sizeof(int));
      bspZipPointer += bsp->leafBrushesCount*sizeof(int);
      memcpy(&bsp->planesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
    	bsp->planes = new BSPPlane[bsp->planesCount];
      memcpy(bsp->planes,bspZipPointer,bsp->planesCount*sizeof(BSPPlane));
      bspZipPointer += bsp->planesCount*sizeof(BSPPlane);
  	  for(int ct = 0; ct < bsp->planesCount; ct++)	{
	  	  float temp = bsp->planes[ct].normal.y;
  	  	bsp->planes[ct].normal.y = bsp->planes[ct].normal.z;
	  	  bsp->planes[ct].normal.z = -temp;
    	}
      memcpy(&bsp->staticModel,bspZipPointer,sizeof(BSPModel));
      bspZipPointer += sizeof(BSPModel);
      bsp->lightVolumesGrid.x =
        int(floor(bsp->staticModel.max[0]/64)-ceil(bsp->staticModel.min[0]/64)+1);
      bsp->lightVolumesInvSizes.x =
        bsp->lightVolumesGrid.x/(bsp->staticModel.max[0]-bsp->staticModel.min[0]);
      bsp->lightVolumesGrid.y =
        int(floor(bsp->staticModel.max[2]/128)-ceil(bsp->staticModel.min[2]/128)+1);
      bsp->lightVolumesInvSizes.y =
        bsp->lightVolumesGrid.y/(bsp->staticModel.max[2]-bsp->staticModel.min[2]);
      bsp->lightVolumesGrid.z =
        int(floor(bsp->staticModel.max[1]/64)-ceil(bsp->staticModel.min[1]/64)+1);
      bsp->lightVolumesInvSizes.z =
        bsp->lightVolumesGrid.z/(bsp->staticModel.max[1]-bsp->staticModel.min[1]);
      memcpy(&bsp->lightVolumesCount,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
    	bsp->lightVolumes = new BSPLightVolume[bsp->lightVolumesCount];
      memcpy(bsp->lightVolumes,bspZipPointer,bsp->lightVolumesCount*sizeof(BSPLightVolume));
      bspZipPointer += bsp->lightVolumesCount*sizeof(BSPLightVolume);
      for(int ct = 0; ct < bsp->lightVolumesCount; ct++) {
        GLColor::gammaCorrection(bsp->lightVolumes[ct].ambient,gamma);
        GLColor::gammaCorrection(bsp->lightVolumes[ct].directional,gamma);
      }
      int visDataLength;
      memcpy(&visDataLength,bspZipPointer,sizeof(int));
      bspZipPointer += sizeof(int);
    	if(visDataLength) {
    		memcpy(&(bsp->clusters.clustersCount),bspZipPointer,sizeof(int));
        bspZipPointer += sizeof(int);
	  	  memcpy(&(bsp->clusters.bytesPerCluster),bspZipPointer,sizeof(int));
        bspZipPointer += sizeof(int);
    		int size = bsp->clusters.clustersCount*bsp->clusters.bytesPerCluster;
  	  	bsp->clusters.bitsets = new BSPByte[size];
        memcpy(bsp->clusters.bitsets,bspZipPointer,size*sizeof(BSPByte));
    	}	else {
        bsp->clusters.bitsets = NULL;
      }
    	bsp->facesDrawn.resize(facesCount);
    }
    delete bspZipBuffer;
    return bsp;
  }
  return NULL;
}

#endif // USE_BSP

#ifdef USE_OGLES
#else // !USE_OGLES

GLVertexProgram* DRZipFile::getVertexProgram(const char* programName) {
  DRData* data = getData(programName);
  if(data) {
    GLVertexProgram* vp = new GLVertexProgram(data);
    delete data;
    return vp;
  }
  return NULL;
}

GLFragmentProgram* DRZipFile::getFragmentProgram(const char* programName) {
  DRData* data = getData(programName);
  if(data) {
    GLFragmentProgram* fp = new GLFragmentProgram(data);
    delete data;
    return fp;
  }
  return NULL;
}

#endif // !USE_OGLES

#ifdef USE_SOUND

FMSample* DRZipFile::getSoundSample(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),fileName);
  	DRSampleFile file(theFileName);
    return file.getSample();
  } else
#endif // USE_DATA_FILES
  if(createZipBuffer(fileName)) {
    FMSample* ret = new FMSample(zipBufferLength,zipBuffer);
    deleteZipBuffer();
    return ret;
  }
  return NULL;
}

FM3DSample* DRZipFile::get3DSoundSample(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),fileName);
  	DRSampleFile file(theFileName);
    return file.getSample3D();
  } else
#endif // USE_DATA_FILES
  if(createZipBuffer(fileName)) {
    FM3DSample* ret = new FM3DSample(zipBufferLength,zipBuffer);
    deleteZipBuffer();
    return ret;
  }
  return NULL;
}

#ifdef USE_MUSIC

FMMusic* DRZipFile::getMusic(const char* fileName) {
#ifdef USE_DATA_FILES
	if(virtualPath) {
  	char theFileName[MAX_PATH];
    strcat(strcpy(theFileName,virtualPath),fileName);
  	DRMusicFile file(theFileName);
    return file.getMusic();
  } else
#endif // USE_DATA_FILES
  if(createZipBuffer(fileName)) {
    FMMusic* ret = new FMMusic(zipBufferLength,zipBuffer);
    deleteZipBuffer();
    return ret;
  }
  return NULL;
}

#endif // USE_MUSIC

#endif // USE_SOUND

#ifndef __linux__

//
// DRPngResource
//
DRPngResource::DRPngResource(int id) throw(ExceptionThrown): DRResource(id) {
}

DRPngImage* DRPngResource::getImage() {
  setReadPointer(getPointer());
  DRPngImage* pi;
  try {
    pi = DRPngReader::readImage();
  } catch(Exception& e) {
    pi = NULL;
  }
  return pi;
}

//
// DRJpegResource
//
DRJpegResource::DRJpegResource(int id) throw(ExceptionThrown):
  DRResource(id), DRJpegReader()
{}

DRJpegImage* DRJpegResource::getImage(int alphaColor, int tolerance) {
  my_source_mgr_res src;
  src.resource = this;
  return DRJpegReader::readImage(
    &cinfo,&src.pub,
    init_source_res,fill_input_buffer_res,
    skip_input_data_res,term_source_res,
    alphaColor,tolerance
  );
}

#ifdef USE_SOUND

//
// DRSoundResource
//
DRSoundResource::DRSoundResource(int id) throw(ExceptionThrown): DRResource(id) {
}

FMSample* DRSoundResource::getSoundSample() {
  return new FMSample(getSize(),getPointer());
}

FM3DSample* DRSoundResource::get3DSoundSample() {
  return new FM3DSample(getSize(),getPointer());
}

#ifdef USE_MUSIC

//
// DRMusicResource
//
DRMusicResource::DRMusicResource(int id) throw(ExceptionThrown): DRResource(id) {
}

FMMusic* DRMusicResource::getMusic() {
  return new FMMusic(getSize(),getPointer());
}

#endif // USE_MUSIC

#endif // USE_SOUND

#endif // __linux__

//
// DRData
//
DRData::DRData(int sz, unsigned char* buf, bool ob):
  size(sz), buffer(buf), ownsBuffer(ob)
{}

DRData::~DRData() {
  if(ownsBuffer && buffer)
    delete[] buffer;
}

//
// DRDataStream
//
DRDataStream::DRDataStream(int sz, const char* buf):
  DRData(sz,(unsigned char*)buf,false), writeable(false),
  increment(0), pointer(0), capacity(sz)
{}

DRDataStream::DRDataStream(int inc): DRData(0,NULL,true),
  writeable(true), increment(inc), pointer(0), capacity(inc)
{
  unsigned char* theBuffer = new unsigned char[capacity];
  buffer = theBuffer;
}

bool DRDataStream::modifyCapacity(int cap) {
  if((cap < size) || (cap == 0))
    return false;
  capacity = cap;
  unsigned char* theBuffer = new unsigned char[capacity];
  if(buffer) {
    if(size > 0)
      memcpy(theBuffer,buffer,size);
    delete buffer;
  }
  buffer = theBuffer;
  return true;
}

DRDataStream* DRDataStream::open(const char* mode) {
  if(mode[0] == 'r')
    writeable = false;
  else if((mode[0] == 'w') && ownsBuffer)
    writeable = true;
  else
    return NULL;
  return this;
}

int DRDataStream::close() {
  if(writeable)
    modifyCapacity(size);
  return 0;
}

int DRDataStream::seek(int offset, int whence) {
  int newPointer;
  switch(whence) {
    default:
    case 0:
      newPointer = offset;
      break;
    case 1:
      newPointer = pointer+offset;
      break;
    case 2: {
      newPointer = size+offset;
      break;
    }
  }
  if((newPointer <= size) && (newPointer >= 0)) {
    pointer = newPointer;
    return 0;
  }
  return 1;
}

int DRDataStream::read(void* ptr, int siz, int items) {
  if(writeable)
    return 0;
  int len = siz*items;
  int diff = size-pointer;
  if(diff >= len) {
    memcpy(ptr,buffer+pointer,len);
    pointer += len;
    return items;
  } else {
    memcpy(ptr,buffer+pointer,diff);
    pointer += diff;
    return diff/siz;
  }
}

int DRDataStream::write(const void* ptr, int siz, int items) {
  if(!writeable)
    return 0;
  int len = siz*items;
  int diff = capacity-pointer;
  if(diff < len)
    modifyCapacity(capacity+max(increment,pointer+len-size));
  memcpy(buffer+pointer,ptr,len);
  pointer += len;
  if(pointer > size)
    size = pointer;
  return items;
}

//
// DRImage
//
DRImage::DRImage(bool ha, bool gs, bool ob):
  hasAlpha(ha), grayScale(gs), width(0), height(0),
  ownsBuffer(ob), buffer(NULL)
{}

DRImage::DRImage(int w, int h, unsigned char* b, bool ha, bool gs, bool ob):
  width(w), height(h), hasAlpha(ha), grayScale(gs),
  buffer(b), ownsBuffer(ob)
{}

DRImage::~DRImage() {
  if(ownsBuffer && buffer) delete[] buffer;
}

DRImage* DRImage::getScreenshot(int x, int y, int w, int h) {
	glFlush();
  unsigned char* buffer = new unsigned char[w*h*3];
  glReadPixels(x,y,w,h,GL_RED|GL_GREEN|GL_BLUE,GL_UNSIGNED_BYTE,buffer);
	return new DRImage(w,h,buffer);
}

bool DRImage::saveAsPng(const char* fileName, bool useFilters) {
	FILE*	file = fopen(fileName,"wb");
  if(file == NULL) return false;
  png_structp png_ptr =
  	png_create_write_struct(PNG_LIBPNG_VER_STRING,NULL,NULL,NULL);
  if(!png_ptr) return false;
  png_infop info_ptr = png_create_info_struct(png_ptr);
 	if(!info_ptr) {
  	png_destroy_write_struct(&png_ptr,(png_infopp)NULL);
    fclose(file);
 	  return false;
  }
 	png_init_io(png_ptr,file);
  png_set_compression_strategy(png_ptr,Z_DEFAULT_STRATEGY);
  png_set_compression_level(png_ptr,Z_BEST_COMPRESSION);
  png_set_filter(png_ptr,0,useFilters? PNG_ALL_FILTERS: PNG_NO_FILTERS);
  int bytes;
  int type;
  if(grayScale) {
  	if(hasAlpha) {
    	type = PNG_COLOR_TYPE_GRAY_ALPHA;
      bytes = 2;
    } else {
    	type = PNG_COLOR_TYPE_GRAY;
      bytes = 1;
    }
  } else {
  	if(hasAlpha) {
    	type = PNG_COLOR_TYPE_RGB_ALPHA;
      bytes = 4;
    } else {
    	type = PNG_COLOR_TYPE_RGB;
      bytes = 3;
    }
  }
  png_set_IHDR(png_ptr,info_ptr,width,height,8,type,NULL,NULL,NULL);
  png_write_info(png_ptr,info_ptr);
  png_bytepp row_pointers = new png_bytep[height];
	for(int y = 0; y < height; y++)
  	row_pointers[height-y-1] = (png_bytep)&buffer[y*width*bytes];
 	png_write_image(png_ptr,row_pointers);
  png_write_end(png_ptr,NULL);
 	png_destroy_write_struct(&png_ptr,&info_ptr);
  fclose(file);
	delete row_pointers;
  return true;
}

bool DRImage::resample(int newW, int newH) {
	if(hasAlpha || grayScale ||
    (width <= 0) || (height <= 0) || (newW <= 0) || (newH <= 0)
  )	return false;
	float wScale = (width-1)/float(newW);
	float hScale = (height-1)/float(newH);
  unsigned char *newBuffer = new unsigned char[newW*newH*3];
  for(int y = 0; y < newH; y++) {
    int iy = int(y*hScale);
		float yy = y*hScale-iy;
    for(int x = 0; x < newW; x++) {
      int ix = int(x*wScale);
	    float xx = x*wScale-ix;
		  float r1,g1,b1, r2,g2,b2, r3,g3,b3, r4,g4,b4;
			if((ix < 0)||( ix >= width)||(iy < 0)||(iy >= height)) {
      	r1 = 0; g1 = 0; b1 = 0;
      } else {
      	int index = 3*(ix+iy*width);
      	r1 = buffer[index  ];
      	g1 = buffer[index+1];
        b1 = buffer[index+2];
      }
			if((ix+1 < 0)||( ix+1 >= width)||(iy < 0)||(iy >= height)) {
      	r2 = 0; g2 = 0; b2 = 0;
      } else {
      	int index = 3*(ix+1+iy*width);
      	r2 = buffer[index  ];
      	g2 = buffer[index+1];
        b2 = buffer[index+2];
      }
			if((ix < 0)||( ix >= width)||(iy+1 < 0)||(iy+1 >= height)) {
      	r3 = 0; g3 = 0; b3 = 0;
      } else {
      	int index = 3*(ix+(iy+1)*width);
      	r3 = buffer[index  ];
      	g3 = buffer[index+1];
        b3 = buffer[index+2];
      }
			if((ix+1 < 0)||( ix+1 >= width)||(iy+1 < 0)||(iy+1 >= height)) {
      	r4 = 0; g4 = 0; b4 = 0;
      } else {
      	int index = 3*(ix+1+(iy+1)*width);
      	r4 = buffer[index  ];
      	g4 = buffer[index+1];
        b4 = buffer[index+2];
      }
      int newIndex = 3*(x+y*newW);
      newBuffer[newIndex  ] = (unsigned char)
      	((r1*(1-yy)+r3*yy)*(1-xx)+(r2*(1-yy)+r4*yy)*xx);
      newBuffer[newIndex+1] = (unsigned char)
    		((g1*(1-yy)+g3*yy)*(1-xx)+(g2*(1-yy)+g4*yy)*xx);
      newBuffer[newIndex+2] = (unsigned char)
      	((b1*(1-yy)+b3*yy)*(1-xx)+(b2*(1-yy)+b4*yy)*xx);
    }
	}
  if(ownsBuffer)
  	delete buffer;
  ownsBuffer = true;
  buffer = newBuffer;
  height = newH;
	width = newW;
}

#ifdef USE_DATA_FILES

DRImage* DRImage::getImageFromFile(const char* imageName) {
  DRImage* image = NULL;
  if(strstr(imageName,".jpg")) {
    DRJpegFile file(imageName);
    image = file.getImage();
  } else if(strstr(imageName,".png")) {
    DRPngFile file(imageName);
    image = file.getImage();
  } else if(strstr(imageName,".tga")) {
    DRTgaFile file(imageName);
    image = file.getImage();
  }
  return image;
}

GLTexture* DRImage::getTextureFromFile(
  const char* fileName, bool repeat, bool doMipmaps, int textureDim
) {
  DRImage* img = getImageFromFile(fileName);
  if(img) {
    GLTexture* txt = new GLTexture(*img,repeat,doMipmaps,textureDim);
    delete img;
    return txt;
  }
  return NULL;
}

#endif // USE_DATA_FILES

void DRImage::showSplash(float waitForSeconds) {
  GLWin* glWin = GLConsole::get().getWin();
  glClear(GL_STENCIL_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);
  int width = glWin->getWidth();
  int height = glWin->getHeight();
  int imgWidth = getWidth();
  int imgHeight = getHeight();
  glWin->getCamera().setOrtho();
  glWin->getCamera().applyOrtho();
  glRasterPos2f(-0.5f*imgWidth,-0.5f*imgHeight);
  glDisable(GL_LIGHTING);
  glDisable(GL_DEPTH);
  glDisable(GL_TEXTURE_2D);
  glDrawPixels(
    imgWidth,imgHeight,GL_RGB,GL_UNSIGNED_BYTE,getBuffer()
  );
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_DEPTH);
  glEnable(GL_LIGHTING);
  glWin->swapBuffers();
  Sleep(int(waitForSeconds*1000));
}

void DRImage::addAlpha(DRImage& img, int threshold, int cutoff) {
  const int rgbaLen = 4;
  const float invThre = ((threshold-cutoff) == 0)? 1: 255.0f/(threshold-cutoff);
  if(hasAlpha) {
    if(img.isGrayScale()) {
      int rowLen = width*rgbaLen;
      int grayScaleIndex = 0;
      for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
        for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
          int rowPosAlpha = rowPos+3;
          unsigned char alpha = img.getBuffer()[grayScaleIndex++];
          buffer[rowPosAlpha] = threshold < 0? alpha:
            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
              (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
        }
      }
    } else {
      int rowLen = width*rgbaLen;
      for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
        for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
          int rowPosAlpha = rowPos+3;
          unsigned char alpha = img.getBuffer()[rowPosAlpha];
          buffer[rowPosAlpha] = threshold < 0? alpha:
            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
              (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
        }
      }
    }
  } else {
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    int rowLen = width*rgbaLen;
    int oldRowPos = 0;
    if(img.isGrayScale()) {
      int grayScaleIndex = 0;
      if(isGrayScale()) {
        setGrayScale(false);
        for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
          for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
            newBuffer[rowPos  ] = buffer[grayScaleIndex];
            newBuffer[rowPos+1] = buffer[grayScaleIndex];
            newBuffer[rowPos+2] = buffer[grayScaleIndex];
            unsigned char alpha = img.getBuffer()[grayScaleIndex++];
            newBuffer[rowPos+3] = threshold < 0? alpha:
	            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
  	            (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
          }
        }
      } else {
        for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
          for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
            newBuffer[rowPos  ] = buffer[oldRowPos++];
            newBuffer[rowPos+1] = buffer[oldRowPos++];
            newBuffer[rowPos+2] = buffer[oldRowPos++];
            unsigned char alpha = img.getBuffer()[grayScaleIndex++];
            newBuffer[rowPos+3] = threshold < 0? alpha:
	            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
  	            (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
          }
        }
      }
    } else {
      if(isGrayScale()) {
        setGrayScale(false);
        int grayScaleIndex = 0;
        for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
          for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
            newBuffer[rowPos  ] = buffer[grayScaleIndex];
            newBuffer[rowPos+1] = buffer[grayScaleIndex];
            newBuffer[rowPos+2] = buffer[grayScaleIndex++];
            unsigned char alpha = img.getBuffer()[rowPos+3];
            newBuffer[rowPos+3] = threshold < 0? alpha:
	            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
  	            (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
          }
        }
      } else {
        if(img.getHasAlpha()) {
          for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
            for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
              newBuffer[rowPos  ] = buffer[oldRowPos++];
              newBuffer[rowPos+1] = buffer[oldRowPos++];
              newBuffer[rowPos+2] = buffer[oldRowPos++];
              unsigned char alpha = img.getBuffer()[rowPos+3];
              newBuffer[rowPos+3] = threshold < 0? alpha:
		            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
    		          (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
            }
          }
        } else {
          for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
            for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
              newBuffer[rowPos  ] = buffer[oldRowPos++];
              newBuffer[rowPos+1] = buffer[oldRowPos++];
              newBuffer[rowPos+2] = buffer[oldRowPos++];
              unsigned char alpha = (unsigned char)((
                img.getBuffer()[oldRowPos-3]+
                img.getBuffer()[oldRowPos-2]+
                img.getBuffer()[oldRowPos-1]
              )/3.0f);
              newBuffer[rowPos+3] = threshold < 0? alpha:
		            alpha >= threshold? (unsigned char)255: alpha <= cutoff?
    		          (unsigned char)0: (unsigned char)((alpha-cutoff)*invThre);
            }
          }
        }
      }
    }
    hasAlpha = true;
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

void DRImage::addAlpha(unsigned char alpha) {
  const int rgbaLen = 4;
  if(hasAlpha) {
    int rowLen = width*rgbaLen;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
        int rowPosAlpha = rowPos+3;
        buffer[rowPosAlpha] = alpha;
      }
    }
  } else {
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    hasAlpha = true;
    int rowLen = width*rgbaLen;
    int oldRowPos = 0;
    if(isGrayScale()) {
      setGrayScale(false);
      int grayScaleIndex = 0;
      for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
        for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
          newBuffer[rowPos  ] = buffer[grayScaleIndex];
          newBuffer[rowPos+1] = buffer[grayScaleIndex];
          newBuffer[rowPos+2] = buffer[grayScaleIndex++];
          newBuffer[rowPos+3] = alpha;
        }
      }
    } else {
      for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
        for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen){
          newBuffer[rowPos  ] = buffer[oldRowPos++];
          newBuffer[rowPos+1] = buffer[oldRowPos++];
          newBuffer[rowPos+2] = buffer[oldRowPos++];
          newBuffer[rowPos+3] = alpha;
        }
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

void DRImage::setGammaCorrection(
  unsigned char* buf, int w, int h, float gamma,
  bool hasAlphaChannel, bool isGrayScale
) {
  const int COMPONENTS = (hasAlphaChannel? 4: 3)+(isGrayScale? 1: 0);
  const int SIZE = w*h;
  if(isGrayScale) {
  	for(int ct = 0; ct < SIZE; ct++, buf += COMPONENTS) {
      const float SCALE_FACTOR = gamma/255;
  		float	gray = buf[0]*SCALE_FACTOR;
		  float scale = 1.0f;
  		float temp;
		  if((gray > 1) && (temp = 1/gray) < scale) scale = temp;
	  	scale *= 255;
		  buf[0] = (unsigned char)(gray*scale);
    }
 	} else {
  	for(int ct = 0; ct < SIZE; ct++, buf += COMPONENTS) {
      const float SCALE_FACTOR = gamma/255;
		  float r = buf[0]*SCALE_FACTOR;
  		float	g = buf[1]*SCALE_FACTOR;
	  	float b = buf[2]*SCALE_FACTOR;
		  float scale = 1.0f;
  		float temp;
	  	if((r > 1) && (temp = 1/r) < scale) scale = temp;
		  if((g > 1) && (temp = 1/g) < scale) scale = temp;
  		if((b > 1) && (temp = 1/b) < scale) scale = temp;
	  	scale *= 255;
		  buf[0] = (unsigned char)(r*scale);
  		buf[1] = (unsigned char)(g*scale);
	  	buf[2] = (unsigned char)(b*scale);
    }
  }
}

void DRImage::convertTo111A(float gray, bool invert) {
  if(hasAlpha)
    return;
  if(grayScale) {
    const int rgbaLen = 4;
    hasAlpha = true;
    grayScale = false;
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    int rowLen = width*rgbaLen;
    int grayScaleIndex = 0;
    int grayValue = int(gray*255);
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
        unsigned char grayShade = buffer[grayScaleIndex++];
        newBuffer[rowPos  ] = (unsigned char)grayValue;
        newBuffer[rowPos+1] = (unsigned char)grayValue;
        newBuffer[rowPos+2] = (unsigned char)grayValue;
        newBuffer[rowPos+3] = invert? (unsigned char)(255-grayShade): grayShade;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  } else {
    const int rgbaLen = 4;
    hasAlpha = true;
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    int rowLen = width*rgbaLen;
    int index = 0;
    int grayValue = int(gray*255);
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
        unsigned char alpha = (unsigned char)(
          (buffer[index++]+buffer[index++]+buffer[index++])/3.0f
        );
        newBuffer[rowPos  ] = (unsigned char)grayValue;
        newBuffer[rowPos+1] = (unsigned char)grayValue;
        newBuffer[rowPos+2] = (unsigned char)grayValue;
        newBuffer[rowPos+3] = invert? (unsigned char)(255-alpha): alpha;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

void DRImage::convertToRGBA(bool invert) {
  if(hasAlpha)
    return;
  if(grayScale) {
    const int rgbaLen = 4;
    hasAlpha = true;
    grayScale = false;
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    int rowLen = width*rgbaLen;
    int grayScaleIndex = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
        unsigned char grayShade = buffer[grayScaleIndex++];
        newBuffer[rowPos  ] = grayShade;
        newBuffer[rowPos+1] = grayShade;
        newBuffer[rowPos+2] = grayShade;
        newBuffer[rowPos+3] = invert? (unsigned char)(255-grayShade): grayShade;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  } else {
    const int rgbaLen = 4;
    hasAlpha = true;
    unsigned char* newBuffer = new unsigned char[width*height*rgbaLen];
    int rowLen = width*rgbaLen;
    int index = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbaLen) {
        unsigned char r = buffer[index++];
        unsigned char g = buffer[index++];
        unsigned char b = buffer[index++];
        unsigned char alpha = (unsigned char)((r+g+b)/3.0f);
        newBuffer[rowPos  ] = r;
        newBuffer[rowPos+1] = g;
        newBuffer[rowPos+2] = b;
        newBuffer[rowPos+3] = invert? (unsigned char)(255-alpha): alpha;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

void DRImage::convertToRGB() {
  if(grayScale) {
    const int rgbLen = 3;
    hasAlpha = false;
    grayScale = false;
    unsigned char* newBuffer = new unsigned char[width*height*rgbLen];
    int rowLen = width*rgbLen;
    int grayScaleIndex = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbLen) {
        unsigned char grayShade = buffer[grayScaleIndex++];
        newBuffer[rowPos  ] = grayShade;
        newBuffer[rowPos+1] = grayShade;
        newBuffer[rowPos+2] = grayShade;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  } else {
    const int rgbLen = 3;
    bool hadAlpha = hasAlpha;
    hasAlpha = false;
    unsigned char* newBuffer = new unsigned char[width*height*rgbLen];
    int rowLen = width*rgbLen;
    int index = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbLen) {
        unsigned char r = buffer[index++];
        unsigned char g = buffer[index++];
        unsigned char b = buffer[index++];
        if(hadAlpha) index++;
        newBuffer[rowPos  ] = r;
        newBuffer[rowPos+1] = g;
        newBuffer[rowPos+2] = b;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

void DRImage::convertToBump(float scaleSide, float scaleHeight) {
  if(grayScale) {
    hasAlpha = false;
    grayScale = false;
    const int rgbLen = 3;
    const int MAX_SIZE = width*height;
    unsigned char* newBuffer = new unsigned char[MAX_SIZE*rgbLen];
    int rowLen = width*rgbLen;
    int grayScaleIndex = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      int grayScaleRowIndex = 0;
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbLen) {
        unsigned char current = buffer[grayScaleIndex];
        int topIndex = grayScaleIndex+width;
        if(topIndex > MAX_SIZE) topIndex -= MAX_SIZE;
        int bottomIndex = grayScaleIndex-width;
        if(bottomIndex < 0) bottomIndex += MAX_SIZE;
        int rightIndex = grayScaleIndex+1;
        if(grayScaleRowIndex >= width-1)
          rightIndex -= width;
        int leftIndex = grayScaleIndex-1;
        if(grayScaleRowIndex <= 0)
          leftIndex += width;
        grayScaleIndex++;
        grayScaleRowIndex++;
        M3Vector top(0,scaleSide,(buffer[topIndex]-current)*scaleHeight);
        M3Vector bottom(0,-scaleSide,(current-buffer[bottomIndex])*scaleHeight);
        M3Vector right(scaleSide,0,(buffer[rightIndex]-current)*scaleHeight);
        M3Vector left(-scaleSide,0,(current-buffer[leftIndex])*scaleHeight);
        M3Vector tmp = top;
        M3Vector sum = tmp.cross(left).normalize();
        tmp = left;
        sum.add(tmp.cross(bottom).normalize());
        tmp = bottom;
        sum.add(tmp.cross(right).normalize());
        tmp = right;
        sum.add(tmp.cross(top).normalize());
        sum.normalize();
        newBuffer[rowPos  ] = sum.getX();
        newBuffer[rowPos+1] = sum.getY();
        newBuffer[rowPos+2] = sum.getZ();
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  } else {
    const int rgbLen = 3;
    bool hadAlpha = hasAlpha;
    hasAlpha = false;
    unsigned char* newBuffer = new unsigned char[width*height*rgbLen];
    int rowLen = width*rgbLen;
    int index = 0;
    for(int rowBase = 0; rowBase < rowLen*height; rowBase += rowLen) {
      for(int rowPos = rowBase; rowPos < rowBase+rowLen; rowPos += rgbLen) {
        unsigned char r = buffer[index++];
        unsigned char g = buffer[index++];
        unsigned char b = buffer[index++];
        if(hadAlpha) index++;
        newBuffer[rowPos  ] = r;
        newBuffer[rowPos+1] = g;
        newBuffer[rowPos+2] = b;
      }
    }
    if(ownsBuffer)
      delete buffer;
    else
      ownsBuffer = true;
    buffer = newBuffer;
  }
}

//
// DRJpegImage
//
DRJpegImage::DRJpegImage(int ac, bool ob): DRImage(ac >= 0, false, ob) {
}

//
// DRPngImage
//
DRPngImage::DRPngImage(bool ha, bool gs, bool ob): DRImage(ha,gs,ob) {
}

//
// DRTgaImage
//
DRTgaImage::DRTgaImage(bool ha, bool gs, bool ob): DRImage(ha,gs,ob) {
}

#ifdef USE_DATA_FILES

//
// DRJpegFile
//
DRJpegFile::DRJpegFile(const char* filNam): DRFile(filNam), DRJpegReader() {
}

DRJpegImage* DRJpegFile::getImage(int alphaColor, int tolerance) {
  if(!openFile())
    return NULL;
  closeFile();
  my_source_mgr_fil src;
  src.file = this;
  return DRJpegReader::readImage(
    &cinfo,&src.pub,
    init_source_fil,fill_input_buffer_fil,
    skip_input_data_fil,term_source_fil,
    alphaColor, tolerance
  );
}

//
// DRPngFile
//
DRPngFile::DRPngFile(const char* filNam): DRDataFile(filNam), DRPngReader() {
}

DRPngImage* DRPngFile::getImage() {
  DRData* data = getData();
  if(data) {
    setReadPointer(data->getBuffer());
    DRPngImage* img;
    try {
      img = DRPngReader::readImage();
    } catch(Exception& e) {
      img = NULL;
    }
    delete data;
    return img;
  }
  return NULL;
}

//
// DRTgaFile
//
DRTgaFile::DRTgaFile(const char* filNam): DRDataFile(filNam) {
}

DRTgaImage* DRTgaFile::getImage() {
  DRData* data = getData();
  if(data) {
    DRTgaImage* img = readImage(data);
    delete data;
    return img;
  }
  return NULL;
}

//
// DRMeshFile
//
DRMeshFile::DRMeshFile(const char* filNam, const char* pth):
	DRFile(filNam,pth), path(pth)
{}

GLObjects* DRMeshFile::getMeshes(DRMeshReader::MeshType meshType) {
	DRMeshReader::MeshFormat fmt;
  if(strstr(fileName,".3ds"))
  	fmt = DRMeshReader::FMT_3DS;
  else if(strstr(fileName,".obj"))
  	fmt = DRMeshReader::FMT_OBJ;
  else
  	return NULL;
	if(openFile()) {
  	DRMeshReader reader(file,path);
    GLObjects* meshes = reader.readMeshes(fmt,meshType);
	  closeFile();
  	return meshes;
  }
  return NULL;
}

GLBasicMesh* DRMeshFile::getBasicMesh() {
	DRMeshReader::MeshFormat fmt;
  if(strstr(fileName,".3ds"))
  	fmt = DRMeshReader::FMT_3DS;
  else if(strstr(fileName,".obj"))
  	fmt = DRMeshReader::FMT_OBJ;
  else
  	return NULL;
  if(openFile()) {
 	  DRMeshReader reader(file,path);
   	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_BASIC);
    closeFile();
    if(meshes) {
	 	  GLBasicMesh* mesh =
  	 	  dynamic_cast<GLBasicMesh*>(meshes->getFirstObject())->clone();
    	delete meshes;
	 	  return mesh;
    }
  }
  return NULL;
}

GLMesh* DRMeshFile::getShaderMesh() {
	DRMeshReader::MeshFormat fmt;
  if(strstr(fileName,".3ds"))
  	fmt = DRMeshReader::FMT_3DS;
  else if(strstr(fileName,".obj"))
  	fmt = DRMeshReader::FMT_OBJ;
  else
  	return NULL;
  if(openFile()) {
 	  DRMeshReader reader(file,path);
   	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_SHADER);
    closeFile();
    if(meshes) {
	 	  GLMesh* mesh =
  	 	  dynamic_cast<GLMesh*>(meshes->getFirstObject())->clone();
    	delete meshes;
	 	  return mesh;
    }
  }
  return NULL;
}

GLMesh* DRMeshFile::getMesh() {
	DRMeshReader::MeshFormat fmt;
  if(strstr(fileName,".3ds"))
  	fmt = DRMeshReader::FMT_3DS;
  else if(strstr(fileName,".obj"))
  	fmt = DRMeshReader::FMT_OBJ;
  else
  	return NULL;
  if(openFile()) {
 	  DRMeshReader reader(file,path);
   	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_NORMAL);
    closeFile();
    if(meshes) {
	 	  GLMesh* mesh = dynamic_cast<GLMesh*>(meshes->getFirstObject())->clone();
  	 	delete meshes;
    	return mesh;
    }
 	}
  return NULL;
}

#ifdef USE_EMBOSS

GLBumpedMesh* DRMeshFile::getBumpedMesh() {
	DRMeshReader::MeshFormat fmt;
  if(strstr(fileName,".3ds"))
  	fmt = DRMeshReader::FMT_3DS;
  else if(strstr(fileName,".obj"))
  	fmt = DRMeshReader::FMT_OBJ;
  else
  	return NULL;
  if(openFile()) {
 	  DRMeshReader reader(file,path);
   	GLObjects* meshes = reader.readMeshes(fmt,DRMeshReader::TYPE_BUMPED);
    closeFile();
    if(meshes) {
	 	  GLBumpedMesh* mesh =
  	 	  dynamic_cast<GLBumpedMesh*>(meshes->getFirstObject())->clone();
    	delete meshes;
	 	  return mesh;
    }
  }
  return NULL;
}

#endif // USE_EMBOSS

//
// DRBasicModelFile
//
DRBasicModelFile::DRBasicModelFile(const char* fileNam): DRFile(fileNam) {}

GLBasicModel* DRBasicModelFile::getBasicModel(
	const char* imageName, const char* alphaName
) {
	GLBasicModel* model = new GLBasicModel();
  if(model->load(fileName,imageName,alphaName))
	  return model;
  delete model;
  return NULL;
}

//
// DRModelFile
//
DRModelFile::DRModelFile(const char* fileNam): DRFile(fileNam) {}

GLModel* DRModelFile::getModel(const char* imageName, const char* alphaName) {
	GLModel* model = new GLModel();
  if(model->load(NULL,fileName,imageName,alphaName))
	  return model;
  delete model;
  return NULL;
}

#ifdef USE_CAL3D

//
// DRAdvancedModelFile
//
DRAdvancedModelFile::DRAdvancedModelFile(const char* fileNam): DRFile(fileNam) {}

GLAdvancedModel* DRAdvancedModelFile::getAdvancedModel(bool useHW) {
  GLAdvancedCoreModel* coreModel = new GLAdvancedCoreModel();
  if(coreModel->load(fileName)) {
    GLAdvancedModel* model = new GLAdvancedModel(*coreModel,useHW);
    return model;
  }
  delete coreModel;
  return NULL;
}

#endif // USE_CAL3D

//
// DRBotFile
//
DRBotFile::DRBotFile(const char* pth, const char* filNam):
	DRFile(filNam), path(pth)
{}

GLBot* DRBotFile::getBot(bool ownsCache) {
	GLBot* bot = new GLBot(ownsCache);
  if(bot->loadBot(path,fileName,ownsCache))
  	return bot;
  return NULL;
}

#ifdef USE_BSP

//
// DRBspFile
//
DRBspFile::DRBspFile(const char* pth, const char* fileNam):
	DRFile(fileNam), path(pth)
{}

GLBsp* DRBspFile::getLevel(float gammaCorrection) {
	GLBsp* bsp = new GLBsp();
  if(bsp->load(path,fileName,gammaCorrection))
	  return bsp;
  delete bsp;
  return NULL;
}

#endif // USE_BSP

#ifdef USE_SOUND

//
// DRSampleFile
//
DRSampleFile::DRSampleFile(const char* fileNam): DRDataFile(fileNam) {}

FMSample* DRSampleFile::getSample() {
	DRData* data = getData();
  if(data) {
    FMSample* ret = new FMSample(data->getSize(),data->getBuffer());
    delete data;
    return ret;
  }
  return NULL;
}

FM3DSample* DRSampleFile::getSample3D() {
	DRData* data = getData();
  if(data) {
    FM3DSample* ret = new FM3DSample(data->getSize(),data->getBuffer());
    delete data;
    return ret;
  }
  return NULL;
}

#ifdef USE_MUSIC

//
// DRMusicFile
//
DRMusicFile::DRMusicFile(const char* filNam): DRDataFile(filNam) {}

FMMusic* DRMusicFile::getMusic() {
	DRData* data = getData();
  if(data) {
    FMMusic* ret = new FMMusic(data->getSize(),data->getBuffer());
    delete data;
    return ret;
  }
  return NULL;
}

#endif // USE_MUSIC
#endif // USE_SOUND

#endif // USE_DATA_FILES
