#ifndef SLINTERPRETER_H
#define SLINTERPRETER_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

#include "small/amx.h"

#include "dataread.h"

#include <limits.h> // for INT_MAX

//
// SLInterpreter
//

class SLInterpreter {
private:
  unsigned char* program;
  float cpuFrequency;
  cell returnValue;
  bool suspended;
  bool running;
  AMX amx;
protected:
  int registerNatives();
public:
  SLInterpreter();
  ~SLInterpreter();
  bool isLoaded() {return program != NULL;}
  bool load(char* fileName, int memoryLimit = 0);
  bool load(DRData* prog, int memoryLimit = 0);
  void unload();
  bool registerNatives(AMX_NATIVE_INFO natives[])
    {return (amx_Register(&amx,natives,-1) == AMX_ERR_NONE);}
  int findPublic(char* name, int* index) {
    int ret = amx_FindPublic(&amx,name,index);
    if(ret == AMX_ERR_NOTFOUND) *index = -1;
    return ret;
  }
  int initMain() {
    amx_timer = 0;
    int ret = amx_Exec(&amx,&returnValue,AMX_EXEC_MAIN,0);
    running = (ret == AMX_ERR_SLEEP);
    return ret;
  }
  int execMain(int cycles) {
    if(suspended) return AMX_ERR_SLEEP;
    amx_timer = cycles;
    int ret = amx_Exec(&amx,&returnValue,AMX_EXEC_CONT,0);
    running = (ret == AMX_ERR_SLEEP);
    return ret;
  }
  int execMain(float deltaT)
    {int cycles = int(deltaT*cpuFrequency+0.5f); return execMain(cycles);}
  int exec(int index, int cycles = INT_MAX) {
    amx_timer = cycles;
    int ret = amx_Exec(&amx,&returnValue,index,0);
    running = (ret == AMX_ERR_SLEEP);
    return ret;
  }
  int execArg(int index, cell arg, int cycles = INT_MAX) {
    amx_timer = cycles;
    int ret = amx_Exec(&amx,&returnValue,index,1,arg);
    running = (ret == AMX_ERR_SLEEP);
    return ret;
  }
  int execNoStop(int index) {
    int ret = exec(index);
    while(isRunning()) ret = exec(AMX_EXEC_CONT);
    return ret;
  }
  int execNoStop(int index, cell arg) {
    int ret = execArg(index,arg);
    while(isRunning()) ret = exec(AMX_EXEC_CONT);
    return ret;
  }
  static cell float2Cell(float f) {
    float *theFloat;
    cell theCell;
    theFloat = (float*)((void*)&theCell);
    *theFloat = f;
    return theCell;
  }
  static float cell2Float(cell c) {
    float *theFloat;
    theFloat = (float*)((void*)&c);
    return *theFloat;
  }
  void setRandomSeed(unsigned int rs) {amx.IL_StandardRandom_seed = rs;}
  void setCPUFrequency(float f) {cpuFrequency = f;}
  float getCPUFrequency() {return cpuFrequency;}
  void setRunning(bool r) {running = false;}
  bool isRunning() {return running;}
  void suspend() {suspended = true;}
  void resume() {suspended = false;}
  cell getReturnValue() {return returnValue;}
};

#endif // USE_CONSOLE && USE_SMALL
#endif // SLINTERPRETER_H
