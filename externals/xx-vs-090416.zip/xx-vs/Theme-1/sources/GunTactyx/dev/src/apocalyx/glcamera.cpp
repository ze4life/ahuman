/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glcamera.h"

#include "opengl.h"
#include "glwin.h"
#ifdef USE_SOUND
#include "fmsound.h"
#endif

#include "math3d.inc"

//
// GLFrustum
//
GLFrustum::GLFrustum(): clipPlaneNear(0), clipPlaneFar(1) {
}

void GLFrustum::update() {
#ifdef USE_OGLES
  glGetFloatv(GL_PROJECTION_MATRIX,projectionMatrix);
  glGetFloatv(GL_MODELVIEW_MATRIX,modelMatrix);
  float* prj = projectionMatrix;
  float* mdl = modelMatrix;
  float clp[16];
#else // !USE_OGLES
  glGetDoublev(GL_PROJECTION_MATRIX,projectionMatrix);
  glGetDoublev(GL_MODELVIEW_MATRIX,modelMatrix);
  double* prj = projectionMatrix;
  double* mdl = modelMatrix;
  double clp[16];
#endif // !USE_OGLES
  float invT;
  clp[ 0] = mdl[ 0]*prj[ 0]+mdl[ 1]*prj[ 4]+mdl[ 2]*prj[ 8]+mdl[ 3]*prj[12];
  clp[ 1] = mdl[ 0]*prj[ 1]+mdl[ 1]*prj[ 5]+mdl[ 2]*prj[ 9]+mdl[ 3]*prj[13];
  clp[ 2] = mdl[ 0]*prj[ 2]+mdl[ 1]*prj[ 6]+mdl[ 2]*prj[10]+mdl[ 3]*prj[14];
  clp[ 3] = mdl[ 0]*prj[ 3]+mdl[ 1]*prj[ 7]+mdl[ 2]*prj[11]+mdl[ 3]*prj[15];
  clp[ 4] = mdl[ 4]*prj[ 0]+mdl[ 5]*prj[ 4]+mdl[ 6]*prj[ 8]+mdl[ 7]*prj[12];
  clp[ 5] = mdl[ 4]*prj[ 1]+mdl[ 5]*prj[ 5]+mdl[ 6]*prj[ 9]+mdl[ 7]*prj[13];
  clp[ 6] = mdl[ 4]*prj[ 2]+mdl[ 5]*prj[ 6]+mdl[ 6]*prj[10]+mdl[ 7]*prj[14];
  clp[ 7] = mdl[ 4]*prj[ 3]+mdl[ 5]*prj[ 7]+mdl[ 6]*prj[11]+mdl[ 7]*prj[15];
  clp[ 8] = mdl[ 8]*prj[ 0]+mdl[ 9]*prj[ 4]+mdl[10]*prj[ 8]+mdl[11]*prj[12];
  clp[ 9] = mdl[ 8]*prj[ 1]+mdl[ 9]*prj[ 5]+mdl[10]*prj[ 9]+mdl[11]*prj[13];
  clp[10] = mdl[ 8]*prj[ 2]+mdl[ 9]*prj[ 6]+mdl[10]*prj[10]+mdl[11]*prj[14];
  clp[11] = mdl[ 8]*prj[ 3]+mdl[ 9]*prj[ 7]+mdl[10]*prj[11]+mdl[11]*prj[15];
  clp[12] = mdl[12]*prj[ 0]+mdl[13]*prj[ 4]+mdl[14]*prj[ 8]+mdl[15]*prj[12];
  clp[13] = mdl[12]*prj[ 1]+mdl[13]*prj[ 5]+mdl[14]*prj[ 9]+mdl[15]*prj[13];
  clp[14] = mdl[12]*prj[ 2]+mdl[13]*prj[ 6]+mdl[14]*prj[10]+mdl[15]*prj[14];
  clp[15] = mdl[12]*prj[ 3]+mdl[13]*prj[ 7]+mdl[14]*prj[11]+mdl[15]*prj[15];
  frustum[0][0] = (float)(clp[ 3]-clp[ 0]);
  frustum[0][1] = (float)(clp[ 7]-clp[ 4]);
  frustum[0][2] = (float)(clp[11]-clp[ 8]);
  frustum[0][3] = (float)(clp[15]-clp[12]);
  float val =
    frustum[0][0]*frustum[0][0]+
    frustum[0][1]*frustum[0][1]+
    frustum[0][2]*frustum[0][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[0][0] *= invT;
  frustum[0][1] *= invT;
  frustum[0][2] *= invT;
  frustum[0][3] *= invT;
  frustum[1][0] = (float)(clp[ 3]+clp[ 0]);
  frustum[1][1] = (float)(clp[ 7]+clp[ 4]);
  frustum[1][2] = (float)(clp[11]+clp[ 8]);
  frustum[1][3] = (float)(clp[15]+clp[12]);
  val =
  	frustum[1][0]*frustum[1][0]+
    frustum[1][1]*frustum[1][1]+
    frustum[1][2]*frustum[1][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[1][0] *= invT;
  frustum[1][1] *= invT;
  frustum[1][2] *= invT;
  frustum[1][3] *= invT;
  frustum[2][0] = (float)(clp[ 3]+clp[ 1]);
  frustum[2][1] = (float)(clp[ 7]+clp[ 5]);
  frustum[2][2] = (float)(clp[11]+clp[ 9]);
  frustum[2][3] = (float)(clp[15]+clp[13]);
  val =
    frustum[2][0]*frustum[2][0]+
    frustum[2][1]*frustum[2][1]+
    frustum[2][2]*frustum[2][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[2][0] *= invT;
  frustum[2][1] *= invT;
  frustum[2][2] *= invT;
  frustum[2][3] *= invT;
  frustum[3][0] = (float)(clp[ 3]-clp[ 1]);
  frustum[3][1] = (float)(clp[ 7]-clp[ 5]);
  frustum[3][2] = (float)(clp[11]-clp[ 9]);
  frustum[3][3] = (float)(clp[15]-clp[13]);
  val =
    frustum[3][0]*frustum[3][0]+
    frustum[3][1]*frustum[3][1]+
    frustum[3][2]*frustum[3][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[3][0] *= invT;
  frustum[3][1] *= invT;
  frustum[3][2] *= invT;
  frustum[3][3] *= invT;
  frustum[4][0] = (float)(clp[ 3]-clp[ 2]);
  frustum[4][1] = (float)(clp[ 7]-clp[ 6]);
  frustum[4][2] = (float)(clp[11]-clp[10]);
  frustum[4][3] = (float)(clp[15]-clp[14]);
  val =
    frustum[4][0]*frustum[4][0]+
    frustum[4][1]*frustum[4][1]+
    frustum[4][2]*frustum[4][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[4][0] *= invT;
  frustum[4][1] *= invT;
  frustum[4][2] *= invT;
  frustum[4][3] *= invT;
  frustum[5][0] = (float)(clp[ 3]+clp[ 2]);
  frustum[5][1] = (float)(clp[ 7]+clp[ 6]);
  frustum[5][2] = (float)(clp[11]+clp[10]);
  frustum[5][3] = (float)(clp[15]+clp[14]);
  val =
  	frustum[5][0]*frustum[5][0]+
    frustum[5][1]*frustum[5][1]+
    frustum[5][2]*frustum[5][2];
  invT = val > 0? 1/sqrt(val): 1;
  frustum[5][0] *= invT;
  frustum[5][1] *= invT;
  frustum[5][2] *= invT;
  frustum[5][3] *= invT;
}

bool GLFrustum::isBoxVisible(
  float minX, float minY, float minZ, float maxX, float maxY, float maxZ
) {
	for(int ct = 0; ct < 6; ct++)	{
    if(
      (dot(ct,minX,minY,minZ) > 0) || (dot(ct,maxX,minY,minZ) > 0) ||
      (dot(ct,minX,maxY,minZ) > 0) || (dot(ct,maxX,maxY,minZ) > 0) ||
      (dot(ct,minX,minY,maxZ) > 0) || (dot(ct,maxX,minY,maxZ) > 0) ||
      (dot(ct,minX,maxY,maxZ) > 0) || (dot(ct,maxX,maxY,maxZ) > 0)
    )
      continue
    ;
		return false;
	}
	return true;
}

//
// GLCamera
//

GLCamera::GLCamera():
  fieldOfView(60), renderingReflections(false), renderingTransparencies(false),
  renderingShadows(false), viewWidth(1), viewHeight(1), viewX(0), viewY(0),
  useScissor(false), mainView(true), ortho(false)
{}

void GLCamera::updateAspect(float w, float h) {
	if(useScissor) {
  	viewWidth = w;
    viewHeight = h;
  }
  if(isOrtho()) setOrtho(clipPlaneFar);
  else setPerspective(fieldOfView,clipPlaneNear,clipPlaneFar);
}

void GLCamera::setViewport(float x, float y, float w, float h) {
	useScissor = (
  	(x != 0) || (y != 0) ||
    (w != GLWin::get().getWidth()) ||
    (h != GLWin::get().getHeight())
  );
	viewX = x;
  viewY = y;
  viewWidth = w;
  viewHeight = h;
}

void GLCamera::setLocation(float x, float y) {
	useScissor = (
  	(x != 0) || (y != 0) ||
    (viewWidth != GLWin::get().getWidth()) ||
    (viewHeight != GLWin::get().getHeight())
  );
	viewX = x;
  viewY = y;
}

void GLCamera::setDimension(float w, float h) {
	useScissor = (
  	(viewX != 0) || (viewY != 0) ||
    (w != GLWin::get().getWidth()) ||
    (h != GLWin::get().getHeight())
  );
	viewWidth = w;
  viewHeight = h;
}

void GLCamera::setOrtho(float zf) {
  ortho = true;
  clipPlaneFar = zf;
}

void GLCamera::saveView() {
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
}

void GLCamera::restoreView() {
  glMatrixMode(GL_MODELVIEW);
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
}

void GLCamera::setPerspective(float fov, float zn, float zf) {
  ortho = false;
  fieldOfView = fov;
  clipPlaneNear = zn;
  clipPlaneFar = zf;
}

#ifdef USE_OGLES // modified from Mesa OpenGL impl

void gluLookAt(
  float eyex, float eyey, float eyez,
  float centerx, float centery, float centerz,
  float upx, float upy, float upz
) {
  float m[16];
  float x[3], y[3], z[3];
  z[0] = eyex-centerx;
  z[1] = eyey-centery;
  z[2] = eyez-centerz;
  float mag = sqrt(z[0]*z[0]+z[1]*z[1]+z[2]*z[2]);
  if(mag) {
    z[0] /= mag;
    z[1] /= mag;
    z[2] /= mag;
  }
  y[0] = upx;
  y[1] = upy;
  y[2] = upz;
  x[0] =  y[1]*z[2]-y[2]*z[1];
  x[1] = -y[0]*z[2]+y[2]*z[0];
  x[2] =  y[0]*z[1]-y[1]*z[0];
  y[0] =  z[1]*x[2]-z[2]*x[1];
  y[1] = -z[0]*x[2]+z[2]*x[0];
  y[2] =  z[0]*x[1]-z[1]*x[0];
  mag = sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
  if(mag) {
    x[0] /= mag;
    x[1] /= mag;
    x[2] /= mag;
  }
  mag = sqrt(y[0]*y[0]+y[1]*y[1]+y[2]*y[2]);
  if(mag) {
    y[0] /= mag;
    y[1] /= mag;
    y[2] /= mag;
  }
#define M(row,col)  m[col*4+row]
  M(0,0) = x[0];
  M(0,1) = x[1];
  M(0,2) = x[2];
  M(0,3) = 0.0f;
  M(1,0) = y[0];
  M(1,1) = y[1];
  M(1,2) = y[2];
  M(1,3) = 0.0f;
  M(2,0) = z[0];
  M(2,1) = z[1];
  M(2,2) = z[2];
  M(2,3) = 0.0f;
  M(3,0) = 0.0f;
  M(3,1) = 0.0f;
  M(3,2) = 0.0f;
  M(3,3) = 1.0f;
#undef M
  glMultMatrixf(m);
  glTranslatef(-eyex,-eyey,-eyez);
}

#endif // USE_OGLES

void GLCamera::applyTransform() {
  M3Vector loc = getPosition();
  M3Vector lookAt(loc);
  lookAt.add(getViewDirectionX(),getViewDirectionY(),getViewDirectionZ());
  glLoadIdentity();
  gluLookAt(
    loc.getX(),loc.getY(),loc.getZ(),
    lookAt.getX(),lookAt.getY(),lookAt.getZ(),
    getUpDirectionX(),getUpDirectionY(),getUpDirectionZ()
  );
  GLFrustum::update();
  float invNorm = 1.0f/sqrt(
    getViewDirectionX()*getViewDirectionX()+
    getViewDirectionZ()*getViewDirectionZ()
  );
  if(invNorm == 0) invNorm = 1;
  horizontalViewX = invNorm*getViewDirectionX();
  horizontalViewZ = invNorm*getViewDirectionZ();
#ifdef USE_SOUND
  if(isMainView()) {
	  M3Vector velocity(getPositionX(),getPositionY(),getPositionZ());
  	velocity.subtract(lastApplyPosition).scale(GLWin::getInvTimeStep());
	  lastApplyPosition.set(getPositionX(),getPositionY(),getPositionZ());
  	FMListener::setAttributes(
    	getViewDirectionX(),getViewDirectionY(),getViewDirectionZ(),
	    getUpDirectionX(),getUpDirectionY(),getUpDirectionZ(),
  	  lastApplyPosition.getArray(),velocity.getArray()
	  );
  }
#endif
}

void GLCamera::applyRotation() {
  M3Vector dir = getViewDirection();
  M3Vector up = getUpDirection();
  glLoadIdentity();
  gluLookAt(
    0,0,0, dir.getX(),dir.getY(),dir.getZ(), up.getX(),up.getY(),up.getZ()
  );
}

void GLCamera::applyPerspective() {
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
	float aspect = viewHeight == 0? 1: viewWidth/viewHeight;
#ifdef USE_OGLES
  float fovy  = fieldOfView;
  float zNear = clipPlaneNear;
  float zFar  = clipPlaneFar;
  float ymax =  zNear*tan(fovy*M_PI/360.0f);
  float ymin = -ymax;
  float xmin =  ymin*aspect;
  float xmax =  ymax*aspect;
  glFrustumf(xmin, xmax, ymin, ymax, zNear, zFar);
#else // !USE_OGLES
  gluPerspective(fieldOfView,aspect,clipPlaneNear,clipPlaneFar);
#endif // !USE_OGLES
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void GLCamera::applyOrtho() {
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  float halfW = viewWidth*0.5f;
  float halfH = viewHeight*0.5f;
#ifdef USE_OGLES
  glOrthof(-halfW,halfW,-halfH,halfH,-1,clipPlaneFar);
#else // !USE_OGLES
  glOrtho(-halfW,halfW,-halfH,halfH,-1,clipPlaneFar);
#endif // !USE_OGLES
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

