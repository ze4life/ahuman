/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_BSP

#include "glextensions.h"
#include "mathtables.h"
#include "glteams.h"

#include "datasets.inc"
#include "math3d.inc"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//
// GLYawPitchAngles
//
GLYawPitchAngles::GLYawPitchAngles(): transform(), pitch(0), yaw(0) {
}

//
// GLAnimationManager
//
GLAnimationManager::GLAnimationManager():
  currFrame(-1), nextFrame(0), lastUpdate(0),
  currAnimation(-1), stopAnimation(-1)
{}

//
// GLTeamMate
//
GLTeamMate::GLTeamMate(GLBot* bot):
  status(NORMAL), genericData(NULL), flashShown(false), dead(false),
  lastTorsoAnimation(-1)
{
  setMaxRadius(bot->getMaxRadius());
  setLegsAnimation(bot,bot->getLowerAnimation());
  setTorsoAnimation(bot,bot->getUpperAnimation());
  setVisible(true);
}

//
// GLTeams
//
GLTeams::GLTeams(
  int iTeamsCount, int iTeamMates, GLBot& iBot,
  GLBasicMaterial** iBodyMaterials, GLBasicMaterial** iTorsoMaterials,
  GLModel& iSign, int iWeaponsCount, GLModel** iWeapon, GLModel** iFlash,
  float lod, GLTexture* iShadowTexture, float iShadowWidth, float iShadowHeight
):
  weaponData(NULL), weaponsCount(iWeaponsCount), teamsCount(iTeamsCount),
  bot(&iBot), signMaterial(iSign.getBasicMaterial()->acquireReference()),
  defaultTorsoFrame(iBot.getUpper().currFrame), lodDistance(lod),
  shadowTexture(iShadowTexture? iShadowTexture->acquireReference(): NULL),
  shadowWidth(iShadowWidth), shadowHeight(iShadowHeight)
{
  weaponLists = new GLDisplayList[weaponsCount];
  weaponMaterials = new GLBasicMaterial*[weaponsCount];
  flashLists = new GLDisplayList[weaponsCount];
  flashTextures = new GLTexture*[weaponsCount];
  for(int ct = 0; ct < weaponsCount; ct++) {
    weaponMaterials[ct] = iWeapon[ct]->getBasicMaterial()->acquireReference();
    flashTextures[ct] =
      iFlash[ct]->getBasicMaterial()->getDiffuseTexture()->acquireReference();
    flashLists[ct].compileBegin();
    for(int ctLink = 0; ctLink < iWeapon[ct]->bone->linksCount; ctLink++) {
      if(*(int*)("flash") != *(int*)(iWeapon[ct]->bone->linkNames[ctLink]+4))
        continue;
      float transform[16];
      iWeapon[ct]->bone->transforms[ctLink].fillArray(transform);
      glMultMatrixf(transform);
      break;
    }
    iFlash[ct]->drawPrimitives();
    flashLists[ct].compileEnd();
    weaponLists[ct].compileBegin();
    iWeapon[ct]->drawPrimitives();
    weaponLists[ct].compileEnd();
  }
  signList.compileBegin();
  iSign.drawPrimitives();
  signList.compileEnd();
  bot->updateFrame();
  bot->getUpper().updateFrame();
  bot->getHead().updateFrame();
  headList.compileBegin();
  bot->getHead().drawPrimitives();
  headList.compileEnd();
  torsoList.compileBegin();
  bot->getUpper().drawPrimitives();
  torsoList.compileEnd();
  team = new DSSortedArray<GLTeamMate>*[teamsCount];
  bodyMaterials = new GLBasicMaterial*[teamsCount];
  torsoMaterials = new GLBasicMaterial*[teamsCount];
  for(int ct = 0; ct < teamsCount; ct++) {
    team[ct] = new DSSortedArray<GLTeamMate>(iTeamMates);
    for(int mat = 0; mat < iTeamMates; mat++)
      team[ct]->addElement(
        static_cast<DSSortableObject*>(new GLTeamMate(bot))
      );
    bodyMaterials[ct] = iBodyMaterials[ct]->acquireReference();
    torsoMaterials[ct] = iTorsoMaterials? (
      iTorsoMaterials[ct]? iTorsoMaterials[ct]->acquireReference(): NULL
    ): NULL;
  }
}

GLTeams::~GLTeams() {
  if(shadowTexture)
    shadowTexture->releaseReference();
  if(weaponMaterials) {
    for(int ct = 0; ct < weaponsCount; ct++) {
      if(weaponMaterials[ct])
        weaponMaterials[ct]->releaseReference();
    }
    delete weaponMaterials;
  }
  if(flashTextures) {
    for(int ct = 0; ct < weaponsCount; ct++) {
      if(flashTextures[ct])
        flashTextures[ct]->releaseReference();
    }
    delete flashTextures;
  }
  if(signMaterial)
    signMaterial->releaseReference();
  if(team) {
    for(int ct = 0; ct < teamsCount; ct++)
      if(team[ct]) delete team[ct];
    delete team;
  }
  if(bodyMaterials) {
    for(int ct = 0; ct < teamsCount; ct++) {
      if(bodyMaterials[ct])
        bodyMaterials[ct]->releaseReference();
    }
    delete bodyMaterials;
  }
  if(torsoMaterials) {
    for(int ct = 0; ct < teamsCount; ct++) {
      if(torsoMaterials[ct])
        torsoMaterials[ct]->releaseReference();
    }
    delete torsoMaterials;
  }
  if(weaponLists)
    delete[] weaponLists;
  if(flashLists)
    delete[] flashLists;
}

void GLTeams::initRender(GLCamera& camera, GLScenery& scenery) {
  for(int tid = 0; tid < teamsCount; tid++) {
    for(int ct = 0; ct < team[tid]->getSize(); ct++) {
      GLObject* obj = team[tid]->getElement(ct);
      if(obj->isVisible()) {
        obj->clip(camera);
        if((!obj->isClipped()) && (!scenery.checkVisibility(camera,obj)))
          obj->setClipped(true);
      }
    }
    team[tid]->quickSort(0,team[tid]->getSize()-1);
  }
}

void GLTeams::renderBodies(GLCamera& camera, GLScenery& scenery) {
  for(int tid = 0; tid < teamsCount; tid++) {
    bodyMaterials[tid]->apply();
    for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
      GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
      if((!mate->isClipped()) && (mate->isVisible())) {
        scenery.initRender(camera,mate);
        mate->updateFrames(bot);
        glPushMatrix();
        glMultMatrixf(mate->getTransform());
        GLModel& lower = bot->getLower();
        if(isGTLodDistance(mate->getDistance())) {
          lower.drawPrimitivesNoInterpol();
          for(int ctLink = 0; ctLink < lower.bone->linksCount; ctLink++) {
            if(*(int*)("torso") != *(int*)(lower.bone->linkNames[ctLink]+4))
              continue;
            float transform[16];
            lower.bone->transforms[
              lower.currFrame*(lower.bone->linksCount)+ctLink
            ].fillArray(transform);
            glMultMatrixf(transform);
            glMultMatrixf(mate->getTorsoAngles().getTransform());
            GLModel& torso = bot->getUpper();
            if(torso.currFrame == defaultTorsoFrame) {
              getTorsoList().execute();
            } else {
              torso.drawPrimitivesNoInterpol();
            }
            mate->saveTransform();
            break;
          }
        } else {
          lower.drawPrimitives();
          for(int ctLink = 0; ctLink < lower.bone->linksCount; ctLink++) {
            if(*(int*)("torso") != *(int*)(lower.bone->linkNames[ctLink]+4))
              continue;
            float transform[16];
            if(lower.currFrame == lower.nextFrame) {
              lower.bone->transforms[
                lower.currFrame*(lower.bone->linksCount)+ctLink
              ].fillArray(transform);
            } else {
              MD3Transform& startTr =
                lower.bone->transforms[
                  lower.currFrame*(lower.bone->linksCount)+ctLink
                ];
              M3Quaternion start(startTr.rotation.matrix);
              MD3Transform& endTr =
                lower.bone->transforms[
                  lower.nextFrame*(lower.bone->linksCount)+ctLink
                ];
              M3Quaternion end(endTr.rotation.matrix);
              start.slerp(end,lower.interpolation);
              start.fillArray(transform);
              float* startPos = startTr.position.coord;
              float* endPos = endTr.position.coord;
              transform[12] =
                startPos[0]+lower.interpolation*(endPos[0]-startPos[0]);
              transform[13] =
                startPos[1]+lower.interpolation*(endPos[1]-startPos[1]);
              transform[14] =
                startPos[2]+lower.interpolation*(endPos[2]-startPos[2]);
            }
            glMultMatrixf(transform);
            glMultMatrixf(mate->getTorsoAngles().getTransform());
            GLModel& torso = bot->getUpper();
            if(torso.currFrame == defaultTorsoFrame) {
              getTorsoList().execute();
            } else {
              torso.drawPrimitives();
            }
            mate->saveTransform();
            break;
          }
        }
        glPopMatrix();
      }
    }
    bodyMaterials[tid]->unapply();
  }
}

void GLTeams::renderLegs(GLCamera& camera, GLScenery& scenery) {
  for(int tid = 0; tid < teamsCount; tid++) {
    bodyMaterials[tid]->apply();
    for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
      GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
      if((!mate->isClipped()) && (mate->isVisible())) {
        scenery.initRender(camera,mate);
        mate->updateLegsFrames(bot);
        glPushMatrix();
        glMultMatrixf(mate->getTransform());
        GLModel& lower = bot->getLower();
        if(isGTLodDistance(mate->getDistance())) {
          lower.drawPrimitivesNoInterpol();
          for(int ctLink = 0; ctLink < lower.bone->linksCount; ctLink++) {
            if(*(int*)("torso") != *(int*)(lower.bone->linkNames[ctLink]+4))
              continue;
            float transform[16];
            lower.bone->transforms[
              lower.currFrame*(lower.bone->linksCount)+ctLink
            ].fillArray(transform);
            glMultMatrixf(transform);
            glMultMatrixf(mate->getTorsoAngles().getTransform());
            mate->saveTransform();
            break;
          }
        } else {
          lower.drawPrimitives();
          for(int ctLink = 0; ctLink < lower.bone->linksCount; ctLink++) {
            if(*(int*)("torso") != *(int*)(lower.bone->linkNames[ctLink]+4))
              continue;
            float transform[16];
            if(lower.currFrame == lower.nextFrame) {
              lower.bone->transforms[
                lower.currFrame*(lower.bone->linksCount)+ctLink
              ].fillArray(transform);
            } else {
              MD3Transform& startTr =
                lower.bone->transforms[
                  lower.currFrame*(lower.bone->linksCount)+ctLink
                ];
              M3Quaternion start(startTr.rotation.matrix);
              MD3Transform& endTr =
                lower.bone->transforms[
                  lower.nextFrame*(lower.bone->linksCount)+ctLink
                ];
              M3Quaternion end(endTr.rotation.matrix);
              start.slerp(end,lower.interpolation);
              start.fillArray(transform);
              float* startPos = startTr.position.coord;
              float* endPos = endTr.position.coord;
              transform[12] =
                startPos[0]+lower.interpolation*(endPos[0]-startPos[0]);
              transform[13] =
                startPos[1]+lower.interpolation*(endPos[1]-startPos[1]);
              transform[14] =
                startPos[2]+lower.interpolation*(endPos[2]-startPos[2]);
            }
            glMultMatrixf(transform);
            glMultMatrixf(mate->getTorsoAngles().getTransform());
            mate->saveTransform();
            break;
          }
        }
        glPopMatrix();
      }
    }
    bodyMaterials[tid]->unapply();
  }
}

void GLTeams::renderTorsos(GLCamera& camera, GLScenery& scenery) {
  for(int tid = 0; tid < teamsCount; tid++) {
    if(torsoMaterials[tid])
      torsoMaterials[tid]->apply();
    else
      bodyMaterials[tid]->apply();
    for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
      GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
      if((!mate->isClipped()) && (mate->isVisible())) {
        scenery.initRender(camera,mate);
        mate->updateTorsoFrames(bot);
        glPushMatrix();
        mate->loadTransform();
        GLModel& torso = bot->getUpper();
        if(torso.currFrame == defaultTorsoFrame) {
          getTorsoList().execute();
        } else {
          if(isGTLodDistance(mate->getDistance())) {
            torso.drawPrimitivesNoInterpol();
          } else {
            torso.drawPrimitives();
          }
        }
        glPopMatrix();
      }
    }
    if(torsoMaterials[tid])
      torsoMaterials[tid]->unapply();
    else
      bodyMaterials[tid]->unapply();
  }
}

void GLTeams::renderWeapons(GLCamera& camera, GLScenery& scenery) {
  int oldWeaponType = -1;
  GLBasicMaterial* material = NULL;
  for(int tid = 0; tid < teamsCount; tid++) {
  for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
    GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
    if((!mate->isClipped()) && (mate->isVisible())) {
      scenery.initRender(camera,mate);
      glPushMatrix();
      mate->loadTransform();
      GLModel& upper = mate->writeTorsoAnimationData(bot);
      for(int ctLink = 0; ctLink < upper.bone->linksCount; ctLink++) {
        if(*(int*)("weapon") != *(int*)(upper.bone->linkNames[ctLink]+4))
          continue;
        float transform[16];
        if(
          isGTLodDistance(mate->getDistance()) ||
          (upper.currFrame == upper.nextFrame)
        ) {
          upper.bone->transforms[
            upper.currFrame*(upper.bone->linksCount)+ctLink
          ].fillArray(transform);
        } else {
          MD3Transform& startTr =
            upper.bone->transforms[
              upper.currFrame*(upper.bone->linksCount)+ctLink
            ];
          M3Quaternion start(startTr.rotation.matrix);
          MD3Transform& endTr =
            upper.bone->transforms[
              upper.nextFrame*(upper.bone->linksCount)+ctLink
            ];
          M3Quaternion end(endTr.rotation.matrix);
          start.slerp(end,upper.interpolation);
          start.fillArray(transform);
          float* startPos = startTr.position.coord;
          float* endPos = endTr.position.coord;
          transform[12] =
            startPos[0]+upper.interpolation*(endPos[0]-startPos[0]);
          transform[13] =
            startPos[1]+upper.interpolation*(endPos[1]-startPos[1]);
          transform[14] =
            startPos[2]+upper.interpolation*(endPos[2]-startPos[2]);
        }
        glMultMatrixf(transform);
        switch(mate->getStatus()) {
          case GLTeamMate::NORMAL: {
            break;
          }
          case GLTeamMate::HAS_SIGN: {
            if(oldWeaponType != GLTeamMate::HAS_SIGN) {
              if(oldWeaponType >= 0)
                material->unapply();
              material = signMaterial;
              material->apply();
              oldWeaponType = GLTeamMate::HAS_SIGN;
            }
            getSignList().execute();
            break;
          }
          case GLTeamMate::HAS_WEAPON:
          case GLTeamMate::HAS_WEAPON2:
          default:
          {
            int weaponType = mate->getStatus();
            int weaponIdx = weaponType-GLTeamMate::HAS_WEAPON;
            if(oldWeaponType != weaponType) {
              if(oldWeaponType >= 0)
                material->unapply();
              material = weaponMaterials[weaponIdx];
              material->apply();
              oldWeaponType = weaponType;
            }
            getWeaponList(weaponIdx).execute();
            break;
          }
        }
        mate->saveTransform();
        break;
      }
      glPopMatrix();
    }
  }
  }
  if(oldWeaponType >= 0)
    material->unapply();
}

void GLTeams::renderHeads(GLCamera& camera, GLScenery& scenery) {
  GLBasicMaterial* m = bot->getHead().getBasicMaterial();
  m->apply();
  for(int tid = 0; tid < teamsCount; tid++) {
  for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
    GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
    if((!mate->isClipped()) && (mate->isVisible())) {
      scenery.initRender(camera,mate);
      glPushMatrix();
      mate->loadTransform();
      GLModel& upper = mate->writeTorsoAnimationData(bot);
      for(int ctLink = 0; ctLink < upper.bone->linksCount; ctLink++) {
        if(*(int*)("head") != *(int*)(upper.bone->linkNames[ctLink]+4))
          continue;
        float transform[16];
        if(
          isGTLodDistance(mate->getDistance()) ||
          (upper.currFrame == upper.nextFrame)
        ) {
          upper.bone->transforms[
            upper.currFrame*(upper.bone->linksCount)+ctLink
          ].fillArray(transform);
        } else {
          MD3Transform& startTr =
            upper.bone->transforms[
              upper.currFrame*(upper.bone->linksCount)+ctLink
            ];
          M3Quaternion start(startTr.rotation.matrix);
          MD3Transform& endTr =
            upper.bone->transforms[
              upper.nextFrame*(upper.bone->linksCount)+ctLink
            ];
          M3Quaternion end(endTr.rotation.matrix);
          start.slerp(end,upper.interpolation);
          start.fillArray(transform);
          float* startPos = startTr.position.coord;
          float* endPos = endTr.position.coord;
          transform[12] =
            startPos[0]+upper.interpolation*(endPos[0]-startPos[0]);
          transform[13] =
            startPos[1]+upper.interpolation*(endPos[1]-startPos[1]);
          transform[14] =
            startPos[2]+upper.interpolation*(endPos[2]-startPos[2]);
        }
        glMultMatrixf(transform);
        glMultMatrixf(mate->getHeadAngles().getTransform());
        getHeadList().execute();
        break;
      }
      glPopMatrix();
    }
  }
  }
  if(!m->hasDiffuse())
    glEnable(GL_TEXTURE_2D);
  if(scenery.isShadowed() && shadowTexture) {
  glDisable(GL_CULL_FACE);
  glDepthMask(GL_FALSE);
  glEnable(GL_BLEND);
  glEnable(GL_ALPHA_TEST);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_LIGHTING);
  glColor3f(0,0,0);
  shadowTexture->apply();
  const float HALF_WIDTH = shadowWidth*0.5f;
  const float HALF_HEIGHT = shadowHeight*0.5f;
  for(int tid = 0; tid < teamsCount; tid++) {
    for(int ct = team[tid]->getSize()-1; ct >= 0; ct--) {
      GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
      scenery.initRender(camera,mate);
      M3Vector& L = scenery.areShadowsStatic()?
        scenery.getStaticLightDirection():
        camera.getNearestLightVector();
      if(L.getY() <= 0)
        continue;
      float x = mate->getPositionX();
      float y = mate->getPositionY();
      float z = mate->getPositionZ();
      float lenXZ = (float)sqrt(L.getX()*L.getX()+L.getZ()*L.getZ());
      float invLenXZ = (lenXZ == 0)? 1: 1/lenXZ;
      float Lx = L.getX()*invLenXZ;
      float Lz = L.getZ()*invLenXZ;
      float invLy = 1/L.getY();
      float k = -y*invLy;
      float Ox = k*Lx+x;
      float Oz = k*Lz+z;
      float S = HALF_WIDTH;
      float Sx =  S*Lz;
      float Sz = -S*Lx;
      float U = HALF_HEIGHT*invLy;
      float Ux =  U*Lx;
      float Uz =  U*Lz;
      const int VERTEXES_COUNT = 4;
      float arrays[(2+3)*VERTEXES_COUNT] = {
        0,0, Ox-Sx-Ux,10,Oz-Sz-Uz,
        1,0, Ox+Sx-Ux,10,Oz+Sz-Uz,
        1,1, Ox+Sx+Ux,10,Oz+Sz+Uz,
        0,1, Ox-Sx+Ux,10,Oz-Sz+Uz,
      };
      glInterleavedArrays(GL_T2F_V3F,0,arrays);
      glDrawArrays(GL_QUADS,0,VERTEXES_COUNT);
    }
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glEnable(GL_LIGHTING);
  glEnable(GL_CULL_FACE);
  glDisable(GL_ALPHA_TEST);
  glDisable(GL_BLEND);
  glDepthMask(GL_TRUE);
  }
}

void GLTeams::renderFlashes(GLCamera& camera, GLScenery& scenery) {
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE,GL_ONE);
  glDepthMask(GL_FALSE);
  glDisable(GL_LIGHTING);
  glColor3f(1,1,1);
  glPushMatrix();
  int oldWeaponType = -1;
  for(int tid = 0; tid < teamsCount; tid++) {
  for(int ct = 0; ct < team[tid]->getSize(); ct++) {
    GLTeamMate* mate = dynamic_cast<GLTeamMate*>(team[tid]->getElement(ct));
    if((!mate->isClipped()) && mate->isFlashShown() && (mate->isVisible())) {
      mate->loadTransform();
      int weaponType = mate->getStatus();
      int weaponIdx = weaponType-GLTeamMate::HAS_WEAPON;
      if(oldWeaponType != weaponType) {
        flashTextures[weaponIdx]->apply();
        oldWeaponType = weaponType;
      }
      getFlashList(weaponIdx).execute();
    }
  }
  }
  glPopMatrix();
  glEnable(GL_LIGHTING);
  glDisable(GL_BLEND);
  glDepthMask(GL_TRUE);
  glEnable(GL_CULL_FACE);
}

void GLTeams::renderDropped(GLCamera& camera, GLScenery& scenery) {
  const float ROTATION_SPEED = 90;
  M3Vector pos;
  int type;
  int attrib;
  int oldType = -1;
  GLBasicMaterial* material = NULL;
  for(int index = 0; weaponData->getWeaponStatus(index,pos,type,attrib);) {
    switch(type) {
      case GLWeaponData::ID_SIGN: {
        float x = pos.getX();
        float y = pos.getY();
        float z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        )
          continue;
        if(type != oldType) {
          if(oldType >= 0)
            material->unapply();
          material = signMaterial;
          material->apply();
          oldType = type;
        }
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        glRotatef(-90,1,0,0);
        getSignList().execute();
        glPopMatrix();
        break;
      }
      case GLWeaponData::ID_WEAPON:
      case GLWeaponData::ID_WEAPON2:
      default:
      {
        float x = pos.getX();
        float y = pos.getY();
        float z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        )
          continue;
        int weaponType = type-GLWeaponData::ID_WEAPON;
        if(type != oldType) {
          if(oldType >= 0)
            material->unapply();
          material = weaponMaterials[weaponType];
          material->apply();
          oldType = type;
        }
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        glRotatef(-90,1,0,0);
        getWeaponList(weaponType).execute();
        glPopMatrix();
        break;
      }
    }
  }
  if(oldType >= 0)
    material->unapply();
}

void GLTeams::render(GLCamera& camera, GLScenery& scenery) {
  glCullFace(GL_FRONT);
  if(torsoMaterials[0]) {
    renderLegs(camera,scenery);
    renderTorsos(camera,scenery);
  } else {
    renderBodies(camera,scenery);
  }
  renderHeads(camera,scenery);
  renderWeapons(camera,scenery);
  renderDropped(camera,scenery);
  renderFlashes(camera,scenery);
  glCullFace(GL_BACK);
}

//
// GLPowerups
//
GLPowerups::GLPowerups(
  GLModel& iMedikit, GLModel& iFood, GLModel& iArmor, GLModel& iBullets,
  GLModel& iGrenades, GLModel& iTarget, GLPowerupData& pd,
  GLTexture* iShadowTexture
):
  powerupData(&pd),
  medikitMaterial(iMedikit.getBasicMaterial()->acquireReference()),
  foodMaterial(iFood.getBasicMaterial()->acquireReference()),
  armorMaterial(iArmor.getBasicMaterial()->acquireReference()),
  bulletsMaterial(iBullets.getBasicMaterial()->acquireReference()),
  grenadesMaterial(iGrenades.getBasicMaterial()->acquireReference()),
  targetMaterial(iTarget.getBasicMaterial()->acquireReference()),
  shadowTexture(iShadowTexture? iShadowTexture->acquireReference(): NULL)
{
  medikitList.compileBegin();
  glPushMatrix();
  glRotatef(-90,1,0,0);
  iMedikit.drawPrimitives();
  glPopMatrix();
  medikitList.compileEnd();
  foodList.compileBegin();
  glPushMatrix();
  glRotatef(-90,1,0,0);
  iFood.drawPrimitives();
  glPopMatrix();
  foodList.compileEnd();
  armorList.compileBegin();
  glPushMatrix();
  glRotatef(-90,1,0,0);
  iArmor.drawPrimitives();
  glPopMatrix();
  armorList.compileEnd();
  bulletsList.compileBegin();
  glPushMatrix();
  glRotatef(-90,1,0,0);
  iBullets.drawPrimitives();
  glPopMatrix();
  bulletsList.compileEnd();
  grenadesList.compileBegin();
  glPushMatrix();
  glRotatef(-90,1,0,0);
  iGrenades.drawPrimitives();
  glPopMatrix();
  grenadesList.compileEnd();
  targetList.compileBegin();
  iTarget.drawPrimitives();
  targetList.compileEnd();
}

GLPowerups::~GLPowerups() {
  if(medikitMaterial)
    medikitMaterial->releaseReference();
  if(foodMaterial)
    foodMaterial->releaseReference();
  if(armorMaterial)
    armorMaterial->releaseReference();
  if(bulletsMaterial)
    bulletsMaterial->releaseReference();
  if(grenadesMaterial)
    grenadesMaterial->releaseReference();
  if(targetMaterial)
    targetMaterial->releaseReference();
  if(shadowTexture)
    shadowTexture->releaseReference();
}

void GLPowerups::render(GLCamera& camera, GLScenery& scenery) {
  glCullFace(GL_FRONT);
  const float ROTATION_SPEED = 90;
  float x, y, z;
  M3Vector pos;
  int type;
  int attrib;
  for(int index = 0; powerupData->getPowerupStatus(index,pos,type,attrib);) {
    bool notVisible = false;
    switch(type) {
      case GLPowerupData::ID_MEDIKIT: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = medikitMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        getMedikitList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
      case GLPowerupData::ID_FOOD: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = foodMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        getFoodList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
      case GLPowerupData::ID_ARMOR: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = armorMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        getArmorList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
      case GLPowerupData::ID_BULLETS: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = bulletsMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        getBulletsList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
      case GLPowerupData::ID_GRENADES: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = grenadesMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        glRotatef(GLModel::getAnimationTime()*ROTATION_SPEED,0,1,0);
        getGrenadesList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
      case GLPowerupData::ID_TARGET: {
        x = pos.getX();
        y = pos.getY();
        z = pos.getZ();
        if(
          !scenery.checkVisibility(camera,x,y,z) ||
          !camera.isSphereVisible(x,y,z,attrib)
        ) {
          notVisible = true;
          break;
        }
        GLBasicMaterial* material = targetMaterial;
        material->apply();
        scenery.initRender(camera,x,y,z);
        glPushMatrix();
        glTranslatef(x,y,z);
        getTargetList().execute();
        material->unapply();
        glPopMatrix();
        break;
      }
    }
    if(scenery.isShadowed() && shadowTexture) {
      if(notVisible)
        scenery.initRender(camera,x,y,z);
      M3Vector& L = scenery.areShadowsStatic()?
        scenery.getStaticLightDirection():
        camera.getNearestLightVector();
      if(L.getY() > 0) {
        glDisable(GL_CULL_FACE);
        glDepthMask(GL_FALSE);
        glEnable(GL_BLEND);
        glEnable(GL_ALPHA_TEST);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_LIGHTING);
        glEnable(GL_TEXTURE_2D);
        glColor3f(0,0,0);
        shadowTexture->apply();
        float lenXZ = (float)sqrt(L.getX()*L.getX()+L.getZ()*L.getZ());
        float invLenXZ = (lenXZ == 0)? 1: 1/lenXZ;
        float Lx = L.getX()*invLenXZ;
        float Lz = L.getZ()*invLenXZ;
        float invLy = 1/L.getY();
        float k = -y*invLy;
        float Ox = k*Lx+x;
        float Oz = k*Lz+z;
        float S = attrib;
        float Sx =  S*Lz;
        float Sz = -S*Lx;
        float U = attrib*invLy;
        float Ux =  U*Lx;
        float Uz =  U*Lz;
        const int VERTEXES_COUNT = 4;
        float arrays[(2+3)*VERTEXES_COUNT] = {
          0,0, Ox-Sx-Ux,10,Oz-Sz-Uz,
          1,0, Ox+Sx-Ux,10,Oz+Sz-Uz,
          1,1, Ox+Sx+Ux,10,Oz+Sz+Uz,
          0,1, Ox-Sx+Ux,10,Oz-Sz+Uz,
        };
        glInterleavedArrays(GL_T2F_V3F,0,arrays);
        glDrawArrays(GL_QUADS,0,VERTEXES_COUNT);
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
        glEnable(GL_LIGHTING);
        glEnable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glDepthMask(GL_TRUE);
      }
    }
  }
  glEnable(GL_TEXTURE_2D);
  glCullFace(GL_BACK);
}

//
// GLAmmo
//
GLAmmo::GLAmmo(
  int iWeaponsCount, float* hSize, float* hExplSize, GLTexture** txt,
  GLTexture** explTxt,
#ifdef USE_SOUND
  FM3DSample** explSmp, bool* soundEnabled,
#endif // USE_SOUND
  GLAmmoData& ad
):
  weaponsCount(iWeaponsCount), ammoData(&ad)
#ifdef USE_SOUND
  , isSoundEnabled(soundEnabled)
#endif // USE_SOUND
{
  halfSize = new float[weaponsCount];
  halfExplSize = new float[weaponsCount];
  texture = new GLTexture*[weaponsCount];
  explTexture = new GLTexture*[weaponsCount];
#ifdef USE_SOUND
  explSample = new FM3DSample*[weaponsCount];
#endif // USE_SOUND
  bulletsColor = new GLColor[weaponsCount];
  grenadesColor = new GLColor[weaponsCount];
  for(int ct = 0; ct < weaponsCount; ct++) {
    halfSize[ct] = hSize[ct];
    halfExplSize[ct] = hExplSize[ct];
    texture[ct] = txt[ct]->acquireReference();
    explTexture[ct] = explTxt[ct]->acquireReference();
#ifdef USE_SOUND
    explSample[ct] = explSmp[ct];
#endif // USE_SOUND
  }
}

GLAmmo::~GLAmmo() {
  if(halfSize) {
    delete halfSize;
  }
  if(halfExplSize) {
    delete halfExplSize;
  }
  if(texture) {
    for(int ct = 0; ct < weaponsCount; ct++) {
      if(texture[ct])
        texture[ct]->releaseReference();
    }
    delete texture;
  }
  if(explTexture) {
    for(int ct = 0; ct < weaponsCount; ct++) {
      if(explTexture[ct])
        explTexture[ct]->releaseReference();
    }
    delete explTexture;
  }
#ifdef USE_SOUND
  if(explSample) {
    delete explSample;
  }
#endif // USE_SOUND
  if(bulletsColor) {
    delete bulletsColor;
  }
  if(grenadesColor) {
    delete grenadesColor;
  }
}

void GLAmmo::render(GLCamera& camera, GLScenery& scenery) {
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE,GL_ONE);
  glDepthMask(GL_FALSE);
  glDisable(GL_LIGHTING);
  M3Vector halfExpSide;
  M3Vector halfSide;
  M3Vector halfExpUp;
  M3Vector halfUp;
  glNormal3f(
    -camera.getViewDirectionX(),
    -camera.getViewDirectionY(),
    -camera.getViewDirectionZ()
  );
  M3Vector pos;
  int type;
  int attrib;
  int oldWeaponType = -1;
  for(int index = 0; ammoData->getAmmoStatus(index,pos,type,attrib);) {
    bool isBullet = (type%2 == 0);
    int weaponType = type/2;
    if(isBullet) {
      glPushMatrix();
      glTranslatef(pos.getX(),pos.getY(),pos.getZ());
      glColor3f(
        bulletsColor[weaponType].getRed(),
        bulletsColor[weaponType].getGreen(),
        bulletsColor[weaponType].getBlue()
      );
      if(weaponType != oldWeaponType) {
        halfSide.set(
          camera.getSideDirectionX(),
          camera.getSideDirectionY(),
          camera.getSideDirectionZ()
        );
        halfExpSide = halfSide;
        halfSide.scale(halfSize[weaponType]);
        halfExpSide.scale(halfExplSize[weaponType]);
        halfUp.set(
          camera.getUpDirectionX(),
          camera.getUpDirectionY(),
          camera.getUpDirectionZ()
        );
        halfExpUp = halfUp;
        halfUp.scale(halfSize[weaponType]);
        halfExpUp.scale(halfExplSize[weaponType]);
        texture[weaponType]->apply();
        oldWeaponType = weaponType;
      }
      glBegin(GL_QUADS);
      glTexCoord2f(1,0);
      glVertex3f(
        -halfSide.getX()-halfUp.getX(),
        -halfSide.getY()-halfUp.getY(),
        -halfSide.getZ()-halfUp.getZ()
      );
      glTexCoord2f(1,1);
      glVertex3f(
        -halfSide.getX()+halfUp.getX(),
        -halfSide.getY()+halfUp.getY(),
        -halfSide.getZ()+halfUp.getZ()
      );
      glTexCoord2f(0,1);
      glVertex3f(
         halfSide.getX()+halfUp.getX(),
         halfSide.getY()+halfUp.getY(),
         halfSide.getZ()+halfUp.getZ()
      );
      glTexCoord2f(0,0);
      glVertex3f(
         halfSide.getX()-halfUp.getX(),
         halfSide.getY()-halfUp.getY(),
         halfSide.getZ()-halfUp.getZ()
      );
      glEnd();
      glPopMatrix();
    } else {
      glPushMatrix();
      glTranslatef(pos.getX(),pos.getY(),pos.getZ());
      if(attrib == 0) {
        glColor3f(
          grenadesColor[weaponType].getRed(),
          grenadesColor[weaponType].getGreen(),
          grenadesColor[weaponType].getBlue()
        );
        if(weaponType != oldWeaponType) {
          halfSide.set(
            camera.getSideDirectionX(),
            camera.getSideDirectionY(),
            camera.getSideDirectionZ()
          );
          halfExpSide = halfSide;
          halfSide.scale(halfSize[weaponType]);
          halfExpSide.scale(halfExplSize[weaponType]);
          halfUp.set(
            camera.getUpDirectionX(),
            camera.getUpDirectionY(),
            camera.getUpDirectionZ()
          );
          halfExpUp = halfUp;
          halfUp.scale(halfSize[weaponType]);
          halfExpUp.scale(halfExplSize[weaponType]);
          texture[weaponType]->apply();
          oldWeaponType = weaponType;
        }
        glBegin(GL_QUADS);
        glTexCoord2f(1,0);
        glVertex3f(
          -halfSide.getX()-halfUp.getX(),
          -halfSide.getY()-halfUp.getY(),
          -halfSide.getZ()-halfUp.getZ()
        );
        glTexCoord2f(1,1);
        glVertex3f(
          -halfSide.getX()+halfUp.getX(),
          -halfSide.getY()+halfUp.getY(),
          -halfSide.getZ()+halfUp.getZ()
        );
        glTexCoord2f(0,1);
        glVertex3f(
           halfSide.getX()+halfUp.getX(),
           halfSide.getY()+halfUp.getY(),
           halfSide.getZ()+halfUp.getZ()
        );
        glTexCoord2f(0,0);
        glVertex3f(
           halfSide.getX()-halfUp.getX(),
           halfSide.getY()-halfUp.getY(),
           halfSide.getZ()-halfUp.getZ()
        );
        glEnd();
      } else {
        if(attrib < 0) {
          attrib = -attrib;
#ifdef USE_SOUND
          if(*isSoundEnabled)
            explSample[weaponType]->playAt(pos.getX(),pos.getY(),pos.getZ());
#endif // USE_SOUND
        }
        attrib--;
        float x = (3-attrib%4)*0.25f;
        float y = (attrib>>2)*0.25f;
        glColor3f(1,1,1);
        explTexture[weaponType]->apply();
        if(weaponType != oldWeaponType) {
          halfSide.set(
            camera.getSideDirectionX(),
            camera.getSideDirectionY(),
            camera.getSideDirectionZ()
          );
          halfExpSide = halfSide;
          halfSide.scale(halfSize[weaponType]);
          halfExpSide.scale(halfExplSize[weaponType]);
          halfUp.set(
            camera.getUpDirectionX(),
            camera.getUpDirectionY(),
            camera.getUpDirectionZ()
          );
          halfExpUp = halfUp;
          halfUp.scale(halfSize[weaponType]);
          halfExpUp.scale(halfExplSize[weaponType]);
          oldWeaponType = weaponType;
        }
        glBegin(GL_QUADS);
        glTexCoord2f(x+0.25f,y);
        glVertex3f(
          -halfExpSide.getX()-halfExpUp.getX(),
          -halfExpSide.getY()-halfExpUp.getY(),
          -halfExpSide.getZ()-halfExpUp.getZ()
        );
        glTexCoord2f(x+0.25f,y+0.25f);
        glVertex3f(
          -halfExpSide.getX()+halfExpUp.getX(),
          -halfExpSide.getY()+halfExpUp.getY(),
          -halfExpSide.getZ()+halfExpUp.getZ()
        );
        glTexCoord2f(x,y+0.25f);
        glVertex3f(
           halfExpSide.getX()+halfExpUp.getX(),
           halfExpSide.getY()+halfExpUp.getY(),
           halfExpSide.getZ()+halfExpUp.getZ()
        );
        glTexCoord2f(x,y);
        glVertex3f(
           halfExpSide.getX()-halfExpUp.getX(),
           halfExpSide.getY()-halfExpUp.getY(),
           halfExpSide.getZ()-halfExpUp.getZ()
        );
        glEnd();
        texture[weaponType]->apply();
      }
      glPopMatrix();
    }
  }
  glEnable(GL_LIGHTING);
  glDisable(GL_ALPHA_TEST);
  glDisable(GL_BLEND);
  glDepthMask(GL_TRUE);
  glEnable(GL_CULL_FACE);
}

#endif // USE_BSP

