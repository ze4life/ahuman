/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "strings.h"

//
// String
//
String::String(const char* t) {
  if(t == NULL) {
    size = 1;
    text = new char[size];
    text[0] = '\0';
  } else {
    size = strlen(t)+1;
    text = new char[size];
    strcpy(text,t);
  }
}

String::String(const char* t1, const char* t2) {
  size = strlen(t1)+strlen(t2)+1;
  text = new char[size];
  strcat(strcpy(text,t1),t2);
}

String::String(int value) {
  size = 16;
  text = new char[size];
  itoa(value,text,10);
}

String::~String() {
  if(text) delete text;
}

void String::setText(const char* t) {
  int newSize = strlen(t)+1;
  if(newSize > size) {
    char* newText = new char[newSize];
    if(text) delete text;
    text = newText;
    size = newSize;
  }
  strcpy(text,t);
}

void String::concat(const char* t) {
  int newSize = strlen(text)+strlen(t)+1;
  if(newSize > size) {
    char* newText = new char[newSize];
    strcpy(newText,text);
    if(text) delete text;
    text = newText;
    size = newSize;
  }
  strcat(text,t);
}

void String::insert(char c, int pos) {
  int len = strlen(text);
  if(pos > len || pos < 0) return;
  int newSize = len+1+1;
  if(newSize > size) {
    char* newText = new char[newSize];
    strcpy(newText,text);
    if(text) delete text;
    text = newText;
    size = newSize;
  }
  for(int ct = len; ct >= pos; ct--)
    text[ct+1] = text[ct];
  text[pos] = c;
}

void String::del(int pos) {
  int len = strlen(text);
  if(pos > len || pos < 0) return;
  for(int ct = pos; ct < len; ct++)
    text[ct] = text[ct+1];
}

void String::setInt(int value) {
  char txt[16];
  itoa(value,txt,10);
  setText(txt);
}

