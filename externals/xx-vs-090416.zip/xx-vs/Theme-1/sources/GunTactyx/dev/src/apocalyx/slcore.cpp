/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

#include <ctype.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>   // for time()

#include "small/amx.h"

typedef unsigned char uchar;

static cell AMX_NATIVE_CALL numargs(AMX *amx, cell *params) {
  AMX_HEADER *hdr;
  uchar *data;
  cell bytes;
  hdr = (AMX_HEADER *)amx->base;
  data = amx->base+(int)hdr->dat;
  bytes = * (cell *)(data+(int)amx->frm+2*sizeof(cell));
  return bytes/sizeof(cell);
}

static cell AMX_NATIVE_CALL getarg(AMX *amx, cell *params) {
  AMX_HEADER *hdr;
  uchar *data;
  cell value;
  hdr = (AMX_HEADER *)amx->base;
  data = amx->base+(int)hdr->dat;
  value = * (cell *)(data+(int)amx->frm+((int)params[1]+3)*sizeof(cell));
  value += params[2]*sizeof(cell);
  value = * (cell *)(data+(int)value);
  return value;
}

static cell AMX_NATIVE_CALL setarg(AMX *amx, cell *params) {
  AMX_HEADER *hdr;
  uchar *data;
  cell value;
  hdr = (AMX_HEADER *)amx->base;
  data = amx->base+(int)hdr->dat;
  value = * (cell *)(data+(int)amx->frm+((int)params[1]+3)*sizeof(cell));
  value += params[2]*sizeof(cell);
  if(value<0 || value>=amx->hea && value<amx->stk)
    return 0;
  * (cell *)(data+(int)value) = params[3];
  return 1;
}

static cell AMX_NATIVE_CALL heapspace(AMX *amx,cell *params) {
  return amx->stk - amx->hea;
}

int amx_StrPack(cell *dest,cell *source) {
  int len;
  amx_StrLen(source,&len);
  if(*source > UCHAR_MAX) {
    while(len >= 0) {
      *dest++ = *source++;
      len-=sizeof(cell);
    }
  } else {
    cell c;
    int i;
    for(c = 0, i = 0; i < len; i++) {
      c = (c<<8) | *source++;
      if(i%sizeof(cell) == sizeof(cell)-1) {
        *dest++=c;
        c=0;
      }
    }
    if(i%sizeof(cell) != 0)
      *dest=c << (sizeof(cell)-i%sizeof(cell))*8;
    else
      *dest=0;
  }
  return AMX_ERR_NONE;
}

int amx_StrUnpack(cell *dest,cell *source) {
  if (*source>UCHAR_MAX) {
    cell c;
    int i,len;
    amx_StrLen(source,&len);
    dest[len]=0;
    for(i = len-1; i >= 0; i--) {
      c=source[i/sizeof(cell)] >> (sizeof(cell)-i%sizeof(cell)-1)*8;
      dest[i]=c & UCHAR_MAX;
    }
  } else {
    while ((*dest++ = *source++) != 0)
      ;
  }
  return AMX_ERR_NONE;
}

static int verify_addr(AMX *amx,cell addr) {
  int err;
  cell *cdest;
  err = amx_GetAddr(amx,addr,&cdest);
  if(err != AMX_ERR_NONE)
    amx_RaiseError(amx,err);
  return err;
}

static cell AMX_NATIVE_CALL core_strlen(AMX *amx,cell *params) {
  cell *cptr;
  int len = 0;
  if(amx_GetAddr(amx,params[1],&cptr) == AMX_ERR_NONE)
    amx_StrLen(cptr,&len);
  return len;
}

static cell AMX_NATIVE_CALL strpack(AMX *amx,cell *params) {
  cell *cdest,*csrc;
  int len,needed,err;
  amx_GetAddr(amx,params[2],&csrc);
  amx_StrLen(csrc,&len);
  needed=(len+sizeof(cell)-1)/sizeof(cell);
  if(verify_addr(amx,(cell)(params[1]+needed)) != AMX_ERR_NONE)
    return 0;
  amx_GetAddr(amx,params[1],&cdest);
  err=amx_StrPack(cdest,csrc);
  if (err!=AMX_ERR_NONE)
    return amx_RaiseError(amx,err);
  return len;
}

static cell AMX_NATIVE_CALL strunpack(AMX *amx,cell *params) {
  cell *cdest,*csrc;
  int len,err;
  amx_GetAddr(amx,params[2],&csrc);
  amx_StrLen(csrc,&len);
  if(verify_addr(amx,(cell)(params[1]+len+1)) != AMX_ERR_NONE)
    return 0;
  amx_GetAddr(amx,params[1],&cdest);
  err=amx_StrUnpack(cdest,csrc);
  if(err != AMX_ERR_NONE)
    return amx_RaiseError(amx,err);
  return len;
}

static cell AMX_NATIVE_CALL core_min(AMX *amx,cell *params) {
  return params[1] <= params[2] ? params[1] : params[2];
}

static cell AMX_NATIVE_CALL core_max(AMX *amx,cell *params) {
  return params[1] >= params[2] ? params[1] : params[2];
}

static cell AMX_NATIVE_CALL core_clamp(AMX *amx,cell *params) {
  cell value = params[1];
  if(params[2] > params[3])
    amx_RaiseError(amx,AMX_ERR_NATIVE);
  if(value < params[2])
    value = params[2];
  else if(value > params[3])
    value = params[3];
  return value;
}

/* This routine comes from the book "Inner Loops" by Rick Booth, Addison-Wesley
 * (ISBN 0-201-47960-5). This is a "multiplicative congruential random number
 * generator" that has been extended to 31-bits (the standard C version returns
 * only 15-bits).
 */

//static unsigned long IL_StandardRandom_seed = 0L; // moved to AMX
#define IL_RMULT 1103515245L
static cell AMX_NATIVE_CALL core_random(AMX *amx,cell *params) {
  unsigned long lo, hi, ll, lh, hh, hl;
  unsigned long result;
  if (amx->IL_StandardRandom_seed == 0L)
    amx->IL_StandardRandom_seed=(unsigned long)time(NULL);
  lo = amx->IL_StandardRandom_seed & 0xffff;
  hi = amx->IL_StandardRandom_seed >> 16;
  amx->IL_StandardRandom_seed = amx->IL_StandardRandom_seed * IL_RMULT + 12345;
  ll = lo * (IL_RMULT  & 0xffff);
  lh = lo * (IL_RMULT >> 16    );
  hl = hi * (IL_RMULT  & 0xffff);
  hh = hi * (IL_RMULT >> 16    );
  result = ((ll + 12345) >> 16) + lh + hl + (hh << 16);
  result &= ~LONG_MIN;
  if(params[1] != 0)
    result %= params[1];
  return (cell)result;
}

/* // stdlib version
static cell AMX_NATIVE_CALL core_random(AMX *amx,cell *params) {
  return (cell)random(params[1]? params[1]: LRAND_MAX);
}
*/

static cell AMX_NATIVE_CALL core_seed(AMX *amx,cell *params) {
  if(params[1] != 0)
    amx->IL_StandardRandom_seed = (unsigned long)params[1];
//  else  // no change if 0
//    amx->IL_StandardRandom_seed = (unsigned long)time(NULL);
  return amx->IL_StandardRandom_seed;
}

/* // stdlib version
static cell AMX_NATIVE_CALL core_seed(AMX *amx,cell *params) {
  if(params[1] != 0) {
    srand(params[1]);
    return params[1];
  } else {
    unsigned int ret = (unsigned int)time(NULL);
    srand(ret);
    return (cell)ret;
  }
}
*/

extern "C" {
  int sc_printf(const char *message, ...);
}

static cell AMX_NATIVE_CALL _print(AMX *amx, cell *params) {
  cell *cstr;
  amx_GetAddr(amx,params[1],&cstr);
  if(cstr[0] >= (1L<<8*sizeof(char))) {
    int j = sizeof(cell)-sizeof(char);
    int ct = 0;
    char c;
    while((c = (char)((ucell)cstr[ct] >> 8*j)) != 0 && ct < 80) {
      sc_printf("%c",c);
      if(j == 0) ct++;
      j = (j+sizeof(cell)-sizeof(char)) % sizeof(cell);
    }
  } else {
    for(int ct = 0; cstr[ct] != 0 && ct < 80; ct++)
      sc_printf("%c",cstr[ct]);
  }
  return 0;
}

static cell AMX_NATIVE_CALL _printint(AMX *amx, cell *params) {
  sc_printf("%d",params[1]);
  return 0;
}

static cell AMX_NATIVE_CALL _printflt(AMX *amx, cell *params) {
  sc_printf("%f",*(float*)(&params[1]));
  return 0;
}

static int printstring(AMX *amx, cell *cstr, cell *params, int num);

static int dochar(AMX *amx, char ch, cell param) {
  cell *cptr;
  switch (ch) {
    case '%':
      sc_printf("%");
      return 0;
    case 'c':
      amx_GetAddr(amx,param,&cptr);
      sc_printf("%c",(int)*cptr);
      return 1;
    case 'd':
      amx_GetAddr(amx,param,&cptr);
      sc_printf("%ld",(long)*cptr);
      return 1;
    case 'f':
      amx_GetAddr(amx,param,&cptr);
      sc_printf("%f",*(float*)cptr);
      return 1;
    case 's':
      amx_GetAddr(amx,param,&cptr);
      printstring(amx,cptr,NULL,0);
      return 1;
  }
  sc_printf("%c",ch);
  return 0;
}

static int printstring(AMX *amx, cell *cstr, cell *params, int num) {
  int i;
  int informat = 0, paramidx = 0;
  if((ucell)*cstr>UCHAR_MAX) {
    int j = sizeof(cell)-sizeof(char);
    char c;
    i = 0;
    for(;;) {
      c = (char)((ucell)cstr[i] >> 8*j);
      if(c == 0)
        break;
      if(informat) {
        if(params == NULL) return 0;
        paramidx += dochar(amx,c,params[paramidx]);
        informat = 0;
      } else if(params != NULL && c == '%') {
        informat = 1;
      } else {
        sc_printf("%c",c);
      }
      if(j == 0)
        i++;
      j = (j+sizeof(cell)-sizeof(char)) % sizeof(cell);
    }
  } else {
    for(i = 0; cstr[i] != 0; i++) {
      if(informat) {
        if(params == NULL) return 0;
        paramidx += dochar(amx,(char)cstr[i],params[paramidx]);
        informat = 0;
      } else if(params != NULL && (int)cstr[i] == '%') {
        if(paramidx < num)
          informat = 1;
        else
          amx_RaiseError(amx, AMX_ERR_NATIVE);
      } else {
        sc_printf("%c",(int)cstr[i]);
      }
    }
  }
  return paramidx;
}

static cell AMX_NATIVE_CALL _printf(AMX *amx, cell *params) {
  cell *cstr;
  amx_GetAddr(amx,params[1],&cstr);
  printstring(amx,cstr,params+2,(int)(params[0]/sizeof(cell))-1);
  return 0;
}

AMX_NATIVE_INFO core_Natives[] = {
  { "numargs",   numargs },
  { "getarg",    getarg },
  { "setarg",    setarg },
  { "heapspace", heapspace },
  { "strlen",    core_strlen },
  { "strpack",   strpack },
  { "strunpack", strunpack },
  { "seed",      core_seed },
  { "random",    core_random },
  { "min",       core_min },
  { "max",       core_max },
  { "clamp",     core_clamp },
  { "print",     _print },
  { "printint",  _printint },
  { "printflt",  _printflt },
  { "printf",    _printf },
  { NULL, NULL }
};

#endif // USE_CONSOLE && USE_SMALL

