/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"

#include "glbackground.h"

#include <stdlib.h> // for rand()

#include "math3d.inc"

//
// GLBackground
//
GLBackground::GLBackground(
  float r, float g, float b, float a, int src, int dst
): color(r,g,b,a), srcBlend(src), dstBlend(dst)
{setVisible(true);}

GLBackground::~GLBackground() {}

//
// GLStarfield
//

GLStarfield::GLStarfield(
  float rr, int num, GLTexture* txt, float sz, bool blend
):
#ifdef USE_OGLES
  nebulaeLength(0), nebulaeArrays(NULL), starsLength(0), starsArrays(NULL),
#else // !USE_OGLES
  GLDisplayLists(2),
#endif // !USE_OGLES
  texture(txt? txt->acquireReference(): NULL)
{
  if(texture) {
#ifdef USE_OGLES
    nebulaeLength = 64;
    nebulaeArrays = new float[nebulaeLength*(2+3)*3];
    float* pointer = nebulaeArrays-1;
    for(int i = 0; i < 4; i++) {
      for(int j = 0; j < 4; j++) {
        float theta = 2*M_PI*(float(rand())/RAND_MAX-0.5f);
        float phi = asin(2*(float(rand())/RAND_MAX-0.5f));
        float rrcosphi = rr*cos(phi);
        float x = rrcosphi*cos(theta);
        float z = rrcosphi*sin(theta);
        float y = rr*sin(phi);
        M3Vector v1(x,y,z);
        M3Vector v2, v3;
        v1.plane(v2,v3);
        v2.scale(sz);
        v3.scale(sz);
        *(++pointer) = 0.25f*float(i);
        *(++pointer) = 0.25f*float(j);
        *(++pointer) = x;
        *(++pointer) = y;
        *(++pointer) = z;
        *(++pointer) = 0.25f*float(i+1);
        *(++pointer) = 0.25f*float(j);
        *(++pointer) = x+v2.getX();
        *(++pointer) = y+v2.getY();
        *(++pointer) = z+v2.getZ();
        *(++pointer) = 0.25f*float(i);
        *(++pointer) = 0.25*float(j+1);
        *(++pointer) = x+v3.getX();
        *(++pointer) = y+v3.getY();
        *(++pointer) = z+v3.getZ();
        *(++pointer) = 0.25f*float(i+1);
        *(++pointer) = 0.25f*float(j+1);
        *(++pointer) = x+v2.getX()+v3.getX();
        *(++pointer) = y+v2.getY()+v3.getY();
        *(++pointer) = z+v2.getZ()+v3.getZ();
      }
    }
#else // !USE_OGLES
    compileBegin(1);
    glBegin(GL_QUADS);
    for(int i = 0; i < 4; i++) {
      for(int j = 0; j < 4; j++) {
        float theta = 2*M_PI*(float(rand())/RAND_MAX-0.5f);
        float phi = asin(2*(float(rand())/RAND_MAX-0.5f));
        float rrcosphi = rr*cos(phi);
        float x = rrcosphi*cos(theta);
        float z = rrcosphi*sin(theta);
        float y = rr*sin(phi);
        M3Vector v1(x,y,z);
        M3Vector v2, v3;
        v1.plane(v2,v3);
        v2.scale(sz);
        v3.scale(sz);
        glTexCoord2f(0.25f*float(i),0.25f*float(j));
        glVertex3f(x,y,z);
        glTexCoord2f(0.25f*float(i+1),0.25f*float(j));
        glVertex3f(x+v2.getX(),y+v2.getY(),z+v2.getZ());
        glTexCoord2f(0.25f*float(i+1),0.25f*float(j+1));
        glVertex3f(
          x+v2.getX()+v3.getX(),y+v2.getY()+v3.getY(),z+v2.getZ()+v3.getZ()
        );
        glTexCoord2f(0.25f*float(i),0.25*float(j+1));
        glVertex3f(x+v3.getX(),y+v3.getY(),z+v3.getZ());
      }
    }
    glEnd();
    compileEnd();
#endif // !USE_OGLES
  }
#ifdef USE_OGLES
  starsLength = num;
  starsArrays = new float[starsLength*(1+3)*3];
  generateStars(starsArrays,rr,num,blend);
#else // !USE_OGLES
  compileBegin(0);
  glPointSize(2);
  glBegin(GL_POINTS);
  generateStars(rr,num/4,blend);
  glEnd();
  glPointSize(1.5f);
  glBegin(GL_POINTS);
  generateStars(rr,num/4,blend);
  glEnd();
  glPointSize(1);
  glBegin(GL_POINTS);
  generateStars(rr,num/2,blend);
  glEnd();
  compileEnd();
#endif // !USE_OGLES
}

GLStarfield::~GLStarfield() {
  if(texture) texture->releaseReference();
#ifdef USE_OGLES
  if(nebulaeArrays) delete nebulaeArrays;
  if(starsArrays) delete starsArrays;
#endif // USE_OGLES
}

#ifdef USE_OGLES

void GLStarfield::generateStars(float* pointer, float rr, int num, bool blend) {
  for(int i = 0; i < num; i++) {
    if(!blend) {
    	float luminosity = float(rand())/RAND_MAX;
	  	luminosity *= luminosity;
    	unsigned int lum = (unsigned char)(255*luminosity);
      lum |= (0xff000000|(lum<<8)|(lum<<16));
      *pointer = *(float*)&lum;
      pointer++;
    }
    float r = rr*pow((float(rand())/RAND_MAX),0.33333f);
    float theta = 2*M_PI*(float(rand())/RAND_MAX-0.5f);
    float phi = asin(2*(float(rand())/RAND_MAX-0.5f));
    float rcosphi = r*cos(phi);
    *pointer = rcosphi*cos(theta);
    pointer++;
    *pointer = rcosphi*sin(theta);
    pointer++;
    *pointer = r*sin(phi);
    pointer++;
  }
}

#else // !USE_OGLES

void GLStarfield::generateStars(float rr, int num, bool blend) {
  for(int i = 0; i < num; i++) {
    if(!blend) {
    	float luminosity = (float(rand())/RAND_MAX);
	  	luminosity *= luminosity;
		  glColor3f(luminosity,luminosity,luminosity);
    }
    float r = rr*pow((float(rand())/RAND_MAX),0.33333f);
    float theta = 2*M_PI*(float(rand())/RAND_MAX-0.5f);
    float phi = asin(2*(float(rand())/RAND_MAX-0.5f));
    float rcosphi = r*cos(phi);
    float x = rcosphi*cos(theta);
    float z = rcosphi*sin(theta);
    float y = r*sin(phi);
    glVertex3f(x,y,z);
  }
}

#endif // !USE_OGLES

void GLStarfield::render(bool blend) {
  if(!blend) {
		glClearColor(0,0,0,1);
    glClear(GL_COLOR_BUFFER_BIT);
  }
  glPushMatrix();
  glMultMatrixf(getTransform());
  bool isFoggy = glIsEnabled(GL_FOG);
  if(isFoggy) glDisable(GL_FOG);
  glDepthMask(GL_FALSE);
  glDisable(GL_LIGHTING);
  glEnable(GL_POINT_SMOOTH);
  glDisable(GL_TEXTURE_2D);
#ifdef USE_OGLES
  GLColor& clr = getColor();
  glColor4f(clr.getRed(),clr.getGreen(),clr.getBlue(),1);
  const int STRIDE = (1+3)*4;
  glEnableClientState(GL_COLOR_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glPointSize(2);
  glColorPointer(4,GL_UNSIGNED_BYTE,STRIDE,starsArrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,starsArrays+4);
  glDrawArrays(GL_POINTS,0,starsLength/4);
  glPointSize(1.5f);
  glDrawArrays(GL_POINTS,starsLength/4,starsLength/4);
  glPointSize(1);
  glDrawArrays(GL_POINTS,starsLength/2,starsLength/2);
  glDisableClientState(GL_NORMAL_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
#else // !USE_OGLES
  glColor3fv(getColor().getFloatArray());
  execute(0);
#endif // !USE_OGLES
  glEnable(GL_TEXTURE_2D);
  glDisable(GL_POINT_SMOOTH);
  if(texture) {
    glBlendFunc(GL_ONE,GL_ONE);
    glEnable(GL_BLEND);
    texture->apply();
#ifdef USE_OGLES
    GLColor& clr = getColor();
    glColor4f(clr.getRed(),clr.getGreen(),clr.getBlue(),1);
    const int STRIDE = (2+3)*4;
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glTexCoordPointer(2,GL_FLOAT,STRIDE,nebulaeArrays);
    glVertexPointer(3,GL_FLOAT,STRIDE,nebulaeArrays+2*4);
    for(int ct = 0; ct < nebulaeLength; ct += 4)
      glDrawArrays(GL_TRIANGLE_STRIP,ct*4,4);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
#else // !USE_OGLES
    glColor3fv(getColor().getFloatArray());
    execute(1);
#endif // !USE_OGLES
    glDisable(GL_BLEND);
  }
  glEnable(GL_LIGHTING);
  glDepthMask(GL_TRUE);
  if(isFoggy) glEnable(GL_FOG);
  glPopMatrix();
}

//
// GLSkydome
//

GLSkydome::GLSkydome(int merid, int paral, float radius, int src, int dst):
  GLBackground(1,1,1,1,src,dst),
  meridians(merid), parallels(paral),
  vertexesCount(0), vertArray(NULL), colArray(NULL),
  indexesCount(0), indexArray(NULL),
  groupsCount(0), groupIndexesCount(NULL), groupIndexesArrays(NULL),
  atmosphereColor(0.125f,0.125f,1), atmosphereHeight(1), atmosphereDensity(0.9f),
  atmosphereMinSin(sin(0*M_PI/180)),atmosphereMaxSin(sin(10*M_PI/180)),
  hazeColor(0.9f,0.9f,0.9f), hazeHeight(0.2f), hazeDensity(0.8f),
  hazeMinSin(sin(-1*M_PI/180)),hazeMaxSin(sin(3*M_PI/180)),
  redShiftMinSin(sin(-8*M_PI/180)),redShiftMaxSin(sin(8*M_PI/180)),
  sunColor(1,1,1), sunIntensity(1), sunDirection(0,0.707f,0.707f),
  fogColor(), cloudColor(), mirrored(false)
{
  vertexesCount = meridians*parallels+1;
  vertArray = new float[3*vertexesCount];
  colArray = new unsigned char[3*vertexesCount];
  indexesCount = (1+meridians+1)+(meridians*2+2)*(parallels-1);
  indexArray = new unsigned short[indexesCount];
  const float MER_STEP = float(2*M_PI/meridians);
  const float PAR_STEP = float(M_PI_2/parallels);
  vertArray[0  ] = 0;
  vertArray[0+1] = 1*radius;
  vertArray[0+2] = 0;
  int offsetVert = 3;
  for(int par = parallels-1; par >= 0; par--) {
    float ANG_PAR = par*PAR_STEP;
    float R_COS_PAR = float(radius*cos(ANG_PAR));
    float R_SIN_PAR = float(radius*sin(ANG_PAR));
    for(int mer = 0; mer < meridians; mer++) {
      float ang = mer*MER_STEP;
      vertArray[offsetVert+mer*3  ] = float(cos(ang)*R_COS_PAR);
      vertArray[offsetVert+mer*3+1] = R_SIN_PAR;
      vertArray[offsetVert+mer*3+2] = float(sin(ang)*R_COS_PAR);
    }
    offsetVert += meridians*3;
  }
  indexArray[0] = (unsigned short)0;
  int offsetIndex = 1;
  for(int mer = 0; mer < meridians; mer++)
    indexArray[offsetIndex+mer] = (unsigned short)offsetIndex+mer;
  indexArray[offsetIndex+meridians] = (unsigned short)1;
  offsetIndex += meridians+1;
  for(int par = 0; par < parallels-1 ; par++) {
    int parOffset = par*meridians+1;
    for(int mer = 0; mer < meridians; mer++) {
      indexArray[offsetIndex+2*mer  ] = (unsigned short)parOffset+mer;
      indexArray[offsetIndex+2*mer+1] = (unsigned short)parOffset+mer+meridians;
    }
    indexArray[offsetIndex+2*meridians  ] = (unsigned short)parOffset;
    indexArray[offsetIndex+2*meridians+1] = (unsigned short)parOffset+meridians;
    offsetIndex += 2*meridians+2;
  }
  if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
    groupsCount = parallels-1;
    groupIndexesCount = new int[groupsCount];
    groupIndexesArrays = new unsigned short*[groupsCount];
    for(int ct = 0; ct < groupsCount; ct++) {
      groupIndexesCount[ct] = 2*meridians+2;
      groupIndexesArrays[ct] = &indexArray[meridians+2+ct*(2*meridians+2)];
    }
  }
  update();
}

GLSkydome::~GLSkydome() {
  if(indexArray) delete indexArray;
  if(vertArray) delete vertArray;
  if(colArray) delete colArray;
  if(groupIndexesCount) delete groupIndexesCount;
  if(groupIndexesArrays) delete groupIndexesArrays;
}

void GLSkydome::draw(bool blend) {
  glDisable(GL_CULL_FACE);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_LIGHTING);
  glDisable(GL_TEXTURE_2D);
  bool isFoggy = glIsEnabled(GL_FOG);
  if(isFoggy)
  	glDisable(GL_FOG);
  if(blend) {
    glEnable(GL_BLEND);
    glBlendFunc(getSrcBlend(),getDstBlend());
  }
  glEnableClientState(GL_COLOR_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glColorPointer(3,GL_UNSIGNED_BYTE,0,colArray);
  glVertexPointer(3,GL_FLOAT,0,vertArray);
  glDrawElements(GL_TRIANGLE_FAN,meridians+2,GL_UNSIGNED_SHORT,indexArray);
#ifndef USE_OGLES
 	if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
 		glMultiDrawElementsEXT(
      GL_TRIANGLE_STRIP,groupIndexesCount,GL_UNSIGNED_SHORT,
      (const void **)groupIndexesArrays,groupsCount
    );
 	} else {
  	if(IS_DRAW_RANGE_ELEMENTS_SUPPORTED) {
      int offset = meridians+2;
      for(int ct = 0; ct < parallels-1; ct++) {
     		glDrawRangeElementsEXT(
          GL_TRIANGLE_STRIP,offset,indexesCount,
          2*meridians+2,GL_UNSIGNED_SHORT,indexArray
        );
        offset += 2*meridians+2;
      }
    } else {
#endif // !USE_OGLES
      unsigned short* idxs = indexArray;
      for(int ct = 0; ct < parallels-1; ct++) {
        glDrawElements(GL_TRIANGLE_STRIP,2*meridians+2,GL_UNSIGNED_SHORT,idxs);
        idxs += 2*meridians+2;
      }
#ifndef USE_OGLES
    }
  }
#endif // !USE_OGLES
  glDisableClientState(GL_COLOR_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  if(blend)
    glDisable(GL_BLEND);
  if(isFoggy)
  	glEnable(GL_FOG);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);
}

void GLSkydome::render(bool blend) {
  draw(blend);
  if(isMirrored()) {
    glPushMatrix();
    glScalef(1,-1,1);
    draw(blend);
    glPopMatrix();
  }
}

void GLSkydome::getRedShift(float shift, GLColor& redShift) {
  float rsd = getRedShiftDensity();
  GLColor& sunColor = getSunColor();
  float r = sunColor.getRed()*rsd+(1-rsd);
  if(r < 0) r = 0;
  float g = sunColor.getGreen()*(1-shift)*rsd+(1-rsd);
  if(g < 0) g = 0;
  float b = sunColor.getBlue()*(shift < 0.5f? 1-2*shift: 0)*rsd+(1-rsd);
  if(b < 0) b = 0;
  redShift.set(r,g,b);
}

float GLSkydome::getRedShiftDensity() {
  const float MIN_SIN_ANGLE = redShiftMinSin;
  const float MAX_SIN_ANGLE = redShiftMaxSin;
  float dirY = sunDirection.getY();
	if(dirY >= MAX_SIN_ANGLE)
		return 0;
	else if(dirY <= MIN_SIN_ANGLE)
		return 1;
	else
		return cos(M_PI_2*(dirY-MIN_SIN_ANGLE)*(1/(MAX_SIN_ANGLE-MIN_SIN_ANGLE)));

}

float GLSkydome::getHazeLight() {
  const float MIN_SIN_ANGLE = hazeMinSin;
  const float MAX_SIN_ANGLE = hazeMaxSin;
  float dirY = sunDirection.getY();
	if(dirY >= MAX_SIN_ANGLE)
		return 1;
	else if(dirY <= MIN_SIN_ANGLE)
		return 0;
	else
		return cos(M_PI_2*(MAX_SIN_ANGLE-dirY)*(1/(MAX_SIN_ANGLE-MIN_SIN_ANGLE)));
}

float GLSkydome::getAtmosphereLight() {
  const float MIN_SIN_ANGLE = atmosphereMinSin;
  const float MAX_SIN_ANGLE = atmosphereMaxSin;
  float dirY = sunDirection.getY();
	if(dirY >= MAX_SIN_ANGLE)
		return 1;
  else if(dirY <= MIN_SIN_ANGLE)
		return 0;
  else
		return cos(M_PI_2*(MAX_SIN_ANGLE-dirY)*(1/(MAX_SIN_ANGLE-MIN_SIN_ANGLE)));
}

void GLSkydome::update() {
  const float MER_STEP = float(2*M_PI/meridians);
  const float PAR_STEP = float(M_PI_2/parallels);
  GLColor bgColor;
  (bgColor.set(atmosphereColor)).scale(1/16.0f);
  float atmosphereLight = getAtmosphereLight();
 	float hazeLight = getHazeLight();
	if(atmosphereLight || hazeLight || sunIntensity) {
	  float invAtmosphereHeight = 1/atmosphereHeight;
  	float invHazeHeight = 1/hazeHeight;
	  float haze = exp(-invHazeHeight)*hazeDensity;
	  GLColor redShift;
    getRedShift(haze,redShift);
    GLColor baseColor;
    baseColor.set(atmosphereColor).scale(
      exp(-invAtmosphereHeight)*atmosphereDensity*atmosphereLight
    ).scale(redShift);
    GLColor tmpColor;
    baseColor.add(
      tmpColor.set(hazeColor).scale(haze*hazeLight).scale(redShift)
    ).add(bgColor);
    M3Vector vertPos(0,1,0);
    float sunDist = 2*vertPos.dist(sunDirection);
    float corona = (
      exp(-sunDist*invHazeHeight)*hazeLight+exp(-sunDist*80*invHazeHeight)
    )*hazeDensity*sunIntensity;
    GLColor theColor;
    theColor.set(hazeColor).scale(corona).scale(redShift).add(baseColor);
    colArray[0] = (unsigned char)
      (theColor.getRed() >= 1? 255: theColor.getRed()*255);
    colArray[1] = (unsigned char)
      (theColor.getGreen() >= 1? 255: theColor.getGreen()*255);
    colArray[2] = (unsigned char)
      (theColor.getBlue() >= 1? 255: theColor.getBlue()*255);
    int offsetVert = 3;
    for(int par = parallels-1; par >= 0; par--) {
      float ANG_PAR = par*PAR_STEP;
      float COS_PAR = float(cos(ANG_PAR));
      float SIN_PAR = float(sin(ANG_PAR));
      float angFrac = ANG_PAR/float(M_PI_2);
      haze = exp(-angFrac*invHazeHeight)*hazeDensity;
	    getRedShift(haze,redShift);
      baseColor.set(atmosphereColor).scale(
        exp(-angFrac*invAtmosphereHeight)*atmosphereDensity*atmosphereLight
      ).scale(redShift);
      baseColor.add(
        tmpColor.set(hazeColor).scale(haze*hazeLight).scale(redShift)
      ).add(bgColor);
      for(int mer = 0; mer < meridians; mer++) {
        float ang = mer*MER_STEP;
        vertPos.set(cos(ang)*COS_PAR,SIN_PAR,sin(ang)*COS_PAR);
        sunDist = 2*vertPos.dist(sunDirection);
        corona = (
          exp(-sunDist*invHazeHeight)*hazeLight+exp(-sunDist*80*invHazeHeight)
        )*hazeDensity*sunIntensity;
        theColor.set(hazeColor).scale(corona).scale(redShift).add(baseColor);
        colArray[offsetVert+mer*3  ] = (unsigned char)
          (theColor.getRed() >= 1? 255: theColor.getRed()*255);
        colArray[offsetVert+mer*3+1] = (unsigned char)
          (theColor.getGreen() >= 1? 255: theColor.getGreen()*255);
        colArray[offsetVert+mer*3+2] = (unsigned char)
          (theColor.getBlue() >= 1? 255: theColor.getBlue()*255);
      }
      offsetVert += meridians*3;
    }
    fogColor.set(hazeColor).scale(redShift).add(baseColor);
	 	actualSunColor.set(sunColor).scale(
    	atmosphereLight+0.5f*hazeLight
    ).scale(redShift).add(bgColor).scale(sunIntensity);
 		cloudColor.set(hazeColor).scale(
   		0.5f*atmosphereLight+hazeLight
	  ).scale(redShift).add(bgColor);
	} else {
		for(int ct = 0; ct < vertexesCount; ct++) {
      colArray[ct*3  ] = (unsigned char)(bgColor.getRed()*255);
      colArray[ct*3+1] = (unsigned char)(bgColor.getGreen()*255);
      colArray[ct*3+2] = (unsigned char)(bgColor.getBlue()*255);
    }
	 	actualSunColor.set(bgColor);
 		fogColor.set(bgColor);
 		cloudColor.set(bgColor);
	}
}

//
// GLSkybox
//

GLSkybox::GLSkybox(int txtCount, GLTexture** txts, int src, int dst):
  GLBackground(1,1,1,1,src,dst)
{
  init(txtCount,txts);
}

void GLSkybox::init(int txtCount, GLTexture** txts) {
  texturesCount = txtCount;
  textures = new GLTexture*[texturesCount];
  for(int ct = 0; ct < texturesCount; ct++)
    textures[ct] = txts[ct]->acquireReference();
#ifdef USE_OGLES
#else // !USE_OGLES
  relink(texturesCount);
#endif // !USE_OGLES
}

GLSkybox::GLSkybox(GLTexture** txts) {
  init(6,txts);
#ifdef USE_OGLES
#else // !USE_OGLES
  const int halfSize = 100;
  compileBegin(0); // Left
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize,-halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(1); // Front
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize,-halfSize, halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize,-halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(2); // Right
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize,-halfSize, halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(3); // Back
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize,-halfSize,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(4); // Top
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(5); // Bottom
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize,-halfSize, halfSize);
    glTexCoord2f(0,1); glVertex3f( halfSize,-halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize,-halfSize, halfSize);
  glEnd();
  compileEnd();
#endif // !USE_OGLES
}

GLSkybox::~GLSkybox() {
  for(int ct = 0; ct < texturesCount; ct++) textures[ct]->releaseReference();
  if(textures) delete textures;
}

void GLSkybox::render(bool blend) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_LIGHTING);
  bool isFoggy = glIsEnabled(GL_FOG);
  if(isFoggy) glDisable(GL_FOG);
  if(blend) {
    glEnable(GL_BLEND);
    glBlendFunc(getSrcBlend(),getDstBlend());
  }
#ifdef USE_OGLES
  GLColor& clr = getColor();
  glColor4f(clr.getRed(),clr.getGreen(),clr.getBlue(),1);
  const int halfSize = 100;
  float arrays[24*5] = {
    0,1, -halfSize, halfSize,-halfSize, // Top
    0,0,  halfSize, halfSize,-halfSize,
    1,1, -halfSize, halfSize, halfSize,
    1,0,  halfSize, halfSize, halfSize,
    1,1,  halfSize, halfSize, halfSize, // Left
    0,1,  halfSize, halfSize,-halfSize,
    1,0,  halfSize,-halfSize, halfSize,
    0,0,  halfSize,-halfSize,-halfSize,
    0,1,  halfSize, halfSize, halfSize, // Front
    0,0,  halfSize,-halfSize, halfSize,
    1,1, -halfSize, halfSize, halfSize,
    1,0, -halfSize,-halfSize, halfSize,
    0,1, -halfSize, halfSize, halfSize, // Right
    0,0, -halfSize,-halfSize, halfSize,
    1,1, -halfSize, halfSize,-halfSize,
    1,0, -halfSize,-halfSize,-halfSize,
    1,1,  halfSize, halfSize,-halfSize, // Back
    0,1, -halfSize, halfSize,-halfSize,
    1,0,  halfSize,-halfSize,-halfSize,
    0,0, -halfSize,-halfSize,-halfSize,
    1,1,  halfSize,-halfSize, halfSize, // Bottom
    0,1,  halfSize,-halfSize,-halfSize,
    1,0, -halfSize,-halfSize, halfSize,
    0,0, -halfSize,-halfSize,-halfSize,
  };
  const int STRIDE = (2+3)*4;
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
  for(int ct = 0; ct < texturesCount; ct++) {
    textures[ct]->apply();
    glDrawArrays(GL_TRIANGLE_STRIP,ct*4,4);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
#else // !USE_OGLES
  glColor3fv(getColor().getFloatArray());
  for(int ct = 0; ct < texturesCount; ct++) {
    textures[ct]->apply();
    execute(ct);
  }
#endif // !USE_OGLES
  if(blend)
    glDisable(GL_BLEND);
  if(isFoggy) glEnable(GL_FOG);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glPopMatrix();
}

//
// GLHalfSkybox
//

GLHalfSkybox::GLHalfSkybox(int txtCount, GLTexture** txts, int src, int dst):
  GLSkybox(txtCount,txts,src,dst)
{}

GLHalfSkybox::GLHalfSkybox(GLTexture** txts, int src, int dst):
  GLSkybox(5,txts,src,dst)
{
#ifdef USE_OGLES
#else // !USE_OGLES
  const int halfSize = 100;
  compileBegin(0); // Top
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(1); // Left
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       , halfSize);
  glEnd();
  compileEnd();
  compileBegin(2); // Front
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(3); // Right
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(4); // Back
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       ,-halfSize);
  glEnd();
  compileEnd();
#endif // !USE_OGLES
}

void GLHalfSkybox::render(bool blend) {
  if(!blend) {
		glClearColor(ground.getRed(),ground.getGreen(),ground.getBlue(),1);
    glClear(GL_COLOR_BUFFER_BIT);
  }
  GLSkybox::render(blend);
}

//
// GLPanorama
//
GLPanorama::GLPanorama(GLTexture** txts, int src, int dst):
  GLHalfSkybox(4,txts,src,dst)
{
#ifdef USE_OGLES
#else // !USE_OGLES
  const int halfSize = 100;
  compileBegin(0); // Left
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       , halfSize);
  glEnd();
  compileEnd();
  compileBegin(1); // Front
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(2); // Right
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(3); // Back
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       ,-halfSize);
  glEnd();
  compileEnd();
#endif // !USE_OGLES
}

#ifdef USE_OGLES

void GLPanorama::render(bool blend) {
  if(!blend)
    glClear(GL_COLOR_BUFFER_BIT);
  glPushMatrix();
  glMultMatrixf(getTransform());
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_LIGHTING);
  bool isFoggy = glIsEnabled(GL_FOG);
  if(isFoggy) glDisable(GL_FOG);
  if(blend) {
    glEnable(GL_BLEND);
    glBlendFunc(getSrcBlend(),getDstBlend());
  }
  GLColor& clr = getColor();
  glColor4f(clr.getRed(),clr.getGreen(),clr.getBlue(),1);
  const int halfSize = 100;
  float arrays[20*5] = {
    1,1,  halfSize, halfSize, halfSize, // Left
    0,1,  halfSize, halfSize,-halfSize,
    1,0,  halfSize,-halfSize, halfSize,
    0,0,  halfSize,-halfSize,-halfSize,
    0,1,  halfSize, halfSize, halfSize, // Front
    0,0,  halfSize,-halfSize, halfSize,
    1,1, -halfSize, halfSize, halfSize,
    1,0, -halfSize,-halfSize, halfSize,
    0,1, -halfSize, halfSize, halfSize, // Right
    0,0, -halfSize,-halfSize, halfSize,
    1,1, -halfSize, halfSize,-halfSize,
    1,0, -halfSize,-halfSize,-halfSize,
    1,1,  halfSize, halfSize,-halfSize, // Back
    0,1, -halfSize, halfSize,-halfSize,
    1,0,  halfSize,-halfSize,-halfSize,
    0,0, -halfSize,-halfSize,-halfSize,
    1,1,  halfSize,-halfSize, halfSize, // Bottom
    0,1,  halfSize,-halfSize,-halfSize,
    1,0, -halfSize,-halfSize, halfSize,
    0,0, -halfSize,-halfSize,-halfSize,
  };
  const int STRIDE = (2+3)*4;
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
  for(int ct = 0; ct < texturesCount; ct++) {
    textures[ct]->apply();
    glDrawArrays(GL_TRIANGLE_STRIP,ct*4,4);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  if(blend)
    glDisable(GL_BLEND);
  if(isFoggy) glEnable(GL_FOG);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glPopMatrix();
}

#endif // !USE_OGLES

//
// GLMirroredSkybox
//

GLMirroredSkybox::GLMirroredSkybox(GLTexture** txts, int src, int dst):
  GLSkybox(5,txts,src,dst)
{
#ifdef USE_OGLES
#else // !USE_OGLES
  const int halfSize = 100;
  compileBegin(0); // Top & Bottom
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize); // Top
    glTexCoord2f(0,0); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
    glTexCoord2f(0,1); glVertex3f(-halfSize,-halfSize,-halfSize); // Bottom
    glTexCoord2f(1,1); glVertex3f(-halfSize,-halfSize, halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize,-halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize,-halfSize,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(1); // Left
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize, halfSize); // Top
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       , halfSize); // Bottom
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       ,-halfSize);
    glTexCoord2f(0,1); glVertex3f( halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,1); glVertex3f( halfSize,-halfSize, halfSize);
  glEnd();
  compileEnd();
  compileBegin(2); // Front
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f( halfSize, halfSize, halfSize); // Top
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize, halfSize);
    glTexCoord2f(0,0); glVertex3f( halfSize, 0       , halfSize); // Bottom
    glTexCoord2f(0,1); glVertex3f( halfSize,-halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize,-halfSize, halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       , halfSize);
  glEnd();
  compileEnd();
  compileBegin(3); // Right
  glBegin(GL_QUADS);
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize, halfSize); // Top
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       , halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       , halfSize); // Bottom
    glTexCoord2f(0,1); glVertex3f(-halfSize,-halfSize, halfSize);
    glTexCoord2f(1,1); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,0); glVertex3f(-halfSize, 0       ,-halfSize);
  glEnd();
  compileEnd();
  compileBegin(4); // Back
  glBegin(GL_QUADS);
    glTexCoord2f(1,1); glVertex3f( halfSize, halfSize,-halfSize); // Top
    glTexCoord2f(0,1); glVertex3f(-halfSize, halfSize,-halfSize);
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       ,-halfSize);
    glTexCoord2f(1,0); glVertex3f( halfSize, 0       ,-halfSize); // Bottom
    glTexCoord2f(0,0); glVertex3f(-halfSize, 0       ,-halfSize);
    glTexCoord2f(0,1); glVertex3f(-halfSize,-halfSize,-halfSize);
    glTexCoord2f(1,1); glVertex3f( halfSize,-halfSize,-halfSize);
  glEnd();
  compileEnd();
#endif // !USE_OGLES
}

#ifdef USE_OGLES

void GLMirroredSkybox::render(bool blend) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_LIGHTING);
  bool isFoggy = glIsEnabled(GL_FOG);
  if(isFoggy) glDisable(GL_FOG);
  if(blend) {
    glEnable(GL_BLEND);
    glBlendFunc(getSrcBlend(),getDstBlend());
  }
  GLColor& clr = getColor();
  glColor4f(clr.getRed(),clr.getGreen(),clr.getBlue(),1);
  const int halfSize = 100;
  float arrays[40*5] = {
    0,1, -halfSize, halfSize,-halfSize, // Top & Bottom: Top
    0,0,  halfSize, halfSize,-halfSize,
    1,1, -halfSize, halfSize, halfSize,
    1,0,  halfSize, halfSize, halfSize,
    0,1, -halfSize,-halfSize,-halfSize, // Top & Bottom: Bottom
    1,1, -halfSize,-halfSize, halfSize,
    0,0,  halfSize,-halfSize,-halfSize,
    1,0,  halfSize,-halfSize, halfSize,
    1,1,  halfSize, halfSize, halfSize, // Left: Top
    0,1,  halfSize, halfSize,-halfSize,
    1,0,  halfSize, 0       , halfSize,
    0,0,  halfSize, 0       ,-halfSize,
    1,0,  halfSize, 0       , halfSize, // Left: Bottom
    0,0,  halfSize, 0       ,-halfSize,
    1,1,  halfSize,-halfSize, halfSize,
    0,1,  halfSize,-halfSize,-halfSize,
    0,1,  halfSize, halfSize, halfSize, // Front: Top
    0,0,  halfSize, 0       , halfSize,
    1,1, -halfSize, halfSize, halfSize,
    1,0, -halfSize, 0       , halfSize,
    0,0,  halfSize, 0       , halfSize, // Front: Bottom
    0,1,  halfSize,-halfSize, halfSize,
    1,0, -halfSize, 0       , halfSize,
    1,1, -halfSize,-halfSize, halfSize,
    0,1, -halfSize, halfSize, halfSize, // Right: Top
    0,0, -halfSize, 0       , halfSize,
    1,1, -halfSize, halfSize,-halfSize,
    1,0, -halfSize, 0       ,-halfSize,
    0,0, -halfSize, 0       , halfSize, // Right: Bottom
    0,1, -halfSize,-halfSize, halfSize,
    1,0, -halfSize, 0       ,-halfSize,
    1,1, -halfSize,-halfSize,-halfSize,
    1,1,  halfSize, halfSize,-halfSize, // Back: Top
    0,1, -halfSize, halfSize,-halfSize,
    1,0,  halfSize, 0       ,-halfSize,
    0,0, -halfSize, 0       ,-halfSize,
    1,0,  halfSize, 0       ,-halfSize, // Back: Bottom
    0,0, -halfSize, 0       ,-halfSize,
    1,1,  halfSize,-halfSize,-halfSize,
    0,1, -halfSize,-halfSize,-halfSize,
  };
  const int STRIDE = (2+3)*4;
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
  for(int ct = 0; ct < texturesCount; ct++) {
    textures[ct]->apply();
    glDrawArrays(GL_TRIANGLE_STRIP,ct*8  ,4);
    glDrawArrays(GL_TRIANGLE_STRIP,ct*8+4,4);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  if(blend)
    glDisable(GL_BLEND);
  if(isFoggy) glEnable(GL_FOG);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glPopMatrix();
}

#endif // !USE_OGLES
