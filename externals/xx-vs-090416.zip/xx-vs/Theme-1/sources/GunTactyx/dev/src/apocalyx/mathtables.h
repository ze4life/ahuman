#ifndef MATHTABLES_H
#define MATHTABLES_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include <math.h>

//
// MTNormals1D
//
class MTNormals1D {
private:
	static float normals[162][3];
public:
  static float* getNormal(int a) {return normals[a];}
  static float getNormal(int a, int coo) {return normals[a][coo];}
};

//
// MTNormals2D
//
class MTNormals2D {
private:
  static bool initialized;
  static float normals[256][256][3];
public:
  static void initialize();
  static bool isInitialized() {return initialized;}
  static float getNormal(int a, int b, int coo) {return normals[a][b][coo];}
};

//
// MTSinCos
//
class MTSinCos {
private:
  static bool initialized;
  static float cosTable[256];
public:
  static void initialize();
  static bool isInitialized() {return initialized;}
  static float getSin(float angle) {return getCos(angle+M_PI/2);}
  static float getCos(float angle) {
    angle = fmod(angle,2*M_PI);
    const float k = 256/(2*M_PI);
    if(angle < M_PI) {
      if(angle < M_PI/2) {
        return cosTable[int(k*angle)];
      } else {
        return -cosTable[int(k*(M_PI-angle))];
      }
    } else {
      if(angle < 3*M_PI/2) {
        return -cosTable[int(k*(angle-M_PI))];
      } else {
        return cosTable[int(k*(2*M_PI-angle))];
      }
    }
  }
};

#endif //MATHTABLES_H
