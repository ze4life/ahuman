#ifndef GLBSP_H
#define GLBSP_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_BSP

#include "glscenery.h"
#include "gltexture.h"
#include "glmodel.h"

#include <mem.h>

//
// Bitset
//

class Bitset {
private:
	int size;
	unsigned int* bits;
public:
  Bitset();
	~Bitset();
	void resize(int count) {
		size = count/32+1;
    if(bits)
			delete bits;
		bits = new unsigned int[size];
		clearAll();
	}
	void set(int i)	{bits[i >> 5] |= (1 << (i & 31));}
	int isOn(int i)	{return bits[i >> 5] & (1 << (i & 31 ));}
	void clear(int i)	{bits[i >> 5] &= ~(1 << (i & 31));}
	void clearAll()	{memset(bits,0,sizeof(unsigned int)*size);}
};

//
// BSP structs
//

struct BSPVector {
	float x;
  float y;
  float z;
  BSPVector() {}
  void set(float iX = 0, float iY = 0, float iZ = 0) {x = iX; y = iY; z = iZ;}
  BSPVector(float iX, float iY, float iZ) {set(iX,iY,iZ);}
	BSPVector operator+(const BSPVector& v) const
    {BSPVector res; res.set(x+v.x,y+v.y,z+v.z); return res;}
	BSPVector operator-(const BSPVector& v) const
    {BSPVector res; res.set(x-v.x,y-v.y,z-v.z); return res;}
	BSPVector operator*(float factor) const
    {BSPVector res; res.set(x*factor,y*factor,z*factor); return res;}
  float dot(const BSPVector& v) const {return x*v.x+y*v.y+z*v.z;}
  float norm2() const {return dot(*this);}
  float norm() const {return sqrt(norm2());}
  BSPVector cross(BSPVector& v) const
    {BSPVector res; res.set(y*v.z-z*v.y,z*v.x-x*v.z,x*v.y-y*v.z); return res;}
	BSPVector normalize() const {
    float invNorm = norm();
    if(invNorm == 0) return *this;
    invNorm = 1/invNorm;
    BSPVector res; res.set(x*invNorm,y*invNorm,z*invNorm); return res;
	}
};

struct BSPIntVector {
	int x;
  int y;
  int z;
};

struct BSPTexCoord {
	float u;
  float v;
  void set(float iU = 0, float iV = 0) {u = iU; v = iV;}
	BSPTexCoord operator+(const BSPTexCoord& t) const
    {BSPTexCoord res; res.set(u+t.u,v+t.v); return res;}
	BSPTexCoord operator*(float factor) const
    {BSPTexCoord res; res.set(u*factor,v*factor); return res;}
};

struct BSPHeader {
  char id[4];
  int version;
};

struct BSPLump {
	int offset;
	int length;
public:
  enum Lump {
    ENTITIES_LUMP = 0, TEXTURES_LUMP, PLANES_LUMP, NODES_LUMP, LEAVES_LUMP,
    LEAFFACES_LUMP, LEAFBRUSHES_LUMP, MODELS_LUMP, BRUSHES_LUMP,
    BRUSHSIDES_LUMP, VERTEXES_LUMP, MESHVERTEXES_LUMP, SHADERS_LUMP,
    FACES_LUMP, LIGHTMAPS_LUMP, LIGHTVOLUMES_LUMP, VISDATA_LUMP, MAX_LUMPS
  };
};

typedef unsigned char BSPByte;

struct BSPVertex {
  BSPVector position;
  BSPTexCoord textureCoord;
  BSPTexCoord lightmapCoord;
	BSPVertex operator+(const BSPVertex& v) const	{
		BSPVertex res;
		res.position = position+v.position;
		res.textureCoord = textureCoord+v.textureCoord;
		res.lightmapCoord = lightmapCoord+v.lightmapCoord;
		return res;
	}
	BSPVertex operator*(float factor) const	{
		BSPVertex res;
		res.position = position*factor;
		res.textureCoord = textureCoord*factor;
		res.lightmapCoord = lightmapCoord*factor;
		return res;
	}
};

struct BSPFullVertex: public BSPVertex {
  BSPVector normal;
  BSPByte color[4];
};

struct BSPFace {
  int textureID;
  int effect;
  int type;
  int firstVertex;
  int vertexesCount;
  int firstMeshVertex;
  int meshVertexesCount;
  int lightmapID;
  int lightmapCorner[2];
  int lightmapSize[2];
  BSPVector lightmapPosition;
  BSPVector lightmapVectors[2];
  BSPVector normal;
  int patchSize[2];
  enum Type {POLYGON = 1, PATCH = 2, MESH = 3, BILLBOARD = 4,};
};

struct BSPBrush {
  int firstBrushSide;
  int brushSidesCount;
  int textureID;
};

struct BSPBrushSide {
  int plane;
  int textureID;
};

struct BSPTexture {
  char name[64];
  int flags;
  int contents;
};

struct BSPShader {
  char strName[64];
  int brushIndex;
  int shaderData;
};

struct BSPLightmap {
  BSPByte imageBits[128][128][3];
};

struct BSPNode {
  int plane;
  int front;
  int back;
  BSPIntVector min;
  BSPIntVector max;
};

struct BSPLeaf {
  int cluster;
  int area;
  BSPIntVector min;
  BSPIntVector max;
  int firstFace;
  int facesCount;
  int firstBrush;
  int brushesCount;
};

struct BSPPlane {
  BSPVector normal;
  float distance;
};

struct BSPModel {
  float min[3];
  float max[3];
  int faceIndex;
  int numOfFaces;
  int brushIndex;
  int numOfBrushes;
};

struct BSPLightVolume {
  BSPByte ambient[3];
  BSPByte directional[3];
  BSPByte direction[2];
};

struct BSPVisData {
	int clustersCount;
	int bytesPerCluster;
	BSPByte* bitsets;
};

//
// GLBspFace
//

class GLBspFace {
public:
	float cameraDist;
  int textureID;
  int lightmapID;
public:
  virtual ~GLBspFace();
  virtual BSPFace::Type getType() = 0;
};

class GLBspPolygon: public GLBspFace {
public:
  int firstVertex;
  int vertexesCount;
public:
  virtual BSPFace::Type getType() {return BSPFace::POLYGON;}
};

class GLBspMesh: public GLBspPolygon {
public:
  int firstMeshVertex;
  int meshVertexesCount;
public:
  virtual BSPFace::Type getType() {return BSPFace::MESH;}
};

class GLPatch {
public:
	int tessellation;
	BSPVertex controls[9];
	BSPVertex* vertexes;
	unsigned int* indexes;
	int* trianglesPerRow;
	unsigned int** rowIndexes;
public:
  GLPatch();
  ~GLPatch();
	void tessellate(int iTessellation);
	void render();
};

class GLBspPatch: public GLBspFace {
public:
  int patchesCount;
	GLPatch* patches;
public:
  GLBspPatch();
  virtual ~GLBspPatch();
  virtual BSPFace::Type getType() {return BSPFace::PATCH;}
};

class GLBspBillboard: public GLBspFace {
public:
  virtual BSPFace::Type getType() {return BSPFace::BILLBOARD;}
};

//
// BspCollision
//

struct BspCollision {
  float fraction;
  BSPVector start;
  BSPVector end;
  BSPVector size;
  BSPVector normal;
  bool isSolid;
};

//
// GLBsp
//

class GLBsp: public GLScenery {
public:
	int vertexesCount;
	BSPVertex* vertexes;
	int meshVertexesCount;
	int* meshVertexes;
	int nodesCount;
  BSPNode* nodes;
	int leavesCount;
	BSPLeaf* leaves;
  float* leafCameraDists; // for depth sort
  int* leafIndexes; // for depth sort
	int planesCount;
	BSPPlane* planes;
	int brushesCount;
	BSPBrush* brushes;
  int brushSidesCount;
  BSPBrushSide* brushSides;
	int leafFacesCount;
	int* leafFaces;
	int leafBrushesCount;
	int* leafBrushes;
  BSPModel staticModel;
  BSPIntVector lightVolumesGrid;
  BSPVector lightVolumesInvSizes;
	int lightVolumesCount;
	BSPLightVolume* lightVolumes;
	BSPVisData clusters;
	DSArray<GLBspFace>* faces;
	DSArray<GLTexture,false>* textures;
  Bitset textureIsHollow;
  Bitset textureHasAlpha;
	DSArray<GLTexture,false>* lightmaps;
	Bitset facesDrawn;
  GLTexture* defaultTexture;
  unsigned int defaultLightmap;
  bool showUntexturedMeshes;
  bool showUntexturedPatches;
  bool showUntexturedPolygons;
  bool showTransparencies;
  DSStaticArray<BSPVector> startingPositions;
  DSStaticArray<BSPVector> medikitPositions;
  DSStaticArray<BSPVector> foodPositions;
  DSStaticArray<BSPVector> armorPositions;
  DSStaticArray<BSPVector> bulletsPositions;
  DSStaticArray<BSPVector> grenadesPositions;
  DSStaticArray<BSPVector> weaponPositions;
private:
  BspCollision collision;
  void checkMove(BSPVector& pos, BSPVector& vel, BSPVector& extent);
  void checkMove(BSPVector& pos, BSPVector& vel);
  void checkMoveLeaf(int leaf);
  void checkMoveLeafNoSize(int leaf);
  void checkMoveNode(
    float start, float end, BSPVector startPos, BSPVector endPos, int node
  );
  void checkMoveNodeNoSize(
    float start, float end, BSPVector startPos, BSPVector endPos, int node
  );
  void clipBoxToBrush(BSPBrush* brush);
  void clipPointToBrush(BSPBrush* brush);
  void clipVelocity(
    BSPVector in, BSPVector planeNormal, BSPVector& out, float overbounce
  );
  void slide(BSPVector& pos, BSPVector& vel, BSPVector& extent);
  void collide(BSPVector& pos, BSPVector& vel, BSPVector& extent);
  void collide(BSPVector& pos, BSPVector& vel);
public:
	GLBsp();
	virtual ~GLBsp();
  int isClusterVisible(int curr, int test) {
  	if((clusters.bitsets == NULL) || (curr < 0)) return 1;
    BSPByte vSet = clusters.bitsets[(curr*clusters.bytesPerCluster)+(test>>3)];
    return (vSet & (1 << ((test) & 7)));
  }
	int findLeaf(float x, float y, float z);
  void slideCollision(BSPVector& pos, BSPVector& vel, BSPVector& extent);
  void checkCollision(BSPVector& pos, BSPVector& vel, BSPVector& extent);
  void checkCollision(BSPVector& pos, BSPVector& vel);
  BSPVector& getCollisionNormal() {return collision.normal;}
#ifdef USE_DATA_FILES
	bool load(const char* path, const char* filNam, float lightmapGamma = 1);
#endif // USE_DATA_FILES
  void setDefaultTexture(GLTexture* txt)
    {defaultTexture = txt->acquireReference();}
  void setShowUntexturedPolygons(bool s) {showUntexturedPolygons = s;}
  void setShowUntexturedPatches(bool s) {showUntexturedPatches = s;}
  void setShowUntexturedMeshes(bool s) {showUntexturedMeshes = s;}
  void setShowTransparencies(bool s) {showTransparencies = s;}
  bool areShownUntexturedPolygons() {return showUntexturedPolygons;}
  bool areShownUntexturedPatches() {return showUntexturedPatches;}
  bool areShownUntexturedMeshes() {return showUntexturedMeshes;}
  bool hasTransparencies() {return showTransparencies;}
  int getStartingPositionsCount() {return startingPositions.getSize();}
  BSPVector& getStartingPosition(int idx = 0)
    {return startingPositions.getElement(idx);}
  int getMedikitPositionsCount() {return medikitPositions.getSize();}
  BSPVector& getMedikitPosition(int idx = 0)
    {return medikitPositions.getElement(idx);}
  int getFoodPositionsCount() {return foodPositions.getSize();}
  BSPVector& getFoodPosition(int idx = 0)
    {return foodPositions.getElement(idx);}
  int getArmorPositionsCount() {return armorPositions.getSize();}
  BSPVector& getArmorPosition(int idx = 0)
    {return armorPositions.getElement(idx);}
  int getBulletsPositionsCount() {return bulletsPositions.getSize();}
  BSPVector& getBulletsPosition(int idx = 0)
    {return bulletsPositions.getElement(idx);}
  int getGrenadesPositionsCount() {return grenadesPositions.getSize();}
  BSPVector& getGrenadesPosition(int idx = 0)
    {return grenadesPositions.getElement(idx);}
  int getWeaponPositionsCount() {return weaponPositions.getSize();}
  BSPVector& getWeaponPosition(int idx = 0)
    {return weaponPositions.getElement(idx);}
  virtual bool getDynamicLightDirection(M3Vector& dir);
  virtual float getPlane(M3Vector& pos, M3Vector& dir, M3Vector& normal);
  virtual void initRender(GLCamera& camera);
	virtual void render(GLCamera& camera);
	virtual void renderOpaque(GLCamera& camera);
	virtual void renderTransparent(GLCamera& camera);
  virtual void initRender(GLCamera& camera, float x, float y, float z);
  virtual void render(GLCamera& camera, GLObject* obj) {obj->render(camera);}
  virtual bool checkVisibility(GLCamera& camera, float x, float y, float z) {
   	int cluster = leaves[findLeaf(x,y,z)].cluster;
    return isClusterVisible(camera.getIntValue(),cluster);
  }
};

#endif // USE_BSP

#endif // GLBSP_H
