/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_SOUND

#include <stdlib.h> // for free()
#include <stdio.h> // for FILE

#include "fmsound.h"
#include "exception.h"

//
// FMSoundManager
//
void FMSoundManager::initialize() throw(ExceptionThrown) {
#ifdef USE_FMOD
  if(FSOUND_GetVersion() < FMOD_VERSION)
    Exception::throws("Wrong FMOD DLL version: 3.73 needed");
  FSOUND_SetOutput(FSOUND_OUTPUT_DSOUND);
  FSOUND_SetDriver(0);
  int channels;
  FSOUND_GetNumHWChannels(NULL, NULL, &channels);
  if(channels < MIN_HARDWARE_CHANNELS)
    FSOUND_SetMinHardwareChannels(channels = MIN_HARDWARE_CHANNELS);
  if(!FSOUND_Init(44100,MIN_HARDWARE_CHANNELS,0))
    Exception::throws("FMOD Sound Init Error");
  FSOUND_SetSFXMasterVolume(255);
#else // !USE_FMOD
  if(alutInit(0,NULL) == AL_FALSE)
    Exception::throws("OpenAL alutInit Error");
#endif // !USE_FMOD
}

void FMSoundManager::finalize() {
#ifdef USE_FMOD
  FSOUND_Close();
#else // !USE_FMOD
  for(int ct = 0; ct < MAX_SOUND_SOURCES; ct++) {
    if(soundSources[ct] != 0)
      alDeleteSources(1,&soundSources[ct]);
    soundSources[ct] = 0;
  }
  alutExit();
#endif // !USE_FMOD
}

#ifdef USE_FMOD
int FMSoundManager::channels = 0;
#else // !USE_FMOD
ALuint FMSoundManager::soundSources[MAX_SOUND_SOURCES] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
#endif // !USE_FMOD

//
// FMSample
//

FMSample::FMSample(int length, unsigned char* buffer):
#ifdef USE_FMOD
  sample(NULL)
#else // !USE_FMOD
  soundBuffer(0), looping(false), volume(255), frequency(0)
#endif // !USE_FMOD
{
  initFromFileBuffer(length,buffer
#ifdef USE_FMOD
    ,FSOUND_HW2D
#else // !USE_FMOD
#endif // !USE_FMOD
  );
}

#ifdef USE_FMOD
#else // !USE_FMOD
FMSample::FMSample(int freq, int fmt, int len, unsigned char* buf):
  soundBuffer(0), looping(false), volume(255), frequency(freq)
{initFromDataBuffer(freq,fmt,len,buf);}
#endif // !USE_FMOD

FMSample::FMSample():
#ifdef USE_FMOD
  sample(NULL)
#else // !USE_FMOD
  soundBuffer(0), looping(false), volume(255), frequency(0)
#endif // !USE_FMOD
{}

void FMSample::initFromFileBuffer(int length, unsigned char* buffer, int flags) {
#ifdef USE_FMOD
  sample = FSOUND_Sample_Load(
    FSOUND_FREE,(const char*)buffer,flags|FSOUND_LOADMEMORY,0,length
  );
#else // !USE_FMOD
  flags;
  ALenum format;
  ALsizei size;
  ALfloat freq;
  alGetError();
	ALvoid* data = alutLoadMemoryFromFileImage(buffer,length,&format,&size,&freq);
  if(alGetError() == AL_NO_ERROR) {
    if(soundBuffer == 0)
      alGenBuffers(1,&soundBuffer);
    alBufferData(soundBuffer,format,data,size,freq);
    free(data);
  }
#endif // !USE_FMOD
}

#ifdef USE_FMOD
#else // !USE_FMOD
void FMSample::initFromDataBuffer(
	int freq, int fmt, int len, unsigned char* buf
) {
  if(soundBuffer == 0)
    alGenBuffers(1,&soundBuffer);
  alBufferData(soundBuffer,fmt,buf,len,freq);
}
#endif // !USE_FMOD

FMSample::~FMSample() {
#ifdef USE_FMOD
  FSOUND_Sample_Free(sample);
#else // !USE_FMOD
  if(soundBuffer > 0)
    alDeleteBuffers(1,&soundBuffer);
#endif // !USE_FMOD
}

FMSound* FMSample::createSound(bool playing) {
  return new FMSound(
    playing? FMSound::IS_CHANNEL_LOST: FMSound::WAS_SOUND_STOPPED,this
  );
}

//
// FM3DSample
//

FM3DSample::FM3DSample(int length, unsigned char* buffer):
#ifdef USE_FMOD
#else // !USE_FMOD
  minDistance(0),
#endif // !USE_FMOD
  invMinDistance2(1)
{
  initFromFileBuffer(length,buffer
#ifdef USE_FMOD
    ,FSOUND_HW3D
#else // !USE_FMOD
#endif // !USE_FMOD
  );
}

#ifdef USE_FMOD
#else // !USE_FMOD
FM3DSample::FM3DSample(int freq, int fmt, int len, unsigned char* buf):
  minDistance(0),
  invMinDistance2(1)
{initFromDataBuffer(freq,fmt,len,buf);}
#endif // !USE_FMOD

FM3DSound* FM3DSample::create3DSound(bool playing) {
  return new FM3DSound(
    playing? FMSound::IS_CHANNEL_LOST: FMSound::WAS_SOUND_STOPPED,this
  );
}

void FM3DSample::playAt(
  float x, float y, float z, float vx, float vy, float vz
) {
#ifdef USE_FMOD
  int channel = FSOUND_PlaySound(FSOUND_FREE,sample);
  float pos[3] = {-x,y,z};
  float vel[3] = {-vx,vy,vz};
  FSOUND_3D_SetAttributes(channel,pos,vel);
#else // !USE_FMOD
  int ct;
  for(ct = 0; ct < FMSoundManager::MAX_SOUND_SOURCES; ct++) {
    if(FMSoundManager::soundSources[ct] == 0) {
      alGenSources(1,&FMSoundManager::soundSources[ct]);
      break;
    } else {
      ALint status;
      alGetSourcei(FMSoundManager::soundSources[ct],AL_SOURCE_STATE,&status);
      if(status == AL_STOPPED)
        break;
    }
  }
  if(ct == FMSoundManager::MAX_SOUND_SOURCES)
    return;
  ALuint soundSource = FMSoundManager::soundSources[ct];
  alSourcei(soundSource,AL_BUFFER,getSoundBuffer());
  float maxGain;
  alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
  alSourcef(soundSource,AL_GAIN,maxGain*getVolume()*(1.0f/255));
  if(getFrequency() > 0) {
    int freq;
    alGetBufferi(soundBuffer,AL_FREQUENCY,&freq);
    alSourcef(soundSource,AL_PITCH,float(getFrequency())/freq);
  }
  float pos[3] = {x,y,z};
  alSourcefv(soundSource,AL_POSITION,pos);
  float vel[3] = {vx,vy,vz};
  alSourcefv(soundSource,AL_VELOCITY,vel);
  if(getMinDistance() > 0)
    alSourcef(soundSource,AL_REFERENCE_DISTANCE,getMinDistance());
  alSourcePlay(soundSource);
#endif // !USE_FMOD
}

//
// FMSound
//

FMSound::FMSound(int c, FMSample* s):
  sample(s),
#ifdef USE_FMOD
  channel(c)
#else // !USE_FMOD
  soundSource(0)
#endif // !USE_FMOD
{
#ifdef USE_FMOD
#else // !USE_FMOD
  c;
  alGenSources(1,&soundSource);
  alSourcei(soundSource,AL_BUFFER,s->getSoundBuffer());
  alSourcei(soundSource,AL_LOOPING,s->isLooping()?AL_TRUE:AL_FALSE);
  alSourcei(soundSource,AL_SOURCE_RELATIVE,AL_TRUE);
  float maxGain;
  alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
  alSourcef(soundSource,AL_GAIN,maxGain*s->getVolume()*(1.0f/255));
  if(s->getFrequency() > 0) {
    int freq;
    alGetBufferi(s->getSoundBuffer(),AL_FREQUENCY,&freq);
    alSourcef(soundSource,AL_PITCH,float(s->getFrequency())/freq);
  }
  if(c == IS_CHANNEL_LOST)
    play();
#endif // !USE_FMOD
}

FMSound::~FMSound() {
  stop();
#ifdef USE_FMOD
#else // !USE_FMOD
  alDeleteSources(1,&soundSource);
#endif // !USE_FMOD
}

void FMSound::setSample(FMSample* s, bool playing) {
  stop(); sample = s;
#ifdef USE_FMOD
  channel = playing? FMSound::IS_CHANNEL_LOST: FMSound::WAS_SOUND_STOPPED;
#else // !USE_FMOD
  alSourcei(soundSource,AL_BUFFER,s->getSoundBuffer());
  alSourcei(soundSource,AL_LOOPING,s->isLooping()?AL_TRUE:AL_FALSE);
  alSourcei(soundSource,AL_SOURCE_RELATIVE,AL_TRUE);
  float maxGain;
  alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
  alSourcef(soundSource,AL_GAIN,maxGain*s->getVolume()*(1.0f/255));
  if(s->getFrequency() > 0) {
    int freq;
    alGetBufferi(s->getSoundBuffer(),AL_FREQUENCY,&freq);
    alSourcef(soundSource,AL_PITCH,float(s->getFrequency())/freq);
  }
  if(playing)
    play();
#endif // !USE_FMOD
}

FMSound::SoundStatus FMSound::getSoundStatus() {
#ifdef USE_FMOD
  if(isAudible()) {
    FSOUND_SAMPLE* s = FSOUND_GetCurrentSample(channel);
    if(s == sample->getPointer()) {
      if(FSOUND_IsPlaying(channel) == TRUE)
        return IS_SOUND_PLAYING;
      else
        channel = WAS_SOUND_STOPPED;
    } else {
      channel = sample->isLooping()? IS_CHANNEL_LOST: WAS_SOUND_STOPPED;
    }
  }
  return (SoundStatus)channel;
#else // !USE_FMOD
  ALint status;
  alGetSourcei(soundSource,AL_SOURCE_STATE,&status);
  switch(status) {
    case AL_INITIAL:
    case AL_PLAYING:
    case AL_PAUSED:
      return IS_SOUND_PLAYING;
    case AL_STOPPED:
    default:
      return WAS_SOUND_STOPPED;
  }
#endif // !USE_FMOD
}

//
// FM3DSound
//

FM3DSound::FM3DSound(int c, FM3DSample* s): FMSound(c,s) {
#ifdef USE_FMOD
#else // !USE_FMOD
  alSourcei(soundSource,AL_SOURCE_RELATIVE,AL_FALSE);
  if(s->getMinDistance() > 0)
    alSourcef(soundSource,AL_REFERENCE_DISTANCE,s->getMinDistance());
#endif // !USE_FMOD
}

void FM3DSound::set3DSample(FM3DSample* s, bool playing) {
  stop(); sample = s;
#ifdef USE_FMOD
  channel = playing? FMSound::IS_CHANNEL_LOST: FMSound::WAS_SOUND_STOPPED;
#else // !USE_FMOD
  alSourcei(soundSource,AL_BUFFER,s->getSoundBuffer());
  alSourcei(soundSource,AL_LOOPING,s->isLooping()?AL_TRUE:AL_FALSE);
  float maxGain;
  alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
  alSourcef(soundSource,AL_GAIN,maxGain*s->getVolume()*(1.0f/255));
  if(s->getFrequency() > 0) {
    int freq;
    alGetBufferi(s->getSoundBuffer(),AL_FREQUENCY,&freq);
    alSourcef(soundSource,AL_PITCH,float(s->getFrequency())/freq);
  }
  if(s->getMinDistance() > 0)
    alSourcef(soundSource,AL_REFERENCE_DISTANCE,s->getMinDistance());
  if(playing)
    play();
#endif // !USE_FMOD
}

#ifndef USE_FMOD

//
// FMCaptureDevice
//

FMCaptureDevice::FMCaptureDevice(int iMaxSamp, int iFreq, int iBits)
throw(ExceptionThrown):
  mono8(iBits == 8), availableSamples(0), samplesBuffer(NULL),
  frequency(iFreq), maxSamples(iMaxSamp)
{
	device = alcCaptureOpenDevice(NULL,
  	iFreq,mono8? AL_FORMAT_MONO8: AL_FORMAT_MONO16,iMaxSamp
  );
  if(device == NULL)
		Exception::throws("OpenAL alcCaptureOpenDevice Error");
	samplesBuffer = new unsigned char[mono8? iMaxSamp: iMaxSamp*2];
}

FMCaptureDevice::~FMCaptureDevice() {
	if(samplesBuffer)
  	delete samplesBuffer;
	alcCaptureCloseDevice(device);
}

#pragma pack (push,1)
typedef struct {
	char szRIFF[4];
	long lRIFFSize;
	char szWave[4];
	char szFmt[4];
	long lFmtSize;
	WAVEFORMATEX wfex;
	char szData[4];
	long lDataSize;
} WAVEHEADER;
#pragma pack (pop)

bool FMCaptureDevice::saveAsWav(const char* fileName) {
	FILE* file = fopen(fileName,"wb");
  if(file) {
  	WAVEHEADER waveHeader;
		sprintf(waveHeader.szRIFF,"RIFF");
		sprintf(waveHeader.szWave,"WAVE");
		sprintf(waveHeader.szFmt,"fmt ");
		waveHeader.lFmtSize = sizeof(WAVEFORMATEX);
		waveHeader.wfex.nChannels = 1;
		waveHeader.wfex.wBitsPerSample = mono8? 8: 16;
		waveHeader.wfex.wFormatTag = WAVE_FORMAT_PCM;
		waveHeader.wfex.nSamplesPerSec = frequency;
		waveHeader.wfex.nBlockAlign =
    	waveHeader.wfex.nChannels*waveHeader.wfex.wBitsPerSample/8;
		waveHeader.wfex.nAvgBytesPerSec =
    	waveHeader.wfex.nSamplesPerSec*waveHeader.wfex.nBlockAlign;
		waveHeader.wfex.cbSize = 0;
		sprintf(waveHeader.szData,"data");
		waveHeader.lDataSize = availableSamples*waveHeader.wfex.nBlockAlign;
    waveHeader.lRIFFSize = waveHeader.lDataSize+ sizeof(WAVEHEADER)-8;
		fwrite(&waveHeader,sizeof(WAVEHEADER),1,file);
		fwrite(samplesBuffer,waveHeader.lDataSize,1,file);
		fclose(file);
	  return true;
  }
  return false;
}

#endif // !USE_FMOD

#ifdef USE_MUSIC

//
// FMMusic
//

FMMusic::FMMusic(int length, unsigned char* buffer)
#ifdef USE_FMOD
#else // !USE_FMOD
  :looping(false),timeDivision(0),musicBuffer(NULL),
   midiStream(NULL),bufferPlaying(-1),buffersCount(0)
#endif // !USE_FMOD
{
#ifdef USE_FMOD
  module = FMUSIC_LoadSongEx(
    (const char*)buffer,0,length,FSOUND_LOADMEMORY,NULL,0
  );
#else // !USE_FMOD
  getMidiStream(buffer,length,&timeDivision,&buffersCount,&musicBuffer);
#endif // USE_FMOD
}

FMMusic::~FMMusic() {
#ifdef USE_FMOD
  FMUSIC_FreeSong(module);
#else // !USE_FMOD
  stop();
  if(musicBuffer) {
  	for(unsigned int ct = 0; ct < buffersCount; ct++) {
 		  if(musicBuffer[ct]) {
   	  	if(musicBuffer[ct]->lpData)
          delete[] musicBuffer[ct]->lpData;
        delete musicBuffer[ct];
      }
 		}
   	delete[] musicBuffer;
  }
#endif // !USE_FMOD
}

#ifdef USE_FMOD
#else // !USE_FMOD

static void CALLBACK MainMidiProc(
	HMIDIIN hMidi, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2
) {
  hMidi; dwParam1; dwParam2;
	FMMusic* music = reinterpret_cast<FMMusic*>(dwInstance);
  if(uMsg == MOM_DONE) {
 		int bp = music->getBufferPlaying();
    if(bp < 0) return;
    if((++bp) < music->getBuffersCount()) {
   		midiStreamOut(
        music->getStream(),music->getHeader(bp),sizeof(MIDIHDR)
      );
      music->setBufferPlaying(bp);
 	  } else {
			if(music->isLooping()) {
     		midiStreamOut(
          music->getStream(),music->getHeader(0),sizeof(MIDIHDR)
        );
        music->setBufferPlaying(0);
      } else {
      	music->stop();
      }
    }
  }
}

void FMMusic::play() {
	stop();
  UINT uMIDIDeviceID = MIDI_MAPPER;
 	midiStreamOpen(
  	&midiStream,&uMIDIDeviceID,(DWORD)1,
 	  (DWORD)::MainMidiProc,(DWORD)this,CALLBACK_FUNCTION
 	);
  MIDIPROPTIMEDIV	mptd;
 	mptd.cbStruct = sizeof(mptd);
 	mptd.dwTimeDiv = timeDivision;
	midiStreamProperty(midiStream,(LPBYTE)&mptd,MIDIPROP_SET|MIDIPROP_TIMEDIV);
	for(unsigned int ct = 0; ct < buffersCount; ct++)
  	midiOutPrepareHeader((HMIDIOUT)midiStream,musicBuffer[ct],sizeof(MIDIHDR));
 	midiStreamRestart(midiStream);
 	midiStreamOut(midiStream,musicBuffer[0],sizeof(MIDIHDR));
	bufferPlaying = 0;
}

void FMMusic::stop() {
	if(bufferPlaying >= 0) {
		midiStreamStop(midiStream);
		for(unsigned int ct = 0; ct < buffersCount; ct++) {
    	midiOutUnprepareHeader(
        (HMIDIOUT)midiStream,musicBuffer[ct],sizeof(MIDIHDR)
      );
    }
	 	midiStreamClose(midiStream);
  	midiStream = NULL;
	  bufferPlaying = -1;
  }
}

int FMMusic::getVolume() {
  unsigned long volume;
  midiOutGetVolume((HMIDIOUT)midiStream,&volume);
  return int((volume & 0xffff) >> 8);
}

void FMMusic::setVolume(unsigned char vol) {
  unsigned int volume = (vol << 8);
  volume |= (volume << 16);
  midiOutSetVolume((HMIDIOUT)midiStream,volume);
}

#endif // !USE_FMOD

#endif // USE_MUSIC

#endif // USE_SOUND
