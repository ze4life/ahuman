/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gloverlay.h"
#include "glwin.h"

#include "datasets.inc"

//
// GLOverlayVisible
//
GLOverlayVisible::GLOverlayVisible(): visible(false) {}

//
// GLOverlayLayered
//
GLOverlayLayered::GLOverlayLayered(): layer(0) {}

GLOverlayLayered::~GLOverlayLayered() {}

#ifdef USE_SJGUI

//
// GLGuiObject
//

GLGuiObject::~GLGuiObject() {
  children.deleteElements();
  sjgui::CWnd* parent = getParentWnd();
  if(parent)
    parent->UnRegisterChild(object);
}

void GLGuiObject::add(GLGuiObject* child) {
  children.add(child);
  sjgui::CWnd* parent = child->getParentWnd();
  if(parent)
    parent->UnRegisterChild(child);
  RegisterChild(child);
}

void GLGuiObject::remove(GLGuiObject* child) {
  UnRegisterChild(child);
  children.remove(child);
}

void GLGuiObject::render(GLCamera& camera) {
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
	glLoadIdentity();
  GLWin& glWin = GLWin::get();
	gluOrtho2D(0,glWin.getWidth(),glWin.getHeight(),0);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
	glLoadIdentity();
	glDisable(GL_TEXTURE_2D);
  Animate();
  Draw();
	glEnable(GL_TEXTURE_2D);
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
};

#endif // USE_SJGUI

//
// GLOverlayColor
//
GLOverlayColor::GLOverlayColor(float r, float g, float b, float a):
  red(r), green(g), blue(b), alpha(a)
{}

//
// GLOverlayFader
//
void GLOverlayFader::render(GLCamera& camera) {
  if(getAlpha() == 0)
    return;
  glDisable(GL_CULL_FACE);
  glDisable(GL_TEXTURE_2D);
  if(isTransparent()) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  glColor4f(getRed(),getGreen(),getBlue(),getAlpha());
  GLWin& glWin = GLWin::get();
  int w = glWin.getWidth();
  int h = glWin.getHeight();
  const int VERT_COUNT = 4;
  const int COMP_COUNT = 3;
  float arrays[COMP_COUNT*VERT_COUNT] = {
    0,0,getLayer(),
    w,0,getLayer(),
    0,h,getLayer(),
    w,h,getLayer(),
  };
  glVertexPointer(COMP_COUNT,GL_FLOAT,COMP_COUNT*sizeof(float),arrays);
  glEnableClientState(GL_VERTEX_ARRAY);
  glDrawArrays(GL_TRIANGLE_STRIP,0,VERT_COUNT);
  glDisableClientState(GL_VERTEX_ARRAY);
  if(isTransparent())
    glDisable(GL_BLEND);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_CULL_FACE);
}

//
// GLOverlayLocation
//

GLOverlayLocation::GLOverlayLocation(float iX, float iY): x(iX), y(iY) {}

//
// GLOverlayRotation
//

GLOverlayRotation::GLOverlayRotation(float rot): rotation(rot*(180/M_PI)) {}

//
// GLOverlayDimension
//

GLOverlayDimension::GLOverlayDimension(float iW, float iH):
  width(iW), height(iH)
{}

//
// GLOverlayTextureCoord
//

GLOverlayTextureCoord::GLOverlayTextureCoord(
  float l, float b, float r, float t
):
  left(l), bottom(b), right(r), top(t)
{}

//
// GLOverlayText
//

GLOverlayText::GLOverlayText(const char* txt, float iX, float iY):
  String(txt), GLOverlayLocation(iX, iY), alignment(CENTER), scale(1)
{}

GLOverlayText::GLOverlayText(
  char* txt, float iR, float iG, float iB, float iX, float iY
):
  String(txt), GLOverlayLocation(iX, iY), GLOverlayColor(iR,iG,iB),
  alignment(CENTER), scale(1)
{}

void GLOverlayText::render(GLFont& font) {
  bool isTextured = font.isTextured();
  if(isTextured) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  font.setColor(getRed(),getGreen(),getBlue(),getAlpha());
  glPushMatrix();
  int length = getLength();
  glTranslatef(
    getX()-(
      alignment == LEFT? 0: (
        font.getSpacing()*length*scale*(alignment == CENTER? 0.5f: 1)
      )
    ),
    getY(),0
  );
  if(scale != 1)
    glScalef(scale,scale,1);
  if(rotation)
    glRotatef(rotation,0,0,-1);
  font.drawText(length,getText());
  glPopMatrix();
  if(isTextured)
    glDisable(GL_BLEND);
}

//
// GLOverlayTexts
//

GLOverlayTexts::GLOverlayTexts(GLFont* f): font(f->acquireReference()) {
}

GLOverlayTexts::~GLOverlayTexts() {
  if(font) font->releaseReference();
}

GLOverlayText* GLOverlayTexts::getText(float x, float y) {
  const int height = font->getHeight();
  const int spacing = font->getSpacing();
  for(int ct = 0; ct < getSize(); ct++) {
    GLOverlayText* txt = getElement(ct);
    float scale = txt->getScale();
    if(txt->isVisible()) {
      int length = strlen(txt->getText());
      float txtX0 = getX()+txt->getX();
      float txtX1 = txtX0;
      float txtY0 = getY()+txt->getY();
      float txtY1 = txtY0+scale*height;
      switch(txt->getAlignment()) {
        case GLOverlayText::LEFT: {
          txtX1 += scale*spacing*length;
          break;
        }
        case GLOverlayText::CENTER: {
          txtX0 -= scale*spacing*length*0.5f;
          txtX1 += scale*spacing*length*0.5f;
          break;
        }
        case GLOverlayText::RIGHT: {
          txtX0 -= int(scale*spacing*length);
          break;
        }
      }
      if((x >= txtX0) && (x <= txtX1) && (y >= txtY0) && (y <= txtY1))
        return txt;
    }
  }
  return NULL;
}

GLOverlayText* GLOverlayTexts::getText(int index) {
	if(index >= 0 && index < getSize())
  	return getElement(index);
  return NULL;
}

void GLOverlayTexts::render(GLCamera& camera) {
  font->initialize();
  bool isFontTextured = font->isTextured();
  if(isFontTextured) {
    glEnable(GL_ALPHA_TEST);
    dynamic_cast<GLTexturedFont*>(font)->applyTexture();
  } else {
    glDisable(GL_TEXTURE_2D);
  }
  glPushMatrix();
  glTranslatef(getX(),getY(),getLayer());
  if(rotation)
    glRotatef(rotation,0,0,-1);
  for(int ct = 0; ct < getSize(); ct++) {
    GLOverlayText* txt = getElement(ct);
    if(txt->isVisible())
      txt->render(*font);
  }
  glPopMatrix();
  if(isFontTextured)
    glDisable(GL_ALPHA_TEST);
	else
    glEnable(GL_TEXTURE_2D);
}

//
// GLOverlaySprite
//

GLOverlaySprite::GLOverlaySprite(
  float iW, float iH, GLTexture* txt, bool ha,
  float l, float b, float r, float t, float iX, float iY
):
  GLOverlayDimension(iW,iH), GLOverlayLocation(iX,iY),
  GLOverlayTextureCoord(l,b,r,t), texture(txt->acquireReference()),
  alphaChannel(ha)
{}

GLOverlaySprite::~GLOverlaySprite() {
  if(texture) texture->releaseReference();
}

void GLOverlaySprite::render(GLCamera& camera) {
  glDisable(GL_CULL_FACE);
  if(hasAlphaChannel() || isTransparent()) {
    glEnable(GL_BLEND);
    glEnable(GL_ALPHA_TEST);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
  }
  glColor4f(getRed(),getGreen(),getBlue(),getAlpha());
  texture->apply();
  glPushMatrix();
  glTranslatef(x,y,getLayer());
  if(rotation)
    glRotatef(rotation,0,0,-1);
  glNormal3f(0,0,-1);
  const int VERTEXES_COUNT = 4;
  const int VERT_COMP_COUNT = 3;
  const int TEX_COMP_COUNT = 2;
  const float w2 = width*0.5f;
  const float h2 = height*0.5f;
  float arrays[(VERT_COMP_COUNT+TEX_COMP_COUNT)*VERTEXES_COUNT] = {
    right,bottom, w2,-h2,0,
    right,top,    w2, h2,0,
    left, bottom,-w2,-h2,0,
    left, top,   -w2, h2,0,
  };
#ifdef USE_OGLES
  glVertexPointer(
    VERT_COMP_COUNT,GL_FLOAT,(VERT_COMP_COUNT+TEX_COMP_COUNT)*sizeof(float),
    arrays+(TEX_COMP_COUNT*sizeof(float))
  );
  glTexCoordPointer(
    TEX_COMP_COUNT,GL_FLOAT,(VERT_COMP_COUNT+TEX_COMP_COUNT)*sizeof(float),
    arrays
  );
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glDrawArrays(GL_TRIANGLE_STRIP,0,VERTEXES_COUNT);
#else // !USE_OGLES
  glInterleavedArrays(GL_T2F_V3F,0,arrays);
  glDrawArrays(GL_TRIANGLE_STRIP,0,VERTEXES_COUNT);
#endif // !USE_OGLES
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glEnable(GL_CULL_FACE);
  if(hasAlphaChannel() || isTransparent()) {
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
    glDepthMask(GL_TRUE);
  }
  glPopMatrix();
}

//
// GLOverlayIndexes
//

GLOverlayIndexes::GLOverlayIndexes(): count(0), indexes(NULL) {}

GLOverlayIndexes::GLOverlayIndexes(int indexesCount, unsigned short* iIndexes):
  count(indexesCount), indexes(iIndexes)
{}

void GLOverlayIndexes::destroyObject() {
  if(indexes)
    delete indexes;
  delete this;
}

//
// GLOverlayCoords
//

GLOverlayCoords::GLOverlayCoords(): count(0), coords(NULL), colors(NULL) {}

GLOverlayCoords::GLOverlayCoords(
	int coordsCount, float* newCoords, unsigned char* newColors
):
  count(coordsCount), coords(newCoords), colors(newColors)
{}

void GLOverlayCoords::destroyObject() {
  if(coords)
    delete coords;
  if(colors)
    delete colors;
  delete this;
}

//
// GLPoints
//

GLOverlayPoints::GLOverlayPoints(
 	int coordsCount, float* newCoords, unsigned char* newColors, bool iSmooth
):
	smooth(iSmooth), size(1),
  coords((new GLOverlayCoords(coordsCount,newCoords,newColors))->acquireReference())
{}

GLOverlayPoints::GLOverlayPoints(GLOverlayCoords& newCoords, bool iSmooth):
	smooth(iSmooth), size(1), coords(newCoords.acquireReference())
{}

GLOverlayPoints::~GLOverlayPoints() {
  if(coords)
  	coords->releaseReference();
}

void GLOverlayPoints::render(GLCamera& camera) {
  glPushMatrix();
  glTranslatef(x,y,getLayer());
  if(rotation)
    glRotatef(rotation,0,0,-1);
  glDisable(GL_TEXTURE_2D);
  if(isTransparent()) {
    glDepthMask(GL_FALSE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  if(size != 1)
  	glPointSize(size);
  if(smooth)
  	glEnable(GL_POINT_SMOOTH);
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(2,GL_FLOAT,GLOverlayCoords::V_STRIDE,getCoords().getCoords());
	if(getCoords().getColors() == NULL) {
		glColor4f(getRed(),getGreen(),getBlue(),getAlpha());
  } else {
	  glEnableClientState(GL_COLOR_ARRAY);
  	glColorPointer(4,GL_UNSIGNED_BYTE,GLOverlayCoords::C_STRIDE,getCoords().getColors());
  }
  glDrawArrays(GL_POINTS,0,getCoords().getCount());
  glDisableClientState(GL_VERTEX_ARRAY);
	if(getCoords().getColors())
	  glDisableClientState(GL_COLOR_ARRAY);
  if(smooth)
  	glDisable(GL_POINT_SMOOTH);
  if(size != 1)
  	glPointSize(1);
  if(isTransparent()) {
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
  }
  glEnable(GL_TEXTURE_2D);
  glPopMatrix();
}

//
// GLOverlayLines
//

GLOverlayLines::GLOverlayLines(
  int indexesCount, unsigned short* iIndexes,
	int coordsCount, float* iCoords, unsigned char* iColors,
  int iMode, bool iSmooth
):
	mode(iMode), indexes(
  	(new GLOverlayIndexes(indexesCount,iIndexes))->acquireReference()
  ),
	GLOverlayPoints(coordsCount,iCoords,iColors), pattern(0xffff), factor(1)
{}

GLOverlayLines::GLOverlayLines(
	GLOverlayCoords& iCoords, GLOverlayIndexes& iIndexes,
  int iMode, bool iSmooth
):
	mode(iMode), indexes(iIndexes.acquireReference()),
  GLOverlayPoints(iCoords,iSmooth)
{}

GLOverlayLines::~GLOverlayLines() {
  if(indexes)
  	indexes->releaseReference();
}

void GLOverlayLines::render(GLCamera& camera) {
  glPushMatrix();
  glTranslatef(x,y,getLayer());
  if(rotation)
    glRotatef(rotation,0,0,-1);
  glDisable(GL_TEXTURE_2D);
  if(isTransparent()) {
    glDepthMask(GL_FALSE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  if(smooth)
  	glEnable(GL_LINE_SMOOTH);
  if(size != 1)
  	glLineWidth(size);
  if(pattern != 0xffff) {
  	glEnable(GL_LINE_STIPPLE);
  	glLineStipple(factor,pattern);
  }
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(2,GL_FLOAT,GLOverlayCoords::V_STRIDE,getCoords().getCoords());
	if(getCoords().getColors() == NULL) {
		glColor4f(getRed(),getGreen(),getBlue(),getAlpha());
  } else {
	  glEnableClientState(GL_COLOR_ARRAY);
  	glColorPointer(4,GL_UNSIGNED_BYTE,GLOverlayCoords::C_STRIDE,getCoords().getColors());
  }
  glDrawElements(mode,indexes->getCount(),GL_UNSIGNED_SHORT,indexes->getIndexes());
  glDisableClientState(GL_VERTEX_ARRAY);
	if(getCoords().getColors())
	  glDisableClientState(GL_COLOR_ARRAY);
  if(pattern != 0xffff)
  	glDisable(GL_LINE_STIPPLE);
  if(size != 1)
  	glLineWidth(1);
  if(smooth)
  	glDisable(GL_LINE_SMOOTH);
  if(isTransparent()) {
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
  }
  glEnable(GL_TEXTURE_2D);
  glPopMatrix();
}

//
// GLOverlayPolys
//

GLOverlayPolys::GLOverlayPolys(
  int indexesCount, unsigned short* iIndexes,
	int coordsCount, float* iCoords, unsigned char* iColors,
  int iMode, bool iSmooth
):
	fillMode(FILL), mask(NULL),
	GLOverlayLines(
  	indexesCount,iIndexes,coordsCount,iCoords,iColors,iMode,iSmooth
  )
{}

GLOverlayPolys::GLOverlayPolys(
	GLOverlayCoords& iCoords, GLOverlayIndexes& iIndexes,
  int iMode, bool iSmooth
):
	fillMode(FILL), mask(NULL),
	GLOverlayLines(iCoords,iIndexes,iMode,iSmooth)
{}

GLOverlayPolys::~GLOverlayPolys() {
  if(mask)
  	delete mask;
}

void GLOverlayPolys::render(GLCamera& camera) {
  glPushMatrix();
  glTranslatef(x,y,getLayer());
  if(rotation)
    glRotatef(rotation,0,0,-1);
  glDisable(GL_CULL_FACE);
  glDisable(GL_TEXTURE_2D);
  if(isTransparent()) {
    glDepthMask(GL_FALSE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  switch(fillMode) {
  	case FILL: {
		  if(smooth)
  			glEnable(GL_POLYGON_SMOOTH);
      if(mask) {
      	glEnable(GL_POLYGON_STIPPLE);
      	glPolygonStipple(mask);
      }
    	break;
    }
    case POINT: {
		  if(size != 1)
  			glPointSize(size);
		  if(smooth)
  			glEnable(GL_POINT_SMOOTH);
    	break;
    }
    case LINE: {
		  if(size != 1)
  			glLineWidth(size);
		  if(smooth)
  			glEnable(GL_LINE_SMOOTH);
		  if(pattern != 0xffff) {
  			glEnable(GL_LINE_STIPPLE);
		  	glLineStipple(factor,pattern);
		  }
    	break;
    }
  }
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(2,GL_FLOAT,GLOverlayCoords::V_STRIDE,getCoords().getCoords());
	if(getCoords().getColors() == NULL) {
		glColor4f(getRed(),getGreen(),getBlue(),getAlpha());
  } else {
	  glEnableClientState(GL_COLOR_ARRAY);
  	glColorPointer(4,GL_UNSIGNED_BYTE,GLOverlayCoords::C_STRIDE,getCoords().getColors());
  }
  glDrawElements(mode,indexes->getCount(),GL_UNSIGNED_SHORT,indexes->getIndexes());
  glDisableClientState(GL_VERTEX_ARRAY);
	if(getCoords().getColors())
	  glDisableClientState(GL_COLOR_ARRAY);
  switch(fillMode) {
  	case FILL: {
		  if(smooth)
  			glDisable(GL_POLYGON_SMOOTH);
      if(mask)
      	glDisable(GL_POLYGON_STIPPLE);
    	break;
    }
    case POINT: {
		  if(smooth)
  			glDisable(GL_POINT_SMOOTH);
		  if(size != 1)
  			glPointSize(1);
    	break;
    }
    case LINE: {
		  if(pattern != 0xffff)
  			glDisable(GL_LINE_STIPPLE);
		  if(size != 1)
		  	glLineWidth(1);
		  if(smooth)
  			glDisable(GL_LINE_SMOOTH);
    	break;
    }
  }
  if(isTransparent()) {
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
  }
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_CULL_FACE);
  glPopMatrix();
}

//
// GLOverlayWorldView
//

GLOverlayWorldView::GLOverlayWorldView(float iW, float iH, float iX, float iY)
	{setMainView(false); setViewport(iX,iY,iW,iH); setPerspective(60,0.1f,1000);}

void GLOverlayWorldView::render(GLCamera& camera)	{
  GLWin& glWin = GLWin::get();
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glWin.getWorld().render((GLCamera&)*this);
  glDisable(GL_LIGHTING);
  glDisable(GL_DEPTH_TEST);
  glViewport(0,0,glWin.getWidth(),glWin.getHeight());
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
}

//
// GLOverlayViewport
//

GLOverlayViewport::GLOverlayViewport(float iW, float iH, float iX, float iY):
  GLOverlayWorldView(iW,iH,iX,iY), GLOverlayColor(0,0,0,0), sun(NULL),
  terrain(NULL), scenery(NULL), shadows(1), background(NULL), ambient(1,1,1,1),
  transparentObjects(1), opaqueObjects(1)
{}

GLOverlayViewport::~GLOverlayViewport()
	{removeEnvironment();}

bool GLOverlayViewport::removeShadow(GLObject* o) {
  for(int ct = 0; shadows.getSize(); ct++) {
    GLShadow* s = shadows.getElement(ct);
    if(&(s->getObject()) == o) {
      shadows.removeElement(ct);
      return true;
    }
  }
  return false;
}

void GLOverlayViewport::removeEnvironment() {
  if(background) {
  	delete background;
    background = NULL;
  }
  if(scenery) {
    delete scenery;
    scenery = NULL;
  }
  if(terrain) {
    delete terrain;
    terrain = NULL;
  }
  if(sun) {
    delete sun;
    sun = NULL;
  }
}

void GLOverlayViewport::setBackground(GLBackground* bg) {
  if(background)
    delete background;
  background = bg;
}

void GLOverlayViewport::setSun(GLSunLight* s) {
  if(sun)
  	delete sun;
  sun = s;
}

void GLOverlayViewport::setTerrain(GLTerrain* t) {
  if(terrain)
  	delete terrain;
  terrain = t;
}

void GLOverlayViewport::setScenery(GLScenery* s) {
  if(scenery)
  	delete scenery;
  scenery = s;
}

void GLOverlayViewport::render(GLCamera& camera) {
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
	glViewport(
  	(int)getViewX(),(int)getViewY(),(int)getViewWidth(),(int)getViewHeight()
  );
	if(isOrtho())
  	applyOrtho();
  else
  	applyPerspective();
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
	glEnable(GL_SCISSOR_TEST);
	glScissor(
  	(int)getViewX(),(int)getViewY(),(int)getViewWidth(),(int)getViewHeight()
	);
  glEnable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambient.getFloatArray());
  renderFog();
  if(background && background->isVisible()) {
    applyRotation();
    background->render();
  } else if(getAlpha() != 0) {
	  glClearColor(getRed(),getGreen(),getBlue(),getAlpha());
    glClear(GL_COLOR_BUFFER_BIT);
  }
  applyTransform();
  if(sun && sun->isVisible()) {
    M3Vector sunPosition(sun->getDirection());
    sunPosition.scale(sun->getCameraDistance()).add(
      getPositionX(),getPositionY(),getPositionZ()
    );
    sun->setPosition(sunPosition);
    if(!sun->clip(*this))
      sun->render(*this);
  }
  if(scenery && scenery->isVisible()) {
    scenery->initRender(*this);
    if(scenery->hasTransparencies())
	    scenery->renderOpaque(*this);
    else
	    scenery->render(*this);
    for(int ct = 0; ct < scenery->getFurnituresCount(); ct++) {
      GLFurniture* f = scenery->getFurniture(ct);
      f->initRender(*this,*scenery);
      f->render(*this,*scenery);
    }
    if(getOpaqueObjectsCount()) {
      for(int ct = 0; ct < getOpaqueObjectsCount(); ct++) {
        GLObject* obj = getOpaqueObject(ct);
        if(obj->isVisible()) obj->clip(*this);
      }
      opaqueObjects.quickSort(0,getOpaqueObjectsCount()-1);
      for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
        GLObject* obj = getOpaqueObject(ct);
        if(!obj->isClipped() && obj->isVisible()) {
          if(scenery->checkVisibility(*this,obj)) {
            scenery->initRender(*this,obj);
            scenery->render(*this,obj);
          }
        }
      }
    }
    if(terrain && terrain->isVisible())
      terrain->render(*this);
    if(scenery->isShadowed() && getShadowsCount()) {
      for(int ct = getShadowsCount()-1; ct >= 0; ct--) {
        GLShadow* shd = getShadow(ct);
        GLObject& obj = shd->getObject();
        if(
          obj.isVisible() && scenery->checkVisibility(*this,&obj) &&
          ((!obj.isClipped()) || (!shd->checkClip(*this)))
        )
          shd->cast(*this,*scenery);
      }
    }
    if(scenery->hasTransparencies())
	    scenery->renderTransparent(*this);
    if(getTransparentObjectsCount()) {
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if(obj->isVisible()) obj->clip(*this);
      }
      transparentObjects.quickSort(0,getTransparentObjectsCount()-1);
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if(!obj->isClipped() && obj->isVisible()) {
          if(scenery->checkVisibility(*this,obj)) {
            scenery->initRender(*this,obj);
            scenery->render(*this,obj);
          }
        }
      }
    }
  } else {
    bool isTerrainVisible = terrain && terrain->isVisible();
    bool isTerrainReflective = isTerrainVisible && terrain->isReflective();
    bool isTerrainTransparent = isTerrainVisible && terrain->isTransparent();
    bool isTerrainShadowed = isTerrainVisible && terrain->isShadowed();
    if(isTerrainReflective) {
      glPushMatrix();
      glScalef(1,-1,1);
    }
    if(sun && sun->isVisible()) {
      sun->applyPropertiesTo(0);
      setNearestLight(true,sun->getDirection());
    }
    setRenderingShadows(isTerrainShadowed);
    setRenderingReflections(isTerrainReflective);
    setRenderingTransparencies(isTerrainTransparent);
    for(int ct = 0; ct < getOpaqueObjectsCount(); ct++) {
      GLObject* obj = getOpaqueObject(ct);
      if(obj->isVisible()) obj->clip(*this);
    }
    for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
      GLObject* obj = getTransparentObject(ct);
      if(obj->isVisible()) obj->clip(*this);
    }
    opaqueObjects.quickSort(0,getOpaqueObjectsCount()-1);
    transparentObjects.quickSort(0,getTransparentObjectsCount()-1);
    if(isTerrainReflective) {
      glCullFace(GL_FRONT);
      for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
        GLObject* obj = getOpaqueObject(ct);
        if((!obj->isClipped()) && (obj->isVisible()))
          obj->render(*this);
      }
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if((!obj->isClipped()) && (obj->isVisible()))
          obj->render(*this);
      }
      glCullFace(GL_BACK);
      glPopMatrix();
      camera.setRenderingReflections(false);
      if(sun && sun->isVisible())
        sun->applyPositionTo(0);
    }
    if(isTerrainVisible && !terrain->isTransparent())
      terrain->render(*this);
    for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
      GLObject* obj = getOpaqueObject(ct);
      if((!obj->isClipped()) && (obj->isVisible()))
        obj->render(*this);
    }
    if(isTerrainTransparent)
      terrain->render(*this);
    if(isTerrainShadowed) {
      for(int ct = getShadowsCount()-1; ct >= 0; ct--) {
        GLShadow* shd = getShadow(ct);
        GLObject& obj = shd->getObject();
        if(
          obj.isVisible() && ((!obj.isClipped()) || (!shd->checkClip(*this)))
        )
          shd->cast(*this,*terrain);
      }
    }
    for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
      GLObject* obj = getTransparentObject(ct);
      if((!obj->isClipped()) && (obj->isVisible()))
        obj->render(*this);
    }
    glDisable(GL_LIGHT0);
  }
  if(sun && (!sun->isClipped()) && sun->isVisible())
    sun->renderLensFlare(*this);
  glDisable(GL_LIGHTING);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_SCISSOR_TEST);
  GLWin& glWin = GLWin::get();
  glViewport(0,0,glWin.getWidth(),glWin.getHeight());
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
}

//
// GLOverlay
//

GLOverlay::GLOverlay():
#ifdef USE_SJGUI
  guiObjects(8),
#endif // USE_SJGUI
  sortedObjects(8), overlayObjects(8),
  pointerShown(false), pointer(NULL)
{}

GLOverlay::~GLOverlay() {}

void GLOverlay::setPointer(GLOverlaySprite* os, float x, float y) {
  if(pointer)
    removeOverlayObject(pointer);
  pointer = os;
  if(pointer) {
    addOverlayObject(pointer);
    if(x >= 0) pointer->setX(x);
    if(y >= 0) pointer->setY(y);
  }
}

void GLOverlay::movePointer(
  float dx, float dy, float maxX, float maxY, float minX, float minY
) {
  if(isPointerShown()) {
    if(dx != 0 || dy != 0) {
      movePointer(dx,dy);
      maxX -= int(pointer->getWidth());
      maxY -= int(pointer->getHeight());
      if(pointer->getX() < minX) pointer->setX(minX);
      if(pointer->getY() < minY) pointer->setY(minY);
      if(pointer->getX() >= maxX) pointer->setX(maxX-1);
      if(pointer->getY() >= maxY) pointer->setY(maxY-1);
    }
  }
}

void GLOverlay::render(GLCamera& camera) {
  sortedObjects.quickSort(0,getObjectsCount()-1);
  for(int ct = 0; ct < getObjectsCount(); ct++) {
    GLOverlayLayered* obj = getObject(ct);
    if(obj->isVisible())
      obj->render(camera);
  }
}
