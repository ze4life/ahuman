/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_BSP

#include <stdlib.h> // for atoi()
#include <dir.h> // for MAX_PATH

#include "glextensions.h"
#include "glbsp.h"

#include "glcolor.h"
#include "mathtables.h"

#include "math3d.inc"
#include "datasets.inc"

//
// Bitset
//

Bitset::Bitset(): bits(NULL), size(0) {
}

Bitset::~Bitset() {
  if(bits)
    delete bits;
}

//
// GLBspFace
//
GLBspFace::~GLBspFace() {
}

//
// GLPatch
//
GLPatch::GLPatch():
  vertexes(NULL), indexes(NULL), trianglesPerRow(NULL), rowIndexes(NULL)
{}

GLPatch::~GLPatch() {
  if(vertexes) delete[] vertexes;
	if(indexes)	delete[] indexes;
  if(trianglesPerRow) delete[] trianglesPerRow;
  if(rowIndexes) delete[] rowIndexes;
}

void GLPatch::tessellate(int iTessellation) {
	tessellation = iTessellation;
	vertexes = new BSPVertex[(tessellation+1)*(tessellation+1)];
	for(int ct = 0; ct <= tessellation; ct++) {
		float x = float(ct)/tessellation;
		vertexes[ct] =
      controls[0]*((1-x)*(1-x))+controls[3]*((1-x)*x*2)+controls[6]*(x*x);
	}
	for(int ct = 1; ct <= tessellation; ct++) {
		float y = float(ct)/tessellation;
    BSPVertex temp[3];
  	temp[0] =
      controls[0]*((1-y)*(1-y))+controls[1]*((1-y)*y*2)+controls[2]*(y*y);
  	temp[1] =
      controls[3]*((1-y)*(1-y))+controls[4]*((1-y)*y*2)+controls[5]*(y*y);
  	temp[2] =
      controls[6]*((1-y)*(1-y))+controls[7]*((1-y)*y*2)+controls[8]*(y*y);
		for(int ct2 = 0; ct2 <= tessellation; ct2++)	{
			float x = float(ct2)/tessellation;
			vertexes[ct*(tessellation+1)+ct2]=
        temp[0]*((1-x)*(1-x))+temp[1]*((1-x)*x*2)+temp[2]*(x*x);
		}
	}
	indexes = new unsigned int[tessellation*(tessellation+1)*2];
	for(int row = 0; row < tessellation; row++) {
		for(int col = 0; col <= tessellation; col++)	{
			indexes[(row*(tessellation+1)+col)*2+1] = row*(tessellation+1)+col;
			indexes[(row*(tessellation+1)+col)*2] = (row+1)*(tessellation+1)+col;
		}
	}
	if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
  	trianglesPerRow = new int[tessellation];
  	rowIndexes = new unsigned int*[tessellation];
  	for(int row = 0; row < tessellation; row++) {
  		trianglesPerRow[row] = 2*(tessellation+1);
		  rowIndexes[row] = &indexes[row*2*(tessellation+1)];
  	}
  }
}

//
// GLBspPatch
//
GLBspPatch::GLBspPatch(): patches(NULL) {
}

GLBspPatch::~GLBspPatch() {
  if(patches) delete[] patches;
}

//
// GLBsp
//

GLBsp::GLBsp():
  vertexesCount(0), vertexes(NULL), meshVertexesCount(0), meshVertexes(NULL),
  planesCount(0), planes(NULL), lightVolumesCount(0), lightVolumes(NULL),
  leavesCount(0), leaves(NULL), leafIndexes(NULL), leafCameraDists(NULL),
  leafFacesCount(0), leafFaces(NULL), brushesCount(0), brushes(NULL),
  brushSidesCount(0), brushSides(NULL), leafBrushesCount(0), leafBrushes(NULL),
  nodesCount(0), nodes(NULL), faces(NULL), textures(NULL), lightmaps(NULL),
  showUntexturedPatches(false), showUntexturedPolygons(false),
  defaultTexture(NULL), showUntexturedMeshes(false),
  showTransparencies(false), startingPositions(8)
{
  clusters.clustersCount = 0;
	clusters.bytesPerCluster = 0;
	clusters.bitsets = NULL;
	glGenTextures(1,&defaultLightmap);
	glBindTexture(GL_TEXTURE_2D,defaultLightmap);
  float lightmapColor[4] = {0.5f,0.5f,0.5f};
	gluBuild2DMipmaps(GL_TEXTURE_2D,GL_RGBA8,1,1,GL_RGB,GL_FLOAT,lightmapColor);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
}

GLBsp::~GLBsp() {
  if(textures) {
    for(int ct = 0; ct < textures->getSize(); ct++)
      if(textures->getElement(ct))
        textures->getElement(ct)->releaseReference();
    delete textures;
  }
  if(lightmaps) {
    for(int ct = 0; ct < lightmaps->getSize(); ct++)
      if(lightmaps->getElement(ct))
        lightmaps->getElement(ct)->releaseReference();
    delete lightmaps;
  }
  glDeleteTextures(1,&defaultLightmap);
  if(defaultTexture) defaultTexture->releaseReference();
	if(vertexes) delete vertexes;
	if(meshVertexes) delete meshVertexes;
	if(planes) delete planes;
	if(nodes)	delete nodes;
	if(leaves) delete leaves;
  if(leafCameraDists) delete leafCameraDists;
  if(leafIndexes) delete leafIndexes;
	if(leafFaces)	delete leafFaces;
	if(brushes)	delete brushes;
	if(brushSides) delete brushSides;
	if(leafBrushes)	delete leafBrushes;
  if(lightVolumes) delete lightVolumes;
	if(clusters.bitsets) delete clusters.bitsets;
	if(faces)	delete faces;
}

static void getPosition(BSPVector& pos, char* entity) {
  char* value = strstr(entity,"\"origin\"")+10;
  char* mark = strchr(value,' ');
  *mark = '\0';
  pos.x = atoi(value);
  value = mark+1;
  mark = strchr(value,' ');
  *mark = '\0';
  pos.z = -atoi(value);
  value = mark+1;
  mark = strchr(value,'\"');
  *mark = '\0';
  pos.y = atoi(value);
}

#ifdef USE_DATA_FILES

bool GLBsp::load(const char* path, const char* filNam, float lightmapGamma) {
	char fileName[MAX_PATH];
  if(path)
  	strcat(strcpy(fileName,path),filNam);
  else
  	strcpy(fileName,filNam);
	FILE* file = fopen(fileName,"rb");
	if(file == NULL)
    return false;
  if(strstr(fileName,".bsp")) {
  	BSPHeader header;
	  fread(&header,1,sizeof(BSPHeader),file);
  	BSPLump lumps[BSPLump::MAX_LUMPS];
	  fread(&lumps,BSPLump::MAX_LUMPS,sizeof(BSPLump),file);
    char* entities = new char[lumps[BSPLump::ENTITIES_LUMP].length];
	  fseek(file,lumps[BSPLump::ENTITIES_LUMP].offset,SEEK_SET);
    fread(entities,lumps[BSPLump::ENTITIES_LUMP].length,1,file);
    char* entity = strtok(entities,"}");
    do {
      BSPVector bspPos;
      if(strstr(entity,"\"info_player_deathmatch\"")) {
        getPosition(bspPos,entity);
        startingPositions.addElement(bspPos);
      } else if(strstr(entity,"\"item_health\"")) {
        getPosition(bspPos,entity);
        medikitPositions.addElement(bspPos);
      } else if(strstr(entity,"\"item_regen\"")) {
        getPosition(bspPos,entity);
        foodPositions.addElement(bspPos);
      } else if(strstr(entity,"\"item_armor_body\"")) {
        getPosition(bspPos,entity);
        armorPositions.addElement(bspPos);
      } else if(strstr(entity,"\"ammo_bullets\"")) {
        getPosition(bspPos,entity);
        bulletsPositions.addElement(bspPos);
      } else if(strstr(entity,"\"ammo_grenades\"")) {
        getPosition(bspPos,entity);
        grenadesPositions.addElement(bspPos);
      } else if(strstr(entity,"\"weapon_machinegun\"")) {
        getPosition(bspPos,entity);
        weaponPositions.addElement(bspPos);
      }
      entity = strtok(NULL,"}");
    } while(entity);
    delete entities;
  	vertexesCount = lumps[BSPLump::VERTEXES_LUMP].length/sizeof(BSPFullVertex);
    if(vertexes) delete vertexes;
  	vertexes = new BSPVertex[vertexesCount];
	  fseek(file,lumps[BSPLump::VERTEXES_LUMP].offset,SEEK_SET);
  	for(int ct = 0; ct < vertexesCount; ct++)	{
      BSPFullVertex fullVertex;
		  fread(&fullVertex,1,sizeof(BSPFullVertex),file);
  		vertexes[ct].position.x = fullVertex.position.x;
	  	vertexes[ct].position.y = fullVertex.position.z;
		  vertexes[ct].position.z = -fullVertex.position.y;
  		vertexes[ct].textureCoord.u = fullVertex.textureCoord.u;
	  	vertexes[ct].textureCoord.v = -fullVertex.textureCoord.v;
		  vertexes[ct].lightmapCoord.u = fullVertex.lightmapCoord.u;
  		vertexes[ct].lightmapCoord.v = fullVertex.lightmapCoord.v;
	  }
  	meshVertexesCount = lumps[BSPLump::MESHVERTEXES_LUMP].length/sizeof(int);
    if(meshVertexes) delete meshVertexes;
  	meshVertexes = new int[meshVertexesCount];
	  fseek(file,lumps[BSPLump::MESHVERTEXES_LUMP].offset,SEEK_SET);
  	fread(meshVertexes,meshVertexesCount,sizeof(int),file);
	  int facesCount = lumps[BSPLump::FACES_LUMP].length/sizeof(BSPFace);
    if(faces) delete faces;
    faces = new DSArray<GLBspFace>(facesCount);
  	BSPFace* faceData = new BSPFace[facesCount];
	  fseek(file,lumps[BSPLump::FACES_LUMP].offset,SEEK_SET);
  	fread(faceData,facesCount,sizeof(BSPFace),file);
    for(int ct = 0; ct < facesCount; ct++) {
      GLBspFace* theFace = NULL;
      switch(faceData[ct].type) {
        case BSPFace::POLYGON: {
          GLBspPolygon* face = new GLBspPolygon();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          face->firstVertex = faceData[ct].firstVertex;
          face->vertexesCount = faceData[ct].vertexesCount;
          theFace = face;
          break;
        }
        case BSPFace::PATCH: {
          GLBspPatch* face = new GLBspPatch();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          int width = faceData[ct].patchSize[0];
          int height = faceData[ct].patchSize[1];
      		int widthCount = (width-1)/2;
    	  	int heightCount = (height-1)/2;
    		  face->patchesCount = widthCount*heightCount;
  		    face->patches = new GLPatch[face->patchesCount];
      		for(int y = 0; y < heightCount; y++) {
      			for(int x = 0; x < widthCount; x++) {
    	  			for(int row = 0; row < 3; row++) {
    		  			for(int col = 0; col < 3; col++) {
    			  			face->patches[y*widthCount+x].controls[row*3+col] =
                    vertexes[
                      faceData[ct].firstVertex +
                      (y * 2 * width + x * 2)+
									    row * width + col
                    ];
      					}
		      		}
    	  			face->patches[y*widthCount+x].tessellate(8);
    		  	}
  		    }
          theFace = face;
          break;
        }
        case BSPFace::MESH: {
          GLBspMesh* face = new GLBspMesh();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          face->firstVertex = faceData[ct].firstVertex;
          face->vertexesCount = faceData[ct].vertexesCount;
          face->firstMeshVertex = faceData[ct].firstMeshVertex;
          face->meshVertexesCount = faceData[ct].meshVertexesCount;
          theFace = face;
          break;
        }
        case BSPFace::BILLBOARD: {
          GLBspBillboard* face = new GLBspBillboard();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          theFace = face;
          break;
        }
      }
      faces->setElement(ct,theFace);
    }
    delete faceData;
  	int texturesCount = lumps[BSPLump::TEXTURES_LUMP].length/sizeof(BSPTexture);
    if(textures) {
      for(int ct = 0; ct < textures->getSize(); ct++)
        if(textures->getElement(ct))
         textures->getElement(ct)->releaseReference();
      delete textures;
    }
    textures = new DSArray<GLTexture,false>(texturesCount);
    textureIsHollow.resize(texturesCount);
    textureHasAlpha.resize(texturesCount);
  	BSPTexture* textureData = new BSPTexture[texturesCount];
	  fseek(file,lumps[BSPLump::TEXTURES_LUMP].offset,SEEK_SET);
  	fread(textureData,texturesCount,sizeof(BSPTexture),file);
	  for(int ct = 0; ct < texturesCount; ct++)	{
      const int CONTENTS_SOLID = 0x00000001;
      const int CONTENTS_WINDOW = 0x00000002;
      const int CONTENTS_PLAYERCLIP = 0x00010000;
      const int CONTENTS_MONSTER = 0x02000000;
      const int IS_HOLLOW =
        CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER;
      if(textureData[ct].contents & IS_HOLLOW)
        textureIsHollow.set(ct);
      char fileName[MAX_PATH];
      if(path)
	      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".jpg");
     	else
	      strcat(strcpy(fileName,textureData[ct].name),".jpg");
      DRImage* image;
      FILE* file = fopen(fileName,"rb");
      if(file) {
        fclose(file);
        DRJpegFile jpegFile(fileName);
        image = jpegFile.getImage();
      } else {
	      if(path)
		      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".tga");
    	 	else
		      strcat(strcpy(fileName,textureData[ct].name),".tga");
        file = fopen(fileName,"rb");
        if(file) {
          fclose(file);
          DRTgaFile tgaFile(fileName);
          image = tgaFile.getImage();
        } else {
		      if(path)
			      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".png");
    		 	else
		  	    strcat(strcpy(fileName,textureData[ct].name),".png");
          file = fopen(fileName,"rb");
          if(file) {
            fclose(file);
            DRPngFile pngFile(fileName);
            image = pngFile.getImage();
          } else {
            image = NULL;
          }
        }
      }
      if(image) {
	      if(image->getHasAlpha())
  	      textureHasAlpha.set(ct);
     		textures->setElement(
        	ct,(new GLTexture(*image,true))->acquireReference()
        );
        delete image;
      } else {
        textures->setElement(ct,NULL);
      }
	  }
  	delete[] textureData;
	  int lightmapsCount =
      lumps[BSPLump::LIGHTMAPS_LUMP].length/sizeof(BSPLightmap);
    if(lightmaps) {
      for(int ct = 0; ct < lightmaps->getSize(); ct++)
        if(lightmaps->getElement(ct))
          lightmaps->getElement(ct)->releaseReference();
      delete lightmaps;
    }
    lightmaps = new DSArray<GLTexture,false>(lightmapsCount);
	  fseek(file,lumps[BSPLump::LIGHTMAPS_LUMP].offset,SEEK_SET);
    BSPLightmap lightmapData;
	  for(int ct = 0; ct < lightmapsCount; ct++) {
  		fread(&lightmapData,1,sizeof(BSPLightmap),file);
      if(lightmapGamma != 1)
        DRImage::setGammaCorrection(
          (BSPByte*)lightmapData.imageBits,128,128,lightmapGamma
        );
      GLTexture* txt = (new GLTexture(
        (BSPByte*)lightmapData.imageBits,128,128)
      )->acquireReference();
      lightmaps->setElement(ct,txt);
	  }
  	nodesCount = lumps[BSPLump::NODES_LUMP].length/sizeof(BSPNode);
    if(nodes) delete nodes;
	  nodes = new BSPNode[nodesCount];
  	fseek(file,lumps[BSPLump::NODES_LUMP].offset,SEEK_SET);
	  fread(nodes,nodesCount,sizeof(BSPNode),file);
  	leavesCount = lumps[BSPLump::LEAVES_LUMP].length/sizeof(BSPLeaf);
    if(leaves) delete leaves;
	  leaves = new BSPLeaf[leavesCount];
    if(leafCameraDists) delete leafCameraDists;
		leafCameraDists = new float[leavesCount];
    if(leafIndexes) delete leafIndexes;
    leafIndexes = new int[leavesCount];
    for(int ct = 0; ct < leavesCount; ct++)
    	leafIndexes[ct] = ct+1;
  	fseek(file,lumps[BSPLump::LEAVES_LUMP].offset,SEEK_SET);
	  fread(leaves,leavesCount,sizeof(BSPLeaf),file);
  	for(int ct = 0; ct < leavesCount; ct++)	{
	  	int temp = leaves[ct].min.y;
		  leaves[ct].min.y = leaves[ct].min.z;
  		leaves[ct].min.z = -temp;
	  	temp = leaves[ct].max.y;
		  leaves[ct].max.y = leaves[ct].max.z;
  		leaves[ct].max.z = -temp;
	  }
  	leafFacesCount = lumps[BSPLump::LEAFFACES_LUMP].length/sizeof(int);
    if(leafFaces) delete leafFaces;
	  leafFaces = new int[leafFacesCount];
  	fseek(file,lumps[BSPLump::LEAFFACES_LUMP].offset,SEEK_SET);
	  fread(leafFaces,leafFacesCount,sizeof(int),file);
  	brushesCount = lumps[BSPLump::BRUSHES_LUMP].length/sizeof(BSPBrush);
    if(brushes) delete brushes;
	  brushes = new BSPBrush[brushesCount];
  	fseek(file,lumps[BSPLump::BRUSHES_LUMP].offset,SEEK_SET);
	  fread(brushes,brushesCount,sizeof(BSPBrush),file);
  	brushSidesCount =
      lumps[BSPLump::BRUSHSIDES_LUMP].length/sizeof(BSPBrushSide);
    if(brushSides) delete brushSides;
  	brushSides = new BSPBrushSide[brushSidesCount];
	  fseek(file,lumps[BSPLump::BRUSHSIDES_LUMP].offset,SEEK_SET);
  	fread(brushSides,brushSidesCount,sizeof(BSPBrushSide),file);
	  leafBrushesCount = lumps[BSPLump::LEAFBRUSHES_LUMP].length/sizeof(int);
    if(leafBrushes) delete leafBrushes;
  	leafBrushes = new int[leafBrushesCount];
	  fseek(file,lumps[BSPLump::LEAFBRUSHES_LUMP].offset,SEEK_SET);
  	fread(leafBrushes,leafBrushesCount,sizeof(int),file);
	  planesCount = lumps[BSPLump::PLANES_LUMP].length/sizeof(BSPPlane);
    if(planes) delete planes;
  	planes = new BSPPlane[planesCount];
	  fseek(file,lumps[BSPLump::PLANES_LUMP].offset,SEEK_SET);
  	fread(planes,planesCount,sizeof(BSPPlane),file);
	  for(int ct = 0; ct < planesCount; ct++)	{
		  float temp = planes[ct].normal.y;
  		planes[ct].normal.y = planes[ct].normal.z;
	  	planes[ct].normal.z = -temp;
  	}
	  fseek(file,lumps[BSPLump::MODELS_LUMP].offset,SEEK_SET);
  	fread(&staticModel,1,sizeof(BSPModel),file);
    lightVolumesGrid.x =
      int(floor(staticModel.max[0]/64)-ceil(staticModel.min[0]/64)+1);
    lightVolumesInvSizes.x =
      lightVolumesGrid.x/(staticModel.max[0]-staticModel.min[0]);
    lightVolumesGrid.y =
      int(floor(staticModel.max[2]/128)-ceil(staticModel.min[2]/128)+1);
    lightVolumesInvSizes.y =
      lightVolumesGrid.y/(staticModel.max[2]-staticModel.min[2]);
    lightVolumesGrid.z =
      int(floor(staticModel.max[1]/64)-ceil(staticModel.min[1]/64)+1);
    lightVolumesInvSizes.z =
      lightVolumesGrid.z/(staticModel.max[1]-staticModel.min[1]);
  	lightVolumesCount =
      lumps[BSPLump::LIGHTVOLUMES_LUMP].length/sizeof(BSPLightVolume);
    if(lightVolumes) delete lightVolumes;
  	lightVolumes = new BSPLightVolume[lightVolumesCount];
	  fseek(file,lumps[BSPLump::LIGHTVOLUMES_LUMP].offset,SEEK_SET);
  	fread(lightVolumes,lightVolumesCount,sizeof(BSPLightVolume),file);
    for(int ct = 0; ct < lightVolumesCount; ct++) {
      GLColor::gammaCorrection(lightVolumes[ct].ambient,lightmapGamma);
      GLColor::gammaCorrection(lightVolumes[ct].directional,lightmapGamma);
    }
  	fseek(file,lumps[BSPLump::VISDATA_LUMP].offset,SEEK_SET);
	  if(lumps[BSPLump::VISDATA_LUMP].length) {
  		fread(&(clusters.clustersCount),1,sizeof(int),file);
	  	fread(&(clusters.bytesPerCluster),1,sizeof(int),file);
		  int size = clusters.clustersCount*clusters.bytesPerCluster;
  		clusters.bitsets = new BSPByte[size];
	  	fread(clusters.bitsets,size,sizeof(BSPByte),file);
  	}	else {
      clusters.bitsets = NULL;
    }
	  fclose(file);
  	facesDrawn.resize(facesCount);
  } else {
    char imageFileName[MAX_PATH];
    strcpy(imageFileName,fileName);
    char* fileNameExt = strstr(imageFileName,".bsx");
    int counter;
    BSPVector* pos;
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        startingPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        medikitPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        foodPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        armorPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        bulletsPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        grenadesPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&counter,1,sizeof(int),file);
    if(counter) {
      pos = new BSPVector[counter];
	    fread(pos,counter,sizeof(BSPVector),file);
      for(int ct = 0; ct < counter; ct++)
        weaponPositions.addElement(pos[ct]);
      delete pos;
    }
	  fread(&vertexesCount,1,sizeof(int),file);
    if(vertexes) delete vertexes;
  	vertexes = new BSPVertex[vertexesCount];
	  fread(vertexes,vertexesCount,sizeof(BSPVertex),file);
	  fread(&meshVertexesCount,1,sizeof(int),file);
    if(meshVertexes) delete meshVertexes;
  	meshVertexes = new int[meshVertexesCount];
  	fread(meshVertexes,meshVertexesCount,sizeof(int),file);
	  int facesCount;
	  fread(&facesCount,1,sizeof(int),file);
    if(faces) delete faces;
    faces = new DSArray<GLBspFace>(facesCount);
  	BSPFace* faceData = new BSPFace[facesCount];
  	fread(faceData,facesCount,sizeof(BSPFace),file);
    for(int ct = 0; ct < facesCount; ct++) {
      GLBspFace* theFace = NULL;
      switch(faceData[ct].type) {
        case BSPFace::POLYGON: {
          GLBspPolygon* face = new GLBspPolygon();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          face->firstVertex = faceData[ct].firstVertex;
          face->vertexesCount = faceData[ct].vertexesCount;
          theFace = face;
          break;
        }
        case BSPFace::PATCH: {
          GLBspPatch* face = new GLBspPatch();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          int width = faceData[ct].patchSize[0];
          int height = faceData[ct].patchSize[1];
      		int widthCount = (width-1)/2;
    	  	int heightCount = (height-1)/2;
    		  face->patchesCount = widthCount*heightCount;
  		    face->patches = new GLPatch[face->patchesCount];
      		for(int y = 0; y < heightCount; y++) {
      			for(int x = 0; x < widthCount; x++) {
    	  			for(int row = 0; row < 3; row++) {
    		  			for(int col = 0; col < 3; col++) {
    			  			face->patches[y*widthCount+x].controls[row*3+col] =
                    vertexes[
                      faceData[ct].firstVertex +
                      (y * 2 * width + x * 2)+
									    row * width + col
                    ];
      					}
		      		}
    	  			face->patches[y*widthCount+x].tessellate(8);
    		  	}
  		    }
          theFace = face;
          break;
        }
        case BSPFace::MESH: {
          GLBspMesh* face = new GLBspMesh();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          face->firstVertex = faceData[ct].firstVertex;
          face->vertexesCount = faceData[ct].vertexesCount;
          face->firstMeshVertex = faceData[ct].firstMeshVertex;
          face->meshVertexesCount = faceData[ct].meshVertexesCount;
          theFace = face;
          break;
        }
        case BSPFace::BILLBOARD: {
          GLBspBillboard* face = new GLBspBillboard();
          face->textureID = faceData[ct].textureID;
          face->lightmapID = faceData[ct].lightmapID;
          theFace = face;
          break;
        }
      }
      faces->setElement(ct,theFace);
    }
    delete faceData;
  	int texturesCount;
	  fread(&texturesCount,1,sizeof(int),file);
    if(textures) {
      for(int ct = 0; ct < textures->getSize(); ct++)
        if(textures->getElement(ct))
         textures->getElement(ct)->releaseReference();
      delete textures;
    }
    textures = new DSArray<GLTexture,false>(texturesCount);
    textureIsHollow.resize(texturesCount);
    textureHasAlpha.resize(texturesCount);
  	BSPTexture* textureData = new BSPTexture[texturesCount];
  	fread(textureData,texturesCount,sizeof(BSPTexture),file);
	  for(int ct = 0; ct < texturesCount; ct++)	{
      const int CONTENTS_SOLID = 0x00000001;
      const int CONTENTS_WINDOW = 0x00000002;
      const int CONTENTS_PLAYERCLIP = 0x00010000;
      const int CONTENTS_MONSTER = 0x02000000;
      const int IS_HOLLOW =
        CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER;
      if(textureData[ct].contents & IS_HOLLOW)
        textureIsHollow.set(ct);
      char fileName[MAX_PATH];
      DRImage* image;
	    if(path)
	      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".tga");
   	 	else
	      strcat(strcpy(fileName,textureData[ct].name),".tga");
      FILE* file = fopen(fileName,"rb");
      if(file) {
        fclose(file);
        DRTgaFile tgaFile(fileName);
        image = tgaFile.getImage();
      } else {
	      if(path)
		      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".png");
    	 	else
		      strcat(strcpy(fileName,textureData[ct].name),".png");
        file = fopen(fileName,"rb");
        if(file) {
          fclose(file);
          DRPngFile pngFile(fileName);
          image = pngFile.getImage();
        } else {
		      if(path)
			      strcat(strcat(strcpy(fileName,path),textureData[ct].name),".jpg");
    		 	else
		  	    strcat(strcpy(fileName,textureData[ct].name),".jpg");
          file = fopen(fileName,"rb");
          if(file) {
            fclose(file);
            DRJpegFile jpegFile(fileName);
            image = jpegFile.getImage();
          } else {
            image = NULL;
          }
        }
      }
      if(image) {
	      if(image->getHasAlpha())
  	      textureHasAlpha.set(ct);
        textures->setElement(
        	ct,(new GLTexture(*image,true))->acquireReference()
        );
        delete image;
      } else {
        textures->setElement(ct,NULL);
      }
	  }
  	delete[] textureData;
	  int lightmapsCount;
	  fread(&lightmapsCount,1,sizeof(int),file);
    if(lightmaps) {
      for(int ct = 0; ct < lightmaps->getSize(); ct++)
        if(lightmaps->getElement(ct))
          lightmaps->getElement(ct)->releaseReference();
      delete lightmaps;
    }
    lightmaps = new DSArray<GLTexture,false>(lightmapsCount);
	  for(int ct = 0; ct < lightmapsCount; ct++) {
      char strCt[6];
      itoa(ct,strCt,10);
      strcat(strcpy(fileNameExt,strCt),".jpg");
      DRImage* image;
      FILE* file = fopen(imageFileName,"rb");
      if(file) {
        fclose(file);
        DRJpegFile jpegFile(imageFileName);
        image = jpegFile.getImage();
      } else {
        strcat(strcpy(fileNameExt,strCt),".tga");
        file = fopen(imageFileName,"rb");
        if(file) {
          fclose(file);
          DRTgaFile tgaFile(imageFileName);
          image = tgaFile.getImage();
        } else {
          strcat(strcpy(fileNameExt,strCt),".png");
          file = fopen(imageFileName,"rb");
          if(file) {
            fclose(file);
            DRPngFile pngFile(imageFileName);
            image = pngFile.getImage();
          } else {
            image = NULL;
          }
        }
      }
      if(image) {
        image->setGammaCorrection(lightmapGamma);
        lightmaps->setElement(
          ct,(new GLTexture(*image,true))->acquireReference()
        );
        delete image;
      } else {
        lightmaps->setElement(ct,NULL);
      }
	  }
	  fread(&nodesCount,1,sizeof(int),file);
    if(nodes) delete nodes;
	  nodes = new BSPNode[nodesCount];
	  fread(nodes,nodesCount,sizeof(BSPNode),file);
	  fread(&leavesCount,1,sizeof(int),file);
    if(leaves) delete leaves;
	  leaves = new BSPLeaf[leavesCount];
    if(leafCameraDists) delete leafCameraDists;
		leafCameraDists = new float[leavesCount];
    if(leafIndexes) delete leafIndexes;
    leafIndexes = new int[leavesCount];
    for(int ct = 0; ct < leavesCount; ct++)
    	leafIndexes[ct] = ct+1;
	  fread(leaves,leavesCount,sizeof(BSPLeaf),file);
  	for(int ct = 0; ct < leavesCount; ct++)	{
	  	int temp = leaves[ct].min.y;
		  leaves[ct].min.y = leaves[ct].min.z;
  		leaves[ct].min.z = -temp;
	  	temp = leaves[ct].max.y;
		  leaves[ct].max.y = leaves[ct].max.z;
  		leaves[ct].max.z = -temp;
	  }
	  fread(&leafFacesCount,1,sizeof(int),file);
    if(leafFaces) delete leafFaces;
	  leafFaces = new int[leafFacesCount];
	  fread(leafFaces,leafFacesCount,sizeof(int),file);
	  fread(&brushesCount,1,sizeof(int),file);
    if(brushes) delete brushes;
	  brushes = new BSPBrush[brushesCount];
	  fread(brushes,brushesCount,sizeof(BSPBrush),file);
	  fread(&brushSidesCount,1,sizeof(int),file);
    if(brushSides) delete brushSides;
  	brushSides = new BSPBrushSide[brushSidesCount];
  	fread(brushSides,brushSidesCount,sizeof(BSPBrushSide),file);
	  fread(&leafBrushesCount,1,sizeof(int),file);
    if(leafBrushes) delete leafBrushes;
  	leafBrushes = new int[leafBrushesCount];
  	fread(leafBrushes,leafBrushesCount,sizeof(int),file);
	  fread(&planesCount,1,sizeof(int),file);
    if(planes) delete planes;
  	planes = new BSPPlane[planesCount];
  	fread(planes,planesCount,sizeof(BSPPlane),file);
	  for(int ct = 0; ct < planesCount; ct++)	{
		  float temp = planes[ct].normal.y;
  		planes[ct].normal.y = planes[ct].normal.z;
	  	planes[ct].normal.z = -temp;
  	}
  	fread(&staticModel,1,sizeof(BSPModel),file);
    lightVolumesGrid.x =
      int(floor(staticModel.max[0]/64)-ceil(staticModel.min[0]/64)+1);
    lightVolumesInvSizes.x =
      lightVolumesGrid.x/(staticModel.max[0]-staticModel.min[0]);
    lightVolumesGrid.y =
      int(floor(staticModel.max[2]/128)-ceil(staticModel.min[2]/128)+1);
    lightVolumesInvSizes.y =
      lightVolumesGrid.y/(staticModel.max[2]-staticModel.min[2]);
    lightVolumesGrid.z =
      int(floor(staticModel.max[1]/64)-ceil(staticModel.min[1]/64)+1);
    lightVolumesInvSizes.z =
      lightVolumesGrid.z/(staticModel.max[1]-staticModel.min[1]);
	  fread(&lightVolumesCount,1,sizeof(int),file);
    if(lightVolumes) delete lightVolumes;
  	lightVolumes = new BSPLightVolume[lightVolumesCount];
  	fread(lightVolumes,lightVolumesCount,sizeof(BSPLightVolume),file);
    for(int ct = 0; ct < lightVolumesCount; ct++) {
      GLColor::gammaCorrection(lightVolumes[ct].ambient,lightmapGamma);
      GLColor::gammaCorrection(lightVolumes[ct].directional,lightmapGamma);
    }
    int visDataLength;
	  fread(&visDataLength,1,sizeof(int),file);
	  if(visDataLength) {
  		fread(&(clusters.clustersCount),1,sizeof(int),file);
	  	fread(&(clusters.bytesPerCluster),1,sizeof(int),file);
		  int size = clusters.clustersCount*clusters.bytesPerCluster;
  		clusters.bitsets = new BSPByte[size];
	  	fread(clusters.bitsets,size,sizeof(BSPByte),file);
  	}	else {
      clusters.bitsets = NULL;
    }
	  fclose(file);
  	facesDrawn.resize(facesCount);
  }
	return true;
}

#endif // USE_DATA_FILES

int GLBsp::findLeaf(float x, float y, float z) {
	float distance = 0.0f;
  int index = 0;
  while(index >= 0) {
		const BSPNode& node = nodes[index];
		const BSPPlane& plane = planes[node.plane];
    distance =
      plane.normal.x * x +
			plane.normal.y * y +
			plane.normal.z * z -
      plane.distance;
    index = (distance >= 0)? node.front: node.back;
  }
  return ~index;
}

float GLBsp::getPlane(M3Vector& pos, M3Vector& dir, M3Vector& normal) {
  BSPVector thePos(pos.getX(),pos.getY(),pos.getZ());
  M3Vector theDir = dir;
  if(dir.getX() || dir.getZ()) {
  	if(dir.getY() > 0)
	    theDir.scale((-pos.getY()+staticModel.min[2]-1)/dir.getY());
  } else {
    theDir.set(0,-pos.getY()+staticModel.min[2]-1,0);
  }
  BSPVector theVel(theDir.getX(),theDir.getY(),theDir.getZ());
  checkCollision(thePos,theVel);
  pos.set(thePos.x,thePos.y,thePos.z);
  BSPVector& theNormal = getCollisionNormal();
  normal.set(theNormal.x,theNormal.y,theNormal.z);
  return pos.dot(normal);
}

void GLBsp::initRender(GLCamera& camera) {
  glEnable(GL_LIGHT0);
  glLighti(GL_LIGHT0,GL_SPOT_CUTOFF,180);
  glLightf(GL_LIGHT0,GL_SPOT_EXPONENT,0);
}

void GLBsp::render(GLCamera& camera) {
  glDisable(GL_LIGHTING);
 	glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
  	glClientActiveTextureARB(GL_TEXTURE1_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   	glClientActiveTextureARB(GL_TEXTURE0_ARB);
  }
	glColor3f(1,1,1);
	facesDrawn.clearAll();
  int leafIndex = findLeaf(
    camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
  );
	int cameraCluster = leaves[leafIndex].cluster;
  camera.setIntValue(cameraCluster);
  int lastTextureID = -1;
  int lastLightmapID = -1;
  glCullFace(GL_FRONT);
// sort leaves (begin)
  for(int ct = 0; ct < leavesCount; ct++) {
  	if(leafIndexes[ct] < 0)
    	leafIndexes[ct] = -leafIndexes[ct];
    int leafIndex = leafIndexes[ct]-1;
		BSPLeaf *leaf = &(leaves[leafIndex]);
		if(!isClusterVisible(cameraCluster,leaf->cluster)) {
    	leafIndexes[ct] = -leafIndexes[ct];
			continue;
    }
    if((
    	leaf->min.x <= leaf->max.x &&
      leaf->min.y <= leaf->max.y &&
      leaf->min.z <= leaf->max.z
    ) || (
			!camera.isBoxVisible(
  	    leaf->min.x,leaf->min.y,leaf->min.z,
        leaf->max.x,leaf->max.y,leaf->max.z
    	)
    )) {
   		leafIndexes[ct] = -leafIndexes[ct];
    	continue;
    }
    float posX = (leaf->max.x+leaf->min.x)*0.5f;
    float posY = (leaf->max.y+leaf->min.y)*0.5f;
    float posZ = (leaf->max.z+leaf->min.z)*0.5f;
    leafCameraDists[leafIndex] =
    	(posX-camera.getPositionX())*camera.getViewDirectionX()+
    	(posY-camera.getPositionY())*camera.getViewDirectionY()+
     	(posZ-camera.getPositionZ())*camera.getViewDirectionZ();
  }
  bool notDone;
  do {
  	notDone = false;
    int ct1 = 0;
    while(ct1 < leavesCount-1) {
    	int thisIndex = leafIndexes[ct1];
      if(thisIndex > 0) {
	      thisIndex--;
        int ct2;
  	    for(ct2 = ct1+1; ct2 < leavesCount; ct2++) {
    	  	int nextIndex = leafIndexes[ct2];
      	  if(nextIndex > 0) {
		        nextIndex--;
  			    if(leafCameraDists[thisIndex] < leafCameraDists[nextIndex]) {
    			  	int tempIndex = leafIndexes[ct1];
      			  leafIndexes[ct1] = leafIndexes[ct2];
        			leafIndexes[ct2] = tempIndex;
	      			notDone = true;
		  	    }
  		      break;
          }
    	  }
	      ct1 = ct2;
      } else {
      	ct1++;
      }
    }
  } while(notDone);
// sort leaves (end)
	int leafCt = leavesCount;
	while(leafCt--)	{
  	int leafIndex = leafIndexes[leafCt];
    if(leafIndex < 0)
    	continue;
    leafIndex--;
		BSPLeaf *leaf = &(leaves[leafIndex]);
		int facesCount = leaf->facesCount;
		while(facesCount--) {
			int faceIndex = leafFaces[leaf->firstFace+facesCount];
      if(!facesDrawn.isOn(faceIndex)) {
      	GLBspFace* theFace = faces->getElement(faceIndex);
				facesDrawn.set(faceIndex);
        GLTexture* texture;
        if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
          if(lastTextureID != theFace->textureID) {
            glActiveTextureARB(GL_TEXTURE0_ARB);
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
             	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
            lastTextureID = theFace->textureID;
          }
          if(lastLightmapID != theFace->lightmapID) {
            glActiveTextureARB(GL_TEXTURE1_ARB);
         		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_COMBINE_EXT);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE0_RGB_EXT,GL_PREVIOUS_EXT);
          	glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND0_RGB_EXT,GL_SRC_COLOR);
        	  glTexEnvi(GL_TEXTURE_ENV,GL_COMBINE_RGB_EXT,GL_MODULATE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE1_RGB_EXT,GL_TEXTURE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND1_RGB_EXT,GL_SRC_COLOR);
         		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,2);
            glEnable(GL_TEXTURE_2D);
            GLTexture* lmTxt;
            if(
              (theFace->lightmapID >= 0) &&
              ((lmTxt = lightmaps->getElement(theFace->lightmapID)) != NULL)
            ) {
              lmTxt->apply();
            } else {
           		glBindTexture(GL_TEXTURE_2D,defaultLightmap);
            }
            lastLightmapID = theFace->lightmapID;
          }
        } else {
          if(lastTextureID != theFace->textureID) {
            lastTextureID = theFace->textureID;
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
          }
        }
        switch(theFace->getType()) {
          case BSPFace::POLYGON: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPolygons)
            ) continue;
            GLBspPolygon* face = dynamic_cast<GLBspPolygon*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].textureCoord)
            );
          	glDrawArrays(GL_TRIANGLE_FAN,face->firstVertex,face->vertexesCount);
            break;
          }
          case BSPFace::PATCH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPatches)
            ) continue;
            GLBspPatch* face = dynamic_cast<GLBspPatch*>(theFace);
           	if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
            		glMultiDrawElementsEXT(
                  GL_TRIANGLE_STRIP,patch.trianglesPerRow,GL_UNSIGNED_INT,
                  (const void **)patch.rowIndexes,patch.tessellation
                );
              }
          	} else {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
          	  	for(int row = 0; row < patch.tessellation; row++) {
          		  	glDrawElements(
                    GL_TRIANGLE_STRIP,2*(patch.tessellation+1),GL_UNSIGNED_INT,
          				  &patch.indexes[row*2*(patch.tessellation+1)]
                  );
          	  	}
              }
          	}
            break;
          }
          case BSPFace::MESH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedMeshes)
            ) continue;
            GLBspMesh* face = dynamic_cast<GLBspMesh*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glEnable(GL_TEXTURE_2D);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),
                &(vertexes[face->firstVertex].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].textureCoord)
            );
        		glDrawElements(
              GL_TRIANGLES,face->meshVertexesCount,GL_UNSIGNED_INT,
              &meshVertexes[face->firstMeshVertex]
            );
            break;
          }
        }
      }
  	}
	}
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
    glActiveTextureARB(GL_TEXTURE1_ARB);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
 		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,1);
    glDisable(GL_TEXTURE_2D);
    glActiveTextureARB(GL_TEXTURE0_ARB);
   	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 	glDisableClientState(GL_VERTEX_ARRAY);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);
  glCullFace(GL_BACK);
}

void GLBsp::renderOpaque(GLCamera& camera) {
  glDisable(GL_LIGHTING);
 	glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
  	glClientActiveTextureARB(GL_TEXTURE1_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   	glClientActiveTextureARB(GL_TEXTURE0_ARB);
  }
	glColor3f(1,1,1);
	facesDrawn.clearAll();
  int cameraLeaf = findLeaf(
    camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
  );
	int cameraCluster = leaves[cameraLeaf].cluster;
  camera.setIntValue(cameraCluster);
  int lastTextureID = -1;
  int lastLightmapID = -1;
  glCullFace(GL_FRONT);
// sort leaves (begin)
  for(int ct = 0; ct < leavesCount; ct++) {
  	if(leafIndexes[ct] < 0)
    	leafIndexes[ct] = -leafIndexes[ct];
    int leafIndex = leafIndexes[ct]-1;
		BSPLeaf *leaf = &(leaves[leafIndex]);
		if(!isClusterVisible(cameraCluster,leaf->cluster)) {
    	leafIndexes[ct] = -leafIndexes[ct];
			continue;
    }
    if((
    	leaf->min.x <= leaf->max.x &&
      leaf->min.y <= leaf->max.y &&
      leaf->min.z <= leaf->max.z
    ) || (
			!camera.isBoxVisible(
  	    leaf->min.x,leaf->min.y,leaf->min.z,
        leaf->max.x,leaf->max.y,leaf->max.z
    	)
    )) {
   		leafIndexes[ct] = -leafIndexes[ct];
    	continue;
    }
    float posX = (leaf->max.x+leaf->min.x)*0.5f;
    float posY = (leaf->max.y+leaf->min.y)*0.5f;
    float posZ = (leaf->max.z+leaf->min.z)*0.5f;
    leafCameraDists[leafIndex] =
    	(posX-camera.getPositionX())*camera.getViewDirectionX()+
    	(posY-camera.getPositionY())*camera.getViewDirectionY()+
     	(posZ-camera.getPositionZ())*camera.getViewDirectionZ();
  }
  bool notDone;
  do {
  	notDone = false;
    int ct1 = 0;
    while(ct1 < leavesCount-1) {
    	int thisIndex = leafIndexes[ct1];
      if(thisIndex > 0) {
	      thisIndex--;
        int ct2;
  	    for(ct2 = ct1+1; ct2 < leavesCount; ct2++) {
    	  	int nextIndex = leafIndexes[ct2];
      	  if(nextIndex > 0) {
		        nextIndex--;
  			    if(leafCameraDists[thisIndex] < leafCameraDists[nextIndex]) {
    			  	int tempIndex = leafIndexes[ct1];
      			  leafIndexes[ct1] = leafIndexes[ct2];
        			leafIndexes[ct2] = tempIndex;
	      			notDone = true;
		  	    }
  		      break;
          }
    	  }
	      ct1 = ct2;
      } else {
      	ct1++;
      }
    }
  } while(notDone);
// sort leaves (end)
	int leafCt = leavesCount;
	while(leafCt--)	{
  	int leafIndex = leafIndexes[leafCt];
    if(leafIndex < 0)
    	continue;
    leafIndex--;
		BSPLeaf *leaf = &(leaves[leafIndex]);
		int facesCount = leaf->facesCount;
// sort transparent faces (begin)
	  BSPVector pos;
		for(int ct = 0; ct < facesCount; ct++) {
			int index = leafFaces[leaf->firstFace+ct];
     	GLBspFace* theFace = faces->getElement(index);
      if(textureHasAlpha.isOn(theFace->textureID)) {
	      switch(theFace->getType()) {
  	      case BSPFace::MESH:
    	    case BSPFace::POLYGON: {
      	    GLBspPolygon* face = dynamic_cast<GLBspPolygon*>(theFace);
        	  pos = vertexes[face->firstVertex].position;
          	break;
	        }
  	      case BSPFace::PATCH: {
    	      GLBspPatch* face = dynamic_cast<GLBspPatch*>(theFace);
      	    GLPatch& patch = face->patches[0];
        	  pos = patch.vertexes[0].position;
          	break;
	        }
  	    }
    	  theFace->cameraDist =
      		(pos.x-camera.getPositionX())*camera.getViewDirectionX()+
      		(pos.y-camera.getPositionY())*camera.getViewDirectionY()+
	      	(pos.z-camera.getPositionZ())*camera.getViewDirectionZ();
      }
    }
		bool notDone;
	  do {
  		notDone = false;
    	int ct1 = leaf->firstFace;
	    while(ct1 < leaf->firstFace+facesCount-1) {
  	  	int thisIndex = leafFaces[ct1];
    		GLBspFace* thisFace = faces->getElement(thisIndex);
      	if(textureHasAlpha.isOn(thisFace->textureID)) {
        	int ct2;
	  	    for(ct2 = ct1+1; ct2 < leaf->firstFace+facesCount; ct2++) {
  	  	  	int nextIndex = leafFaces[ct2];
			    	GLBspFace* nextFace = faces->getElement(nextIndex);
		  	    if(textureHasAlpha.isOn(nextFace->textureID)) {
  				    if(thisFace->cameraDist < nextFace->cameraDist) {
    				  	int tempIndex = leafFaces[ct1];
      				  leafFaces[ct1] = leafFaces[ct2];
        				leafFaces[ct2] = tempIndex;
		      			notDone = true;
			  	    }
  			      break;
      	    }
    	  	}
		      ct1 = ct2;
  	    } else {
    	  	ct1++;
	      }
  	  }
	  } while(notDone);
// sort faces (end)
		while(facesCount--) {
			int faceIndex = leafFaces[leaf->firstFace+facesCount];
      if(!facesDrawn.isOn(faceIndex)) {
      	GLBspFace* theFace = faces->getElement(faceIndex);
        if(textureHasAlpha.isOn(theFace->textureID))
        	continue;
				facesDrawn.set(faceIndex);
        GLTexture* texture;
        if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
          if(lastTextureID != theFace->textureID) {
            glActiveTextureARB(GL_TEXTURE0_ARB);
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
             	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
            lastTextureID = theFace->textureID;
          }
          if(lastLightmapID != theFace->lightmapID) {
            glActiveTextureARB(GL_TEXTURE1_ARB);
         		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_COMBINE_EXT);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE0_RGB_EXT,GL_PREVIOUS_EXT);
          	glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND0_RGB_EXT,GL_SRC_COLOR);
        	  glTexEnvi(GL_TEXTURE_ENV,GL_COMBINE_RGB_EXT,GL_MODULATE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE1_RGB_EXT,GL_TEXTURE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND1_RGB_EXT,GL_SRC_COLOR);
         		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,2);
            glEnable(GL_TEXTURE_2D);
            GLTexture* lmTxt;
            if(
              (theFace->lightmapID >= 0) &&
              ((lmTxt = lightmaps->getElement(theFace->lightmapID)) != NULL)
            ) {
              lmTxt->apply();
            } else {
           		glBindTexture(GL_TEXTURE_2D,defaultLightmap);
            }
            lastLightmapID = theFace->lightmapID;
          }
        } else {
          if(lastTextureID != theFace->textureID) {
            lastTextureID = theFace->textureID;
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
          }
        }
        switch(theFace->getType()) {
          case BSPFace::POLYGON: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPolygons)
            ) continue;
            GLBspPolygon* face = dynamic_cast<GLBspPolygon*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].textureCoord)
            );
          	glDrawArrays(GL_TRIANGLE_FAN,face->firstVertex,face->vertexesCount);
            break;
          }
          case BSPFace::PATCH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPatches)
            ) continue;
            GLBspPatch* face = dynamic_cast<GLBspPatch*>(theFace);
           	if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
            		glMultiDrawElementsEXT(
                  GL_TRIANGLE_STRIP,patch.trianglesPerRow,GL_UNSIGNED_INT,
                  (const void **)patch.rowIndexes,patch.tessellation
                );
              }
          	} else {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
          	  	for(int row = 0; row < patch.tessellation; row++) {
          		  	glDrawElements(
                    GL_TRIANGLE_STRIP,2*(patch.tessellation+1),GL_UNSIGNED_INT,
          				  &patch.indexes[row*2*(patch.tessellation+1)]
                  );
          	  	}
              }
          	}
            break;
          }
          case BSPFace::MESH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedMeshes)
            ) continue;
            GLBspMesh* face = dynamic_cast<GLBspMesh*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glEnable(GL_TEXTURE_2D);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),
                &(vertexes[face->firstVertex].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].textureCoord)
            );
        		glDrawElements(
              GL_TRIANGLES,face->meshVertexesCount,GL_UNSIGNED_INT,
              &meshVertexes[face->firstMeshVertex]
            );
            break;
          }
        }
      }
  	}
	}
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
    glActiveTextureARB(GL_TEXTURE1_ARB);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
 		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,1);
    glDisable(GL_TEXTURE_2D);
    glActiveTextureARB(GL_TEXTURE0_ARB);
   	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 	glDisableClientState(GL_VERTEX_ARRAY);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);
  glCullFace(GL_BACK);
}

void GLBsp::renderTransparent(GLCamera& camera) {
  glDisable(GL_LIGHTING);
 	glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
  	glClientActiveTextureARB(GL_TEXTURE1_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
   	glClientActiveTextureARB(GL_TEXTURE0_ARB);
  }
	glColor3f(1,1,1);
  int lastTextureID = -1;
  int lastLightmapID = -1;
	int cameraCluster = camera.getIntValue();
  glDisable(GL_CULL_FACE);
  glDepthMask(GL_FALSE);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  for(int leafCt = 0; leafCt < leavesCount; leafCt++) {
  	int leafIndex = leafIndexes[leafCt];
    if(leafIndex < 0)
    	continue;
    leafIndex--;
		BSPLeaf *leaf = &(leaves[leafIndex]);
		int facesCount = leaf->facesCount;
    for(int facesCt = 0; facesCt < facesCount; facesCt++) {
			int faceIndex = leafFaces[leaf->firstFace+facesCt];
      if(!facesDrawn.isOn(faceIndex)) {
      	GLBspFace* theFace = faces->getElement(faceIndex);
				facesDrawn.set(faceIndex);
        GLTexture* texture;
        if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
          if(lastTextureID != theFace->textureID) {
            glActiveTextureARB(GL_TEXTURE0_ARB);
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
             	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
            lastTextureID = theFace->textureID;
          }
          if(lastLightmapID != theFace->lightmapID) {
            glActiveTextureARB(GL_TEXTURE1_ARB);
         		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_COMBINE_EXT);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE0_RGB_EXT,GL_PREVIOUS_EXT);
          	glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND0_RGB_EXT,GL_SRC_COLOR);
        	  glTexEnvi(GL_TEXTURE_ENV,GL_COMBINE_RGB_EXT,GL_MODULATE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE1_RGB_EXT,GL_TEXTURE);
         		glTexEnvi(GL_TEXTURE_ENV,GL_OPERAND1_RGB_EXT,GL_SRC_COLOR);
         		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,2);
            glEnable(GL_TEXTURE_2D);
            GLTexture* lmTxt;
            if(
              (theFace->lightmapID >= 0) &&
              ((lmTxt = lightmaps->getElement(theFace->lightmapID)) != NULL)
            ) {
              lmTxt->apply();
            } else {
           		glBindTexture(GL_TEXTURE_2D,defaultLightmap);
            }
            lastLightmapID = theFace->lightmapID;
          }
        } else {
          if(lastTextureID != theFace->textureID) {
            lastTextureID = theFace->textureID;
            texture = textures->getElement(theFace->textureID);
            if(texture) {
              glEnable(GL_TEXTURE_2D);
              texture->apply();
            } else {
              if(defaultTexture) {
                glEnable(GL_TEXTURE_2D);
                defaultTexture->apply();
              } else {
                glDisable(GL_TEXTURE_2D);
              }
            }
          }
        }
        switch(theFace->getType()) {
          case BSPFace::POLYGON: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPolygons)
            ) continue;
            GLBspPolygon* face = dynamic_cast<GLBspPolygon*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),&(vertexes[0].textureCoord)
            );
          	glDrawArrays(GL_TRIANGLE_FAN,face->firstVertex,face->vertexesCount);
            break;
          }
          case BSPFace::PATCH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedPatches)
            ) continue;
            GLBspPatch* face = dynamic_cast<GLBspPatch*>(theFace);
           	if(IS_MULTI_DRAW_ARRAYS_SUPPORTED) {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
            		glMultiDrawElementsEXT(
                  GL_TRIANGLE_STRIP,patch.trianglesPerRow,GL_UNSIGNED_INT,
                  (const void **)patch.rowIndexes,patch.tessellation
                );
              }
          	} else {
            	for(int ct = 0; ct < face->patchesCount; ct++) {
                GLPatch& patch = face->patches[ct];
              	glVertexPointer(
                  3,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].position
                );
              	glTexCoordPointer(
                  2,GL_FLOAT,sizeof(BSPVertex),&patch.vertexes[0].textureCoord
                );
                if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
                	glClientActiveTextureARB(GL_TEXTURE1_ARB);
              	  glTexCoordPointer(
                    2,GL_FLOAT,sizeof(BSPVertex),
                    &patch.vertexes[0].lightmapCoord
                  );
                	glClientActiveTextureARB(GL_TEXTURE0_ARB);
                }
          	  	for(int row = 0; row < patch.tessellation; row++) {
          		  	glDrawElements(
                    GL_TRIANGLE_STRIP,2*(patch.tessellation+1),GL_UNSIGNED_INT,
          				  &patch.indexes[row*2*(patch.tessellation+1)]
                  );
          	  	}
              }
          	}
            break;
          }
          case BSPFace::MESH: {
            if(
              (theFace->lightmapID < 0) &&
              (texture == NULL) &&
              (!showUntexturedMeshes)
            ) continue;
            GLBspMesh* face = dynamic_cast<GLBspMesh*>(theFace);
          	glVertexPointer(
              3,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].position)
            );
            if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
              glClientActiveTextureARB(GL_TEXTURE1_ARB);
            	glEnable(GL_TEXTURE_2D);
            	glTexCoordPointer(
                2,GL_FLOAT,sizeof(BSPVertex),
                &(vertexes[face->firstVertex].lightmapCoord)
              );
              glClientActiveTextureARB(GL_TEXTURE0_ARB);
            }
          	glTexCoordPointer(
              2,GL_FLOAT,sizeof(BSPVertex),
              &(vertexes[face->firstVertex].textureCoord)
            );
        		glDrawElements(
              GL_TRIANGLES,face->meshVertexesCount,GL_UNSIGNED_INT,
              &meshVertexes[face->firstMeshVertex]
            );
            break;
          }
        }
      }
  	}
	}
  glDisable(GL_BLEND);
  glDepthMask(GL_TRUE);
  glEnable(GL_CULL_FACE);
  if(IS_TEXTURE_ENV_COMBINE_SUPPORTED) {
    glActiveTextureARB(GL_TEXTURE1_ARB);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
 		glTexEnvf(GL_TEXTURE_ENV,GL_RGB_SCALE_EXT,1);
    glDisable(GL_TEXTURE_2D);
    glActiveTextureARB(GL_TEXTURE0_ARB);
   	glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 	glDisableClientState(GL_VERTEX_ARRAY);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);
}

bool GLBsp::getDynamicLightDirection(M3Vector& dir) {
  float x = dir.getX();
  float y = dir.getY();
  float z = dir.getZ();
  if(x < staticModel.min[0]) x = staticModel.min[0];
  else if(x >= staticModel.max[0]) x = staticModel.max[0]-1;
  if(y < staticModel.min[2]) y = staticModel.min[2];
  else if(y >= staticModel.max[2]) y = staticModel.max[2]-1;
  if(-z < staticModel.min[1]) z = -staticModel.min[1];
  else if(-z >= staticModel.max[1]) z = -staticModel.max[1]+1;
  int idxX = int(( x-staticModel.min[0])*lightVolumesInvSizes.x);
  int idxY = int(( y-staticModel.min[2])*lightVolumesInvSizes.y);
  int idxZ = int((-z-staticModel.min[1])*lightVolumesInvSizes.z);
  int index =
    idxX+idxZ*(lightVolumesGrid.x)+idxY*(lightVolumesGrid.x*lightVolumesGrid.z);
  BSPLightVolume* lgh = &lightVolumes[index];
  int dirA = lgh->direction[0];
  int dirB = lgh->direction[1];
  dir.set(
     MTNormals2D::getNormal(dirA,dirB,0),
     MTNormals2D::getNormal(dirA,dirB,2),
    -MTNormals2D::getNormal(dirA,dirB,1)
  );
  return true;
}

void GLBsp::initRender(GLCamera& camera, float x, float y, float z) {
  if(x < staticModel.min[0]) x = staticModel.min[0];
  else if(x >= staticModel.max[0]) x = staticModel.max[0]-1;
  if(y < staticModel.min[2]) y = staticModel.min[2];
  else if(y >= staticModel.max[2]) y = staticModel.max[2]-1;
  if(-z < staticModel.min[1]) z = -staticModel.min[1];
  else if(-z >= staticModel.max[1]) z = -staticModel.max[1]+1;
  int idxX = int(( x-staticModel.min[0])*lightVolumesInvSizes.x);
  int idxY = int(( y-staticModel.min[2])*lightVolumesInvSizes.y);
  int idxZ = int((-z-staticModel.min[1])*lightVolumesInvSizes.z);
  int index =
    idxX+idxZ*(lightVolumesGrid.x)+idxY*(lightVolumesGrid.x*lightVolumesGrid.z);
  BSPLightVolume* lgh = &lightVolumes[index];
  float ambient[] =
    {lgh->ambient[0]/255.0f,lgh->ambient[1]/255.0f,lgh->ambient[2]/255.0f,1};
  glLightfv(GL_LIGHT0,GL_AMBIENT,ambient);
  float diffuse[] = {
    lgh->directional[0]/255.0f,
    lgh->directional[1]/255.0f,
    lgh->directional[2]/255.0f,
    1
  };
  glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse);
  glLightfv(GL_LIGHT0,GL_SPECULAR,diffuse);
  int dirA = lgh->direction[0];
  int dirB = lgh->direction[1];
  GLfloat direction[] = {
     MTNormals2D::getNormal(dirA,dirB,0),
     MTNormals2D::getNormal(dirA,dirB,2),
    -MTNormals2D::getNormal(dirA,dirB,1),
     0
  };
  glLightfv(GL_LIGHT0,GL_POSITION,direction);
  camera.setNearestLight(direction[0],direction[1],direction[2]);
}

void GLBsp::slideCollision(BSPVector& pos, BSPVector& vel, BSPVector& extent) {
  const int STEP_SIZE = 15;
  BSPVector newPos = pos;
  BSPVector newVel = vel;
  slide(newPos,newVel,extent);
  BSPVector upPos(pos.x,pos.y+STEP_SIZE,pos.z);
  BSPVector upVel = vel;
  collide(upPos,upVel,extent);
  BSPVector down(upPos.x,upPos.y-STEP_SIZE,upPos.z);
  checkMove(upPos,down,extent);
  if(!collision.isSolid)
    upPos = collision.end;
  float dx, dz;
  dx = newPos.x-pos.x;
  dz = newPos.z-pos.z;
  float newStep = dx*dx+dz*dz;
  dx = upPos.x-pos.x;
  dz = upPos.z-pos.z;
  float upStep = dx*dx+dz*dz;
  const float MIN_COLLISION_NORMAL_Y = 0.7f;
  //... 1.01f?
  if(1.01f*newStep > upStep || collision.normal.y < MIN_COLLISION_NORMAL_Y) {
    pos = newPos;
    vel = newVel;
  } else {
    pos = upPos;
    vel = upVel;
  }
}

void GLBsp::checkCollision(BSPVector& pos, BSPVector& vel, BSPVector& extent) {
  collide(pos,vel,extent);
}

void GLBsp::checkCollision(BSPVector& pos, BSPVector& vel) {
  collide(pos,vel);
}

inline void GLBsp::slide(BSPVector& pos, BSPVector& vel, BSPVector& extent) {
  BSPVector initVel = vel;
  BSPVector planes[5];
  int planesCount = 0;
  float fractionLeft = 1;
  collision.fraction = 0;
  for(int ct = 0; ct < 4; ct++) {
    fractionLeft -= collision.fraction;
    BSPVector startPos = pos;
    BSPVector endPos = startPos+vel;
    checkMove(startPos,endPos,extent);
    if(collision.fraction > 0) {
      pos = collision.end;
      planesCount = 0;
      if(collision.fraction == 1)
        break;
    }
    if(planesCount >= 5)
      break;
    planes[planesCount] = collision.normal.normalize();
    planesCount++;
    int i,j;
    for(i = 0; i < planesCount; i++) {
      clipVelocity(vel,planes[i],vel,1.01f);
      for(j = 0; j < planesCount; j++)
        if (j != i) {
          if(vel.dot(planes[j]) < 0)
            break;
        }
      if(j == planesCount)
        break;
    }
    if(i != planesCount) {
      BSPVector dir = vel.normalize();
      clipVelocity(vel,planes[0],vel,1.01f);
    } else {
      if(planesCount != 2) {
        vel.set();
        break;
      }
      BSPVector dir = planes[0].cross(planes[1]);
      vel = dir*dir.dot(vel);
    }
    if(vel.dot(initVel) <= 0) {
      vel.set();
      break;
    }
  }
}

inline void GLBsp::collide(BSPVector& pos, BSPVector& vel, BSPVector& extent) {
  float fractionLeft = 1;
  collision.fraction = 0;
  for(int ct = 0; ct < 4; ct++) {
    fractionLeft -= collision.fraction;
    BSPVector startPos = pos;
    BSPVector endPos = startPos+vel;
    checkMove(startPos,endPos,extent);
    if(collision.fraction > 0) {
      pos = collision.end;
      if(collision.fraction == 1)
        break;
    }
  }
}

inline void GLBsp::collide(BSPVector& pos, BSPVector& vel) {
  float fractionLeft = 1;
  collision.fraction = 0;
  for(int ct = 0; ct < 4; ct++) {
    fractionLeft -= collision.fraction;
    BSPVector startPos = pos;
    BSPVector endPos = startPos+vel;
    checkMove(startPos,endPos);
    if(collision.fraction > 0) {
      pos = collision.end;
      if(collision.fraction == 1)
        break;
    }
  }
}

inline void GLBsp::checkMove(
  BSPVector& start, BSPVector& end, BSPVector& extent
) {
  collision.size = extent;
  collision.start = start;
  collision.end = end;
  collision.normal.set();
  collision.fraction = 1;
  collision.isSolid = false;
  checkMoveNode(0,1,start,end,0);
  collision.end = collision.fraction < 1?
    (start+(end-start)*(collision.fraction)): end;
}

inline void GLBsp::checkMove(BSPVector& start, BSPVector& end) {
  collision.start = start;
  collision.end = end;
  collision.normal.set();
  collision.fraction = 1;
  collision.isSolid = false;
  checkMoveNodeNoSize(0,1,start,end,0);
  collision.end = collision.fraction < 1?
    (start+(end-start)*(collision.fraction)): end;
}

inline void GLBsp::checkMoveNode(
  float start, float end, BSPVector startPos, BSPVector endPos, int node
) {
  if(collision.fraction <= start)
    return;
  if(node < 0) {
    checkMoveLeaf(~node);
    return;
  }
  int plane = nodes[node].plane;
  float t1 = planes[plane].normal.dot(startPos)-planes[plane].distance;
  float t2 = planes[plane].normal.dot(endPos)-planes[plane].distance;
  float offset =
    fabs(collision.size.x*planes[plane].normal.x)+
    fabs(collision.size.y*planes[plane].normal.y)+
    fabs(collision.size.z*planes[plane].normal.z);
  if((t1 >= offset) && (t2 >= offset)) {
    checkMoveNode(start,end,startPos,endPos,nodes[node].front);
    return;
  } else if ((t1 < -offset) && (t2 < -offset)) {
    checkMoveNode(start,end,startPos,endPos,nodes[node].back);
    return;
  }
  enum Side {FRONT = 0, BACK};
  int whichSide;
  float frac;
  float frac2;
  const float DIST_EPSILON= 1.0f/32;
  if(t1 < t2) {
    whichSide = BACK;
    float invDist = 1/(t1 - t2);
    frac = (t1-offset-DIST_EPSILON)*invDist;
    frac2 = (t1+offset+DIST_EPSILON)*invDist;
  } else if (t1 > t2) {
    whichSide = FRONT;
    float invDist = 1/(t1-t2);
    frac = (t1+offset+DIST_EPSILON)*invDist;
    frac2 = (t1-offset-DIST_EPSILON)*invDist;
  } else {
    whichSide = FRONT;
    frac = 1;
    frac2 = 0;
  }
  if(frac < 0) frac = 0;
  else if(frac > 1) frac = 1;
  if(frac2 < 0) frac2 = 0;
  else if(frac2 > 1) frac2 = 1;
  float mid = start+(end-start)*frac;
  BSPVector midPos = startPos+(endPos-startPos)*frac;
  checkMoveNode(
    start,mid,startPos,midPos,
    whichSide == FRONT? nodes[node].front: nodes[node].back
  );
  mid = start+(end-start)*frac2;
  midPos = startPos+(endPos-startPos)*frac2;
  checkMoveNode(
    mid,end,midPos,endPos,
    whichSide == FRONT? nodes[node].back: nodes[node].front
  );
}

inline void GLBsp::checkMoveNodeNoSize(
  float start, float end, BSPVector startPos, BSPVector endPos, int node
) {
  if(collision.fraction <= start)
    return;
  if(node < 0) {
    checkMoveLeafNoSize(~node);
    return;
  }
  int plane = nodes[node].plane;
  float t1 = planes[plane].normal.dot(startPos)-planes[plane].distance;
  float t2 = planes[plane].normal.dot(endPos)-planes[plane].distance;
  if((t1 >= 0) && (t2 >= 0)) {
    checkMoveNodeNoSize(start,end,startPos,endPos,nodes[node].front);
    return;
  } else if ((t1 < 0) && (t2 < 0)) {
    checkMoveNodeNoSize(start,end,startPos,endPos,nodes[node].back);
    return;
  }
  enum Side {FRONT = 0, BACK};
  int whichSide;
  float frac;
  float frac2;
  const float DIST_EPSILON= 1.0f/32;
  if(t1 < t2) {
    whichSide = BACK;
    float invDist = 1/(t1-t2);
    frac = (t1-DIST_EPSILON)*invDist;
    frac2 = (t1+DIST_EPSILON)*invDist;
  } else if (t1 > t2) {
    whichSide = FRONT;
    float invDist = 1/(t1-t2);
    frac = (t1+DIST_EPSILON)*invDist;
    frac2 = (t1-DIST_EPSILON)*invDist;
  } else {
    whichSide = FRONT;
    frac = 1;
    frac2 = 0;
  }
  if(frac < 0) frac = 0;
  else if(frac > 1) frac = 1;
  if(frac2 < 0) frac2 = 0;
  else if(frac2 > 1) frac2 = 1;
  float mid = start+(end-start)*frac;
  BSPVector midPos = startPos+(endPos-startPos)*frac;
  checkMoveNodeNoSize(
    start,mid,startPos,midPos,
    whichSide == FRONT? nodes[node].front: nodes[node].back
  );
  mid = start+(end-start)*frac2;
  midPos = startPos+(endPos-startPos)*frac2;
  checkMoveNodeNoSize(
    mid,end,midPos,endPos,
    whichSide == FRONT? nodes[node].back: nodes[node].front
  );
}

inline void GLBsp::checkMoveLeaf(int leaf) {
  int firstBrush = leaves[leaf].firstBrush;
  for(int ct = 0; ct < leaves[leaf].brushesCount; ct++) {
    int brushIndex = leafBrushes[firstBrush+ct];
    BSPBrush* brush = &brushes[brushIndex];
    clipBoxToBrush(brush);
    if(!collision.fraction)
      return;
  }
}

inline void GLBsp::checkMoveLeafNoSize(int leaf) {
  int firstBrush = leaves[leaf].firstBrush;
  for(int ct = 0; ct < leaves[leaf].brushesCount; ct++) {
    int brushIndex = leafBrushes[firstBrush+ct];
    BSPBrush* brush = &brushes[brushIndex];
    clipPointToBrush(brush);
    if(!collision.fraction)
      return;
  }
}

inline void GLBsp::clipBoxToBrush(BSPBrush* brush) {
  if((!textureIsHollow.isOn(brush->textureID)) || (brush->brushSidesCount == 0))
    return;
  const float DIST_EPSILON = 1.0f/32;
  float enter = -1;
  float exit = 1;
  bool startOut = false;
  bool endOut = false;
  int firstBrushSide = brush->firstBrushSide;
  BSPVector hitNormal(0,0,0);
  for(int ct = 0; ct < brush->brushSidesCount; ct++) {
    int planeIndex = brushSides[firstBrushSide+ct].plane;
    BSPPlane& plane = planes[planeIndex];
    BSPVector offsets = collision.size*(-1);
    if(plane.normal.x < 0)
      offsets.x = -offsets.x;
    if(plane.normal.y < 0)
      offsets.y = -offsets.y;
    if(plane.normal.z < 0)
      offsets.z = -offsets.z;
    float dist = plane.distance-offsets.dot(plane.normal);
    float d1 = collision.start.dot(plane.normal)-dist;
    float d2 = collision.end.dot(plane.normal)-dist;
    if(d1 > 0)
      startOut = true;
    if(d2 > 0)
      endOut = true;
    if((d1 > 0) && (d2 >= d1))
      return;
    if((d1 <= 0) && (d2 <= 0))
      continue;
    float f;
    if(d1 > d2) {
      f = (d1-DIST_EPSILON)/(d1 - d2);
      if(f > enter) {
        enter = f;
        hitNormal = plane.normal;
      }
    } else {
      f = (d1+DIST_EPSILON)/(d1 - d2);
      if(f < exit)
        exit = f;
    }
  }
  if(!startOut) {
    if(!endOut)
      collision.isSolid = true;
    return;
  }
  if(enter < exit) {
    if((enter > -1) && (enter < collision.fraction)) {
      if(enter < 0)
        enter = 0;
      collision.fraction = enter;
      collision.normal = hitNormal;
    }
  }
}

inline void GLBsp::clipPointToBrush(BSPBrush* brush) {
  if((!textureIsHollow.isOn(brush->textureID)) || (brush->brushSidesCount == 0))
    return;
  const float DIST_EPSILON = 1.0f/32;
  float enter = -1;
  float exit = 1;
  bool startOut = false;
  bool endOut = false;
  int firstBrushSide = brush->firstBrushSide;
  BSPVector hitNormal(0,0,0);
  for(int ct = 0; ct < brush->brushSidesCount; ct++) {
    int planeIndex = brushSides[firstBrushSide+ct].plane;
    BSPPlane& plane = planes[planeIndex];
    float dist = plane.distance;
    float d1 = collision.start.dot(plane.normal)-dist;
    float d2 = collision.end.dot(plane.normal)-dist;
    if(d1 > 0)
      startOut = true;
    if(d2 > 0)
      endOut = true;
    if((d1 > 0) && (d2 >= d1))
      return;
    if((d1 <= 0) && (d2 <= 0))
      continue;
    float f;
    if(d1 > d2) {
      f = (d1-DIST_EPSILON)/(d1-d2);
      if(f > enter) {
        enter = f;
        hitNormal = plane.normal;
      }
    } else {
      f = (d1+DIST_EPSILON)/(d1-d2);
      if(f < exit)
        exit = f;
    }
  }
  if(!startOut) {
    if(!endOut)
      collision.isSolid = true;
    return;
  }
  if(enter < exit) {
    if((enter > -1) && (enter < collision.fraction)) {
      if(enter < 0)
        enter = 0;
      collision.fraction = enter;
      collision.normal = hitNormal;
    }
  }
}

inline void GLBsp::clipVelocity(
  BSPVector in, BSPVector planeNormal, BSPVector& out, float overbounce
) {
  const float STOP_EPSILON = 0.1f;
  out = in-planeNormal*(in.dot(planeNormal)*overbounce);
  if(fabs(out.x) < STOP_EPSILON) out.x = 0;
  if(fabs(out.y) < STOP_EPSILON) out.y = 0;
  if(fabs(out.z) < STOP_EPSILON) out.z = 0;
}

#endif // USE_BSP
