/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

#include "slinterpreter.h"

//
// SLInterpreter
//

SLInterpreter::SLInterpreter():
  program(NULL), running(false), suspended(false), cpuFrequency(10000)
{}

SLInterpreter::~SLInterpreter() {
  if(program)
    delete[] program;
}

int SLInterpreter::registerNatives() {
  extern AMX_NATIVE_INFO math_Natives[];
  amx_Register(&amx,math_Natives,-1);
  extern AMX_NATIVE_INFO core_Natives[];
  return amx_Register(&amx,core_Natives,-1);
}

bool SLInterpreter::load(DRData* prog, int memoryLimit) {
  if(program) {
    delete[] program;
    program = NULL;
  }
  running = false;
  AMX_HEADER* header = (AMX_HEADER*)prog->getBuffer();
  amx_Align32((unsigned long *)&header->stp);
  size_t programSize = (size_t)header->stp;
  if(memoryLimit > 0 && programSize > memoryLimit)
    programSize = (size_t)(header->stp = memoryLimit);
  program = new unsigned char[programSize];
  int minSize = prog->getSize() > programSize? programSize: prog->getSize();
  memcpy(program,prog->getBuffer(),minSize);
  memset(&amx,0,sizeof amx);
  return
    (amx_Init(&amx,program) == AMX_ERR_NONE) &&
    (registerNatives() == AMX_ERR_NONE);
}

bool SLInterpreter::load(char* fileName, int memoryLimit) {
  DRDataFile file(fileName);
  DRData* data = file.getData();
  if(data) {
    bool ret = load(data,memoryLimit);
    delete data;
    return ret;
  }
  return false;
}

void SLInterpreter::unload() {
  if(program) {
    delete[] program;
    program = NULL;
  }
  running = false;
}

#endif // USE_CONSOLE && USE_SMALL
