#ifndef FMSOUND_H
#define FMSOUND_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_SOUND

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "exception.h"

#include "void.h"

#ifdef USE_FMOD
#include "fmod/fmod.h"
#else // !USE_FMOD
//#include "al/OpenAL32.h" // NVidia
#include "al/al.h" // Creative
#include "al/alut.h"
#ifdef USE_MUSIC
#include "midi/midistrm.h"
#endif // USE_MUSIC
#endif // !USE_FMOD

class FMSoundManager;
class FMSample;
class FM3DSample;
class FMSound;
class FM3DSound;
class FM3DListener;
#ifdef USE_MUSIC
class FMMusic;
#endif // USE_MUSIC

//
// FMSoundManager
//
class FMSoundManager {
#ifdef USE_FMOD
private:
  static int channels;
public:
  enum {MIN_HARDWARE_CHANNELS = 16};
  static int getChannels() {return channels;}
#else // !USE_FMOD
public:
  enum {MAX_SOUND_SOURCES = 16};
  static ALuint soundSources[MAX_SOUND_SOURCES];
#endif // !USE_FMOD
public:
  static void initialize() throw(ExceptionThrown);
  static void finalize();
  static void update3DSound() {
#ifdef USE_FMOD
    FSOUND_Update();
#else // !USE_FMOD
#endif // !USE_FMOD
  }
};

//
// FMSample
//
class FMSample: virtual public Void {
#ifdef USE_FMOD
protected:
  FSOUND_SAMPLE* sample;
#else // !USE_FMOD
protected:
  ALuint soundBuffer;
  unsigned int frequency;
  unsigned char volume;
  bool looping;
#endif // !USE_FMOD
protected:
  FMSample();
  void initFromFileBuffer(int length, unsigned char* buffer, int flags = 0);
#ifdef USE_FMOD
#else // !USE_FMOD
  void initFromDataBuffer(int freq, int fmt, int len, unsigned char* buf);
#endif // !USE_FMOD
public:
  FMSample(int length, unsigned char* buffer);
#ifdef USE_FMOD
#else // !USE_FMOD
  FMSample(int freq, int fmt, int len, unsigned char* buf);
#endif // !USE_FMOD
  ~FMSample();
#ifdef USE_FMOD
  void setDefaults(int vol, int pan = -1, int freq = -1, int pri = -1)
    {FSOUND_Sample_SetDefaults(sample,freq,vol,pan,pri);}
  void getDefaults(int* vol, int* pan, int* freq, int* pri)
    {FSOUND_Sample_GetDefaults(sample,freq,vol,pan,pri);}
  void setVolume(unsigned char vol) {setDefaults(-1,vol,-1,-1);}
  int getVolume() {int vol; getDefaults(NULL,&vol,NULL,NULL); return vol;}
  void setPan(unsigned char pan) {setDefaults(-1,-1,pan,-1);}
  int getPan() {int pan; getDefaults(NULL,NULL,&pan,NULL); return pan;}
  void setFrequency(unsigned int freq) {setDefaults(freq,-1,-1,-1);}
  int getFrequency() {int freq; getDefaults(&freq,NULL,NULL,NULL); return freq;}
  void setPriority(unsigned char pri) {setDefaults(-1,-1,-1,pri);}
  int getPriority() {int pri; getDefaults(NULL,NULL,NULL,&pri); return pri;}
  bool isLooping() {return FSOUND_Sample_GetMode(sample) & FSOUND_LOOP_NORMAL;}
  void setLooping(bool l)
    {FSOUND_Sample_SetMode(sample, l? FSOUND_LOOP_NORMAL: FSOUND_LOOP_OFF);}
  FSOUND_SAMPLE* getPointer() {return sample;}
#else // !USE_FMOD
  void setVolume(unsigned char vol) {volume = vol;}
  int getVolume() {return (int)volume;}
  void setPan(unsigned char p) {p;}
  int getPan() {return 128;}
  void setFrequency(unsigned int freq) {frequency = freq;}
  int getFrequency() {return frequency;}
  void setPriority(unsigned char pri) {pri;}
  int getPriority() {return 128;}
  void setLooping(bool l) {looping = l;}
  bool isLooping() {return looping;}
  ALuint getSoundBuffer() {return soundBuffer;}
#endif // !USE_FMOD
  FMSound* createSound(bool playing = true);
};

//
// FM3DSample
//
class FM3DSample: public FMSample {
private:
  float invMinDistance2;
#ifdef USE_FMOD
#else // !USE_FMOD
private:
  float minDistance;
public:
  float getMinDistance() {return minDistance;}
#endif // !USE_FMOD
public:
  FM3DSample(int length, unsigned char* buffer);
#ifdef USE_FMOD
#else // !USE_FMOD
  FM3DSample(int freq, int fmt, int len, unsigned char* buf);
#endif // !USE_FMOD
  FM3DSound* create3DSound(bool playing = true);
  void playAt(
    float x, float y, float z, float vx = 0, float vy = 0, float vz = 0
  );
  float getInvMinDistance2() {return invMinDistance2;}
  void setMinDistance(float min) {
    invMinDistance2 = 1/(min*min);
#ifdef USE_FMOD
    FSOUND_Sample_SetMinMaxDistance(sample,min,1e9f);
#else // !USE_FMOD
    minDistance = min;
#endif // !USE_FMOD
  }
};

//
// FMSound
//
class FMSound: virtual public Void {
public:
  enum SoundStatus {
    IS_SOUND_PLAYING = 0,
    IS_CHANNEL_LOST = -1,
    WAS_SOUND_STOPPED = -2,
  };
protected:
  FMSample* sample;
#ifdef USE_FMOD
  int channel;
#else // !USE_FMOD
  ALuint soundSource;
#endif // !USE_FMOD
public:
  FMSound(int c, FMSample* s);
  ~FMSound();
#ifdef USE_FMOD
  bool isAudible() {return channel >= 0;}
  int getVolume() {
    int vol;
    if(isAudible()) return FSOUND_GetVolume(channel);
    else FSOUND_Sample_GetDefaults(sample->getPointer(),NULL,&vol,NULL,NULL);
    return vol;
  }
  int getFrequency() {
    int freq;
    if(isAudible()) return FSOUND_GetFrequency(channel);
    else FSOUND_Sample_GetDefaults(sample->getPointer(),&freq,NULL,NULL,NULL);
    return freq;
  }
  void setVolume(int vol)
    {if(isAudible()) FSOUND_SetVolume(channel,vol);}
  void setPan(int pan)
    {if(isAudible()) FSOUND_SetPan(channel,pan);}
  void setFrequency(int freq)
    {if(isAudible()) FSOUND_SetFrequency(channel,freq);}
  void setPriority(int pri)
    {if(isAudible()) FSOUND_SetPriority(channel,pri);}
  void stop()
    {if(isAudible()) FSOUND_StopSound(channel); channel = WAS_SOUND_STOPPED;}
  void play(unsigned char priority = 128) {
    if(!isAudible()) {
      sample->setPriority(priority);
      channel = FSOUND_PlaySound(FSOUND_FREE,sample->getPointer());
    }
  }
#else // !USE_SOUND
  bool isAudible() {return true;}
  int getVolume() {
    float maxGain, gain;
    alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
    alGetSourcef(soundSource,AL_GAIN,&gain);
    return int(255*gain/maxGain);
  }
  int getFrequency() {
    int freq;
    alGetBufferi(sample->getSoundBuffer(),AL_FREQUENCY,&freq);
    float pitch;
    alGetSourcef(soundSource,AL_PITCH,&pitch);
    return int(freq*pitch);
  }
  void setVolume(int vol) {
    float maxGain;
    alGetSourcef(soundSource,AL_MAX_GAIN,&maxGain);
    alSourcef(soundSource,AL_GAIN,maxGain*vol/255);
  }
  void setFrequency(int freq)
    {alSourcef(soundSource,AL_PITCH,float(sample->getFrequency())/freq);}
  void setPan(int pan) {pan;}
  void setPriority(int pri) {pri;}
  void play(unsigned char priority = 128)
    {alSourcePlay(soundSource);}
  void stop()
    {alSourceStop(soundSource);}
#endif // !USE_FMOD
  void setSample(FMSample* s, bool playing = true);
  SoundStatus getSoundStatus();
};

//
// FM3DSound
//
class FM3DSound: public FMSound {
public:
  FM3DSound(int c, FM3DSample* s);
  void set3DSample(FM3DSample* s, bool playing = true);
  void setAttributes(float* pos = NULL, float* vel = NULL) {
#ifdef USE_FMOD
    if(pos) pos[0] = -pos[0];
    if(vel) vel[0] = -vel[0];
    FSOUND_3D_SetAttributes(channel,pos,vel);
    if(pos) pos[0] = -pos[0];
    if(vel) vel[0] = -vel[0];
#else // !USE_FMOD
    if(pos)
      alSourcefv(soundSource,AL_POSITION,pos);
    if(vel)
      alSourcefv(soundSource,AL_VELOCITY,vel);
#endif // !USE_FMOD
  }
  float getInvMinDistance2()
    {return dynamic_cast<FM3DSample*>(sample)->getInvMinDistance2();}
};

//
// FM3DListener
//
class FMListener {
public:
  static void setDistanceFactor(float factor) {
#ifdef USE_FMOD
    FSOUND_3D_SetDistanceFactor(factor);
#else // !USE_FMOD
    alSpeedOfSound(343*factor);
#endif // USE_FMOD
  }
  static void setAttributes(
    float fwdX, float fwdY, float fwdZ,
    float topX, float topY, float topZ,
    float* pos = NULL, float* vel = NULL
  ) {
#ifdef USE_FMOD
    if(pos) pos[0] = -pos[0];
    if(vel) vel[0] = -vel[0];
    FSOUND_3D_Listener_SetAttributes(pos,vel,-fwdX,fwdY,fwdZ,-topX,topY,topZ);
    if(pos) pos[0] = -pos[0];
    if(vel) vel[0] = -vel[0];
#else // !USE_FMOD
    if(pos)
      alListenerfv(AL_POSITION,pos);
    if(vel)
      alListenerfv(AL_VELOCITY,vel);
    ALfloat orient[6] = {fwdX,fwdY,fwdZ,topX,topY,topZ};
    alListenerfv(AL_ORIENTATION,orient);
#endif // USE_FMOD
  }
};

#ifndef USE_FMOD

//
// FMCaptureDevice
//

class FMCaptureDevice: virtual public Void {
private:
	ALCdevice* device;
  int maxSamples;
  unsigned char* samplesBuffer;
  int availableSamples;
  int frequency;
  bool mono8;
public:
	FMCaptureDevice(int iMaxSamp, int iFreq, int iBits = 8) throw(ExceptionThrown);
  ~FMCaptureDevice();
  void start() {alcCaptureStart(device);}
  void stop() {alcCaptureStop(device);}
  int getMaxSamples() {return maxSamples;}
  void setAvailableSamples(int as)
  	{availableSamples = as < maxSamples? as: maxSamples;}
  int getAvailableSamples() {return availableSamples;}
  int getAcquiredSamples()
  	{int i; alcGetIntegerv(device,ALC_CAPTURE_SAMPLES,1,&i); return i;}
  float getSample(int index) {
  	return (index < 0 || index >= maxSamples)? 0: mono8?
    (samplesBuffer[index]*(2/255.0f)-1):
    ((*((short*)&samplesBuffer[index*2]))*(1/32767.0f));
  }
  void setSample(int index, float val) {
  	if(index < 0 || index >= maxSamples) return;
    if(mono8) samplesBuffer[index] = (unsigned char)((val+1)*0.5f*255);
    else (*((short*)&samplesBuffer[index*2])) = short(val*32767);
  }
  unsigned char* getSamplesBuffer() {return samplesBuffer;}
  void captureSamples()	{alcCaptureSamples(
  	device,samplesBuffer,(availableSamples = getAcquiredSamples())
  );}
  void writeToSample(FMSample& s) {alBufferData(
  	s.getSoundBuffer(),mono8?AL_FORMAT_MONO8:AL_FORMAT_MONO16,
    samplesBuffer,mono8?availableSamples:2*availableSamples,frequency
  );}
  void writeTo3DSample(FM3DSample& s) {alBufferData(
  	s.getSoundBuffer(),mono8?AL_FORMAT_MONO8:AL_FORMAT_MONO16,
    samplesBuffer,mono8?availableSamples:2*availableSamples,frequency
  );}
  FMSample* createSample() {return new FMSample(
  	frequency,mono8?AL_FORMAT_MONO8:AL_FORMAT_MONO16,
    mono8?availableSamples:2*availableSamples,samplesBuffer
  );}
  FM3DSample* create3DSample() {return new FM3DSample(
  	frequency,mono8?AL_FORMAT_MONO8:AL_FORMAT_MONO16,
    mono8?availableSamples:2*availableSamples,samplesBuffer
  );}
  bool saveAsWav(const char* fileName);
};

#endif // !USE_FMOD

#ifdef USE_MUSIC

//
// FMMusic
//

class FMMusic: virtual public Void {
#ifdef USE_FMOD
private:
  FMUSIC_MODULE* module;
#else // !USE_FMOD
private:
  bool looping;
  int bufferPlaying;
  DWORD buffersCount;
	DWORD timeDivision;
  LPMIDIHDR* musicBuffer;
	HMIDISTRM midiStream;
#endif // !USE_FMOD
public:
  FMMusic(int length, unsigned char* buffer);
  ~FMMusic();
#ifdef USE_FMOD
  int getVolume() {return FMUSIC_GetMasterVolume(module);}
  void setVolume(unsigned char vol) {FMUSIC_SetMasterVolume(module,vol);}
  void setLooping(bool l) {FMUSIC_SetLooping(module,l);}
  void play() {FMUSIC_PlaySong(module);}
  void stop() {FMUSIC_StopSong(module);}
  bool isPlaying() {return FMUSIC_IsPlaying(module) == TRUE;}
#else // !USE_FMOD
  int getVolume();
  void setVolume(unsigned char vol);
  void setLooping(bool l) {looping = l;}
  bool isLooping() {return looping;}
  void play();
  void stop();
  int getBuffersCount() {return buffersCount;}
  int getBufferPlaying() {return bufferPlaying;}
  void setBufferPlaying(int bp) {bufferPlaying = bp;}
  bool isPlaying() {return bufferPlaying >= 0;}
  HMIDISTRM getStream() {return midiStream;}
  LPMIDIHDR getHeader(int idx) {return musicBuffer[idx];}
#endif // !USE_FMOD
};

#endif // USE_MUSIC

#endif // USE_SOUND
#endif // FMSOUND_H
