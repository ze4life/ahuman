#ifndef GLCOLOR_H
#define GLCOLOR_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

class GLColor {
private:
  float color[4];
public:
  GLColor(float r = 0, float g = 0, float b = 0, float a = 1);
  GLColor& set(float r = 0, float g = 0, float b = 0, float a = 1)
    {color[0] = r; color[1] = g; color[2] = b; color[3] = a; return *this;}
  GLColor& setColor(float r = 0, float g = 0, float b = 0, float a = 1)
    {return set(r,g,b,a);}
  GLColor& set(const GLColor& c)
    {return set(c.getRed(),c.getGreen(),c.getBlue(),c.getAlpha());}
  void setRed(float f) {color[0] = f;}
  void setGreen(float f) {color[1] = f;}
  void setBlue(float f) {color[2] = f;}
  void setAlpha(float f) {color[3] = f;}
  void setR(float f) {setRed(f);}
  void setG(float f) {setGreen(f);}
  void setB(float f) {setBlue(f);}
  void setA(float f) {setAlpha(f);}
  float getRed() const {return color[0];}
  float getGreen() const {return color[1];}
  float getBlue() const {return color[2];}
  float getAlpha() const {return color[3];}
  float getR() const {return getRed();}
  float getG() const {return getGreen();}
  float getB() const {return getBlue();}
  float getA() const {return getAlpha();}
  GLColor& add(const GLColor& c) {return set(
    getRed()+c.getRed(),getGreen()+c.getGreen(),
    getBlue()+c.getBlue(),getAlpha()+c.getAlpha()
  );}
  GLColor& subtract(const GLColor& c) {return set(
      getRed()-c.getRed(),getGreen()-c.getGreen(),
      getBlue()-c.getBlue(),getAlpha()-c.getAlpha()
  );}
  GLColor& scale(const GLColor& s) {return set(
    s.getRed()*getRed(), s.getGreen()*getGreen(),
    s.getBlue()*getBlue(), s.getAlpha()*getAlpha()
  );}
  GLColor& scale(float s)
    {return set(s*getRed(),s*getGreen(),s*getBlue(),s*getAlpha());}
  static void gammaCorrection(unsigned char* color, float gamma);
  void gammaCorrection(float gamma);
  const float* getFloatArray() const {return color;}
};

#endif // GLCOLOR_H
