#ifndef GLVERTEXBUFFER_H
#define GLVERTEXBUFFER_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"

#include "datamanager.h"

#ifdef USE_OGLES
#else // !USE_OGLES

//
// GLVertexBuffer
//
class GLVertexBuffer: public DMReference {
protected:
  unsigned int bufferID;
public:
  unsigned int getID() {return bufferID;}
  void gen() {glGenBuffersARB(1,&bufferID);}
  void apply() {glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferID);}
  void setStaticData(int dataSize, void* data)
    {glBufferDataARB(GL_ARRAY_BUFFER_ARB,dataSize,data,GL_STATIC_DRAW_ARB);}
  bool unmap() {return glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);}
  void* map() {return glMapBufferARB(GL_ARRAY_BUFFER_ARB,GL_WRITE_ONLY_ARB);}
  static void disable() {glBindBufferARB(GL_ARRAY_BUFFER_ARB,0);}
protected:
  virtual void destroyObject();
public:
  GLVertexBuffer(int dataSize, void* data);
  static char* getOffset(int offs) {return ((char*)NULL + (offs));}
  virtual GLVertexBuffer* acquireReference()
    {return dynamic_cast<GLVertexBuffer*>(DMReference::acquireReference());}
};

#endif // USE_OGLES

#endif // GLVERTEXBUFFER_H
