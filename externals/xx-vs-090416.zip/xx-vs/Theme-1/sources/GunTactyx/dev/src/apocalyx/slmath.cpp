/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#if defined(USE_CONSOLE) && defined(USE_SMALL)

#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "small/amx.h"

int __cdecl _matherr(struct _exception *e) {
  switch(e->type) {
    case SING:
    case TLOSS:
    case DOMAIN:
    case OVERFLOW:
    case UNDERFLOW:
      e->retval = 0; return 1;
  }
  return 0;
}

static char *pcCreateAndFillStringFromCell(AMX *amx,cell params) {
    char *szDest;
    int nLen;
    cell *pString;
    amx_GetAddr(amx,params,&pString);
    amx_StrLen(pString, &nLen);
    szDest = new char[nLen+1];
    amx_GetString(szDest, pString);
    return szDest;
}

inline static cell ConvertFloatToCell(float fValue) {
    float *pFloat;
    cell fCell;
    pFloat = (float *)((void *)&fCell);
    *pFloat = fValue;
    return fCell;
}

inline static float fConvertCellToFloat(cell cellValue) {
    float *pFloat;
    pFloat = (float *)((void *)&cellValue);
    return *pFloat;
}

static cell AMX_NATIVE_CALL _float(AMX *,cell *params) {
    float fValue;
    fValue = (float)params[1];
    return ConvertFloatToCell(fValue);
}

static cell AMX_NATIVE_CALL _floatstr(AMX *amx,cell *params) {
    char *szSource;
    float fNum;
    szSource = pcCreateAndFillStringFromCell(amx, params[1]);
    fNum = (float)atof(szSource);
    delete[] szSource;
    return ConvertFloatToCell(fNum);
}

static cell AMX_NATIVE_CALL _floatmul(AMX *,cell *params) {
    float fA, fB, fRes;
    fA = fConvertCellToFloat(params[1]);
    fB = fConvertCellToFloat(params[2]);
    fRes = fA * fB;
    return ConvertFloatToCell(fRes);
}

static cell AMX_NATIVE_CALL _floatdiv(AMX *,cell *params) {
    float fA, fB, fRes;
    fA = fConvertCellToFloat(params[1]);
    fB = fConvertCellToFloat(params[2]);
    fRes = fA / fB;
    return ConvertFloatToCell(fRes);
}

static cell AMX_NATIVE_CALL _floatadd(AMX *,cell *params) {
    float fA, fB, fRes;
    fA = fConvertCellToFloat(params[1]);
    fB = fConvertCellToFloat(params[2]);
    fRes = fA + fB;
    return ConvertFloatToCell(fRes);
}

static cell AMX_NATIVE_CALL _floatsub(AMX *,cell *params) {
    float fA, fB, fRes;
    fA = fConvertCellToFloat(params[1]);
    fB = fConvertCellToFloat(params[2]);
    fRes = fA - fB;
    return ConvertFloatToCell(fRes);
}

static cell AMX_NATIVE_CALL _floatfract(AMX *,cell *params) {
    float fA;
    fA = fConvertCellToFloat(params[1]);
    fA = fA - (float)(floor((double)fA));
    return ConvertFloatToCell(fA);
}

static cell AMX_NATIVE_CALL _floatround(AMX *,cell *params) {
    float fA;
    fA = fConvertCellToFloat(params[1]);
    switch (params[2]) {
        case 1:
            fA = (float)(floor((double)fA));
            break;
        case 2:
            fA = (float)(ceil((double)fA));
            break;
        default:
            fA = (float)(floor((double)fA+.5));
            break;
    }
    return (long)fA;
}

static cell AMX_NATIVE_CALL _floatcmp(AMX *,cell *params) {
    float fA, fB;
    fA = fConvertCellToFloat(params[1]);
    fB = fConvertCellToFloat(params[2]);
    if (fA == fB)
        return 0;
    else if (fA>fB)
        return 1;
    else
        return -1;
}

static cell AMX_NATIVE_CALL _abs(AMX *,cell *params) {
  return ConvertFloatToCell(fabs(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _acos(AMX *,cell *params) {
  return ConvertFloatToCell(acos(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _asin(AMX *,cell *params) {
  return ConvertFloatToCell(asin(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _atan(AMX *,cell *params) {
  return ConvertFloatToCell(atan(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _cos(AMX *,cell *params) {
  return ConvertFloatToCell(cos(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _exp(AMX *,cell *params) {
  return ConvertFloatToCell(exp(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _log(AMX *,cell *params) {
  return ConvertFloatToCell(log(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _mod(AMX *,cell *params) {
  return ConvertFloatToCell(
    fmod(fConvertCellToFloat(params[1]),fConvertCellToFloat(params[2])));
}

static cell AMX_NATIVE_CALL _frac(AMX *,cell *params) {
  double integer;
  return ConvertFloatToCell(modf(fConvertCellToFloat(params[1]),&integer));
}

static cell AMX_NATIVE_CALL _pow(AMX *,cell *params) {
  return ConvertFloatToCell(
    pow(fConvertCellToFloat(params[1]),fConvertCellToFloat(params[2]))
  );
}

static cell AMX_NATIVE_CALL _sin(AMX *,cell *params) {
  return ConvertFloatToCell(sin(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _sqrt(AMX *,cell *params) {
  return ConvertFloatToCell(sqrt(fConvertCellToFloat(params[1])));
}

static cell AMX_NATIVE_CALL _tan(AMX *,cell *params) {
  return ConvertFloatToCell(tan(fConvertCellToFloat(params[1])));
}

/* extern */ AMX_NATIVE_INFO math_Natives[] = {
  { "float",      _float },
  { "floatstr",   _floatstr },
  { "floatmul",   _floatmul },
  { "floatdiv",   _floatdiv },
  { "floatadd",   _floatadd },
  { "floatsub",   _floatsub },
  { "floatfract", _floatfract },
  { "floatround", _floatround },
  { "floatcmp",   _floatcmp },
  { "abs",  _abs },
  { "acos", _acos },
  { "asin", _asin },
  { "atan", _atan },
  { "cos",  _cos },
  { "exp",  _exp },
  { "log",  _log },
  { "mod",  _mod },
  { "frac", _frac },
  { "pow",  _pow },
  { "sin",  _sin },
  { "sqrt", _sqrt },
  { "tan",  _tan },
  { NULL, NULL }
};

#endif // USE_CONSOLE && USE_SMALL

