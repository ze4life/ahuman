#ifndef GLSCENE_H
#define GLSCENE_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glwin.h"

//
// GLScene
//
class GLScene {
public:
  virtual bool initialize(GLWin& glWin) {return true;}
  virtual void finalize(GLWin& glWin) {};
  virtual int update(GLWin& glWin) {return 0;}
  virtual void keyDownEvent(GLWin& glWin, int key) {}
};

//
// GLSceneManager
//
class GLSceneManager {
private:
  GLWin* glWin;
  DSArray<GLScene> scenes;
  int currentScene;
protected:
  void setCurrentScene(int idx)
    {finalizeCurrent(); currentScene = idx; initializeCurrent();}
  GLScene* getCurrentScene() {return scenes.getElement(currentScene);}
  void initializeCurrent() {getCurrentScene()->initialize(*glWin);}
  void finalizeCurrent() {getCurrentScene()->finalize(*glWin);}
public:
  GLSceneManager(GLWin* w);
  int addScene(GLScene* s) {scenes.addElement(s); return scenes.getSize()-1;}
  int addScenes(GLScene** s);
  void deleteScenes() {finalizeCurrent(); scenes.deleteElements();}
  void dispatchKeyDownEvent(int key)
    {getCurrentScene()->keyDownEvent(*glWin,key);}
  void updateScene() {
    int newScene = getCurrentScene()->update(*glWin);
    if(newScene != currentScene) setCurrentScene(newScene);
  }
};

#endif // GLSCENE_H
