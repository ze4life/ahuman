#ifndef DATASETS_H
#define DATASETS_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "void.h"

//
// DSStaticArray
//
template <class T> class DSStaticArray {
protected:
  int increment;
  int capacity;
  int size;
  T* elements;
public:
  DSStaticArray(int cap = 1);
  ~DSStaticArray();
  int getCapacity() {return capacity;}
  int getSize() {return size;}
  bool isEmpty() {return getSize() == 0;}
  void incrementCapacity();
  T& getElement(int idx) {return elements[idx];}
  void addElements(int count, const T& val);
  void addElement(const T& val)
    {if(size == capacity) incrementCapacity(); elements[size] = val; size++;}
  void zeroSize() {size = 0;}
  void decrementSize(int dec = 1) {size -= dec;}
};

//
// DSArray
//
template <class T, bool ownsElements = true> class DSArray:
  public DSStaticArray<T*>
{
protected:
  void zeroSize() {DSStaticArray<T*>::zeroSize();}
  T* setElementNC(int idx, T* val)
    {T* e = elements[idx]; elements[idx] = val; return e;} 
public:
  DSArray(int cap = 1);
  ~DSArray();
  void incrementCapacity();
  T* setElement(int idx, T* val);
  void removeElement(int idx);
  bool removeElement(T* element);
  void deleteElements();
};

//
// DSSortableObject
//
class DSSortableObject: virtual public Void {
public:
  virtual float getSortIndex() = 0;
};

//
// DSSortedArray
//
template <class T, bool ownsElements = true> class DSSortedArray:
  public DSArray<T,ownsElements>
{
protected:
  T* setElement(int idx, T* val)
    {return DSArray<T,ownsElements>::setElement(idx,val);}
  T* setElementNC(int idx, T* val)
    {return DSArray<T,ownsElements>::setElementNC(idx,val);}
  DSSortableObject* setElementNC(int idx, DSSortableObject* val)
    {return DSArray<T,ownsElements>::setElementNC(idx,dynamic_cast<T*>(val));}
  void addElement(T* val) {return DSArray<T,ownsElements>::addElement(val);}
public:
  DSSortedArray();
  DSSortedArray(int cap);
  DSSortableObject* setElement(int idx, DSSortableObject* val)
    {return DSArray<T,ownsElements>::setElement(idx,dynamic_cast<T*>(val));}
  void addElement(DSSortableObject* val)
    {DSArray<T,ownsElements>::addElement(dynamic_cast<T*>(val));}
  void quickSort(int low,int high);
};

//
// DSChainNode
//
class DSChainNode {
protected:
  DSChainNode* next;
public:
  DSChainNode();
  virtual ~DSChainNode();
  DSChainNode* getNextNode() {return next;}
  void setNextNode(DSChainNode* node) {next = node;}
};

//
// DSTwoWayChainNode
//
class DSTwoWayChainNode: public DSChainNode {
private:
  DSTwoWayChainNode* prev;
public:
  DSTwoWayChainNode();
  DSTwoWayChainNode* getPrevNode() {return prev;}
  DSTwoWayChainNode* getNextNode() {
    DSChainNode* next = DSChainNode::getNextNode();
    return static_cast<DSTwoWayChainNode*>(next);
  }
  void setPrevNode(DSTwoWayChainNode* node) {prev = node;}
  };

//
// DSChain
//
class DSChain {
protected:
  unsigned short length;
  DSChainNode* first;
  DSChainNode* last;
  DSChainNode* pointer;
public:
  DSChain();
  virtual ~DSChain();
  DSChainNode* getFirstNode() {return first;}
  DSChainNode* getThisNode() {return pointer;}
  DSChainNode* getLastNode() {return last;}
  unsigned short getLength() {return length;}
  DSChainNode* reset() {return pointer = first;}
  DSChainNode* resetTo(DSChainNode* node) {return pointer = node;}
  DSChainNode* nextNode();
  void addNodeFirst(DSChainNode* node);
  void addNodeLast(DSChainNode* node);
  void insertNodeBehind(DSChainNode* node);
  bool deleteNode(DSChainNode* node);
  void deleteAll();
};

//
// DSTwoWayChain
//
class DSTwoWayChain: private DSChain {
public:
  DSTwoWayChainNode* getFirstNode()
    {return static_cast<DSTwoWayChainNode*>(DSChain::getFirstNode());}
  DSTwoWayChainNode* getThisNode()
    {return static_cast<DSTwoWayChainNode*>(DSChain::getThisNode());}
  DSTwoWayChainNode* getLastNode() 
    {return static_cast<DSTwoWayChainNode*>(DSChain::getLastNode());}
  unsigned short getLength() {return length;}
  DSTwoWayChainNode* reset()
    {return static_cast<DSTwoWayChainNode*>(pointer = first);}
  DSTwoWayChainNode* resetTo(DSChainNode* node) 
    {return static_cast<DSTwoWayChainNode*>(pointer = node);}
  DSTwoWayChainNode* resetToLast()
    {return static_cast<DSTwoWayChainNode*>(pointer = last);}
  DSTwoWayChainNode* nextNode()
    {return static_cast<DSTwoWayChainNode*>(DSChain::nextNode());}
  DSTwoWayChainNode* prevNode();
  void addNodeFirst(DSTwoWayChainNode* node);
  void addNodeLast(DSTwoWayChainNode* node);
  void insertNodeBefore(DSTwoWayChainNode* node);
  void insertNodeBehind(DSTwoWayChainNode* node);
  bool deleteNode(DSTwoWayChainNode* node);
  void deleteAll() {DSChain::deleteAll();}
};

//
// DSListNode
//
template <class T, bool ownsElements = true> class DSListNode:
  public DSChainNode
{
private:
  T* element;
public:
  DSListNode(T* e);
  ~DSListNode();
  T* getElement() {return element;}
  void setElement(T* e) {element = e;}
  DSListNode<T,ownsElements>* getNextNode() {
    return static_cast<DSListNode<T,ownsElements>*>(
      DSChainNode::getNextNode()
    );
  }
  void setNextNode(DSListNode<T,ownsElements>* node)
    {DSChainNode::setNextNode(node);}
};

//
// DSTwoWayListNode
//
template <class T, bool ownsElements = true> 
class DSTwoWayListNode: public DSTwoWayChainNode {
private:
  T* element;
public:
  DSTwoWayListNode(T* e);
  ~DSTwoWayListNode();
  T* getElement() {return element;}
  void setElement(T* e) {element = e;}
  DSTwoWayListNode<T,ownsElements>* getNextNode()	{
    return static_cast<DSTwoWayListNode<T,ownsElements>*>
     (DSTwoWayChainNode::getNextNode());
  }
  DSTwoWayListNode<T,ownsElements>* getPrevNode() {
    return static_cast<DSTwoWayListNode<T,ownsElements>*>
      (DSTwoWayChainNode::getPrevNode());
  }
  void setPrevNode(DSTwoWayListNode<T,ownsElements>* node)
  	{DSTwoWayChainNode::setPrevNode(node);}
};

//
// DSList
//
template <class T, bool ownsElements = true> 
class DSList: private DSChain {
public:
  unsigned short getLength() {return DSChain::getLength();}
  DSListNode<T,ownsElements>* reset()
    {return static_cast<DSListNode<T,ownsElements>*>(DSChain::reset());}
  DSListNode<T,ownsElements>* resetTo(DSListNode<T,ownsElements>* node)
    {return static_cast<DSListNode<T,ownsElements>*>(DSChain::resetTo(node));}
  T* resetToFirstElement() {
    DSListNode<T,ownsElements>* n = reset(); 
    if(n != 0) {
      T* el = n->getElement();
      return( el );
    } else {
      return(0);
    }
  }
  T* resetToElementOf(DSListNode<T,ownsElements>* n) {
    resetTo(n); 
    return n ? n->getElement(): 0;
  }
  bool isEmpty() {return !getLength();}
  T* getFirstElement() {
    return isEmpty() ? 0 :
    static_cast<DSListNode<T,ownsElements>*>(getFirstNode())->getElement();
  }
  T* getLastElement() {
    return isEmpty() ? 0 :
    static_cast<DSListNode<T,ownsElements>*>(getLastNode())->getElement();
  }
  T* thisElement();
  T* nextElement();
  DSListNode<T,ownsElements>* nextNode() {
    return static_cast<DSListNode<T,ownsElements>*>(DSChain::nextNode());
  }
  DSListNode<T,ownsElements>* addElement(T* e);
  DSListNode<T,ownsElements>* insertElement(T* e);
  bool deleteElement(T* e);
  bool removeElement(T* e);
  bool deleteNode(DSListNode<T,ownsElements>* n) {
    return DSChain::deleteNode(static_cast<DSChainNode*>(n));
  }
  bool removeNode(DSListNode<T,ownsElements>* n);
  void deleteAll() {DSChain::deleteAll();}
};

//
// DSTwoWayList
//
template <class T, bool ownsElements = true> class DSTwoWayList:
	private DSTwoWayChain
{
public:
  unsigned short getLength() {return DSChain::getLength();}
  DSTwoWayListNode< T, ownsElements >* reset() {
    return static_cast<DSTwoWayListNode< T, ownsElements >*>
      (DSTwoWayChain::reset());
  }
  DSTwoWayListNode< T, ownsElements >* resetTo(
    DSTwoWayListNode< T, ownsElements >* node
  ) {
    return static_cast<DSTwoWayListNode< T, ownsElements >*>
      (DSTwoWayChain::resetTo(node));
  }
  T* resetToFirstElement() {
    DSTwoWayListNode< T, ownsElements >* n = reset(); 
    if(n != 0) {
      T* el = n->getElement();
      return(el);
    } else {
      return(0);
    }
  }
  DSTwoWayListNode< T, ownsElements >* resetToLast() {
    return static_cast<DSTwoWayListNode< T, ownsElements >*>
      (DSTwoWayChain::resetToLast());
  }
  T* resetToLastElement() {
    DSTwoWayListNode< T, ownsElements >* n = resetToLast();
    return n? n->getElement() : 0;
  }
  bool isEmpty() {return !getLength();}
  T* getFirstElement() {
    return isEmpty() ? 0 :
      static_cast<DSTwoWayListNode< T, ownsElements >*>
        (getFirstNode())->getElement();
  }
  T* getLastElement() {
    return isEmpty() ? 0 :
      static_cast<DSTwoWayListNode< T, ownsElements >*>
        (getLastNode())->getElement();
  }
  T* thisElement();
  T* nextElement();
  T* prevElement();
  DSTwoWayListNode< T, ownsElements >* nextNode() {
    return static_cast<DSTwoWayListNode< T, ownsElements >*>
      (DSTwoWayChain::nextNode());
  }
  DSTwoWayListNode< T, ownsElements >* prevNode() {
    return static_cast<DSTwoWayListNode< T, ownsElements >*>
      (DSTwoWayChain::prevNode());
  }
  DSTwoWayListNode< T, ownsElements >* addElement(T* e);
  DSTwoWayListNode< T, ownsElements >* insertElement(T* e);
  bool deleteElement(T* e);
  bool removeElement(T* e);
  bool swapElements();
  bool deleteNode(DSTwoWayListNode< T, ownsElements >* n) {
    return DSTwoWayChain::deleteNode(n);
  }
  bool removeNode(DSTwoWayListNode< T, ownsElements >* n);
  void deleteAll() {DSTwoWayChain::deleteAll();}
};

#endif //DATASETS_H
