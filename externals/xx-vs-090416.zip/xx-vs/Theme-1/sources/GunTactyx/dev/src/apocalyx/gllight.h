#ifndef GLLIGHT_H
#define GLLIGHT_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "globject.h"
#include "glcolor.h"
#include "gltexture.h"

//
// GLAttenuation
//
class GLAttenuation {
public:
  float constant;
  float linear;
  float quadratic;
};

//
// GLSpot
//
class GLSpot {
public:
  float exponent;
  int cutoff;
};

//
// GLLight
//
class GLLight: public GLObject {
protected:
  GLColor color;
  float lightSize;
  GLTexture* texture;
  GLAttenuation attenuation;
  M3Vector direction;
  bool isDistant;
  GLSpot spot;
public:
  GLLight(GLTexture* lghTxt, float lghSiz);
  virtual ~GLLight();
  void setLightSize(float ls) {lightSize = ls;}
  void setColor(float r, float g, float b) {color.set(r,g,b);}
  void setAttenuation(float c = 1, float l = 0, float q = 0)
    {attenuation.constant=c; attenuation.linear=l; attenuation.quadratic=q;}
  bool isDirectional() {return isDistant;}
  void setDirectional(M3Vector& direc)
    {direction = direc; isDistant = true;}
  M3Vector& getDirection() {return direction;}
  void setSpot(int cut = 180, float exp = 0)
    {spot.cutoff = cut; spot.exponent = exp; isDistant = false;}
  void setSpot(M3Vector& direc, int cut = 180, float exp = 0)
    {direction = direc; setSpot(cut,exp);}
  virtual void applyPropertiesTo(int index);
  void applyPositionTo(int index);
  virtual void render(GLCamera& camera);
};

//
// GLFireLight
//
class GLFireLight: public GLLight {
protected:
  float lastChange;
  GLColor minIntensity;
  GLColor rangeIntensity;
public:
  GLFireLight(GLTexture* lghTxt, float lghSiz);
  void setIntensities(
    float minRed = 0, float minGreen = 0, float minBlue = 0,
    float maxRed = 1, float maxGreen = 1, float maxBlue = 1
  ) {
    minIntensity.set(minRed,minGreen,minBlue);
    rangeIntensity.set(maxRed-minRed,maxGreen-minGreen,maxBlue-minBlue);
  }
  virtual void applyPropertiesTo(int index);
};

//
// GLMoonLight
//
class GLMoonLight: public GLLight {
private:
  float cameraDistance;
public:
  GLMoonLight(
    GLTexture* lghTxt, float lghSz, M3Vector& direc, float cameraDist = 1000
  );
  float getCameraDistance() {return cameraDistance;}
  virtual void render(GLCamera& camera);
};

//
// GLFlare
//
class GLFlare {
public:
  GLColor color;
  float position;
  float size;
};

//
// GLSunLight
//
class GLSunLight: public GLMoonLight {
private:
  static DMCache* cache;
  bool lensFlareShown;
  bool wasOccluded;
  bool checkDepth;
public:
  static float* getArrays(int siz)
    {cache->checkSize(4*siz); return (float*)cache->getDataPointer();}
protected:
  int flaresCount;
  GLFlare* flares;
  float flaresSize;
  GLTexture* flaresTexture;
public:
  GLSunLight(
    GLTexture* lghTxt, float lghSz, M3Vector& direc,
    GLTexture* flareTxt = NULL, int flrCount = 0, float flrSz = 0.1,
    float cameraDist = 1000, bool checkOcclusion = true
  );
  ~GLSunLight();
  void setLensFlareShown(bool b) {lensFlareShown = b;}
  bool isLensFlareShown() {return lensFlareShown;}
  void checkOcclusion(GLCamera& camera);
  void renderLensFlare(GLCamera& camera);
  virtual void render(GLCamera& camera);
};

#endif // GLLIGHT_H
