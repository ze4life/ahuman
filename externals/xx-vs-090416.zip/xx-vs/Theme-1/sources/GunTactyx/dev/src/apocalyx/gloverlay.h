#ifndef GLOVERLAY_H
#define GLOVERLAY_H

/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glfont.h"
#include "glworld.h"

#include "void.h"

#include "strings.h"

#ifdef USE_SJGUI
#include "sjgui/sjgui.h"
#endif // USE_SJGUI

//
// GLOverlayVisible
//
class GLOverlayVisible {
protected:
  bool visible;
public:
  GLOverlayVisible();
  void setVisible(bool v) {visible = v;}
  bool isVisible() {return visible;}
};

//
// GLOverlayLayered
//
class GLOverlayLayered: public GLOverlayVisible, public DSSortableObject {
protected:
  float layer;
public:
  GLOverlayLayered();
  virtual ~GLOverlayLayered();
  void setLayer(float l) {layer = l;}
  float getLayer() {return layer;}
  float getSortIndex() {return getLayer();}
  virtual void render(GLCamera& camera) = 0;
};

//
// GLOverlayObject
//
class GLOverlayObject: public GLOverlayLayered {};

#ifdef USE_SJGUI

//
// GLGuiObject
//

class GLGuiObject: public sjgui::CWndCtrlBase, public GLOverlayLayered {
private:
  DSArray<GLGuiObject*> children;
public:
  ~GLGuiObject();
  void add(GLGuiObject* child);
  void remove(GLGuiObject* child);
  virtual void render(GLCamera& camera);
};

#endif // USE_SJGUI

//
// GLOverlayColor
//
class GLOverlayColor {
protected:
  float red;
  float green;
  float blue;
  float alpha;
public:
  GLOverlayColor(float r = 1, float g = 1, float b = 1, float a = 1);
  void setColor(float r = 1, float g = 1, float b = 1, float a = 1)
    {red = r; green = g; blue = b; alpha = a;}
  void setRed(float f) {red = f;}
  void setGreen(float f) {green = f;}
  void setBlue(float f) {blue = f;}
  void setAlpha(float f) {alpha = f;}
  float getRed() const {return red;}
  float getGreen() const {return green;}
  float getBlue() const {return blue;}
  float getAlpha() const {return alpha;}
  bool isOpaque() {return alpha == 1;}
  bool isTransparent() {return alpha < 1;}
};

//
// GLOverlayFader
//
class GLOverlayFader: public GLOverlayObject, public GLOverlayColor {
public:
  virtual void render(GLCamera& camera);
};

//
// GLOverlayLocation
//
class GLOverlayLocation {
protected:
  float x;
  float y;
public:
  GLOverlayLocation(float iX = 0, float iY = 0);
  float getX() {return x;}
  float getY() {return y;}
  void setLocation(float iX, float iY) {x = iX; y = iY;}
  void set(float iX, float iY) {setLocation(iX,iY);}
  void setX(float iX) {x = iX;}
  void setY(float iY) {y = iY;}
  void addX(float iX) {x += iX;}
  void addY(float iY) {y += iY;}
  void add(float iX, float iY) {addX(iX); addY(iY);}
};

//
// GLOverlayRotation
//
class GLOverlayRotation {
protected:
  float rotation;
public:
  GLOverlayRotation(float iRot = 0);
  float getRotation() {return rotation*(M_PI/180);}
  void setRotation(float rot) {rotation = rot*(180/M_PI);}
  void addRotation(float rot) {rotation += rot*(180/M_PI);}
};

//
// GLOverlayDimension
//
class GLOverlayDimension {
protected:
  float width;
  float height;
public:
  GLOverlayDimension(float iW, float iH);
  void setDimension(float iW, float iH) {width = iW; height = iH;}
  float getWidth() {return width;}
  float getHeight() {return height;}
};

//
// GLOverlayTextureCoord
//
class GLOverlayTextureCoord {
protected:
  float right;
  float left;
  float top;
  float bottom;
public:
  GLOverlayTextureCoord(float l = 0, float b = 0, float r = 1, float t = 1);
  void setTextureCoord(float l = 0, float b = 0, float r = 1, float t = 1)
    {left = l; bottom = b; right = r; top = t;}
  float getLeft() {return left;}
  float getBottom() {return bottom;}
  float getRight() {return right;}
  float getTop() {return top;}
};

//
// GLOverlayText
//
class GLOverlayText:
  public GLVisible, public GLOverlayLocation, public GLOverlayRotation,
  public GLOverlayColor, public String, virtual public Void
{
public:
  enum Alignment {LEFT, CENTER, RIGHT};
private:
  Alignment alignment;
  float scale;
public:
  GLOverlayText(const char* txt, float iX = 0, float iY = 0);
  GLOverlayText(
    char* txt, float iR, float iG, float iB, float iX = 0, float iY = 0
  );
  Alignment getAlignment() {return alignment;}
  void setAlignment(Alignment a) {alignment = a;}
  void setScale(float s) {scale = s;}
  float getScale() {return scale;}
  void render(GLFont& f);
};

//
// GLOverlayTexts
//
class GLOverlayTexts:
  public GLOverlayObject, public GLOverlayLocation, public GLOverlayRotation,
  public DSArray<GLOverlayText>
{
private:
  GLFont* font;
public:
  GLOverlayTexts(GLFont* f);
  virtual ~GLOverlayTexts();
  GLOverlayText* getText(float x, float y);
  GLOverlayText* getText(int index);
  GLFont* getFont() {return font;}
  virtual void render(GLCamera& camera);
};

//
// GLOverlaySprite
//
class GLOverlaySprite:
  public GLOverlayObject, public GLOverlayLocation, public GLOverlayRotation,
  public GLOverlayDimension, public GLOverlayColor, public GLOverlayTextureCoord
{
private:
  GLTexture* texture;
  bool alphaChannel;
public:
  GLOverlaySprite(
    float iW, float iH, GLTexture* txt, bool ha = false,
    float l = 0, float b = 0, float r = 1, float t = 1,
    float iX = 0, float iY = 0
  );
  void setAlphaChannel(bool a) {alphaChannel = a;}
  bool hasAlphaChannel() {return alphaChannel;}
  virtual ~GLOverlaySprite();
  virtual void render(GLCamera& camera);
};

//
// GLOverlayIndexes
//
class GLOverlayIndexes: public DMReference {
private:
  int count;
  unsigned short* indexes;
public:
  GLOverlayIndexes* acquireReference()
    {return dynamic_cast<GLOverlayIndexes*>(DMReference::acquireReference());}
protected:
  GLOverlayIndexes();
  virtual void destroyObject();
public:
  GLOverlayIndexes(int indexesCount, unsigned short* iIndexes);
  int getCount() {return count;}
  unsigned short* getIndexes() {return indexes;}
};

//
// GLOverlayCoords
//
class GLOverlayCoords: public DMReference {
public:
  enum {V_STRIDE = 8, C_STRIDE = 4};
protected:
  int count;
  float* coords;
  unsigned char* colors;
public:
  GLOverlayCoords* acquireReference()
    {return dynamic_cast<GLOverlayCoords*>(DMReference::acquireReference());}
protected:
  GLOverlayCoords();
  virtual void destroyObject();
public:
  GLOverlayCoords(int coordsCount, float* coo, unsigned char* clr = NULL);
  int getCount() {return count;}
  float* getCoords() {return coords;}
  unsigned char* getColors() {return colors;}
  float* getCoord(int idx) {return &coords[idx*V_STRIDE];}
  float getCoordX(int idx) {return coords[idx*V_STRIDE+0];}
  float getCoordY(int idx) {return coords[idx*V_STRIDE+1];}
  void setCoordX(int idx, float f) {coords[idx*V_STRIDE+0] = f;}
  void setCoordY(int idx, float f) {coords[idx*V_STRIDE+1] = f;}
  unsigned char* getColor(int idx) {return &colors[idx*C_STRIDE];}
  unsigned char getColorR(int idx) {return colors[idx*C_STRIDE+0];}
  unsigned char getColorG(int idx) {return colors[idx*C_STRIDE+1];}
  unsigned char getColorB(int idx) {return colors[idx*C_STRIDE+2];}
  unsigned char getColorA(int idx) {return colors[idx*C_STRIDE+3];}
  void setColorR(int idx, unsigned char f) {colors[idx*C_STRIDE+0] = f;}
  void setColorG(int idx, unsigned char f) {colors[idx*C_STRIDE+1] = f;}
  void setColorB(int idx, unsigned char f) {colors[idx*C_STRIDE+2] = f;}
  void setColorA(int idx, unsigned char f) {colors[idx*C_STRIDE+3] = f;}
};

//
// GLOverlayPoints
//
class GLOverlayPoints:
  public GLOverlayObject, public GLOverlayLocation,
  public GLOverlayRotation, public GLOverlayColor
{
protected:
	GLOverlayCoords* coords;
  bool smooth;
  float size;
public:
	GLOverlayPoints(
  	int coordsCount, float* iCoords, unsigned char* iColors = NULL,
    bool iSmooth = false
  );
	GLOverlayPoints(GLOverlayCoords& newCoords, bool iSmooth = false);
  GLOverlayPoints::~GLOverlayPoints();
  GLOverlayCoords& getCoords() {return *coords;}
  void setSmooth(bool s) {smooth = s;}
  bool getSmooth() {return smooth;}
  void setSize(float s) {size = s;}
  float getSize() {return size;}
  virtual void render(GLCamera& camera);
};

//
// GLOverlayLines
//
class GLOverlayLines: public GLOverlayPoints {
public:
  enum {LINES = GL_LINES, LINESTRIP = GL_LINE_STRIP, LINELOOP = GL_LINE_LOOP,};
protected:
	GLOverlayIndexes* indexes;
  unsigned short pattern;
  int factor;
  int mode;
public:
	GLOverlayLines(
    int indexesCount, unsigned short* iIndexes,
  	int coordsCount, float* iCoords, unsigned char* iColors = NULL,
    int iMode = LINES, bool iSmooth = false
  );
	GLOverlayLines(
  	GLOverlayCoords& coords, GLOverlayIndexes& indexes,
    int iMode = LINES, bool iSmooth = false
  );
  GLOverlayLines::~GLOverlayLines();
  GLOverlayIndexes& getIndexes() {return *indexes;}
  void setStipple(unsigned short p, int f = 1) {pattern = p; factor = f;}
  unsigned short getPattern() {return pattern;}
  int getFactor() {return factor;}
  void setMode(int m) {mode = m;}
  int getMode() {return mode;}
  virtual void render(GLCamera& camera);
};

//
// GLPolys
//
class GLOverlayPolys: public GLOverlayLines {
public:
  enum {
		POLY = GL_POLYGON, TRIANGS = GL_TRIANGLES,
    TRIANGSTRIP = GL_TRIANGLE_STRIP, TRIANGFAN = GL_TRIANGLE_FAN,
  };
  enum {FILL = GL_FILL, POINT = GL_POINT, LINE = GL_LINE,};
protected:
	unsigned char* mask;
  int fillMode;
public:
	GLOverlayPolys(
    int indexesCount, unsigned short* iIndexes,
  	int coordsCount, float* iCoords, unsigned char* iColors = NULL,
    int iMode = POLY, bool iSmooth = false
  );
	GLOverlayPolys(
  	GLOverlayCoords& coords, GLOverlayIndexes& indexes,
    int iMode = POLY, bool iSmooth = false
  );
  GLOverlayPolys::~GLOverlayPolys();
  void setMask(unsigned char* newMask) {if(mask) delete mask; newMask = mask;}
  void setFill(int mode) {fillMode = mode;}
  virtual void render(GLCamera& camera);
};

//
// GLOverlayWorldView
//

class GLOverlayWorldView: public GLCamera, public GLOverlayObject {
public:
  GLOverlayWorldView(float iW, float iH, float iX = 0, float iY = 0);
  virtual void render(GLCamera& camera);
};

//
// GLOverlayViewport
//

class GLOverlayViewport:
	public GLOverlayWorldView, public GLOverlayColor, public GLFog
{
public:
  int getOpaqueObjectsCount() {return opaqueObjects.getSize();}
  int getTransparentObjectsCount() {return transparentObjects.getSize();}
  GLObject* getOpaqueObject(int idx)
    {return opaqueObjects.getElement(idx);}
  GLObject* getTransparentObject(int idx)
    {return transparentObjects.getElement(idx);}
  GLShadow* getShadow(int idx)
    {return shadows.getElement(idx);}
  void addObject(GLObject* object) {
    (object->isTransparent()? transparentObjects: opaqueObjects).addElement(
      static_cast<DSSortableObject*>(object)
    );
  }
  bool removeOpaqueObject(GLObject* o)
  	{removeShadow(o); return opaqueObjects.removeElement(o);}
  bool removeTransparentObject(GLObject* o)
  	{removeShadow(o); return transparentObjects.removeElement(o);}
  bool removeObject(GLObject* o) {
    removeShadow(o);
    return (opaqueObjects.removeElement(o) || transparentObjects.removeElement(o));
  }
  void deleteObjects() {
    transparentObjects.deleteElements();
    opaqueObjects.deleteElements();
    deleteShadows();
  }
  int getShadowsCount() {return shadows.getSize();}
  void addShadow(GLShadow* shadow) {shadows.addElement(shadow);}
  bool removeShadow(GLShadow* s) {return shadows.removeElement(s);}
  bool removeShadow(GLObject* o);
  void deleteShadows() {shadows.deleteElements();}
  void removeEnvironment();
  void empty() {deleteObjects(); removeEnvironment();}
  GLBackground* getBackground() {return background;}
  void setBackground(GLBackground* bg);
  GLScenery* getScenery() {return scenery;}
  void setScenery(GLScenery* s);
  GLTerrain* getTerrain() {return terrain;}
  void setTerrain(GLTerrain* t);
  GLSunLight* getSun() {return sun;}
  void setSun(GLSunLight* s);
  void setAmbient(float r, float g, float b) {ambient.set(r,g,b);}
private:
  GLBackground* background;
  DSSortedArray<GLObject> opaqueObjects;
  DSSortedArray<GLObject> transparentObjects;
  DSArray<GLShadow> shadows;
  GLScenery* scenery;
  GLTerrain* terrain;
  GLSunLight* sun;
  GLColor ambient;
public:
  GLOverlayViewport(float iW, float iH, float iX = 0, float iY = 0);
  virtual ~GLOverlayViewport();
  virtual void render(GLCamera& camera);
};

//
// GLOverlay
//
class GLOverlay {
private:
  bool pointerShown;
  GLOverlaySprite* pointer;
  DSSortedArray<GLOverlayLayered,false> sortedObjects;
  DSArray<GLOverlayObject> overlayObjects;
#ifdef USE_SJGUI
  DSArray<GLGuiObject> guiObjects;
#endif // USE_SJGUI
public:
  GLOverlay();
  ~GLOverlay();
  bool isPointerShown() {return pointer && pointer->isVisible();}
  void showPointer() {if(pointer) pointer->setVisible(true);}
  void hidePointer() {if(pointer) pointer->setVisible(false);}
  float getPointerX() {return pointer? pointer->getX(): 0;}
  float getPointerY() {return pointer? pointer->getY()+pointer->getHeight(): 0;}
  float getPointerWidth() {return pointer? pointer->getWidth(): 0;}
  float getPointerHeight() {return pointer? pointer->getHeight(): 0;}
  void setPointer(float x, float y)
    {if(pointer) pointer->set(x,y-pointer->getHeight());}
  void setPointerX(float x) {if(pointer) pointer->setX(x);}
  void setPointerY(float y) {if(pointer) pointer->setY(y-pointer->getHeight());}
  void movePointer(
    float dx, float dy, float maxX, float maxY, float minX = 0, float minY = 0
  );
  void movePointer(float dx, float dy) {if(pointer) pointer->add(dx,dy);}
  void setPointer(GLOverlaySprite* os, float x = -1, float y = -1);
  int getObjectsCount() {return sortedObjects.getSize();}
  GLOverlayLayered* getObject(int idx) {return sortedObjects.getElement(idx);}
  void addOverlayObject(GLOverlayObject* object) {
    sortedObjects.addElement(static_cast<DSSortableObject*>(object));
    overlayObjects.addElement(object);
  }
  bool removeOverlayObject(GLOverlayObject* o) {
    sortedObjects.removeElement(o);
    return overlayObjects.removeElement(o);
  }
#ifdef USE_SJGUI
  void addGuiObject(GLGuiObject* object) {
    GLWin::get().getGui().RegisterChild(object);
    sortedObjects.addElement(static_cast<DSSortableObject*>(object));
    guiObjects.addElement(object);
  }
  bool removeGuiObject(GLGuiObject* object) {
    CWnd* parent = object->GetParent();
    if(parent)
      parent->UnRegisterChild(object);
    sortedObjects.removeElement(object);
    return guiObjects.removeElement(object);
  }
#endif // USE_SJGUI
  void deleteObjects() {
    overlayObjects.deleteElements();
    sortedObjects.deleteElements();
#ifdef USE_SJGUI
    guiObjects.deleteElements();
#endif // USE_SJGUI
  }
  bool isEmpty() {return sortedObjects.isEmpty();}
  void empty() {deleteObjects();}
  void render(GLCamera& camera);
};

#endif // GLOVERLAY_H
