/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"
#include "gltexture.h"
#include "glwin.h"

//
// GLTexture
//

GLTexture::GLTexture(unsigned int id): textureID(id), textureDim(GL_TEXTURE_2D)
{}

GLTexture::GLTexture(DRImage& img, bool repeat, bool doMipmaps, int txtDim):
  textureDim(txtDim)
{
  glGenTextures(1,&textureID);
  glBindTexture(textureDim,textureID);
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  if(img.isGrayScale()) img.convertGray2RGBA();
  if(doMipmaps) {
    glTexParameteri(textureDim,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(textureDim,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
  } else {
    glTexParameteri(textureDim,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(textureDim,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
  }
#ifndef USE_OGLES
  if(textureDim == GL_TEXTURE_1D) {
    if(repeat) {
      glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    } else {
      glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
    }
    glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    if(doMipmaps) {
      gluBuild1DMipmaps (
        GL_TEXTURE_1D,img.getHasAlpha()?GL_RGBA8:GL_RGB8,img.getWidth(),
        img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
      );
    } else {
      glTexImage1D(
        GL_TEXTURE_1D,0,img.getHasAlpha()?4:3,img.getWidth(),0,
        img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
      );
    }
  } else {
#endif // !USE_OGLES
    if(repeat) {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    } else {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE);
    }
#ifndef USE_OGLES
    if(doMipmaps) {
      gluBuild2DMipmaps(
        GL_TEXTURE_2D,img.getHasAlpha()?GL_RGBA8:GL_RGB8,
        img.getWidth(),img.getHeight(),img.getHasAlpha()?GL_RGBA:GL_RGB,
        GL_UNSIGNED_BYTE,img.getBuffer()
      );
    } else {
#endif // !USE_OGLES
      glTexImage2D(
        GL_TEXTURE_2D,0,img.getHasAlpha()?4:3,img.getWidth(),img.getHeight(),0,
        img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
      );
#ifndef USE_OGLES
    }
  }
#endif // !USE_OGLES
}

GLTexture::GLTexture(
  unsigned char* image, int width, int height, bool repeat, bool doMipmaps
) {
	glGenTextures(1,&textureID);
  textureDim =
#ifndef USE_OGLES
    (height == 1)? GL_TEXTURE_1D:
#endif // !USE_OGLES
    GL_TEXTURE_2D;
	glBindTexture(textureDim,textureID);
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  if(doMipmaps) {
    glTexParameteri(textureDim,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(textureDim,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
  } else {
    glTexParameteri(textureDim,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(textureDim,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
  }
#ifndef USE_OGLES
  if(textureDim == GL_TEXTURE_1D) {
    if(repeat) {
      glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    } else {
      glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
    }
    glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    if(doMipmaps)
  	  gluBuild1DMipmaps(GL_TEXTURE_1D,3,width,GL_RGB,GL_UNSIGNED_BYTE,image);
    else
      glTexImage1D(GL_TEXTURE_1D,0,3,width,0,GL_RGB,GL_UNSIGNED_BYTE,image);
  } else {
#endif // !USE_OGLES
    if(repeat) {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    } else {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE);
    }
#ifndef USE_OGLES
    if(doMipmaps) {
  	  gluBuild2DMipmaps(
        GL_TEXTURE_2D,3,width,height,GL_RGB,GL_UNSIGNED_BYTE,image
      );
    } else {
#endif // !USE_OGLES
      glTexImage2D(
        GL_TEXTURE_2D,0,3,width,height,0,GL_RGB,GL_UNSIGNED_BYTE,image
      );
#ifndef USE_OGLES
    }
  }
#endif // !USE_OGLES
}

void GLTexture::destroyObject() {
  glDeleteTextures(1,&textureID);
  delete this;
}

//
// GLAnimatedTexture
//

GLAnimatedTexture::GLAnimatedTexture(
  int imgsCount, DRImage** imgs, float duration, bool repeat, bool doMipmaps
):
  GLTexture((unsigned int)imgsCount), loopDuration(duration),
  textureIDs(new unsigned int[imgsCount]), animated(true)
{
  glGenTextures(imgsCount,textureIDs);
  for(int ct = 0; ct < imgsCount; ct++) {
    glBindTexture(GL_TEXTURE_2D,textureIDs[ct]);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    if(repeat) {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    } else {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE);
    }
    if(imgs[ct]->isGrayScale()) imgs[ct]->convertGray2RGBA();
#ifndef USE_OGLES
    if(doMipmaps) {
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameteri(
        GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST
      );
      gluBuild2DMipmaps(
        GL_TEXTURE_2D,imgs[ct]->getHasAlpha()?GL_RGBA8:GL_RGB8,
        imgs[ct]->getWidth(),imgs[ct]->getHeight(),
        imgs[ct]->getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,
        imgs[ct]->getBuffer()
      );
    } else {
#endif // !USE_OGLES
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
      glTexImage2D(
        GL_TEXTURE_2D,0,imgs[ct]->getHasAlpha()?4:3,
        imgs[ct]->getWidth(),imgs[ct]->getHeight(),0,
        imgs[ct]->getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,
        imgs[ct]->getBuffer()
      );
#ifndef USE_OGLES
    }
#endif // !USE_OGLES
  }
}

GLAnimatedTexture::GLAnimatedTexture(int imgsCount, float duration):
  GLTexture((unsigned int)imgsCount), loopDuration(duration),
  textureIDs(new unsigned int[imgsCount]), animated(true)
{
  glGenTextures(imgsCount,textureIDs);
}

void GLAnimatedTexture::destroyObject() {
  glDeleteTextures(getTexturesCount(),textureIDs);
  delete textureIDs;
  delete this;
}

void GLAnimatedTexture::addTextureToFrame(
  int frame, DRImage& img, bool repeat, bool doMipmaps
) {
  glBindTexture(GL_TEXTURE_2D,textureIDs[frame]);
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  if(repeat) {
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
  } else {
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE);
  }
  if(img.isGrayScale())
    img.convertGray2RGBA();
#ifndef USE_OGLES
  if(doMipmaps) {
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(
      GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST
    );
    gluBuild2DMipmaps(
      GL_TEXTURE_2D,img.getHasAlpha()?GL_RGBA8:GL_RGB8,
      img.getWidth(),img.getHeight(),
      img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,
      img.getBuffer()
    );
  } else {
#endif USE_OGLES
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexImage2D(
      GL_TEXTURE_2D,0,img.getHasAlpha()?4:3,
      img.getWidth(),img.getHeight(),0,
      img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,
      img.getBuffer()
    );
#ifndef USE_OGLES
  }
#endif // !USE_OGLES
}

void GLAnimatedTexture::apply() {
  if(isAnimated()) {
    double integer;
    apply((int)
      (modf(GLWin::getElapsedTime()/loopDuration,&integer)*getTexturesCount())
    );
  } else {
    apply(0);
  }
}

#ifndef USE_OGLES

//
// GLCubeMapTexture
//

GLCubeMapTexture::GLCubeMapTexture(DRImage** imgs, bool doMipmaps):
  GLTexture(0)
{
  textureDim = GL_TEXTURE_CUBE_MAP_ARB;
  glGenTextures(1,&textureID);
  glBindTexture(GL_TEXTURE_CUBE_MAP_ARB,textureID);
  glEnable(GL_TEXTURE_CUBE_MAP_ARB);
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  for(int ct = 0; ct < 6; ct++) {
    glTexParameteri(
      GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE
    );
    glTexParameteri(
      GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE
    );
    if(doMipmaps) {
      glTexParameteri(
        GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MAG_FILTER,GL_LINEAR
      );
      glTexParameteri(
        GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR
      );
      gluBuild2DMipmaps(
        cubeMapDirection[ct],GL_RGB8,
        imgs[ct]->getWidth(),imgs[ct]->getHeight(),
        GL_RGB,GL_UNSIGNED_BYTE,imgs[ct]->getBuffer()
      );
    } else {
      glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
      glTexImage2D(
        cubeMapDirection[ct],0,3,imgs[ct]->getWidth(),imgs[ct]->getHeight(),0,
        GL_RGB,GL_UNSIGNED_BYTE,imgs[ct]->getBuffer()
      );
    }
  }
  glDisable(GL_TEXTURE_CUBE_MAP_ARB);
}

GLCubeMapTexture::GLCubeMapTexture(): GLTexture(0) {
  textureDim = GL_TEXTURE_CUBE_MAP_ARB;
  glGenTextures(1,&textureID);
}

GLuint GLCubeMapTexture::cubeMapDirection[6] = {
  GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB,
  GL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB,
  GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB,
  GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB,
  GL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB,
  GL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB,
};

void GLCubeMapTexture::addTextureToDirection(
  int dir, DRImage& img, bool doMipmaps
) {
  glBindTexture(GL_TEXTURE_CUBE_MAP_ARB,textureID);
  glEnable(GL_TEXTURE_CUBE_MAP_ARB);
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  glTexParameteri(
    GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE
  );
  glTexParameteri(
    GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE
  );
  if(doMipmaps) {
    glTexParameteri(
      GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MAG_FILTER,GL_LINEAR
    );
    glTexParameteri(
      GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR
    );
    gluBuild2DMipmaps(
      cubeMapDirection[dir],GL_RGB8,img.getWidth(),img.getHeight(),
      GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
    );
  } else {
    glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexImage2D(
      cubeMapDirection[dir],0,3,img.getWidth(),img.getHeight(),0,
      GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
    );
  }
  glDisable(GL_TEXTURE_CUBE_MAP_ARB);
}

#endif // !USE_OGLES

#ifdef USE_EMBOSS

//
// GLBumpedTexture
//

GLBumpedTexture::GLBumpedTexture(DRImage& img, bool repeat) {
  int w = img.getWidth();
  int h = img.getHeight();
  glGenTextures(2,textureID);
  glPixelStorei(GL_UNPACK_ALIGNMENT,1);
  if(repeat) {
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
  } else {
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,TEXTURE_CLAMP_MODE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,TEXTURE_CLAMP_MODE);
  }
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexParameteri(
    GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST
  );
  glBindTexture(GL_TEXTURE_2D,textureID[0]);
  if(img.isGrayScale()) img.convertGray2RGBA();
#ifdef USE_OGLES
  glTexImage2D(
    GL_TEXTURE_2D,0,img.getHasAlpha()?4:3,w,h,0,
    img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
  );
#else // !USE_OGLES
  glPixelTransferf(GL_RED_SCALE,0.5f);
  glPixelTransferf(GL_GREEN_SCALE,0.5f);
  glPixelTransferf(GL_BLUE_SCALE,0.5f);
  gluBuild2DMipmaps(
    GL_TEXTURE_2D,img.getHasAlpha()?GL_RGBA8:GL_RGB8,w,h,
    img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
  );
#endif // !USE_OGLES
  glBindTexture(GL_TEXTURE_2D,textureID[1]);
#ifdef USE_OGLES
  glTexImage2D(
    GL_TEXTURE_2D,0,img.getHasAlpha()?4:3,w,h,0,
    img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
  );
#else // !USE_OGLES
  glPixelTransferf(GL_RED_SCALE,-0.5f);
  glPixelTransferf(GL_GREEN_SCALE,-0.5f);
  glPixelTransferf(GL_BLUE_SCALE,-0.5f);
  glPixelTransferf(GL_RED_BIAS,0.5f);
  glPixelTransferf(GL_GREEN_BIAS,0.5f);
  glPixelTransferf(GL_BLUE_BIAS,0.5f);
  gluBuild2DMipmaps(
    GL_TEXTURE_2D,img.getHasAlpha()?GL_RGBA8:GL_RGB8,w,h,
    img.getHasAlpha()?GL_RGBA:GL_RGB,GL_UNSIGNED_BYTE,img.getBuffer()
  );
  glPixelTransferf(GL_RED_SCALE,1);
  glPixelTransferf(GL_GREEN_SCALE,1);
  glPixelTransferf(GL_BLUE_SCALE,1);
  glPixelTransferf(GL_RED_BIAS,0);
  glPixelTransferf(GL_GREEN_BIAS,0);
  glPixelTransferf(GL_BLUE_BIAS,0);
#endif // !USE_OGLES
}

void GLBumpedTexture::destroyObject() {
  glDeleteTextures(2,textureID);
  delete this;
}

#endif // USE_EMBOSS

