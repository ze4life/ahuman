#ifndef GLCONSOLE_H
#define GLCONSOLE_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_CONSOLE

#ifdef USE_LUA
#include "llinterpreter.h"
#endif
#ifdef USE_SMALL
#include "slinterpreter.h"
#endif
#include "datasets.h"
#include "glwin.h"

//
// GlConsole
//
class GLConsole {
public:
  enum {
    CONSOLE_ROWS = 28,
    CONSOLE_COLS = 80,
    HISTORY_LENGTH = 32,
  };
private:
  static GLConsole* console;
  String programDir;
  String workingDir;
  String history[HISTORY_LENGTH];
  int historyCurrent;
  int historyBase;
  bool editMode;
  int editorBase;
  int editorRow;
  int editorCol;
  String editFile;
  String editorStatus;
  DSArray<String> editor;
#ifdef USE_LUA
  LLInterpreter luaInterpreter;
  char* luaInteractiveString;
  bool wasLastCommandLua;
#endif
#ifdef USE_SMALL
  SLInterpreter smallInterpreter;
#endif
  bool suspended;
  char screen[CONSOLE_ROWS][CONSOLE_COLS+1];
  int currentRow;
  int currentCol;
  char prompt;
  GLWin* win;
protected:
  void drawCursor() {
    screen[currentRow][currentCol] = '_';
    screen[currentRow][currentCol+1] = '\0';
  }
  void newLine() {
    screen[currentRow][currentCol] = '\0';
    if(++currentRow >= CONSOLE_ROWS) currentRow = 0;
    currentCol = 0;
  }
public:
  GLConsole();
  static GLConsole& get() {return *console;}
  char* getProgramDir() {return programDir.getText();}
  char* getWorkingDir() {return workingDir.getText();}
#ifdef USE_LUA
  LLInterpreter& getLuaInterpreter() {return luaInterpreter;}
#endif
  void setWin(GLWin* w) {win = w;}
  GLWin* getWin() {return win;}
#ifdef USE_SMALL
  SLInterpreter& getSmallInterpreter() {return smallInterpreter;}
  void continueExecution(float deltaT) {
    if(smallInterpreter.isRunning())
      if(smallInterpreter.execMain(deltaT) != AMX_ERR_SLEEP)
        printPrompt();
  }
  bool isSuspended() {return suspended;}
  void suspend() {
    if(smallInterpreter.isRunning()) {
      suspended = true;
      newLine();
      printPrompt();
    }
  }
  void resume() {
    if(smallInterpreter.isRunning()) {
      suspended = false;
      newLine();
    }
  }
#endif
  int getRows() {return CONSOLE_ROWS;}
  int getCols() {return CONSOLE_COLS;}
  char* getRow(int idx);
  bool isEditMode() {return editMode;}
  int getCursorRow() {return editorRow;}
  int getCursorCol() {return editorCol;}
  int getCursorBase() {return editorBase;}
  void print(char ch, bool typed = false);
  void print(const char* text);
  void println(const char* text) {print(text); print('\n');}
  void setPrompt(char ch) {prompt = ch;}
  void printPrompt()
    {if(currentCol != 0) print('\n'); print(prompt); print(' ');}
  void keyPressed(char ch, bool extended = false, bool altDown = false);
  bool executeCommand(char* commandLine);
};

#endif // USE_CONSOLE
#endif // GLCONSOLE_H
