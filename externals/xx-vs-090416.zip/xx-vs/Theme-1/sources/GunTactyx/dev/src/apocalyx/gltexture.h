#ifndef GLTEXTURE_H
#define GLTEXTURE_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "opengl.h"
#include "dataread.h"
#include "datamanager.h"

class DRImage;

//
// GLTexture
//
class GLTexture: public DMReference {
protected:
  unsigned int textureID;
  unsigned int textureDim;
protected:
  GLTexture(unsigned int id);
  virtual void destroyObject();
public:
  GLTexture(
    DRImage& img, bool repeat = false, bool doMipmaps = true,
    int txtDim = GL_TEXTURE_2D
  );
	GLTexture(
    unsigned char* image, int width, int height, bool repeat = false,
    bool doMipmaps = true
  );
  unsigned int getID() {return textureID;}
  unsigned int getTextureDim() {return textureDim;}
  virtual GLTexture* acquireReference()
    {return dynamic_cast<GLTexture*>(DMReference::acquireReference());}
  virtual void apply() {glBindTexture(textureDim,textureID);}
};

//
// GLAnimatedTexture
//
class GLAnimatedTexture: public GLTexture {
private:
  unsigned int* textureIDs;
  float loopDuration;
  bool animated;
protected:
  virtual void destroyObject();
public:
  GLAnimatedTexture(int imgsCount, float duration);
  GLAnimatedTexture(
    int imgsCount, DRImage** imgs, float duration, bool repeat = false,
    bool doMipmaps = true
  );
  void addTextureToFrame(
    int frame, DRImage& img, bool repeat = false, bool doMipmaps = true
  );
  GLTexture* acquireReference()
    {return dynamic_cast<GLAnimatedTexture*>(DMReference::acquireReference());}
  unsigned int getTexturesCount() {return getID();}
  void setLoopDuration(float ld) {loopDuration = ld;}
  float getLoopDuration() {return loopDuration;}
  bool isAnimated() {return animated;}
  void setAnimated(bool a) {animated = a;}
  void apply(int idx) {glBindTexture(textureDim,textureIDs[idx]);}
  void apply();
};

#ifndef USE_OGLES

//
// GLCubeMapTexture
//
class GLCubeMapTexture: public GLTexture {
protected:
  static GLuint cubeMapDirection[6];
public:
  GLCubeMapTexture();
  GLCubeMapTexture(DRImage** imgs, bool doMipmaps = true);
  void addTextureToDirection(int dir, DRImage& img, bool doMipmaps = true);
  GLCubeMapTexture* acquireReference()
    {return dynamic_cast<GLCubeMapTexture*>(DMReference::acquireReference());}
};

#endif // !USE_OGLES

#ifdef USE_EMBOSS

//
// GLBumpedTexture
//
class GLBumpedTexture: public DMReference {
private:
  unsigned int textureID[2];
protected:
  virtual void destroyObject();
public:
  GLBumpedTexture(DRImage& img, bool repeat = false);
  GLBumpedTexture* acquireReference()
    {return dynamic_cast<GLBumpedTexture*>(DMReference::acquireReference());}
  void applyDirect()
    {glBindTexture(GL_TEXTURE_2D,textureID[0]);}
  void applyInverse()
    {glBindTexture(GL_TEXTURE_2D,textureID[1]);}
};

#endif // USE_EMBOSS

#endif // GLTEXTURE_H
