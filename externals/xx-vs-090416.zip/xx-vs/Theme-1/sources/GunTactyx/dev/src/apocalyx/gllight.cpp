/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gllight.h"
#include "glwin.h"

#include "math3d.inc"

#include <stdlib.h> // for rand()

//
// GLLight
//

GLLight::GLLight(GLTexture* lghTxt, float lghSiz):
  texture(lghTxt->acquireReference()), lightSize(lghSiz), color(1,1,1),
  isDistant(false)
{
  setSpot();
  setAttenuation();
  setMaxRadius(lghSiz);
  setTransparent(true);
}

GLLight::~GLLight() {
  texture->releaseReference();
}

void GLLight::applyPropertiesTo(int index) {
  int light = GL_LIGHT0+index;
  glEnable(light);
  glLightf(light,GL_SPOT_CUTOFF,spot.cutoff);
  glLightf(light,GL_SPOT_EXPONENT,spot.exponent);
  glLightf(light,GL_CONSTANT_ATTENUATION,attenuation.constant);
  glLightf(light,GL_LINEAR_ATTENUATION,attenuation.linear);
  glLightf(light,GL_QUADRATIC_ATTENUATION,attenuation.quadratic);
  GLfloat zero[] = {0,0,0,1};
  glLightfv(light,GL_AMBIENT,zero);
  glLightfv(light,GL_DIFFUSE,color.getFloatArray());
  glLightfv(light,GL_SPECULAR,color.getFloatArray());
  applyPositionTo(index);
}

void GLLight::applyPositionTo(int index) {
  int light = GL_LIGHT0+index;
  if(isDistant) {
    GLfloat dir[] = {direction.getX(),direction.getY(),direction.getZ(),0};
    glLightfv(light,GL_POSITION,dir);
  } else {
    glPushMatrix();
    glMultMatrixf(getTransform());
    GLfloat zero[] = {0,0,0,1};
    glLightfv(light,GL_POSITION,zero);
    if(spot.cutoff != 180) {
      GLfloat direc[] =
        {direction.getX(),direction.getY(),direction.getZ()};
      glLightfv(light,GL_SPOT_DIRECTION,direc);
    }
    glPopMatrix();
  }
}

void GLLight::render(GLCamera& camera) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  float modView[16];
  glGetFloatv(GL_MODELVIEW_MATRIX,modView);
  M3Vector p1(modView[0]*lightSize,modView[4]*lightSize,modView[8]*lightSize);
  M3Vector p2(modView[1]*lightSize,modView[5]*lightSize,modView[9]*lightSize);
#ifdef USE_OGLES
  bool isFog = glIsEnabled(GL_FOG);
#else // !USE_OGLES
  glPushAttrib(GL_FOG_BIT);
#endif // !USE_OGLES
  glDisable(GL_FOG);
  glDepthMask(GL_FALSE);
  glDisable(GL_LIGHTING);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE,GL_ONE);
#ifdef USE_OGLES
  glColor4f(color.getRed(),color.getGreen(),color.getBlue(),color.getAlpha());
#else // !USE_OGLES
  glColor4fv(color.getFloatArray());
#endif // !USE_OGLES
  texture->apply();
  const int VERTEXES_COUNT = 4;
  float arrays[(2+3)*VERTEXES_COUNT] = {
    0,1,-p1.getX()-p2.getX(),-p1.getY()-p2.getY(),-p1.getZ()-p2.getZ(),
    1,1, p1.getX()-p2.getX(), p1.getY()-p2.getY(), p1.getZ()-p2.getZ(),
    0,0,-p1.getX()+p2.getX(),-p1.getY()+p2.getY(),-p1.getZ()+p2.getZ(),
    1,0, p1.getX()+p2.getX(), p1.getY()+p2.getY(), p1.getZ()+p2.getZ(),
  };
#ifdef USE_OGLES
  const int STRIDE = (2+3)*4;
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
#else // !USE_OGLES
  glInterleavedArrays(GL_T2F_V3F,0,arrays);
#endif // !USE_OGLES
  glDrawArrays(GL_TRIANGLE_STRIP,0,VERTEXES_COUNT);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  glEnable(GL_LIGHTING);
#ifdef USE_OGLES
  if(isFog)
    glEnable(GL_FOG);
#else // !USE_OGLES
  glPopAttrib();
#endif // !USE_OGLES
  glPopMatrix();
}

//
// GLFireLight
//

GLFireLight::GLFireLight(GLTexture* lghTxt, float lghSiz):
  GLLight(lghTxt,lghSiz), minIntensity(0,0,0), rangeIntensity(1,1,1),
  lastChange(0)
{}

void GLFireLight::applyPropertiesTo(int index) {
  if(GLWin::getElapsedTime()-lastChange > 0.04f) {
    lastChange = GLWin::getElapsedTime();
    setColor(
      float(rand())/RAND_MAX*rangeIntensity.getRed()+minIntensity.getRed(),
      float(rand())/RAND_MAX*rangeIntensity.getGreen()+minIntensity.getGreen(),
      float(rand())/RAND_MAX*rangeIntensity.getBlue()+minIntensity.getBlue()
    );
  }
  GLLight::applyPropertiesTo(index);
}

//
// GLMoonLight
//

GLMoonLight::GLMoonLight(
  GLTexture* lghTxt, float lghSiz, M3Vector& direc, float cameraDist
):
  GLLight(lghTxt,lghSiz*cameraDist), cameraDistance(cameraDist)
{
  setDirectional(direc.normalize());
}

void GLMoonLight::render(GLCamera& camera) {
  float wrlModView[16];
  glGetFloatv(GL_MODELVIEW_MATRIX,wrlModView);
  glPushMatrix();
  glMultMatrixf(getTransform());
  float modView[16];
  glGetFloatv(GL_MODELVIEW_MATRIX,modView);
  M3Vector p1(modView[0]*lightSize,modView[4]*lightSize,modView[8]*lightSize);
  M3Vector p2(modView[1]*lightSize,modView[5]*lightSize,modView[9]*lightSize);
#ifdef USE_OGLES
  bool isFog = glIsEnabled(GL_FOG);
#else // !USE_OGLES
  glPushAttrib(GL_FOG_BIT);
#endif // !USE_OGLES
  glDisable(GL_FOG);
  glDepthMask(GL_FALSE);
  glDisable(GL_LIGHTING);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE,GL_ONE);
#ifdef USE_OGLES
  glColor4f(color.getRed(),color.getGreen(),color.getBlue(),color.getAlpha());
#else // !USE_OGLES
  glColor4fv(color.getFloatArray());
#endif // !USE_OGLES
  texture->apply();
  const int VERTEXES_COUNT = 4;
  float arrays[(2+3)*VERTEXES_COUNT] = {
    0,1,-p1.getX()-p2.getX(),-p1.getY()-p2.getY(),-p1.getZ()-p2.getZ(),
    1,1, p1.getX()-p2.getX(), p1.getY()-p2.getY(), p1.getZ()-p2.getZ(),
    0,0,-p1.getX()+p2.getX(),-p1.getY()+p2.getY(),-p1.getZ()+p2.getZ(),
    1,0, p1.getX()+p2.getX(), p1.getY()+p2.getY(), p1.getZ()+p2.getZ(),
  };
#ifdef USE_OGLES
  const int STRIDE = (2+3)*4;
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnableClientState(GL_VERTEX_ARRAY);
  glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
  glVertexPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
#else // !USE_OGLES
  glInterleavedArrays(GL_T2F_V3F,0,arrays);
#endif // !USE_OGLES
  glDrawArrays(GL_TRIANGLE_STRIP,0,VERTEXES_COUNT);
  glDepthMask(GL_TRUE);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisable(GL_BLEND);
  glEnable(GL_LIGHTING);
#ifdef USE_OGLES
  if(isFog)
    glEnable(GL_FOG);
#else // !USE_OGLES
  glPopAttrib();
#endif // !USE_OGLES
  glPopMatrix();
}

//
// GLSunLight
//

GLSunLight::GLSunLight(
  GLTexture* lghTxt, float lghSiz, M3Vector& direc, GLTexture* flareTxt,
  int flrCount, float flareSz, float cameraDist, bool checkOcclusion
):
  GLMoonLight(lghTxt,lghSiz,direc,cameraDist), flaresCount(flrCount),
  flaresSize(flareSz*cameraDist), flares(NULL), lensFlareShown(true),
  flaresTexture(flareTxt? flareTxt->acquireReference(): NULL),
  checkDepth(checkOcclusion), wasOccluded(true)
{
  setMaxRadius(0);
  if(cache == NULL)
    cache = new DMCache();
  cache->acquireReference();
  if(flaresCount > 0) {
    flares = new GLFlare[flaresCount];
    for(int ct = 0; ct < flaresCount; ct++) {
      flares[ct].position = (ct+ct+2)/(float)(flaresCount);
      if(ct%2)
        flares[ct].size =
          0.5f*(flaresCount-ct)/(float)(flaresCount)+(float(rand())/RAND_MAX/2);
      else
        flares[ct].size = 0.5f*ct/(float)(flaresCount)+(float(rand())/RAND_MAX);
      flares[ct].color.set(
        1-(float(rand())/RAND_MAX/2),
        1-(float(rand())/RAND_MAX/2),
        1-(float(rand())/RAND_MAX/2)
      );
    }
  }
}

DMCache* GLSunLight::cache = NULL;

GLSunLight::~GLSunLight() {
  if(cache && cache->releaseReference())
    cache = NULL;
  if(flaresTexture) flaresTexture->releaseReference();
}

void GLSunLight::checkOcclusion(GLCamera& camera) {
  if(lensFlareShown && flaresCount > 0) {
#ifndef USE_OGLES
    if(checkDepth) {
      double* modelMatrix = camera.getModelMatrix();
      double* projectionMatrix = camera.getProjectionMatrix();
      GLint viewport[4];
      glGetIntegerv(GL_VIEWPORT,viewport);
      GLdouble winX, winY, winZ;
      if(
        gluProject(
          getPosition().getX(),getPosition().getY(),getPosition().getZ(),
          modelMatrix,projectionMatrix,viewport,
          &winX,&winY,&winZ
        ) == GL_TRUE
      ) {
        float depthValue;
        glReadPixels(
          (int)winX,(int)winY,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&depthValue
        );
        wasOccluded = (depthValue != 1.0f);
      }
    } else
#endif // !USE_OGLES
      wasOccluded = false;
  } else
    wasOccluded = true;
}

void GLSunLight::render(GLCamera& camera) {
  if(!wasOccluded)
  	GLMoonLight::render(camera);
}

void GLSunLight::renderLensFlare(GLCamera& camera) {
  if(!wasOccluded) {
    glPushMatrix();
    glMultMatrixf(getTransform());
    float modView[16];
    glGetFloatv(GL_MODELVIEW_MATRIX,modView);
    glPopMatrix();
    M3Vector p1(modView[0]*lightSize,modView[4]*lightSize,modView[8]*lightSize);
    M3Vector p2(modView[1]*lightSize,modView[5]*lightSize,modView[9]*lightSize);
    glPushMatrix();
    glTranslatef(
      camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
    );
#ifdef USE_OGLES
    bool isFog = glIsEnabled(GL_FOG);
#else // !USE_OGLES
    glPushAttrib(GL_FOG_BIT);
#endif // !USE_OGLES
    glDisable(GL_FOG);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE,GL_ONE);
    glDisable(GL_DEPTH_TEST);
    M3Vector lightDir(getDirection());
    M3Vector flareDir(
      camera.getViewDirectionX(),
      camera.getViewDirectionY(),
      camera.getViewDirectionZ()
    );
    float lightDotFlare = lightDir.dot(flareDir);
    float luminosity = 0.333f*lightDotFlare;
    flareDir.scale(getCameraDistance());
    lightDir.scale(getCameraDistance()/lightDotFlare);
    flareDir.subtract(lightDir);
    flaresTexture->apply();
#ifdef USE_OGLES
    const int VERTEXES_COUNT = 4;
    float* arrays = getArrays((2+3+3)*VERTEXES_COUNT);
    const int STRIDE = (2+3+3)*4;
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
    glColorPointer(3,GL_FLOAT,STRIDE,arrays+2*4);
    glVertexPointer(3,GL_FLOAT,STRIDE,arrays+(2+3)*4);
    for(int ct = 0; ct < flaresCount; ct++) {
      float* arrayPointer = arrays-1;
      float offU, offV;
      switch(ct%4) {
        default:
        case 0: offU = offV = 0; break;
        case 1: offU = 0.5f; offV = 0; break;
        case 2: offU = 0; offV = 0.5f; break;
        case 3: offU = offV = 0.5f; break;
      };
      float red = flares[ct].color.getRed()*luminosity*color.getRed();
      float green = flares[ct].color.getGreen()*luminosity*color.getGreen();
      float blue = flares[ct].color.getBlue()*luminosity*color.getBlue();
      float flareSizes = flares[ct].size*flaresSize;
      p1 = M3Vector(
        modView[0]*flareSizes,modView[4]*flareSizes,modView[8]*flareSizes
      );
      p2 = M3Vector(
        modView[1]*flareSizes,modView[5]*flareSizes,modView[9]*flareSizes
      );
      M3Vector flarePos(flareDir);
      flarePos.scale(flares[ct].position).add(lightDir);
      *(++arrayPointer) = offU;
      *(++arrayPointer) = offV+0.5f;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()-p1.getX()-p2.getX();
      *(++arrayPointer) = flarePos.getY()-p1.getY()-p2.getY();
      *(++arrayPointer) = flarePos.getZ()-p1.getZ()-p2.getZ();
      *(++arrayPointer) = offU+0.5f;
      *(++arrayPointer) = offV+0.5f;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()+p1.getX()-p2.getX();
      *(++arrayPointer) = flarePos.getY()+p1.getY()-p2.getY();
      *(++arrayPointer) = flarePos.getZ()+p1.getZ()-p2.getZ();
      *(++arrayPointer) = offU;
      *(++arrayPointer) = offV;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()-p1.getX()+p2.getX();
      *(++arrayPointer) = flarePos.getY()-p1.getY()+p2.getY();
      *(++arrayPointer) = flarePos.getZ()-p1.getZ()+p2.getZ();
      *(++arrayPointer) = offU+0.5f;
      *(++arrayPointer) = offV;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()+p1.getX()+p2.getX();
      *(++arrayPointer) = flarePos.getY()+p1.getY()+p2.getY();
      *(++arrayPointer) = flarePos.getZ()+p1.getZ()+p2.getZ();
      glDrawArrays(GL_TRIANGLE_STRIP,0,VERTEXES_COUNT);
    }
#else // !USE_OGLES
    const int VERTEXES_COUNT = 4*flaresCount;
    float* arrays = getArrays((2+3+3)*VERTEXES_COUNT);
    float* arrayPointer = arrays-1;
    for(int ct = 0; ct < flaresCount; ct++) {
      float offU, offV;
      switch(ct%4) {
        default:
        case 0: offU = offV = 0; break;
        case 1: offU = 0.5f; offV = 0; break;
        case 2: offU = 0; offV = 0.5f; break;
        case 3: offU = offV = 0.5f; break;
      };
      float red = flares[ct].color.getRed()*luminosity*color.getRed();
      float green = flares[ct].color.getGreen()*luminosity*color.getGreen();
      float blue = flares[ct].color.getBlue()*luminosity*color.getBlue();
      float flareSizes = flares[ct].size*flaresSize;
      p1 = M3Vector(
        modView[0]*flareSizes,modView[4]*flareSizes,modView[8]*flareSizes
      );
      p2 = M3Vector(
        modView[1]*flareSizes,modView[5]*flareSizes,modView[9]*flareSizes
      );
      M3Vector flarePos(flareDir);
      flarePos.scale(flares[ct].position).add(lightDir);
      *(++arrayPointer) = offU;
      *(++arrayPointer) = offV+0.5f;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()-p1.getX()-p2.getX();
      *(++arrayPointer) = flarePos.getY()-p1.getY()-p2.getY();
      *(++arrayPointer) = flarePos.getZ()-p1.getZ()-p2.getZ();
      *(++arrayPointer) = offU+0.5f;
      *(++arrayPointer) = offV+0.5f;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()+p1.getX()-p2.getX();
      *(++arrayPointer) = flarePos.getY()+p1.getY()-p2.getY();
      *(++arrayPointer) = flarePos.getZ()+p1.getZ()-p2.getZ();
      *(++arrayPointer) = offU+0.5f;
      *(++arrayPointer) = offV;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()+p1.getX()+p2.getX();
      *(++arrayPointer) = flarePos.getY()+p1.getY()+p2.getY();
      *(++arrayPointer) = flarePos.getZ()+p1.getZ()+p2.getZ();
      *(++arrayPointer) = offU;
      *(++arrayPointer) = offV;
      *(++arrayPointer) = red;
      *(++arrayPointer) = green;
      *(++arrayPointer) = blue;
      *(++arrayPointer) = flarePos.getX()-p1.getX()+p2.getX();
      *(++arrayPointer) = flarePos.getY()-p1.getY()+p2.getY();
      *(++arrayPointer) = flarePos.getZ()-p1.getZ()+p2.getZ();
    }
    glInterleavedArrays(GL_T2F_C3F_V3F,0,arrays);
    glDrawArrays(GL_QUADS,0,VERTEXES_COUNT);
#endif // !USE_OGLES
    glEnable(GL_DEPTH_TEST);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);
#ifdef USE_OGLES
    if(isFog)
      glEnable(GL_FOG);
#else // !USE_OGLES
    glPopAttrib();
#endif // !USE_OGLES
    glPopMatrix();
  }
}

