/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "guntactyx.h"

#include "gtsim.h"
#include "gtengine.h"
#include "gtoverlay.h"

#include "apocalyx/glapp.h"
#include "apocalyx/glmodel.h"
#include "apocalyx/glteams.h"
#include "apocalyx/glbsp.h"
#include "apocalyx/fmsound.h"
#include "apocalyx/strings.h"

#include "apocalyx/math3d.inc"
#include "apocalyx/datasets.inc"

#include "small/amx.h"

#include <stdlib.h> // for random()
#include <dir.h> // for chdir()

//
// Game
//

#define GT_VERSION "GUN-TACTYX 1.1.5"

#define MIN_MULTIPLIER (1.0f/16)
#define MAX_MULTIPLIER 64

#define INTRO_STRINGS_COUNT 5
#define GOAL_STRINGS_COUNT 3
#define PLAY_STRINGS_COUNT 3

enum OptioTexts {
  TXT_SCRIPT = 0, TXT_PACKAGE, TXT_LEVEL, TXT_TEAMS,
  TXT_TEAM_A, TXT_TEAM_B, TXT_TEAM_C, TXT_TEAM_D,
  TXT_MATES, TXT_GOAL, TXT_PLAY, TXT_TIMEOUT, TXT_MINHZ, TXT_FX,
  TXT_SOUND, TXT_MUSIC, TXT_EXIT, TXT_QUIT, OPTIO_STRINGS_COUNT
};
enum FightTexts {
  TXT_NAME_A = 0, TXT_NAME_B, TXT_NAME_C, TXT_NAME_D,
  TXT_TIME, TXT_MULT, TXT_RATIO,
  TXT_MATES_A, TXT_MATES_B, TXT_MATES_C, TXT_MATES_D,
  TXT_KILLS_A, TXT_KILLS_B, TXT_KILLS_C, TXT_KILLS_D,
  TXT_HEALTH_A, TXT_HEALTH_B, TXT_HEALTH_C, TXT_HEALTH_D,
  TXT_ENERGY_A, TXT_ENERGY_B, TXT_ENERGY_C, TXT_ENERGY_D,
  TXT_SHOTS_A, TXT_SHOTS_B, TXT_SHOTS_C, TXT_SHOTS_D,
};
enum FinalTexts {
  TXT_WINNER_NAME = 0, TXT_WINNER_GOAL,
};

class Game: public GLApp {
public:
  enum {INTRO_SCENE = 0, FIGHT_SCENE, RESULTS_SCENE, SCENES_COUNT};
  static int currentScene;
  //
  enum {MODE_3D = 0, MODE_2D, MODE_CONT, MODE_DEMO, MODE_INTERACTIVE};
  static int mode;
  static unsigned int randomSeed;
  static unsigned int selectedSeed;
  //
  static bool isSoundEnabled;
  static bool isMusicEnabled;
  static bool areEffectsEnabled;
  static FMMusic *soundTrack;
  //
  static FM3DSample *shotSample;
  static FM3DSample *boomSample;
  static FM3DSample *deathSample;
  //
  static GLBsp* bsp;
  //
  static bool followTarget;
  static GLModel* target;
  static GLModel* weapon;
  static GLModel* medikit;
  static GLModel* food;
  static GLModel* armor;
  static GLModel* bullets;
  static GLModel* grenades;
  static GLModel* sign;
  static GLBot* warrior;
  static M3Reference warriorBaseTransform;
  static GLMaterial* redLoMaterial;
  static GLMaterial* redHiMaterial;
  static GLMaterial* blueLoMaterial;
  static GLMaterial* blueHiMaterial;
  static GLMaterial* magentaLoMaterial;
  static GLMaterial* magentaHiMaterial;
  static GLTexture* boomTexture;
  static GLTexture* shadowTexture;
  static GLModel* flash;
  //
  static GTOverlayArenaData* dataOverlay;
  static GTOverlayArenaMap* mapOverlay;
  static GLOverlayTexts* introTexts;
  static GLOverlayTexts* crediTexts;
  static GLOverlayTexts* optioTexts;
  static GLOverlayTexts* fightTexts;
  static GLOverlayTexts* finalTexts;
  static char* introString[INTRO_STRINGS_COUNT];
  static char* goalString[GOAL_STRINGS_COUNT];
  static char* playString[PLAY_STRINGS_COUNT];
  //
  static GLOverlaySprite* logoSprite;
  //
  static GTEngineScript interpreter;
  static int ENGINE_SCRIPT_INITIALIZE;
  static int ENGINE_SCRIPT_FINALIZE;
  static int ENGINE_SCRIPT_KEYDOWN;
  static int ENGINE_SCRIPT_UPDATE;
  static int ENGINE_SCRIPT_STEP;
  //
  static String ngnScriptName;
  static String packageName;
  static int levelIndex;
  static int goalIndex;
  static int playIndex;
  static int teamsCount;
  static int matesCount;
  static int matchDuration;
  static int minFrameRate;
  //
  static float timeMultiplier;
  static float tempMultiplier;
  //
  static DSArray<String> ngnScriptNames;
  static DSArray<String> botScriptNames;
  static DSArray<String> packageNames;
  static DSArray<String> levelNames;
  static int corners[4];
private:
  static FILE* playlistFile;
  static char* playlistFileName;
  static char* optionsFileName;
  static char* statsFileName;
public:
  static FILE* getPlaylistFile() {return playlistFile;}
  static char* getPlaylistFileName() {return playlistFileName;}
  static char* getOptionsFileName()
    {return optionsFileName? optionsFileName: "options.ini";}
  static char* getStatsFileName()
    {return statsFileName? statsFileName: "GUN-TACTYX-results.txt";}
  static void setPlaylistFile(FILE* f)
    {if(playlistFile) fclose(playlistFile); playlistFile =f;}
  static void setPlaylistFileName(char* pfn) {
    if(playlistFileName) delete playlistFileName;
    playlistFileName = pfn;
  }
  static void setOptionsFileName(char* ofn) {
    if(optionsFileName) delete optionsFileName;
    optionsFileName = ofn;
  }
  static void setStatsFileName(char* sfn) {
    if(statsFileName) delete statsFileName;
    statsFileName = sfn;
  }
  static bool suddenStart;
  static int matchesCount;
  static int maxMatches;
protected:
  char* getTitle() {return GT_VERSION;}
  const char* getHelpLine(int line);
  bool initializeScene();
  void finalizeScene();
public:
  Game(char* initStr);
  static void loadLevels();
  static bool setupTeams();
  static void setupDefaultTeams();
  static void getOptioString(char* buf, char* cmp, char* res);
  static bool scriptExists(char* name);
  static bool keyDownEventSound(GLWin& glWin, int key);
  void setupWorld(
    bool newPackage = true, bool newLevel = true, bool newScript = true
  );
};

//
// Scene
//
class Scene: public GLScene {
public:
  virtual const char* getHelpLine(int line) = 0;
};

//
// IntroScene
//
class IntroScene: public Scene {
public:
  enum Mode {INTRO_MODE = 0, OPTIO_MODE} mode;
  static enum CreditPhase {INIT,FADE_IN,WAIT,FADE_OUT} creditPhase;
  static enum CreditPage {
    START,DEVEL,DEMO,MATTEO,SOFT,LIB,TUT_SITES,GP_SITES,NEWSG,END
  } creditPage;
  static int corner;
public:
  IntroScene();
  bool initialize(GLWin& glWin);
  void finalize(GLWin& glWin);
  int update(GLWin& glWin);
  void keyDownEvent(GLWin& glWin, int key);
  const char* getHelpLine(int line);
};

IntroScene::CreditPhase IntroScene::creditPhase = IntroScene::INIT;
IntroScene::CreditPage IntroScene::creditPage = IntroScene::END;
int IntroScene::corner = 2;

IntroScene::IntroScene(): mode(INTRO_MODE) {
}

bool IntroScene::initialize(GLWin& glWin) {
  glWin.getOverlay().showPointer();
  if(creditPage == DEVEL)
    creditPage = DEMO;
  mode = INTRO_MODE;
  Game::logoSprite->setVisible(true);
  Game::logoSprite->setLocation(glWin.getWidth()>>1,glWin.getHeight());
  for(int ct = Game::teamsCount; ct < 4; ct++) {
    Game::introTexts->getElement(ct  )->setVisible(false);
    Game::introTexts->getElement(ct+6)->setVisible(false);
    Game::fightTexts->getElement(TXT_NAME_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_MATES_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_KILLS_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_HEALTH_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_ENERGY_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_SHOTS_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_MATES_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_KILLS_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_HEALTH_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_ENERGY_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_SHOTS_A+22+ct)->setVisible(false);
  }
  Game::introTexts->setVisible(true);
  Game::introTexts->setLocation(0,glWin.getHeight());
  GLCamera& camera = glWin.getCamera();
  BSPVector& start = Game::bsp->getStartingPosition(IntroScene::corner);
  if((--IntroScene::corner) < 0)
    IntroScene::corner = 3;
  const float HEIGHT = 5;
  camera.setPosition(start.x,start.y+HEIGHT*BSP_SCENE_SCALE,start.z);
  camera.pointTo(0,0,0);
  return true;
}

void IntroScene::finalize(GLWin& glWin) {
  glWin.getOverlay().hidePointer();
  Game::logoSprite->setVisible(false);
  Game::introTexts->setVisible(false);
  Game::crediTexts->setVisible(false);
  Game::optioTexts->setVisible(false);
}

int IntroScene::update(GLWin& glWin) {
  GLCamera& camera = glWin.getCamera();
  float timeStep = GLWin::getTimeStep();
  if(mode == INTRO_MODE) {
  const int LOGO_SPEED_X = 200;
  const int LOGO_SPEED_Y = 400;
  const float VIEW_MARK_X =
    (glWin.getWidth()-320)>>1;
  const float VIEW_MARK_Y =
    float((glWin.getHeight()+int(Game::logoSprite->getWidth())-480)>>1);
  if(timeStep > 0.1f)
    timeStep = 0.1f;
  if(Game::logoSprite->getY() > VIEW_MARK_Y) {
    float y = Game::logoSprite->getY()-timeStep*LOGO_SPEED_Y;
    Game::logoSprite->setY(y < VIEW_MARK_Y? VIEW_MARK_Y: y);
    Game::introTexts->setY(
      (y < VIEW_MARK_Y? VIEW_MARK_Y: y)-Game::logoSprite->getWidth()/2
    );
  } else if(Game::logoSprite->getY() == VIEW_MARK_Y) {
    Game::logoSprite->setY(VIEW_MARK_Y-1);
    Game::introTexts->setY(VIEW_MARK_Y-1-Game::logoSprite->getWidth()/2);
  } else {
    if(Game::logoSprite->getX() > VIEW_MARK_X) {
      float x = Game::logoSprite->getX()-timeStep*LOGO_SPEED_X;
      Game::logoSprite->setX(x < VIEW_MARK_X? VIEW_MARK_X: x);
    } else if(Game::logoSprite->getX() == VIEW_MARK_X) {
      glWin.setHelpMode(GLWin::HIDDEN_HELP);
      Game::logoSprite->setX(VIEW_MARK_X-1);
      Game::crediTexts->setVisible(true);
      Game::crediTexts->setLocation(0,-glWin.getHeight()/2);
      creditPhase = INIT;
    } else {
      static float startTime = glWin.getElapsedTime();
      switch(creditPhase) {
        case INIT: {
          Game::crediTexts->deleteElements();
          const float theColor[3][3] = {{1,1,0},{.75f,1,1},{1,1,1}};
          const float FONT_H = Game::crediTexts->getFont()->getHeight();
          const float X = glWin.getWidth()/2+160;
          char** theStrings;
          short* theColors;
          float y;
          if((++creditPage) >= END) creditPage = START;
          switch(creditPage) {
            case START: {
              const int STRINGS_COUNT = 7;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "G U N - T A C T Y X","copyright \xB8 2003-2006",
                "Leonardo Boselli","",
                "A Programming Game based","on the concept of 1985",
                "Tom Poindexter's CROBOTS",NULL
              };
              short colors[STRINGS_COUNT] = {0,2,1,0,2,2,2};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case DEVEL: {
              const int STRINGS_COUNT = 15;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "- Programming & Design -","Leonardo \"leo\" Boselli",
                "tetractys@users.sf.net",
                "- Warrior Model -","Grant Struthers",
                "TheGragster@yahoo.com",
                "- Gun Model -","Janus & Chemical Burn",
                "janus@planetquake.com",
                "- Scenery -","Leonardo Boselli",
                "- Textures -","Remedy Entertainment Ltd.",
                "from MAX PAYNE's official",
                "textures pack (non-comm.)",
                NULL
              };
              short colors[STRINGS_COUNT] = {0,1,2,0,1,2,0,1,2,0,1,0,1,2,2};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case MATTEO: {
              const int STRINGS_COUNT = 11;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "Thanks to","","Matteo \"Fuzz\" Perenzoni","",
                "for fruitful discussions on",
                "OpenGL and 3D programming.","",
                "The sources of his demo for",
                "the NeHe's Apocalypse Contest",
                "were the base building blocks",
                "of the APOCALYX 3D Engine.",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,1,2,2,2,2,2,2,2,2};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case SOFT: {
              const int STRINGS_COUNT = 15;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "Thanks to","","ITB Compuphase",
                "for the SMALL script language",
                "www.compuphase.com","","Borland",
                "for their free C++ compiler",
                "www.borland.com","","ID Software",
                "for developing great FPS",
                "whose file formats were",
                "fundamental for this game",
                "www.idsoftware.com",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,0,2,1,2,0,2,1,2,0,2,2,2,1};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case LIB: {
              const int STRINGS_COUNT = 14;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "Thanks to","","FireLight Multimedia",
                "for the FMOD Sound System",
                "www.fmod.com","","Thomas G. Lane",
                "for the JPEG format library","",
                "Glenn Randers-Pehrson",
                "for the PNG format library","",
                "Jean-loup Gailly & Mark Adler",
                "for the Zlib compression",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,0,2,1,2,0,2,2,0,2,2,0,2};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case TUT_SITES: {
              const int STRINGS_COUNT = 15;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "Thanks to the following sites",
                "for the useful tutorials about",
                "game programming they provide","",
                "NeHe Productions","nehe.gamedev.net",
                "Game Tutorials","www.gametutorials.com",
                "SULACO","www.sulaco.co.za","","and","",
                "Game Programming Italia","www.gameprog.it",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,2,2,0,1,0,1,0,1,2,2,2,0,1};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case GP_SITES: {
              const int STRINGS_COUNT = 12;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "Thanks to these web sites",
                "for publishing news about game",
                "development and related stuff","",
                "GameDev","www.gamedev.net",
                "FlipCode","www.flipcode.net",
                "CFXweb","www.cfxweb.net",
                "OpenGL.org","www.opengl.org",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,2,2,0,1,0,1,0,1,0,1};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case NEWSG: {
              const int STRINGS_COUNT = 7;
              y = (glWin.getHeight()-240+FONT_H*(STRINGS_COUNT-1))/2;
              char* strings[STRINGS_COUNT+1] = {
                "","And, finally, thanks to",
                "all the people of the",
                "italian newsgroup","",
                "it.comp.giochi.sviluppo","",
                NULL
              };
              short colors[STRINGS_COUNT] = {2,2,2,2,0};
              theStrings = strings;
              theColors = colors;
              break;
            }
            case DEMO: {
              for(int ct = 0; ct < Game::teamsCount; ct++) {
                Game::fightTexts->getElement(ct)->setText(
                  Game::introTexts->getElement(ct)->getText()
                );
              }
              Game::mode = Game::MODE_DEMO;
              return Game::currentScene = Game::FIGHT_SCENE;
            }
          }
          for(int ct = 0; theStrings[ct]; ct++) {
            int clr = theColors[ct];
            GLOverlayText* txt = new GLOverlayText(
              theStrings[ct],theColor[clr][0],theColor[clr][1],theColor[clr][2],
              X,y
            );
            y -= FONT_H;
            txt->setVisible(true);
            Game::crediTexts->addElement(txt);
          }
          Game::crediTexts->setLocation(0,-glWin.getHeight()/2);
          creditPhase = FADE_IN;
          break;
        }
        case FADE_IN: {
          float y = Game::crediTexts->getY()+timeStep*LOGO_SPEED_X;
          if(y >= 0) {
            Game::crediTexts->setY(0);
            startTime = glWin.getElapsedTime();
            creditPhase = WAIT;
          } else {
            Game::crediTexts->setY(y);
          }
          break;
        }
        case WAIT: {
          float diff = glWin.getElapsedTime()-startTime;
          if(diff > Game::crediTexts->getSize()*.75f)
            creditPhase = FADE_OUT;
          break;
        }
        case FADE_OUT: {
          float y = Game::crediTexts->getY()-timeStep*LOGO_SPEED_Y;
          if(y <= -glWin.getHeight()/2) {
            Game::crediTexts->setY(-glWin.getHeight()/2);
            creditPhase = INIT;
          } else {
            Game::crediTexts->setY(y);
          }
          break;
        }
      }
    }
  }
  }
  BSPVector& nextPos = Game::bsp->getStartingPosition(corner);
  float diffX = nextPos.x-camera.getPositionX();
  float diffZ = nextPos.z-camera.getPositionZ();
  const float CAMERA_SPEED = 7.5f*BSP_SCENE_SCALE;
  float cameraStep = timeStep*CAMERA_SPEED;
  if(diffX == 0) {
    if(cameraStep > fabs(diffZ)) {
      cameraStep = fabs(diffZ);
      if((--corner) < 0)
        corner = 3;
    }
    camera.move(0,0,diffZ > 0? cameraStep: -cameraStep);
  } else {
    if(cameraStep > fabs(diffX)) {
      cameraStep = fabs(diffX);
      if((--corner) < 0)
        corner = 3;
    }
    camera.move(diffX > 0? cameraStep: -cameraStep,0,0);
  }
  camera.pointTo(0,0,0);
  const int dx = glWin.getMouseDX();
  const int dy = glWin.getMouseDY();
  GLOverlay& overlay = glWin.getOverlay();
  overlay.movePointer(dx,dy,glWin.getWidth(),glWin.getHeight());
  GLOverlayTexts* texts =
    mode == INTRO_MODE? Game::introTexts: Game::optioTexts;
  GLOverlayText* text =
    texts->getText(overlay.getPointerX(),overlay.getPointerY());
  static GLOverlayText* oldText = NULL;
  if(text) {
    bool isActive = (text->getText()[0] == '[');
    if(text != oldText) {
      if(oldText) oldText->setColor(1,1,0);
      if(isActive) {
        text->setColor(1,0.25f,0.25f);
        oldText = text;
      }
    }
    static bool selected = false;
    if(glWin.isLeftButtonPressed()) {
      if(isActive && !selected) {
        keyDownEvent(glWin,int(text->getText()[2]));
        selected = true;
      }
    } else {
      selected = false;
    }
  } else if(oldText) {
    oldText->setColor(1,1,0);
    oldText = NULL;
  }
  return Game::currentScene;
}

static void setTeamsVisibility() {
  int ct;
  for(ct = 2; ct < Game::teamsCount; ct++) {
    Game::introTexts->getElement(ct  )->setVisible(true);
    Game::introTexts->getElement(ct+6)->setVisible(true);
    Game::fightTexts->getElement(TXT_NAME_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_MATES_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_KILLS_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_HEALTH_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_ENERGY_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_SHOTS_A+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_MATES_A+22+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_KILLS_A+22+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_HEALTH_A+22+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_ENERGY_A+22+ct)->setVisible(true);
    Game::fightTexts->getElement(TXT_SHOTS_A+22+ct)->setVisible(true);
  }
  for(; ct < 4; ct++) {
    Game::introTexts->getElement(ct  )->setVisible(false);
    Game::introTexts->getElement(ct+6)->setVisible(false);
    Game::fightTexts->getElement(TXT_NAME_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_MATES_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_KILLS_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_HEALTH_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_ENERGY_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_SHOTS_A+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_MATES_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_KILLS_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_HEALTH_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_ENERGY_A+22+ct)->setVisible(false);
    Game::fightTexts->getElement(TXT_SHOTS_A+22+ct)->setVisible(false);
  }
}

void IntroScene::keyDownEvent(GLWin& glWin, int key) {
  if(mode == INTRO_MODE) {
  switch(key) {
    case 0: {
      break;
    }
    case 'T': {
      glWin.keyUp('T');
      if(Game::teamsCount == 4)
        Game::teamsCount = 2;
      else
        Game::teamsCount++;
      setTeamsVisibility();
      break;
    }
    case 'N': {
      glWin.keyUp('N');
      if(Game::matesCount == 1)
        Game::matesCount = 64;
      else
        Game::matesCount /= 2;
      String string(Game::matesCount);
      Game::introTexts->getElement(4)->setText(string.getText());
      break;
    }
    case '0': {
      glWin.keyUp('0');
      mode = OPTIO_MODE;
      Game::introTexts->setVisible(false);
      Game::crediTexts->setVisible(false);
      Game::logoSprite->setVisible(false);
      Game::optioTexts->setVisible(true);
      break;
    }
    case '1': {
      glWin.keyUp('1');
      for(int ct = 0; ct < Game::teamsCount; ct++) {
        Game::fightTexts->getElement(ct)->setText(
          Game::introTexts->getElement(ct)->getText()
        );
      }
      Game::mode = Game::MODE_3D;
      Game::currentScene = Game::FIGHT_SCENE;
      Game::selectedSeed = 0;
      break;
    }
    case '2': {
      glWin.keyUp('2');
      for(int ct = 0; ct < Game::teamsCount; ct++) {
        Game::fightTexts->getElement(ct)->setText(
          Game::introTexts->getElement(ct)->getText()
        );
      }
      glWin.getWorld().getBackground()->setVisible(false);
      glWin.getWorld().getSun()->setVisible(false);
      glWin.getWorld().getScenery()->setVisible(false);
      Game::mode = Game::MODE_2D;
      Game::currentScene = Game::FIGHT_SCENE;
      Game::selectedSeed = 0;
      break;
    }
    case '3': {
      glWin.keyUp('3');
      for(int ct = 0; ct < Game::teamsCount; ct++) {
        Game::fightTexts->getElement(ct)->setText(
          Game::introTexts->getElement(ct)->getText()
        );
      }
      glWin.getWorld().getBackground()->setVisible(false);
      glWin.getWorld().getSun()->setVisible(false);
      glWin.getWorld().getScenery()->setVisible(false);
      Game::mode = Game::MODE_CONT;
      Game::currentScene = Game::FIGHT_SCENE;
      Game::selectedSeed = 0;
      break;
    }
    case '4': {
      glWin.keyUp('4');
      Game::currentScene = Game::RESULTS_SCENE;
      break;
    }
    case 'D':
    case 'C':
    case 'B':
    case 'A': {
      int tid = key-'A';
      int ct;
      for(ct = 0; ct < Game::botScriptNames.getSize(); ct++) {
        if(
          Game::introTexts->getElement(tid)->equals(
            Game::botScriptNames.getElement(ct)
          )
        )
          break;
      }
      if((++ct) == Game::botScriptNames.getSize())
        ct = 0;
      Game::introTexts->getElement(tid)->setText(
        Game::botScriptNames.getElement(ct)->getText()
      );
      break;
    }
    default: {
      Game::keyDownEventSound(glWin,key);
      break;
    }
  }
  } else { // OPTIO_MODE
  switch(key) {
    case 0: {
      break;
    }
    case 'F': { // Effects
      glWin.keyUp('F');
      bool isOn = Game::optioTexts->getElement(TXT_FX)->equals("on");
      Game::optioTexts->getElement(TXT_FX)->setText(isOn? "off": "on");
      break;
    }
    case 'E': { // Script
      glWin.keyUp('E');
      int ct;
      for(ct = 0; ct < Game::ngnScriptNames.getSize(); ct++) {
        if(
          Game::optioTexts->getElement(TXT_SCRIPT)->equals(
            Game::ngnScriptNames.getElement(ct)
          )
        )
          break;
      }
      if((++ct) == Game::ngnScriptNames.getSize())
        ct = 0;
      Game::optioTexts->getElement(TXT_SCRIPT)->setText(
        Game::ngnScriptNames.getElement(ct)->getText()
      );
      Game::loadLevels();
      break;
    }
    case 'P': { // Package
      glWin.keyUp('P');
      int ct;
      for(ct = 0; ct < Game::packageNames.getSize(); ct++) {
        if(
          Game::optioTexts->getElement(TXT_PACKAGE)->equals(
            Game::packageNames.getElement(ct)
          )
        )
          break;
      }
      if((++ct) == Game::packageNames.getSize())
        ct = 0;
      Game::optioTexts->getElement(TXT_PACKAGE)->setText(
        Game::packageNames.getElement(ct)->getText()
      );
      Game::loadLevels();
      break;
    }
    case 'L': { // Level
      glWin.keyUp('L');
      int ct;
      for(ct = 0; ct < Game::levelNames.getSize(); ct++) {
        if(
          Game::optioTexts->getElement(TXT_LEVEL)->equals(
            Game::levelNames.getElement(ct)
          )
        )
          break;
      }
      if((++ct) == Game::levelNames.getSize())
        ct = 0;
      Game::optioTexts->getElement(TXT_LEVEL)->setText(
        Game::levelNames.getElement(ct)->getText()
      );
      break;
    }
    case 'T': {
      glWin.keyUp('T');
      int teamsCount = atoi(Game::optioTexts->getElement(TXT_TEAMS)->getText());
      if(teamsCount == 4)
        teamsCount = 2;
      else
        teamsCount++;
      String string(teamsCount);
      Game::optioTexts->getElement(TXT_TEAMS)->setText(string.getText());
      break;
    }
    case 'N': {
      glWin.keyUp('N');
      int matesCount = atoi(Game::optioTexts->getElement(TXT_MATES)->getText());
      if(matesCount == 1)
        matesCount = 64;
      else
        matesCount /= 2;
      String string(matesCount);
      Game::optioTexts->getElement(TXT_MATES)->setText(string.getText());
      break;
    }
    case 'G': { // Goal
      glWin.keyUp('G');
      int ct;
      for(ct = 0; ct < GOAL_STRINGS_COUNT; ct++)
        if(Game::optioTexts->getElement(TXT_GOAL)->equals(Game::goalString[ct]))
          break;
      if((++ct) == GOAL_STRINGS_COUNT)
        ct = 0;
      Game::optioTexts->getElement(TXT_GOAL)->setText(Game::goalString[ct]);
      break;
    }
    case 'K': { // Play
      glWin.keyUp('K');
      int ct;
      for(ct = 0; ct < PLAY_STRINGS_COUNT; ct++)
        if(Game::optioTexts->getElement(TXT_PLAY)->equals(Game::playString[ct]))
          break;
      if((++ct) == PLAY_STRINGS_COUNT)
        ct = 0;
      Game::optioTexts->getElement(TXT_PLAY)->setText(Game::playString[ct]);
      break;
    }
    case 'O': { // Timeout
      glWin.keyUp('O');
      int timeout = atoi(Game::optioTexts->getElement(TXT_TIMEOUT)->getText());
      switch(timeout) {
        case  1*60: timeout =  2*60; break;
        case  2*60: timeout =  3*60; break;
        case  3*60: timeout =  5*60; break;
        case  5*60: timeout = 10*60; break;
        case 10*60: timeout = 15*60; break;
        case 15*60: timeout = 20*60; break;
        case 20*60: timeout = 30*60; break;
        case 30*60: timeout = 45*60; break;
        case 45*60: timeout = 60*60; break;
        case 60*60: timeout =  1*60; break;
      }
      String string(timeout);
      Game::optioTexts->getElement(TXT_TIMEOUT)->setText(string.getText());
      break;
    }
    case 'R': { // Min Hz
      glWin.keyUp('R');
      int frameRate = atoi(Game::optioTexts->getElement(TXT_MINHZ)->getText());
      if(frameRate >= 80)
        frameRate = 5;
      else
        frameRate += 5;
      String string(frameRate);
      Game::optioTexts->getElement(TXT_MINHZ)->setText(string.getText());
      break;
    }
    case 'D':
    case 'C':
    case 'B':
    case 'A': {
      int tid = key-'A';
      char* curName = Game::optioTexts->getElement(TXT_TEAM_A+tid)->getText();
      int ct;
      for(ct = 0; ct < Game::botScriptNames.getSize(); ct++) {
        if(Game::botScriptNames.getElement(ct)->equals(curName))
          break;
      }
      if((++ct) == Game::botScriptNames.getSize())
        ct = 0;
      Game::optioTexts->getElement(TXT_TEAM_A+tid)->setText(
        Game::botScriptNames.getElement(ct)->getText()
      );
      break;
    }
    case 'M': {
      bool isOn = Game::optioTexts->getElement(TXT_MUSIC)->equals("on");
      Game::optioTexts->getElement(TXT_MUSIC)->setText(isOn? "off": "on");
      break;
    };
    case 'S': {
      bool isOn = Game::optioTexts->getElement(TXT_SOUND)->equals("on");
      Game::optioTexts->getElement(TXT_SOUND)->setText(isOn? "off": "on");
      break;
    }
    case 'Q': { // Quit
      glWin.keyUp('Q');
      mode = INTRO_MODE;
      Game::introTexts->setVisible(true);
      Game::crediTexts->setVisible(true);
      Game::logoSprite->setVisible(true);
      Game::optioTexts->setVisible(false);
      Game::optioTexts->getElement(TXT_FX)->setText(
        Game::areEffectsEnabled? "on": "off"
      );
      Game::optioTexts->getElement(TXT_MUSIC)->setText(
        Game::isMusicEnabled? "on": "off"
      );
      Game::optioTexts->getElement(TXT_SOUND)->setText(
        Game::isSoundEnabled? "on": "off"
      );
      Game::optioTexts->getElement(TXT_TEAMS)->setInt(Game::teamsCount);
      Game::optioTexts->getElement(TXT_MATES)->setInt(Game::matesCount);
      Game::optioTexts->getElement(TXT_TIMEOUT)->setInt(Game::matchDuration);
      Game::optioTexts->getElement(TXT_MINHZ)->setInt(Game::minFrameRate);
      for(int ct = 0; ct < 4; ct++)
        Game::optioTexts->getElement(TXT_TEAM_A+ct)->setText(
          Game::introTexts->getElement(ct)->getText()
        );
      Game::optioTexts->getElement(TXT_GOAL)->setText(
        Game::goalString[Game::goalIndex]
      );
      Game::optioTexts->getElement(TXT_PLAY)->setText(
        Game::playString[Game::playIndex]
      );
      Game::optioTexts->getElement(TXT_PACKAGE)->setText(
        Game::packageName.getText()
      );
      Game::optioTexts->getElement(TXT_LEVEL)->setText(
        Game::levelNames.getElement(Game::levelIndex)->getText()
      );
      break;
    }
    case 'X': { // Exit
      glWin.keyUp('X');
      mode = INTRO_MODE;
      Game::introTexts->setVisible(true);
      Game::crediTexts->setVisible(true);
      Game::logoSprite->setVisible(true);
      Game::optioTexts->setVisible(false);
      Game::areEffectsEnabled =
        Game::optioTexts->getElement(TXT_FX)->equals("on");
      glWin.getWorld().getSun()->setLensFlareShown(Game::areEffectsEnabled);
      glWin.getWorld().getScenery()->setShadowed(Game::areEffectsEnabled);
      Game::isMusicEnabled =
        Game::optioTexts->getElement(TXT_MUSIC)->equals("on");
      if(Game::isMusicEnabled)
        if(Game::soundTrack) Game::soundTrack->play();
      else
        if(Game::soundTrack) Game::soundTrack->stop();
      Game::isSoundEnabled =
        Game::optioTexts->getElement(TXT_SOUND)->equals("on");
      Game::teamsCount = Game::optioTexts->getElement(TXT_TEAMS)->getInt();
      setTeamsVisibility();
      Game::matesCount = Game::optioTexts->getElement(TXT_MATES)->getInt();
      Game::introTexts->getElement(TXT_TIME)->setText(
        Game::optioTexts->getElement(TXT_MATES)->getText()
      );
      Game::matchDuration = Game::optioTexts->getElement(TXT_TIMEOUT)->getInt();
      Game::minFrameRate = Game::optioTexts->getElement(TXT_MINHZ)->getInt();
      for(int ct = 0; ct < 4; ct++) {
        Game::introTexts->getElement(ct)->setText(
          Game::optioTexts->getElement(TXT_TEAM_A+ct)->getText()
        );
        Game::fightTexts->getElement(ct)->setText(
          Game::optioTexts->getElement(TXT_TEAM_A+ct)->getText()
        );
      }
      int ct;
      for(ct = 0; ct < GOAL_STRINGS_COUNT; ct++)
        if(Game::optioTexts->getElement(TXT_GOAL)->equals(Game::goalString[ct]))
          break;
      if(ct >= GOAL_STRINGS_COUNT)
        ct = 0;
      Game::goalIndex = ct;
      for(ct = 0; ct < PLAY_STRINGS_COUNT; ct++)
        if(Game::optioTexts->getElement(TXT_PLAY)->equals(Game::playString[ct]))
          break;
      if(ct >= PLAY_STRINGS_COUNT)
        ct = 0;
      Game::playIndex = ct;
      bool newScript =
        !Game::ngnScriptName.equals(Game::optioTexts->getElement(TXT_SCRIPT));
      if(newScript)
        Game::ngnScriptName.setText(
          Game::optioTexts->getElement(TXT_SCRIPT)->getText()
        );
      bool newPackage =
        !Game::packageName.equals(Game::optioTexts->getElement(TXT_PACKAGE));
      if(newPackage)
        Game::packageName.setText(
          Game::optioTexts->getElement(TXT_PACKAGE)->getText()
        );
      for(ct = 0; ct < Game::levelNames.getSize(); ct++)
        if(Game::optioTexts->getElement(TXT_LEVEL)->equals(
          Game::levelNames.getElement(ct)
        ))
          break;
      if(ct >= Game::levelNames.getSize())
        ct = 0;
      bool newLevel = newPackage || (Game::levelIndex != ct);
      Game::levelIndex = ct;
      FILE* file = fopen(Game::getOptionsFileName(),"w");
      if(file) {
        String* string;
        fwrite("[PACKAGE] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_PACKAGE);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[LEVEL] ",9,1,file);
        string = Game::optioTexts->getElement(TXT_LEVEL);
        fwrite(string->getText(),string->getLength(),1,file);
        if(!Game::optioTexts->getElement(TXT_SCRIPT)->equals("NONE")) {
          fwrite("\n[SCRIPT] ",10,1,file);
          string = Game::optioTexts->getElement(TXT_SCRIPT);
          fwrite(string->getText(),string->getLength(),1,file);
        }
        fwrite("\n[TEAMS] ",9,1,file);
        string = Game::optioTexts->getElement(TXT_TEAMS);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[MATES] ",9,1,file);
        string = Game::optioTexts->getElement(TXT_MATES);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[TEAM A] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_TEAM_A);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[TEAM B] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_TEAM_B);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[TEAM C] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_TEAM_C);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[TEAM D] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_TEAM_D);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[GOAL] ",8,1,file);
        string = Game::optioTexts->getElement(TXT_GOAL);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[PLAY] ",8,1,file);
        string = Game::optioTexts->getElement(TXT_PLAY);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[TIMEOUT] ",11,1,file);
        string = Game::optioTexts->getElement(TXT_TIMEOUT);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[MIN HZ] ",10,1,file);
        string = Game::optioTexts->getElement(TXT_MINHZ);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[EFFECTS] ",11,1,file);
        string = Game::optioTexts->getElement(TXT_FX);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[SOUND] ",9,1,file);
        string = Game::optioTexts->getElement(TXT_SOUND);
        fwrite(string->getText(),string->getLength(),1,file);
        fwrite("\n[MUSIC] ",9,1,file);
        string = Game::optioTexts->getElement(TXT_MUSIC);
        fwrite(string->getText(),string->getLength(),1,file);
        fclose(file);
      }
      static_cast<Game*>(&GLWin::get())->setupWorld(
        newPackage,newLevel,newScript
      );
      break;
    }
  }
  }
}

const char* IntroScene::getHelpLine(int line) {
  switch(line) {
    case 13: return GT_VERSION;
    case 12: return "http:apocalyx.sourceforge.net";
    case 11: return "mailto:tetractys@users.sf.net";
    case 10: return "";
    case  9: return Game::introString[0];
    case  8: return Game::introString[1];
    case  7: return Game::introString[2];
    case  6: return Game::introString[3];
    case  5: return Game::introString[4];
    case  4: return "[A-D] Change A,B,C,D Team";
    case  3: return "[ T ] Change Teams Number";
    case  2: return "[ N ] Change Mates Number";
    case  1: return "";
    case  0: return "[M/S] Music/Sound On/Off";
    default: return NULL;
  }
}

static inline void setupTeamIndexes(int* idx) {
  int maxScripts = Game::botScriptNames.getSize();
  for(int ct = (maxScripts < 4? maxScripts: 4); ct < 4; ct++)
    idx[ct] = maxScripts-1;
  for(int ct = 0; ct < (maxScripts < 4? maxScripts: 4); ct++)
    idx[ct] = ct;
  idx[0] = random(maxScripts);
  if(maxScripts >= 4) {
    for(int tid = 1; tid < 4; tid++) {
      bool repeat;
      do {
        repeat = false;
        idx[tid] = random(maxScripts);
        for(int ct = 0; ct < tid; ct++) {
          if(idx[ct] == idx[tid]) {
            repeat = true;
            break;
          }
        }
      } while(repeat);
    }
  }
}

//
// FightScene
//

class FightScene: public Scene {
public:
  enum TorsoAnimation {
    TORSO_DEATH, TORSO_ATTACK, TORSO_DROP, TORSO_RAISE, TORSO_STAND,
    MAX_TORSO_ANIMATIONS
  };
  enum LegsAnimation {
    LEGS_DEATH, LEGS_WALKCR, LEGS_WALK, LEGS_RUN, LEGS_WALKBK, LEGS_IDLE,
    LEGS_IDLECR, LEGS_TURN, MAX_LEGS_ANIMATIONS
  };
private:
  GLTeams* teams;
  GTArena* arena;
  int linkedTeamView;
  int linkedMateView;
  float lastElapsedTime;
  float lastRealTime;
  int winner;
protected:
  enum StartMode {REPEAT,REPLAY,SHUFFLE};
  void startAgain(GLWin& glWin, StartMode mode = SHUFFLE);
public:
  FightScene();
  bool initialize(GLWin& glWin);
  void finalize(GLWin& glWin);
  void keyDownEvent(GLWin& glWin, int key);
  int update(GLWin& glWin);
  const char* getHelpLine(int line);
};

FightScene::FightScene() {
  linkedTeamView = 0;
  linkedMateView = -1;
  winner = -1;
  teams = NULL;
  arena = NULL;
  Game::dataOverlay->setArena(NULL);
  Game::mapOverlay->setArena(NULL);
}

bool FightScene::initialize(GLWin& glWin) {
  Game::get().setPaused(false);
  if(Game::selectedSeed != 0) {
    srand(Game::selectedSeed);
  } else {
    Game::randomSeed = (unsigned int)(
      time(NULL)+SLInterpreter::float2Cell(GLWin::getElapsedTime())
    );
    srand(Game::randomSeed);
  }
  const bool MODE_AUTO =
    Game::mode == Game::MODE_DEMO ||
    Game::mode == Game::MODE_INTERACTIVE;
  const bool MODE_3D = MODE_AUTO || Game::mode == Game::MODE_3D;
  if(MODE_AUTO) {
    linkedTeamView = 0;
    linkedMateView = 0;
  } else if(Game::mode != Game::MODE_3D ||
    linkedTeamView > Game::teamsCount || linkedMateView > Game::matesCount
  ) {
    linkedTeamView = 0;
    linkedMateView = -1;
  }
  Game::fightTexts->getElement(TXT_RATIO)->setText("\0");
  Game::fightTexts->setVisible(true);
  if(!MODE_3D)
    Game::mapOverlay->setVisible(true);
  char text[16];
  gcvt(Game::timeMultiplier,2,text);
  Game::fightTexts->getElement(TXT_MULT)->setText(text);
  Game::tempMultiplier = 1;
  GLModel::setAnimationTime(0);
  winner = -1;
  /// script
  if(Game::ENGINE_SCRIPT_INITIALIZE >= 0)
    Game::interpreter.execNoStop(Game::ENGINE_SCRIPT_INITIALIZE);
  /// arena
  {
    if(MODE_3D) {
      Game::warrior->setUpperAnimation(FightScene::TORSO_STAND);
      Game::warrior->setLowerAnimation(FightScene::LEGS_IDLE);
      GLBasicMaterial* bodyLoMats[4] = {
        Game::warrior->getMaterial(),
        Game::redLoMaterial,
        Game::blueLoMaterial,
        Game::magentaLoMaterial,
      };
      GLBasicMaterial* bodyHiMats[4] = {
        Game::redHiMaterial? Game::warrior->getUpper().getMaterial(): NULL,
        Game::redHiMaterial,
        Game::blueHiMaterial,
        Game::magentaHiMaterial,
      };
      GLModel* weaponModels[1] = {Game::weapon};
      GLModel* flashModels[1] = {Game::flash};
      const float LOD_DISTANCE = 20*BSP_SCENE_SCALE;
      teams = new GLTeams(
        Game::teamsCount,Game::matesCount,*Game::warrior,bodyLoMats,bodyHiMats,
        *Game::sign,1,weaponModels,flashModels,LOD_DISTANCE,Game::shadowTexture,
        0.8f*BSP_SCENE_SCALE,2.5f*BSP_SCENE_SCALE
      );
    }
    if(!Game::getPlaylistFile()) {
      for(int ct = 0; ct < Game::teamsCount; ct++) {
        bool repeat;
        do {
          Game::corners[ct] = random(Game::bsp->getStartingPositionsCount());
          repeat = false;
          for(int cmp = ct-1; cmp >= 0; cmp--) {
            if(Game::corners[ct] == Game::corners[cmp]) {
              repeat = true;
              break;
            }
          }
        } while(repeat);
      }
    }
    char* names[4] = {
      Game::fightTexts->getElement(TXT_NAME_A)->getText(),
      Game::fightTexts->getElement(TXT_NAME_B)->getText(),
      Game::fightTexts->getElement(TXT_NAME_C)->getText(),
      Game::fightTexts->getElement(TXT_NAME_D)->getText(),
    };
    arena = new GTArena(
      Game::randomSeed,Game::goalIndex,Game::playIndex,Game::matchDuration,
      *Game::bsp,Game::corners,names,Game::teamsCount,Game::matesCount,teams
    );
    Game::mapOverlay->setArena(arena);
    if(MODE_3D) {
      GLPowerups* powerups = new GLPowerups(
        *Game::medikit,*Game::food,*Game::armor,*Game::bullets,
        *Game::grenades,*Game::target,arena->getItems(),Game::shadowTexture
      );
      Game::bsp->addFurniture(powerups);
      Game::dataOverlay->setArena(arena);
      Game::bsp->addFurniture(teams);
      float hSize[1] = {0.25f*BSP_SCENE_SCALE};
      float hExplSize[1] = {GTWeapon::GRENADE_RANGE_MAX*BSP_SCENE_SCALE};
      GLTexture* txt[1] = {Game::flash->getMaterial()->getDiffuseTexture()};
      GLTexture* boomTxt[1] = {Game::boomTexture};
      FM3DSample* explSmp[1] = {Game::boomSample};
      GLAmmo* ammo = new GLAmmo(
        1,hSize,hExplSize,txt,boomTxt,explSmp,&Game::isSoundEnabled,
        arena->getItems()
      );
      ammo->setBulletsColor(0, 1,0.75f,0.75f);
      ammo->setGrenadesColor(0, 1,0.25f,1);
      Game::bsp->addFurniture(ammo);
      for(int tid = 0; tid < teams->getTeamsCount(); tid++) {
        for(int ct = 0; ct < teams->getTeamMatesCount(tid); ct++) {
          GLTeamMate* mate = teams->getTeamMate(tid,ct);
          GLSoundSource* soundSource =
            new GLSoundSource(Game::shotSample,mate,false);
          mate->setGenericData((void*)soundSource);
          glWin.getWorld().addSoundSource(soundSource);
        }
      }
    }
    BSPVector& start = Game::bsp->getStartingPosition(Game::corners[0]);
    GLCamera& camera = glWin.getCamera();
    if(MODE_3D) {
      const float HALF_ARENA_SIZE = GTArena::ARENA_SIZE/2;
      float startX = start.x+(start.x > 0? 7: -7)*BSP_SCENE_SCALE;
      float startZ = start.z+(start.z > 0? 7: -7)*BSP_SCENE_SCALE;
      if(
        startX <= -HALF_ARENA_SIZE || startX >= HALF_ARENA_SIZE ||
        startZ <= -HALF_ARENA_SIZE || startZ >= HALF_ARENA_SIZE
      ) {
        startX = start.x+(start.x > 0? 1: -1)*BSP_SCENE_SCALE;
        startZ = start.z+(start.z > 0? 1: -1)*BSP_SCENE_SCALE;
        camera.setPosition(startX,start.y+2*BSP_SCENE_SCALE,startZ);
        camera.pointTo(0,0,0);
      } else {
        camera.setPosition(startX,start.y+1.25f*BSP_SCENE_SCALE,startZ);
        camera.pointTo(start.x,start.y,start.z);
      }
    } else {
      const float HEIGHT = 6;
      camera.setPosition(0,HEIGHT*BSP_SCENE_SCALE,0);
      camera.pointTo(0,(HEIGHT+1)*BSP_SCENE_SCALE,-2.5f*BSP_SCENE_SCALE);
    }
  }
  if(Game::mode == Game::MODE_INTERACTIVE) {
    GTBot* bot = arena->getBot(0);
    bot->suspend();
    if(Game::playIndex == ID_PLAY_SOCCER)
      bot->setKickSpeed(GTBot::KICK_SPEED_MAX);
  }
  lastElapsedTime = GLWin::getElapsedTime();
  lastRealTime = arena->getRealTime();
  return true;
}

void FightScene::finalize(GLWin& glWin) {
  if(Game::ENGINE_SCRIPT_FINALIZE >= 0)
    Game::interpreter.execNoStop(Game::ENGINE_SCRIPT_FINALIZE);
  Game::fightTexts->setVisible(false);
  Game::finalTexts->setVisible(false);
  Game::dataOverlay->setVisible(false);
  Game::mapOverlay->setVisible(false);
  if(arena) {
    delete arena;
    arena = NULL;
    Game::dataOverlay->setArena(NULL);
    Game::mapOverlay->setArena(NULL);
    if(
      Game::mode == Game::MODE_3D ||
      Game::mode == Game::MODE_DEMO ||
      Game::mode == Game::MODE_INTERACTIVE
    ) {
      glWin.getWorld().deleteSoundSources();
      Game::bsp->empty();
      teams = NULL;
    }
  }
}

void FightScene::startAgain(GLWin& glWin, StartMode mode) {
  bool dataIsVisible = Game::dataOverlay->isVisible();
  bool mapIsVisible = Game::mapOverlay->isVisible();
  M3Reference oldCamera = glWin.getCamera();
  finalize(glWin);
  switch(mode) {
    case SHUFFLE:
      Game::selectedSeed = 0;
      if(!Game::setupTeams()) {
        glWin.exit();
        return;
      }
      break;
    case REPLAY:
      Game::selectedSeed = Game::randomSeed;
      break;
    case REPEAT:
      Game::selectedSeed = 0;
      break;
  }
  initialize(glWin);
  dynamic_cast<M3Reference&>(glWin.getCamera()) = oldCamera;
  Game::mapOverlay->setVisible(mapIsVisible);
  Game::dataOverlay->setVisible(dataIsVisible);
  if(Game::mode == Game::MODE_CONT || Game::mode == Game::MODE_DEMO)
    Game::finalTexts->setVisible(true);
}

int FightScene::update(GLWin& glWin) {
  if(Game::ENGINE_SCRIPT_UPDATE >= 0)
    Game::interpreter.execNoStop(Game::ENGINE_SCRIPT_UPDATE,
      SLInterpreter::float2Cell(GLWin::getTimeStep())
    );
  const bool MODE_3D =
    Game::mode == Game::MODE_3D ||
    Game::mode == Game::MODE_DEMO ||
    Game::mode == Game::MODE_INTERACTIVE;
  GLCamera& camera = glWin.getCamera();
  float timeStep = GLWin::getTimeStep();
  if(!glWin.isPaused()) {
    const float SCALE_FACTOR = 1.5f;
    const float MIN_REQUIRED_INV_FPS = 1.0f/Game::minFrameRate;
    if(timeStep > MIN_REQUIRED_INV_FPS) {
      Game::tempMultiplier *= (1.0f/SCALE_FACTOR);
      if(Game::tempMultiplier < MIN_MULTIPLIER)
        Game::tempMultiplier = MIN_MULTIPLIER;
    } else {
      if(Game::tempMultiplier < Game::timeMultiplier) {
        Game::tempMultiplier *= SCALE_FACTOR;
        if(Game::tempMultiplier > Game::timeMultiplier)
          Game::tempMultiplier = Game::timeMultiplier;
      } else if(Game::tempMultiplier > Game::timeMultiplier) {
        Game::tempMultiplier = Game::timeMultiplier;
      }
    }
    float virtualTimeStep = GLWin::getTimeStep()*Game::tempMultiplier;
    GLModel::setAnimationTime(GLModel::getAnimationTime()+virtualTimeStep);
    static float simTimeLeft = 0;
    float simTimeStep = virtualTimeStep+simTimeLeft;
    int simSteps = int(simTimeStep*(1.0f/GTBotBrain::SIMULATION_TIME_STEP)+0.5f);
    simTimeLeft = simTimeStep-simSteps*GTBotBrain::SIMULATION_TIME_STEP;
    if(Game::ENGINE_SCRIPT_STEP >= 0) {
      for(int ct = simSteps; ct > 0; ct--) {
        Game::interpreter.execNoStop(Game::ENGINE_SCRIPT_STEP);
        if((winner = arena->update()) >= 0) break;
      }
    } else {
      for(int ct = simSteps; ct > 0; ct--)
        if((winner = arena->update()) >= 0) break;
    }
    int mates[4] = {0, 0, 0, 0};
    int kills[4] = {0, 0, 0, 0};
    float health[4] = {0, 0, 0, 0};
    float energy[4] = {0, 0, 0, 0};
    int shots[4] = {0, 0, 0, 0};
    for(int ct = 0; ct < arena->getBotsSize(); ct++) {
      GTBot* bot = arena->getBot(ct);
      kills[bot->getTeamID()] += bot->getKilledEnemies();
      if(!bot->isDead()) {
        mates[bot->getTeamID()]++;
        health[bot->getTeamID()] += bot->getHealth();
        energy[bot->getTeamID()] += bot->getEnergy();
        shots[bot->getTeamID()] += bot->getBulletsCount();
      }
    }
    if(winner >= 0) {
      if(winner == 4) { //timeout
        bool loser[4] = {false,false,false,false};
        int highest = mates[0];
        int theWinner = 0;
        for(int ct = 1; ct < Game::teamsCount; ct++) {
          if(highest < mates[ct]) {
            loser[theWinner] = true;
            highest = mates[ct];
            theWinner = ct;
          } else if(highest > mates[ct]) {
            loser[ct] = true;
          }
        }
        bool hasWinner = true;
        for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
          if(!loser[ct]) {
            hasWinner = false;
            break;
          }
        }
        if(hasWinner) {
          winner = theWinner;
          Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText("More Mates");
        } else {
          highest = kills[theWinner];
          for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
            if(loser[ct]) continue;
            if(highest < kills[ct]) {
              loser[theWinner] = true;
              highest = kills[ct];
              theWinner = ct;
            } else if(highest > kills[ct]) {
              loser[ct] = true;
            }
          }
          hasWinner = true;
          for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
            if(!loser[ct]) {
              hasWinner = false;
              break;
            }
          }
          if(hasWinner) {
            winner = theWinner;
            Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText("More Kills");
          } else {
            highest = health[theWinner];
            for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
              if(loser[ct]) continue;
              if(highest < health[ct]) {
                loser[theWinner] = true;
                highest = health[ct];
                theWinner = ct;
              } else if(highest > health[ct]) {
                loser[ct] = true;
              }
            }
            hasWinner = true;
            for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
              if(!loser[ct]) {
                hasWinner = false;
                break;
              }
            }
            if(hasWinner) {
              winner = theWinner;
              Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText("More Health");
            } else {
/* // no_energy
              highest = energy[theWinner];
              for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
                if(loser[ct]) continue;
                if(highest < energy[ct]) {
                  loser[theWinner] = true;
                  highest = energy[ct];
                  theWinner = ct;
                } else if(highest > energy[ct]) {
                  loser[ct] = true;
                }
              }
              hasWinner = true;
              for(int ct = theWinner+1; ct < Game::teamsCount; ct++) {
                if(!loser[ct]) {
                  hasWinner = false;
                  break;
                }
              }
              if(hasWinner) {
                winner = theWinner;
                Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText("More Energy");
              } else {
*/ // no_energy
                winner = 4;
                Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText("Same Values");
                Game::finalTexts->getElement(TXT_WINNER_NAME)->setText("None");
                Game::finalTexts->getElement(TXT_WINNER_NAME)->setColor(0.75f,0.75f,1);
// // no_energy              }
            }
          }
        }
      } else {
        Game::finalTexts->getElement(TXT_WINNER_GOAL)->setText(
          Game::goalString[Game::goalIndex]
        );
      }
      Game::finalTexts->setVisible(true);
      if(winner != 4) {
        GLOverlayText* text = Game::finalTexts->getElement(TXT_WINNER_NAME);
        text->setText(Game::fightTexts->getElement(winner)->getText());
        switch(winner) {
          case 0: text->setColor(0.75f,1,0.75f); break;
          case 1: text->setColor(1,0.75f,0.25f); break;
          case 2: text->setColor(0.25f,0.75f,1); break;
          case 3: text->setColor(0.75f,0.25f,1); break;
        }
      }
      if(Game::mode == Game::MODE_CONT) {
        if(winner != 4) {
          const int MAX_TEXT_LENGTH = 8192;
          char text[MAX_TEXT_LENGTH];
          itoa(Game::randomSeed,text,10);
          strcat(text,",");
          itoa(Game::teamsCount,text+strlen(text),10);
          strcat(text,",");
          itoa(Game::matesCount,text+strlen(text),10);
          strcat(text,",");
          strcat(text,Game::fightTexts->getElement(winner)->getText());
          strcat(text,",");
          itoa(Game::corners[winner],text+strlen(text),10);
          strcat(text,",");
          for(int ct = 0; ct < Game::teamsCount; ct++) {
            if(ct != winner) {
              strcat(text,Game::fightTexts->getElement(ct)->getText());
              strcat(text,",");
              itoa(Game::corners[ct],text+strlen(text),10);
              strcat(text,",");
            }
          }
          itoa(int(arena->getRealTime()),text+strlen(text),10);
          strcat(text,",");
          itoa(mates[winner],text+strlen(text),10);
          strcat(text,",");
          itoa(kills[winner],text+strlen(text),10);
          strcat(text,",");
          itoa(int(health[winner]),text+strlen(text),10);
          strcat(text,",");
          itoa(int(energy[winner]),text+strlen(text),10);
          strcat(text,",");
          itoa(shots[winner],text+strlen(text),10);
          strcat(text,",");
          for(int ct = 0; ct < Game::teamsCount; ct++) {
            if(ct != winner) {
              itoa(mates[ct],text+strlen(text),10);
              strcat(text,",");
              itoa(kills[ct],text+strlen(text),10);
              strcat(text,",");
              itoa(int(health[ct]),text+strlen(text),10);
              strcat(text,",");
              itoa(int(energy[ct]),text+strlen(text),10);
              strcat(text,",");
              itoa(shots[ct],text+strlen(text),10);
              strcat(text,",");
            }
          }
          strcat(text,Game::optioTexts->getElement(TXT_PACKAGE)->getText());
          strcat(text,",");
          strcat(text,Game::optioTexts->getElement(TXT_LEVEL)->getText());
          strcat(text,",");
          itoa(Game::goalIndex,text+strlen(text),10);
          strcat(text,",");
          itoa(Game::playIndex,text+strlen(text),10);
          strcat(text,",");
          strcat(text,Game::optioTexts->getElement(TXT_TIMEOUT)->getText());
          strcat(text,",\n");
          FILE* f = fopen(Game::getStatsFileName(),"a");
          fwrite(text,strlen(text),1,f);
          fclose(f);
        }
        Game::matchesCount++;
        if(Game::maxMatches && (Game::maxMatches <= Game::matchesCount))
          glWin.exit();
        else
          startAgain(glWin,SHUFFLE);
      } else if(Game::mode == Game::MODE_DEMO) {
        startAgain(glWin,REPEAT);
      }
    }
    if(MODE_3D) {
      for(int ct = 0; ct < arena->getBotsSize(); ct++) {
        GTBot* bot = arena->getBot(ct);
        GLTeamMate* tm = bot->getTeamMate();
        if(!tm->isDead()) {
          if(
            tm->getLegsAnimation().getCurrentAnimation() != bot->getLegsAttitude()
          ) {
            if(
              tm->getLegsAnimation().getCurrentAnimation() == LEGS_TURN &&
              bot->getLegsAttitude() == GTBot::IDLE
            ) {
              if(
                bot->getLegsAngle().getCurrent() ==
                bot->getLegsAngle().getRequired()
              ) {
                tm->setLegsAnimation(teams->getBotModel(),LEGS_IDLE);
              }
            } else if(tm->getLegsAnimation().getCurrentAnimation() != -1) {
              tm->setLegsAnimation(teams->getBotModel(),bot->getLegsAttitude());
            }
          } else if(
            tm->getLegsAnimation().getCurrentAnimation() == LEGS_IDLE &&
            bot->getLegsAngle().getCurrent() != bot->getLegsAngle().getRequired()
          ) {
            tm->setLegsAnimation(teams->getBotModel(),LEGS_TURN);
          }
          TorsoAnimation ta;
          if((ta = tm->getTorsoAnimation().getStoppedAnimation()) != -1) {
            tm->setLastTorsoAnimation(ta);
            switch(ta) {
              case TORSO_DROP:
              case TORSO_RAISE:
              case TORSO_ATTACK:
                tm->setTorsoAnimation(teams->getBotModel(),TORSO_STAND); break;
            }
          }
          tm->set(Game::warriorBaseTransform);
          tm->rotateStanding(bot->getLegsAngle().getCurrent());
          M3Vector& pos = *bot;
          tm->setPosition(pos.getX(),pos.getY(),pos.getZ());
          if(bot->getTorsoAttitude() == GTBot::TDEATH) {
            tm->getTorsoAngles().setAngles(0,0);
            tm->getHeadAngles().setAngles(0,0);
            tm->setTorsoAnimation(teams->getBotModel(),TORSO_DEATH);
            tm->setFlashShown(false);
            tm->setDead(true);
            if(Game::isSoundEnabled) {
              FM3DSound* sound =
                ((GLSoundSource*)tm->getGenericData())->get3DSound();
              sound->set3DSample(Game::deathSample);
              if(Game::timeMultiplier < 1) {
                sound->play();
                sound->setFrequency(sound->getFrequency()*Game::timeMultiplier);
              }
            }
          } else {
            tm->getTorsoAngles().setAngles(
              -bot->getTorsoAngles().getYaw().getCurrent(),
              bot->getTorsoAngles().getPitch().getCurrent()
            );
            tm->getHeadAngles().setAngles(
              -bot->getHeadAngles().getYaw().getCurrent(),
              bot->getHeadAngles().getPitch().getCurrent()
            );
            if(tm->getTorsoAnimation().getCurrentAnimation() == -1) {
              if(tm->getLastTorsoAnimation() == TORSO_STAND) {
                switch(bot->getTorsoAttitude()) {
                  case GTBot::ATTACK: {
                    tm->setTorsoAnimation(teams->getBotModel(),TORSO_ATTACK);
                    if(Game::isSoundEnabled) {
                      FM3DSound* sound =
                        ((GLSoundSource*)tm->getGenericData())->get3DSound();
                      sound->play();
                      if(Game::timeMultiplier < 1)
                        sound->setFrequency(
                          sound->getFrequency()*Game::timeMultiplier
                        );
                    }
                    break;
                  }
                  case GTBot::DROP: {
                    tm->setTorsoAnimation(teams->getBotModel(),TORSO_DROP);
                    break;
                  }
                  case GTBot::RAISE: {
                    tm->setTorsoAnimation(teams->getBotModel(),TORSO_RAISE);
                    break;
                  }
                }
              }
            } else if(
              tm->getTorsoAnimation().getCurrentAnimation() == TORSO_ATTACK
            ) {
              tm->setFlashShown(bot->isFlashing());
            }
          }
        }
      }
    }
    char text[16];
    if(winner == -1) {
      itoa(int(Game::matchDuration+0.5f-arena->getRealTime()),text,10);
      Game::fightTexts->getElement(TXT_TIME)->setText(text);
    }
    float diffElapsedTime = GLWin::getElapsedTime()-lastElapsedTime;
    if(diffElapsedTime > 2) {
      float mult = (arena->getRealTime()-lastRealTime)/diffElapsedTime;
      gcvt(mult,2,text);
      Game::fightTexts->getElement(TXT_RATIO)->setText(text);
      lastElapsedTime = GLWin::getElapsedTime();
      lastRealTime = arena->getRealTime();
    }
    for(int ct = 0; ct < Game::teamsCount; ct++) {
      itoa(mates[ct],text,10);
      Game::fightTexts->getElement(TXT_MATES_A+ct)->setText(text);
      itoa(kills[ct],text,10);
      Game::fightTexts->getElement(TXT_KILLS_A+ct)->setText(text);
      itoa(int(health[ct]),text,10);
      Game::fightTexts->getElement(TXT_HEALTH_A+ct)->setText(text);
      itoa(int(energy[ct]),text,10);
      Game::fightTexts->getElement(TXT_ENERGY_A+ct)->setText(text);
      itoa(int(shots[ct]),text,10);
      Game::fightTexts->getElement(TXT_SHOTS_A+ct)->setText(text);
    }
  }
  const float rotAngle = 0.15f*timeStep;
  if(
    glWin.isKeyPressed(VK_UP) || glWin.isKeyPressed(VK_DOWN) ||
    glWin.isKeyPressed(VK_LEFT) || glWin.isKeyPressed(VK_RIGHT) ||
    glWin.isKeyPressed(VK_PRIOR) || glWin.isKeyPressed(VK_NEXT) ||
    glWin.isLeftButtonPressed() || glWin.isRightButtonPressed()
  ) {
    if(Game::mode != Game::MODE_INTERACTIVE) {
      if(linkedMateView >= 0)
        linkedMateView = -linkedMateView-1;
      BSPVector pos(
        camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
      );
      BSPVector vel(0,0,0);
      if(glWin.isKeyPressed(VK_PRIOR) || glWin.isKeyPressed(VK_NEXT)) {
        const float climbSpeed = 10*BSP_SCENE_SCALE;
        vel.y =
          timeStep*(glWin.isKeyPressed(VK_PRIOR)? climbSpeed: -climbSpeed);
      }
      if(glWin.isKeyPressed(VK_LEFT) || glWin.isKeyPressed(VK_RIGHT)) {
        const float moveSpeed = 10*BSP_SCENE_SCALE;
        const float k =
          timeStep*(glWin.isKeyPressed(VK_LEFT)? moveSpeed: -moveSpeed);
        vel.set(
          vel.x+camera.getSideDirectionX()*k,
          vel.y+camera.getSideDirectionY()*k,
          vel.z+camera.getSideDirectionZ()*k
        );
      }
      if(glWin.isKeyPressed(VK_UP) || glWin.isKeyPressed(VK_DOWN)) {
        const float moveSpeed = 10*BSP_SCENE_SCALE;
        const float k =
          timeStep*(glWin.isKeyPressed(VK_UP)? moveSpeed: -moveSpeed);
        vel.set(
          vel.x+camera.getViewDirectionX()*k,
          vel.y,
          vel.z+camera.getViewDirectionZ()*k
        );
      }
      if(glWin.isLeftButtonPressed() || glWin.isRightButtonPressed()) {
        const float moveSpeed = 10*BSP_SCENE_SCALE;
        const float k =
          timeStep*(glWin.isLeftButtonPressed()? moveSpeed: -moveSpeed);
        vel.set(
          vel.x+camera.getViewDirectionX()*k,
          vel.y+camera.getViewDirectionY()*k,
          vel.z+camera.getViewDirectionZ()*k
        );
      }
      BSPVector extent(14,14,14);
      Game::bsp->slideCollision(pos,vel,extent);
      camera.setPosition(pos.x,pos.y,pos.z);
    } else {
      GTBot* bot = arena->getBot(
        linkedMateView+linkedTeamView*Game::matesCount
      );
      if(!bot->isDead()) {
        if(glWin.isKeyPressed(VK_UP) || glWin.isKeyPressed(VK_DOWN)) {
          if(bot->canLegsChange()) {
            switch(bot->getLegsAttitude()) {
              case GTBot::IDLE:
                if(glWin.isKeyPressed(VK_UP))
                  bot->setLegsAttitude(GTBot::WALK);
                else if(glWin.isKeyPressed(VK_DOWN))
                  bot->setLegsAttitude(GTBot::WALKBK);
                break;
              case GTBot::RUN:
                if(glWin.isKeyPressed(VK_DOWN))
                  bot->setLegsAttitude(GTBot::WALK);
                break;
              case GTBot::WALKBK:
                if(glWin.isKeyPressed(VK_UP))
                  bot->setLegsAttitude(GTBot::IDLE);
                break;
              case GTBot::WALK:
                if(glWin.isKeyPressed(VK_UP))
                  bot->setLegsAttitude(GTBot::RUN);
                else if(glWin.isKeyPressed(VK_DOWN))
                  bot->setLegsAttitude(GTBot::IDLE);
                break;
              case GTBot::WALKCR:
                if(glWin.isKeyPressed(VK_DOWN))
                  bot->setLegsAttitude(GTBot::IDLECR);
                break;
              case GTBot::IDLECR:
                if(glWin.isKeyPressed(VK_UP))
                  bot->setLegsAttitude(GTBot::WALKCR);
                else if(glWin.isKeyPressed(VK_DOWN))
                  bot->setLegsAttitude(GTBot::IDLE);
                break;
            }
          }
        }
        if(glWin.isKeyPressed(VK_LEFT) || glWin.isKeyPressed(VK_RIGHT)) {
          float rot = GTBot::SPEED_ROTATION*timeStep+0.02f;
          if(glWin.isKeyPressed(VK_RIGHT))
            rot = -rot;
          bot->getLegsAngle().setRequired(bot->getLegsAngle().getCurrent()+rot);
        }
        if(glWin.isKeyPressed(VK_NEXT))
          bot->drop();
        else if(glWin.isKeyPressed(VK_PRIOR))
          bot->raise(bot->getTouchedID());
        if(glWin.isLeftButtonPressed()) {
          if(bot->canTorsoChange())
            bot->shootBullet();
        } else if(glWin.isRightButtonPressed()) {
          if(bot->canTorsoChange())
            bot->launchGrenade();
        }
      }
    }
  }
  const int dx = glWin.getMouseDX();
  const int dy = glWin.getMouseDY();
  if(Game::mode != Game::MODE_INTERACTIVE) {
    if(dx != 0) {
      Game::followTarget = false;
      if(linkedMateView >= 0)
        linkedMateView = -linkedMateView-1;
      camera.rotateStanding(-dx*rotAngle);
    }
    if(dy != 0) {
      Game::followTarget = false;
      if(linkedMateView >= 0)
        linkedMateView = -linkedMateView-1;
      camera.pitch(-dy*rotAngle);
    }
  } else {
    GTBot* bot = arena->getBot(
      linkedMateView+linkedTeamView*Game::matesCount
    );
    int itemTouched = bot->getTouchedID();
    if(itemTouched >= 0 && itemTouched != ID_ITEM_WEAPON)
      bot->raise(itemTouched);
    if(dx != 0) {
      float rot = -0.25f*timeStep*dx;
      GTAngle& headAngle = bot->getHeadAngles().getYaw();
      if(headAngle.getCurrent() != 0) {
        float oldH = headAngle.getCurrent();
        float h = oldH+rot;
        if(h*oldH < 0) {
          GTAngle& torsoAngle = bot->getTorsoAngles().getYaw();
          float t = torsoAngle.getCurrent();
          t += h;
          h = 0;
          if(t > GTBot::TORSO_YAW_MAX) {
            h = t-GTBot::TORSO_YAW_MAX;
            t = GTBot::TORSO_YAW_MAX;
            if(h > GTBot::HEAD_YAW_MAX)
              h = GTBot::HEAD_YAW_MAX;
          } else if(t < GTBot::TORSO_YAW_MIN) {
            h = t-GTBot::TORSO_YAW_MIN;
            t = GTBot::TORSO_YAW_MIN;
            if(h < GTBot::HEAD_YAW_MIN)
              h = GTBot::HEAD_YAW_MIN;
          }
          torsoAngle.setRequired(t);
        } else if(h > GTBot::HEAD_YAW_MAX) {
          h = GTBot::HEAD_YAW_MAX;
        } else if(h < GTBot::HEAD_YAW_MIN) {
          h = GTBot::HEAD_YAW_MIN;
        }
        headAngle.setRequired(h);
      } else {
        GTAngle& torsoAngle = bot->getTorsoAngles().getYaw();
        float t = torsoAngle.getCurrent();
        t += rot;
        if(t > GTBot::TORSO_YAW_MAX) {
          float h = t-GTBot::TORSO_YAW_MAX;
          t = GTBot::TORSO_YAW_MAX;
          if(h > GTBot::HEAD_YAW_MAX)
            h = GTBot::HEAD_YAW_MAX;
          headAngle.setRequired(h);
        } else if(t < GTBot::TORSO_YAW_MIN) {
          float h = t-GTBot::TORSO_YAW_MIN;
          t = GTBot::TORSO_YAW_MIN;
          if(h < GTBot::HEAD_YAW_MIN)
            h = GTBot::HEAD_YAW_MIN;
          headAngle.setRequired(h);
        }
        torsoAngle.setRequired(t);
      }
    }
    if(dy != 0) {
      float rot = 0.25f*timeStep*dy;
      GTAngle& headAngle = bot->getHeadAngles().getPitch();
      if(headAngle.getCurrent() != 0) {
        float oldH = headAngle.getCurrent();
        float h = oldH+rot;
        if(h*oldH < 0) {
          h = 0;
        } else if(h > GTBot::HEAD_PITCH_MAX) {
          h = GTBot::HEAD_PITCH_MAX;
        } else if(h < GTBot::HEAD_PITCH_MIN) {
          h = GTBot::HEAD_PITCH_MIN;
        }
        headAngle.setRequired(h);
      } else {
        GTAngle& torsoAngle = bot->getTorsoAngles().getPitch();
        float t = torsoAngle.getCurrent();
        t += rot;
        if(t > GTBot::TORSO_PITCH_MAX) {
          float h = t-GTBot::TORSO_PITCH_MAX;
          t = GTBot::TORSO_PITCH_MAX;
          if(h > GTBot::HEAD_PITCH_MAX)
            h = GTBot::HEAD_PITCH_MAX;
          headAngle.setRequired(h);
        } else if(t < GTBot::TORSO_PITCH_MIN) {
          float h = t-GTBot::TORSO_PITCH_MIN;
          t = GTBot::TORSO_PITCH_MIN;
          if(h < GTBot::HEAD_PITCH_MIN)
            h = GTBot::HEAD_PITCH_MIN;
          headAngle.setRequired(h);
        }
        torsoAngle.setRequired(t);
      }
    }
  }
  if(linkedMateView >= 0) {
    if(Game::mode == Game::MODE_DEMO) {
      while(arena->getBot(
        linkedMateView+linkedTeamView*Game::matesCount
      )->isDead()) {
        if((++linkedMateView) >= Game::matesCount) {
          linkedMateView = 0;
          if((++linkedTeamView) >= Game::teamsCount) {
            linkedTeamView = 0;
            break;
          }
        }
      }
    }
    GLTeamMate* mate = arena->getBot(
      linkedMateView+linkedTeamView*Game::matesCount
    )->getTeamMate();
    M3Reference model;
    model.set(mate->getTransform());
    model.multiplyT(mate->getTorsoAngles().getTransform());
    model.multiplyT(mate->getHeadAngles().getTransform());
    model.pitch(M_PI/2);
    model.yaw(M_PI/2);
    model.moveUp(1*BSP_SCENE_SCALE);
    const float BK_STEP =
      (Game::mode == Game::MODE_INTERACTIVE? -5: -2)*BSP_SCENE_SCALE;
    const float UP_STEP = 0.5f*BSP_SCENE_SCALE;
    BSPVector pos(
      model.getPositionX(),model.getPositionY(),model.getPositionZ()
    );
    BSPVector vel(
      model.getViewDirectionX()*BK_STEP+model.getUpDirectionX()*UP_STEP,
      model.getViewDirectionY()*BK_STEP+model.getUpDirectionY()*UP_STEP,
      model.getViewDirectionZ()*BK_STEP+model.getUpDirectionZ()*UP_STEP
    );
    BSPVector extent(14,14,14);
    Game::bsp->checkCollision(pos,vel,extent);
    model.setPosition(pos.x,pos.y,pos.z);
    M3Quaternion end(model.getTransform(),4);
    M3Quaternion start(camera.getTransform(),4);
    M3Vector path(
      model.getPositionX()-camera.getPositionX(),
      model.getPositionY()-camera.getPositionY(),
      model.getPositionZ()-camera.getPositionZ()
    );
    float dist = path.norm();
    float speed;
    if(dist < 10*BSP_SCENE_SCALE) speed = 10*BSP_SCENE_SCALE;
    if(dist < 25*BSP_SCENE_SCALE) speed = 25*BSP_SCENE_SCALE;
    else speed = 100*BSP_SCENE_SCALE;
    float interpolation = speed*timeStep/dist;
    if(interpolation > 1)
      interpolation = 1;
    start.slerpAccurate(end,interpolation);
    float transform[16];
    start.fillArray(transform);
    transform[12] = camera.getPositionX()+interpolation*path.getX();
    transform[13] = camera.getPositionY()+interpolation*path.getY();
    transform[14] = camera.getPositionZ()+interpolation*path.getZ();
    camera.set(transform);
  }
  if(Game::playIndex == ID_PLAY_SOCCER) {
    if(Game::followTarget) {
      GTTarget* t = GTArena::get()->getTarget();
      if(t->getCountdown() <= 0)
        camera.pointTo(t->getX(),0,t->getZ());
    }
  }
  return Game::currentScene;
}

void FightScene::keyDownEvent(GLWin& glWin, int key) {
  if(Game::ENGINE_SCRIPT_KEYDOWN >= 0) {
    Game::interpreter.execNoStop(Game::ENGINE_SCRIPT_KEYDOWN,(cell)key);
    key = Game::interpreter.getReturnValue();
  }
  const bool MODE_3D =
    Game::mode == Game::MODE_3D ||
    Game::mode == Game::MODE_DEMO ||
    Game::mode == Game::MODE_INTERACTIVE;
  switch(key) {
    case 0: {
      break;
    }
    case VK_RETURN: {
      glWin.keyUp(VK_RETURN);
      glWin.getWorld().getBackground()->setVisible(true);
      glWin.getWorld().getSun()->setVisible(true);
      glWin.getWorld().getScenery()->setVisible(true);
      Game::currentScene = Game::INTRO_SCENE;
      break;
    }
    case '1': {
      glWin.keyUp('1');
      startAgain(glWin,REPEAT);
      break;
    }
    case '2': {
      glWin.keyUp('2');
      startAgain(glWin,REPLAY);
      break;
    }
    case '3': {
      glWin.keyUp('3');
      startAgain(glWin,SHUFFLE);
      break;
    }
    case 'D': {
      glWin.keyUp('D');
      if(MODE_3D)
        Game::dataOverlay->setVisible(!Game::dataOverlay->isVisible());
      break;
    }
    case 'V': {
      glWin.keyUp('V');
      if(MODE_3D)
        Game::mapOverlay->setVisible(!Game::mapOverlay->isVisible());
      break;
    }
    case 'I': {
      glWin.keyUp('I');
      if(MODE_3D) {
        if(Game::mode == Game::MODE_INTERACTIVE) {
          Game::mode = Game::MODE_3D;
          arena->getBot(
            linkedMateView+linkedTeamView*Game::matesCount
          )->resume();
        } else {
          Game::mode = Game::MODE_INTERACTIVE;
          Game::followTarget = false;
          if(linkedMateView < 0) {
            linkedTeamView = 0;
            linkedMateView = 0;
          }
          GTBot* bot =
            arena->getBot(linkedMateView+linkedTeamView*Game::matesCount);
          bot->suspend();
          if(Game::playIndex == ID_PLAY_SOCCER)
            bot->setKickSpeed(GTBot::KICK_SPEED_MAX);
        }
      }
      break;
    }
    case 'C': {
      glWin.keyUp('C');
      if(MODE_3D) {
        if(linkedMateView < 0) {
          linkedMateView = -linkedMateView-2;
        } else if(Game::mode == Game::MODE_INTERACTIVE) {
          arena->getBot(
            linkedMateView+linkedTeamView*Game::matesCount
          )->resume();
        }
        do {
          if((++linkedMateView) >= Game::matesCount) {
            linkedMateView = 0;
            break;
          }
        } while(arena->getBot(
          linkedMateView+linkedTeamView*Game::matesCount
        )->isDead());
        if(Game::mode == Game::MODE_INTERACTIVE)
          arena->getBot(
            linkedMateView+linkedTeamView*Game::matesCount
          )->suspend();
      }
      break;
    }
    case 'X': {
      glWin.keyUp('X');
      if(MODE_3D) {
        if(Game::mode == Game::MODE_INTERACTIVE)
          arena->getBot(
            linkedMateView+linkedTeamView*Game::matesCount
          )->resume();
        linkedMateView = 0;
        if((++linkedTeamView) >= Game::teamsCount)
          linkedTeamView = 0;
        if(Game::mode == Game::MODE_INTERACTIVE)
          arena->getBot(
            linkedMateView+linkedTeamView*Game::matesCount
          )->suspend();
      }
      break;
    }
    case 'Z': {
      glWin.keyUp('Z');
      if(MODE_3D) {
        if(
          Game::mode == Game::MODE_3D ||
          Game::mode == Game::MODE_INTERACTIVE
        ) {
          Game::mode = Game::MODE_DEMO;
          if(linkedMateView < 0) {
            linkedTeamView = 0;
            linkedMateView = 0;
          }
        } else {
          Game::mode = Game::MODE_3D;
        }
      }
      break;
    }
    case 'T': {
      glWin.keyUp('T');
      if(MODE_3D) {
        if(Game::mode != Game::MODE_INTERACTIVE)
          Game::followTarget = !Game::followTarget;
      }
      break;
    }
    case VK_ADD: {
      glWin.keyUp(VK_ADD);
      if((Game::timeMultiplier *= 2) > MAX_MULTIPLIER)
        Game::timeMultiplier = MAX_MULTIPLIER;
      char text[16];
      gcvt(Game::timeMultiplier,2,text);
      Game::fightTexts->getElement(TXT_MULT)->setText(text);
      break;
    }
    case VK_SUBTRACT: {
      glWin.keyUp(VK_SUBTRACT);
      if((Game::timeMultiplier /= 2) < MIN_MULTIPLIER)
        Game::timeMultiplier = MIN_MULTIPLIER;
      char text[16];
      gcvt(Game::timeMultiplier,2,text);
      Game::fightTexts->getElement(TXT_MULT)->setText(text);
      break;
    }
    case VK_NUMPAD0:
    case VK_NUMPAD1:
    case VK_NUMPAD2:
    case VK_NUMPAD3:
    case VK_NUMPAD4:
    case VK_NUMPAD5:
    case VK_NUMPAD6:
    case VK_NUMPAD7:
    case VK_NUMPAD8:
    case VK_NUMPAD9:
    {
      if(Game::mode == Game::MODE_INTERACTIVE) {
        arena->getBot(
          linkedMateView+linkedTeamView*Game::matesCount
        )->say(key-VK_NUMPAD0);
      }
      break;
    }
    default: {
      Game::keyDownEventSound(glWin,key);
      break;
    }
  }
}

const char* FightScene::getHelpLine(int line) {
  if(Game::mode != Game::MODE_INTERACTIVE) {
    switch(line) {
      case 14: return GT_VERSION;
      case 13: return "      MODE: AUTO";
      case 12: return "";
      case 11: return "[  MOUSE  ] Camera Look Around";
      case 10: return "[LR BUTTON] Camera Forward/Backward";
      case  9: return "[ UP /DOWN] Camera Level Forw/Backw";
      case  8: return "[PREV/NEXT] Camera Higher/Lower";
      case  7: return "[LEFT/RGHT] Camera Slide Left/Right";
      case  6: return "[  M / S  ] Music/Sound On/Off";
      case  5: {
        char* text = "[  + / -  ] Time Multiplier = 000000";
        char* subs = strchr(text,'=')+2;
        gcvt(Game::timeMultiplier,2,subs);
        return text;
      }
      case  4: return "[  D/V/I  ] Data/Map/Interactive";
      case  3: return Game::playIndex == ID_PLAY_SOCCER?
        "[ Z/X-C/T ] Auto/Change View/Target":
        "[  Z/X-C  ] Auto/Change View";
      case  2: return "[  PAUSE  ] Pause On/Off";
      case  1: return "[  1/2/3  ] Restart/Replay/Shuffle";
      case  0: return "[  ENTER  ] Stop/Exit";
      default: return NULL;
    }
  } else {
    switch(line) {
      case 14: return GT_VERSION;
      case 13: return "      MODE: INTERACTIVE";
      case 12: return "[  MOUSE  ] Look Around";
      case 11: return "[LR BUTTON] Fire Main/Alternate";
      case 10: return "[ UP/DOWN ] Move Forw/Backw";
      case  9: return "[LEFT/RGHT] Rotate Left/Right";
      case  8: return "[PREV/NEXT] Drop Weapon/Raise Item";
      case  7: return "[ PAD 0-9 ] Say Word ('0'-'9')";
      case  6: return "[  M / S  ] Music/Sound On/Off";
      case  5: {
        char* text = "[  + / -  ] Time Multiplier = 000000";
        char* subs = strchr(text,'=')+2;
        gcvt(Game::timeMultiplier,2,subs);
        return text;
      }
      case  4: return "[  D/V/I  ] Data/Map/Interactive";
      case  3: return "[  Z/X-C  ] Auto/Change View";
      case  2: return "[  PAUSE  ] Pause On/Off";
      case  1: return "[  1/2/3  ] Restart/Replay/Shuffle";
      case  0: return "[  ENTER  ] Stop/Exit";
      default: return NULL;
    }
  }
}

//
// ResultsScene
//
class ResultsScene: public Scene {
protected:
  GLOverlayTexts* resultTexts;
  GLOverlayTexts* titleTexts;
public:
  ResultsScene();
  bool initialize(GLWin& glWin);
  void finalize(GLWin& glWin);
  int update(GLWin& glWin);
  void keyDownEvent(GLWin& glWin, int key);
  const char* getHelpLine(int line);
};

ResultsScene::ResultsScene(): resultTexts(NULL), titleTexts(NULL) {
}

class TeamResults: public DSSortableObject {
public:
  TeamResults(char* iName);
  String teamName;
  int survivorsCount;
  int friendsCount;
  int killsCount;
  int enemiesCount;
  int victoriesCount;
  int matchesCount;
  float ratio;
  float getSortIndex() {return ratio;}
};

TeamResults::TeamResults(char* name):
  teamName(name), victoriesCount(0), matchesCount(0),
  survivorsCount(0), friendsCount(0), killsCount(0), enemiesCount(0)
{}

bool ResultsScene::initialize(GLWin& glWin) {
  glWin.getOverlay().showPointer();
  GLFont* font = glWin.getMainOverlayFont();
  const float SCALE = 1.5f;
  const float FONT_HEIGHT = font->getHeight()*SCALE;
  const float HEIGHT = float(glWin.getHeight());
  const float HALF_W = float(glWin.getWidth()>>1);
  titleTexts = new GLOverlayTexts(font);
  titleTexts->setVisible(true);
  resultTexts = new GLOverlayTexts(font);
  resultTexts->setVisible(true);
  resultTexts->setLocation(-100,0);
  float rowHeight = HEIGHT-FONT_HEIGHT*2;
  DSSortedArray<TeamResults> results;
  FILE* f = fopen(Game::getStatsFileName(),"r");
  if(f) {
    const int BUF_LEN = 8191;
    char line[BUF_LEN+1];
    while(fgets(line,BUF_LEN,f)) {
      line[strlen(line)-1] = '\0';
      strtok(line,","); // randomSeed
      int teamsCount = atoi(strtok(NULL,","));
      int matesCount = atoi(strtok(NULL,","));
      char* winner = strtok(NULL,",");
      strtok(NULL,","); // winner corner
      bool foundWinner = false;
      int losersID[3];
      int winnerID;
      int ct;
      for(ct = 0; ct < results.getSize(); ct++) {
        if(results.getElement(ct)->teamName.equals(winner)) {
          results.getElement(ct)->victoriesCount++;
          results.getElement(ct)->matchesCount++;
          foundWinner = true;
          winnerID = ct;
          break;
        }
      }
      if(!foundWinner) {
        TeamResults* tr = new TeamResults(winner);
        tr->victoriesCount = 1;
        tr->matchesCount = 1;
        results.addElement((DSSortableObject*)tr);
        winnerID = ct;
      }
      for(int loserCt = 0; loserCt < teamsCount-1; loserCt++) {
        char* loser = strtok(NULL,",");
        strtok(NULL,","); // loser corner
        bool foundLoser = false;
        int ct;
        for(ct = 0; ct < results.getSize(); ct++) {
          if(results.getElement(ct)->teamName.equals(loser)) {
            results.getElement(ct)->matchesCount++;
            foundLoser = true;
            losersID[loserCt] = ct;
            break;
          }
        }
        if(!foundLoser) {
          TeamResults* tr = new TeamResults(loser);
          tr->matchesCount = 1;
          results.addElement((DSSortableObject*)tr);
          losersID[loserCt] = ct;
        }
      }
      strtok(NULL,","); // elapsed time
      results.getElement(winnerID)->survivorsCount += atoi(strtok(NULL,","));
      results.getElement(winnerID)->friendsCount += matesCount;
      results.getElement(winnerID)->killsCount += atoi(strtok(NULL,","));
      results.getElement(winnerID)->enemiesCount += matesCount*(teamsCount-1);
      strtok(NULL,","); // health
      strtok(NULL,","); // energy
      strtok(NULL,","); // shots
      for(int loserCt = 0; loserCt < teamsCount-1; loserCt++) {
        results.getElement(losersID[loserCt])->survivorsCount +=
          atoi(strtok(NULL,","));
        results.getElement(losersID[loserCt])->friendsCount += matesCount;
        results.getElement(losersID[loserCt])->killsCount +=
          atoi(strtok(NULL,","));
        results.getElement(losersID[loserCt])->enemiesCount +=
          matesCount*(teamsCount-1);
        strtok(NULL,","); // health
        strtok(NULL,","); // energy
        strtok(NULL,","); // shots
      }
    }
    fclose(f);
    GLOverlayText* txt;
    txt =
      new GLOverlayText("Actual Results",1,1,1,HALF_W,rowHeight -= FONT_HEIGHT);
    txt->setScale(SCALE);
    txt->setVisible(true);
    titleTexts->addElement(txt);
    txt = new GLOverlayText("Team",1,1,1,HALF_W,rowHeight -= FONT_HEIGHT);
    txt->setAlignment(GLOverlayText::RIGHT);
    txt->setVisible(true);
    resultTexts->addElement(txt);
    txt = new GLOverlayText(
      " Surv% | Kill% | Perc. (Vic./Matches)",1,1,1,HALF_W,rowHeight
    );
    txt->setAlignment(GLOverlayText::LEFT);
    txt->setVisible(true);
    resultTexts->addElement(txt);
  } else {
    GLOverlayText* txt;
    txt = new GLOverlayText("No Results",1,1,1,HALF_W,rowHeight -= FONT_HEIGHT);
    txt->setScale(SCALE);
    txt->setVisible(true);
    titleTexts->addElement(txt);
  }
  for(int ct = 0; ct < results.getSize(); ct++) {
    TeamResults* tr = results.getElement(ct);
    tr->ratio = (tr->matchesCount > 0)?
      (float(tr->victoriesCount)/tr->matchesCount): 0;
  }
  results.quickSort(0,results.getSize()-1);
  for(int ct = 0; ct < results.getSize(); ct++) {
    GLOverlayText* txt;
    txt = new GLOverlayText(
      results.getElement(ct)->teamName.getText(),1,1,0,
      HALF_W,rowHeight -= FONT_HEIGHT
    );
    txt->setAlignment(GLOverlayText::RIGHT);
    txt->setScale(SCALE);
    txt->setVisible(true);
    resultTexts->addElement(txt);
    char text[512] = " ";
    char perc[8];
    float percVal;
    int len;
    percVal =
      100.0f*results.getElement(ct)->survivorsCount/(
        results.getElement(ct)->friendsCount
      );
    gcvt(percVal,3,perc);
    strcat(text,perc);
    len = strlen(perc);
    switch(len) {
      case 1: strcat(text,".00"); break;
      case 2: strcat(text,".0"); break;
      case 3: strcat(text,percVal == 100? ".": "0"); break;
      case 5: text[strlen(text)-1] = '\0'; break;
    }
    strcat(text,"% | ");
    percVal =
      100.0f*results.getElement(ct)->killsCount/(
        results.getElement(ct)->enemiesCount
      );
    gcvt(percVal,3,perc);
    strcat(text,perc);
    len = strlen(perc);
    switch(len) {
      case 1: strcat(text,".00"); break;
      case 2: strcat(text,".0"); break;
      case 3: strcat(text,percVal == 100? ".": "0"); break;
      case 5: text[strlen(text)-1] = '\0'; break;
    }
    strcat(text,"% | ");
    percVal = results.getElement(ct)->ratio*100;
    gcvt(percVal,3,perc);
    strcat(text,perc);
    len = strlen(perc);
    switch(len) {
      case 1: strcat(text,".00"); break;
      case 2: strcat(text,".0"); break;
      case 3: strcat(text,percVal == 100? ".": "0"); break;
      case 5: text[strlen(text)-1] = '\0'; break;
    }
    strcat(text,"% (");
    itoa(results.getElement(ct)->victoriesCount,text+strlen(text),10);
    strcat(text,"/");
    itoa(results.getElement(ct)->matchesCount,text+strlen(text),10);
    strcat(text,") ");
    txt = new GLOverlayText(text,0.75f,1,1,HALF_W,rowHeight);
    txt->setAlignment(GLOverlayText::LEFT);
    txt->setVisible(true);
    resultTexts->addElement(txt);
  }
  GLOverlayText* txt;
  txt =
    new GLOverlayText("[DEL] To Delete",1,1,1,HALF_W,rowHeight -= FONT_HEIGHT);
  txt->setVisible(true);
  titleTexts->addElement(txt);
  txt =
    new GLOverlayText("[ENTER] To Exit",1,1,1,HALF_W,rowHeight -= FONT_HEIGHT);
  txt->setVisible(true);
  titleTexts->addElement(txt);
  glWin.getOverlay().addOverlayObject(titleTexts);
  glWin.getOverlay().addOverlayObject(resultTexts);
  return true;
}

void ResultsScene::finalize(GLWin& glWin) {
  resultTexts->setVisible(false);
  titleTexts->setVisible(false);
  glWin.getOverlay().removeOverlayObject(resultTexts);
  glWin.getOverlay().removeOverlayObject(titleTexts);
  resultTexts = NULL;
  titleTexts = NULL;
}

int ResultsScene::update(GLWin& glWin) {
  GLCamera& camera = glWin.getCamera();
  float timeStep = GLWin::getTimeStep();
  BSPVector& nextPos = Game::bsp->getStartingPosition(IntroScene::corner);
  float diffX = nextPos.x-camera.getPositionX();
  float diffZ = nextPos.z-camera.getPositionZ();
  const float CAMERA_SPEED = 7.5f*BSP_SCENE_SCALE;
  float cameraStep = timeStep*CAMERA_SPEED;
  if(diffX == 0) {
    if(cameraStep > fabs(diffZ)) {
      cameraStep = fabs(diffZ);
      if((--IntroScene::corner) < 0)
        IntroScene::corner = 3;
    }
    camera.move(0,0,diffZ > 0? cameraStep: -cameraStep);
  } else {
    if(cameraStep > fabs(diffX)) {
      cameraStep = fabs(diffX);
      if((--IntroScene::corner) < 0)
        IntroScene::corner = 3;
    }
    camera.move(diffX > 0? cameraStep: -cameraStep,0,0);
  }
  camera.pointTo(0,0,0);
  const int dx = glWin.getMouseDX();
  const int dy = glWin.getMouseDY();
  GLOverlay& overlay = glWin.getOverlay();
  overlay.movePointer(dx,dy,glWin.getWidth(),glWin.getHeight());
  if(overlay.getPointerY() <= overlay.getPointerHeight()) {
    const float SCROLL_SPEED = 200;
    float scrollStep = timeStep*SCROLL_SPEED;
    titleTexts->set(titleTexts->getX(),titleTexts->getY()+scrollStep);
    resultTexts->set(resultTexts->getX(),resultTexts->getY()+scrollStep);
  } else if(
    overlay.getPointerY() >= glWin.getHeight()-2*overlay.getPointerHeight()
  ) {
    const float SCROLL_SPEED = 200;
    float scrollStep = timeStep*SCROLL_SPEED;
    titleTexts->set(titleTexts->getX(),titleTexts->getY()-scrollStep);
    resultTexts->set(resultTexts->getX(),resultTexts->getY()-scrollStep);
  }
  GLOverlayTexts* texts = titleTexts;
  GLOverlayText* text =
    texts->getText(overlay.getPointerX(),overlay.getPointerY());
  static GLOverlayText* oldText = NULL;
  if(text) {
    bool isActive = (text->getText()[0] == '[');
    if(text != oldText) {
      if(oldText) oldText->setColor(1,1,1);
      if(isActive) {
        text->setColor(1,0.25f,0.25f);
        oldText = text;
      }
    }
    static bool selected = false;
    if(glWin.isLeftButtonPressed()) {
      if(isActive && !selected) {
        if(strstr(text->getText(),"DEL")) {
          keyDownEvent(glWin,VK_DELETE);
        } else if(strstr(text->getText(),"ENTER")) {
          keyDownEvent(glWin,VK_RETURN);
        }
        selected = true;
      }
    } else {
      selected = false;
    }
  } else if(oldText) {
    oldText->setColor(1,1,1);
    oldText = NULL;
  }
  return Game::currentScene;
}

void ResultsScene::keyDownEvent(GLWin& glWin, int key) {
  switch(key) {
    case 0: {
      break;
    }
    case VK_DELETE: {
      glWin.keyUp(VK_DELETE);
      unlink(Game::getStatsFileName());
      Game::currentScene = Game::INTRO_SCENE;
      break;
    }
    case VK_RETURN: {
      glWin.keyUp(VK_RETURN);
      Game::currentScene = Game::INTRO_SCENE;
      break;
    }
    default: {
      Game::keyDownEventSound(glWin,key);
      break;
    }
  }
}

const char* ResultsScene::getHelpLine(int line) {
  switch(line) {
    case  7: return GT_VERSION;
    case  6: return "http:apocalyx.sourceforge.net";
    case  5: return "mailto:tetractys@users.sf.net";
    case  4: return "";
    case  3: return "[ M/S ] Music/Sound On/Off";
    case  2: return "";
    case  1: return "[ DEL ] To Delete";
    case  0: return "[ENTER] To Exit";
    default: return NULL;
  }
}

//
// Game
//

int Game::currentScene = 0;

int Game::mode = 0;

bool Game::isSoundEnabled = true;
bool Game::isMusicEnabled = true;
bool Game::areEffectsEnabled = true;

FMMusic* Game::soundTrack = NULL;
FM3DSample* Game::shotSample = NULL;
FM3DSample* Game::boomSample = NULL;
FM3DSample* Game::deathSample = NULL;

GLBsp* Game::bsp = NULL;

bool Game::followTarget = false;
GLModel* Game::target = NULL;
GLModel* Game::weapon = NULL;
GLModel* Game::medikit = NULL;
GLModel* Game::food = NULL;
GLModel* Game::armor = NULL;
GLModel* Game::bullets = NULL;
GLModel* Game::grenades = NULL;
GLModel* Game::sign = NULL;
GLBot* Game::warrior = NULL;
M3Reference Game::warriorBaseTransform;
GLMaterial* Game::redLoMaterial = NULL;
GLMaterial* Game::blueLoMaterial = NULL;
GLMaterial* Game::magentaLoMaterial = NULL;
GLMaterial* Game::redHiMaterial = NULL;
GLMaterial* Game::blueHiMaterial = NULL;
GLMaterial* Game::magentaHiMaterial = NULL;
GLTexture* Game::boomTexture = NULL;
GLTexture* Game::shadowTexture = NULL;
GLModel* Game::flash = NULL;

GTOverlayArenaData* Game::dataOverlay = NULL;
GTOverlayArenaMap* Game::mapOverlay = NULL;
GLOverlayTexts* Game::introTexts = NULL;
GLOverlayTexts* Game::crediTexts = NULL;
GLOverlayTexts* Game::optioTexts = NULL;
GLOverlayTexts* Game::fightTexts = NULL;
GLOverlayTexts* Game::finalTexts = NULL;
char* Game::introString[INTRO_STRINGS_COUNT] = {
  "[ 1 ] Play Match (3D Mode)",
  "[ 2 ] Play Match (2D Mode)",
  "[ 3 ] Play Random Matches ",
  "[ 4 ] Show Actual Results ",
  "[ 0 ] Show/Change Options ",
};
char* Game::goalString[GOAL_STRINGS_COUNT] = {
  "Enemy Chief Terminated", "Enemy Team Terminated", "Enemy Sign Captured",
};
char* Game::playString[PLAY_STRINGS_COUNT] = {
  "Fight", "Soccer", "Race",
};

GLOverlaySprite* Game::logoSprite = NULL;

unsigned int Game::selectedSeed = 0;
unsigned int Game::randomSeed = 0;

GTEngineScript Game::interpreter;
int Game::ENGINE_SCRIPT_INITIALIZE = -1;
int Game::ENGINE_SCRIPT_FINALIZE = -1;
int Game::ENGINE_SCRIPT_KEYDOWN = -1;
int Game::ENGINE_SCRIPT_UPDATE = -1;
int Game::ENGINE_SCRIPT_STEP = -1;
String Game::ngnScriptName;
String Game::packageName;
int Game::levelIndex = 0;
int Game::goalIndex = 0;
int Game::playIndex = 0;
int Game::teamsCount = 2;
int Game::matesCount = 16;
int Game::matchDuration = 300;
int Game::minFrameRate = 30;

float Game::timeMultiplier = 1;
float Game::tempMultiplier = 1;

int Game::corners[4];

DSArray<String> Game::ngnScriptNames(4);
DSArray<String> Game::botScriptNames(8);
DSArray<String> Game::packageNames(2);
DSArray<String> Game::levelNames(4);

FILE* Game::playlistFile = NULL;
char* Game::playlistFileName = NULL;
char* Game::optionsFileName = NULL;
char* Game::statsFileName = NULL;

bool Game::suddenStart = false;
int Game::matchesCount = 0;
int Game::maxMatches = 0;

Game::Game(char* initStr) {
  char* chrPtr;
  if((chrPtr = strstr(initStr,"-maxmatches")) != NULL) {
    chrPtr += 11;
    char* chr;
    for(chr = chrPtr; (*chr != ' ') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char text[16];
    strncpy(text,chrPtr,nameLen);
    text[nameLen] = '\0';
    maxMatches = atoi(text);
  }
  if((chrPtr = strstr(initStr,"-timemult")) != NULL) {
    chrPtr += 9;
    char* chr;
    for(chr = chrPtr; (*chr != ' ') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char text[16];
    strncpy(text,chrPtr,nameLen);
    text[nameLen] = '\0';
    timeMultiplier = atoi(text);
  }
  if(strstr(initStr,"-playrandom"))
    suddenStart = true;
  if((chrPtr = strstr(initStr,"-playlist\"")) != NULL) {
    suddenStart = true;
    chrPtr += 10;
    char* chr;
    for(chr = chrPtr; (*chr != '\"') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char* newFileName = new char[nameLen+1];
    strncpy(newFileName,chrPtr,nameLen);
    newFileName[nameLen] = '\0';
    setPlaylistFileName(newFileName);
  }
  if((chrPtr = strstr(initStr,"-options\"")) != NULL) {
    chrPtr += 9;
    char* chr;
    for(chr = chrPtr; (*chr != '\"') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char* newFileName = new char[nameLen+1];
    strncpy(newFileName,chrPtr,nameLen);
    newFileName[nameLen] = '\0';
    setOptionsFileName(newFileName);
  }
  if((chrPtr = strstr(initStr,"-stats\"")) != NULL) {
    chrPtr += 7;
    char* chr;
    for(chr = chrPtr; (*chr != '\"') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char* newFileName = new char[nameLen+1];
    strncpy(newFileName,chrPtr,nameLen);
    newFileName[nameLen] = '\0';
    setStatsFileName(newFileName);
  }
  struct ffblk blk;
  chdir("bots");
  bool done = findfirst("*.amx",&blk,0);
  while(!done) {
    int len = strlen(blk.ff_name);
    blk.ff_name[len-4] = '\0';
    botScriptNames.addElement(new String(blk.ff_name));
    done = findnext(&blk);
  }
  chdir("..\\engine");
  done = findfirst("*.amx",&blk,0);
  ngnScriptNames.addElement(new String("NONE"));
  while(!done) {
    int len = strlen(blk.ff_name);
    blk.ff_name[len-4] = '\0';
    ngnScriptNames.addElement(new String(blk.ff_name));
    done = findnext(&blk);
  }
  chdir("..");
  done = findfirst("*.dat",&blk,0);
  while(!done) {
    int len = strlen(blk.ff_name);
    blk.ff_name[len-4] = '\0';
    packageNames.addElement(new String(blk.ff_name));
    done = findnext(&blk);
  }
}

bool Game::initializeScene() {
  /// font
  {
    DRPngResource fontResource(RCDATA_FONTPNG);
    DRImage* fontImage = fontResource.getImage();
    fontImage->addAlpha(*fontImage);
    GLTexture* fontTexture = new GLTexture(*fontImage);
    setMainOverlayFont(new GLTexturedFont(16,16,10,fontTexture));
    delete fontImage;
  }
  /// overlay (intro)
  {
    GLFont* font = getMainOverlayFont();
    crediTexts = new GLOverlayTexts(font);
    introTexts = new GLOverlayTexts(font);
    const float HALF_W = float(getWidth()>>1);
    const float HALF_H = float(getHeight()>>1);
    const float FONT_SCALE = 1.25f;
    const float FONT_SCALE2 = 1.5f;
    const float FONT_HEIGHT = font->getHeight()*FONT_SCALE;
    const float FONT_HEIGHT2 = font->getHeight()*FONT_SCALE2;
    const int STRINGS_COUNT = 17;
    char* theStrings[STRINGS_COUNT] = {
      botScriptNames.getElement(botScriptNames.getSize()-1)->getText(),
      botScriptNames.getElement(0)->getText(),
      botScriptNames.getElement(0)->getText(),
      botScriptNames.getElement(0)->getText(),
      "16","vs","[ A ]","[ B ]", "[ C ]","[ D ]","[ N ]","[ T ]",
      introString[0],introString[1],introString[2],introString[3],
      introString[4],
    };
    float theLocs[STRINGS_COUNT][2] = {
      {-160,FONT_HEIGHT*8},{160,FONT_HEIGHT*8},
      {-160,FONT_HEIGHT*6},{160,FONT_HEIGHT*6},
      {0,FONT_HEIGHT*8+FONT_HEIGHT2},{0,FONT_HEIGHT*8},
      {-160,FONT_HEIGHT*8+FONT_HEIGHT2},{160,FONT_HEIGHT*8+FONT_HEIGHT2},
      {-160,FONT_HEIGHT*6+FONT_HEIGHT2},{160,FONT_HEIGHT*6+FONT_HEIGHT2},
      {0,FONT_HEIGHT*8+FONT_HEIGHT2*2},{0,FONT_HEIGHT*8-FONT_HEIGHT2},
      {0,FONT_HEIGHT*5},{0,FONT_HEIGHT*4},{0,FONT_HEIGHT*3},{0,FONT_HEIGHT*2},
      {0,FONT_HEIGHT*1},
    };
    float theScales[STRINGS_COUNT] = {
      FONT_SCALE2,FONT_SCALE2,FONT_SCALE2,FONT_SCALE2,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,
    };
    float theColors[STRINGS_COUNT][3] = {
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {1,1,1}, {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0},
      {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0}, {1,1,0},
    };
    for(int ct = 0; ct < STRINGS_COUNT; ct++) {
      GLOverlayText* txt = new GLOverlayText(
        theStrings[ct],theColors[ct][0],theColors[ct][1],theColors[ct][2],
        theLocs[ct][0]+HALF_W,theLocs[ct][1]+HALF_H
      );
      txt->setScale(theScales[ct]);
      txt->setVisible(true);
      introTexts->addElement(txt);
    }
    getOverlay().addOverlayObject(introTexts);
    getOverlay().addOverlayObject(crediTexts);
  }
  /// overlay (options)
  {
    char* optioString[OPTIO_STRINGS_COUNT] = {
      "[ E ] Script :", "[ P ] Package:", "[ L ] Level  :", "[ T ] Teams #:",
      "[ A ] A Team :", "[ B ] B Team :", "[ C ] C Team :", "[ D ] D Team :",
      "[ N ] Mates #:", "[ G ] Goal   :", "[ K ] Play   :", "[ O ] Timeout:",
      "[ R ] Min Hz :", "[ F ] Effects:", "[ S ] Sound  :", "[ M ] Music  :",
      "[ X ] Save",     "[ Q ] Quit",
    };
    GLFont* font = getMainOverlayFont();
    optioTexts = new GLOverlayTexts(font);
    const float FONT_SCALE = 1;
    const float FONT_HEIGHT = font->getHeight()*FONT_SCALE;
    for(int ct = 0; ct < OPTIO_STRINGS_COUNT; ct++) {
      GLOverlayText* txt = new GLOverlayText(
        "",1,1,1,FONT_HEIGHT+(strlen(optioString[0])+1)*font->getSpacing(),
        (OPTIO_STRINGS_COUNT+1-ct)*FONT_HEIGHT
      );
      txt->setAlignment(GLOverlayText::LEFT);
      txt->setScale(FONT_SCALE);
      txt->setVisible(true);
      optioTexts->addElement(txt);
    }
    for(int ct = 0; ct < OPTIO_STRINGS_COUNT ; ct++) {
      GLOverlayText* txt = new GLOverlayText(
        optioString[ct],1,1,0,FONT_HEIGHT,(OPTIO_STRINGS_COUNT+1-ct)*FONT_HEIGHT
      );
      txt->setAlignment(GLOverlayText::LEFT);
      txt->setScale(FONT_SCALE);
      txt->setVisible(true);
      optioTexts->addElement(txt);
    }
    getOverlay().addOverlayObject(optioTexts);
  }
  /// overlay (fight)
  {
    GLFont* font = getMainOverlayFont();
    fightTexts = new GLOverlayTexts(font);
    const float FONT_SCALE = 1;
    const float FONT_SCALE2 = 1.25f;
    const float FONT_WIDTH = font->getWidth()*FONT_SCALE;
    const float FONT_HEIGHT = font->getHeight()*FONT_SCALE;
    const float FONT_HEIGHT2 = font->getHeight()*FONT_SCALE2;
    const float WIDTH = float(getWidth());
    const float HEIGHT = float(getHeight()-FONT_HEIGHT);
    const int STRINGS_COUNT = 49;
    char* theStrings[STRINGS_COUNT] = {
      botScriptNames.getElement(0)->getText(),
      botScriptNames.getElement(0)->getText(),
      botScriptNames.getElement(0)->getText(),
      botScriptNames.getElement(0)->getText(),
      "000","1","0000",
      "000","000","000","000",
      "000","000","000","000",
      "0000","0000","0000","0000",
      "0000","0000","0000","0000",
      "0000","0000","0000","0000",
      "Time","x",
      "mates","mates","mates","mates",
      "kills","kills","kills","kills",
      "health","health","health","health",
      "energy","energy","energy","energy",
      "shots","shots","shots","shots",
    };
    float theLocs[STRINGS_COUNT][2] = {
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2},
      {FONT_WIDTH,FONT_HEIGHT*12},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*12},
      {WIDTH/2,HEIGHT-FONT_HEIGHT2*2},
      {WIDTH/2,HEIGHT-FONT_HEIGHT2*2-FONT_HEIGHT},
      {WIDTH/2,HEIGHT-FONT_HEIGHT2*2-FONT_HEIGHT*2},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*2},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*2},
      {FONT_WIDTH,FONT_HEIGHT*10},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*10},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*4},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*4},
      {FONT_WIDTH,FONT_HEIGHT*8},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*8},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*6},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*6},
      {FONT_WIDTH,FONT_HEIGHT*6},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*6},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*8},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*8},
      {FONT_WIDTH,FONT_HEIGHT*4},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*4},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*10},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*10},
      {FONT_WIDTH,FONT_HEIGHT*2},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*2},
      {WIDTH/2,HEIGHT-FONT_HEIGHT2},
      {WIDTH/2-FONT_WIDTH,HEIGHT-FONT_HEIGHT2*2-FONT_HEIGHT},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*1},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*1},
      {FONT_WIDTH,FONT_HEIGHT*11},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*11},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*3},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*3},
      {FONT_WIDTH,FONT_HEIGHT*9},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*9},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*5},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*5},
      {FONT_WIDTH,FONT_HEIGHT*7},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*7},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*7},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*7},
      {FONT_WIDTH,FONT_HEIGHT*5},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*5},
      {FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*9},
      {WIDTH-FONT_WIDTH,HEIGHT-FONT_HEIGHT2-FONT_HEIGHT*9},
      {FONT_WIDTH,FONT_HEIGHT*3},
      {WIDTH-FONT_WIDTH,FONT_HEIGHT*3},
    };
    GLOverlayText::Alignment theAlign[STRINGS_COUNT] = {
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::CENTER,GLOverlayText::LEFT,GLOverlayText::CENTER,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::CENTER,GLOverlayText::LEFT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
      GLOverlayText::LEFT,GLOverlayText::RIGHT,
    };
    float theScales[STRINGS_COUNT] = {
      FONT_SCALE2,FONT_SCALE2,FONT_SCALE2,FONT_SCALE2,
      FONT_SCALE2,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE2,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
      FONT_SCALE,FONT_SCALE,FONT_SCALE,FONT_SCALE,
    };
    float theColors[STRINGS_COUNT][3] = {
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,1}, {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,1}, {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,1}, {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,1}, {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,1}, {1,1,1}, {1,1,1}, {1,1,1},
      {1,1,0}, {1,1,0},
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
      {0.75f,1,0.75f}, {1,0.75f,0.25f}, {0.25f,0.75f,1}, {0.75f,0.25f,1},
    };
    for(int ct = 0; ct < STRINGS_COUNT; ct++) {
      GLOverlayText* txt = new GLOverlayText(
        theStrings[ct],theColors[ct][0],theColors[ct][1],theColors[ct][2],
        theLocs[ct][0],theLocs[ct][1]
      );
      txt->setAlignment(theAlign[ct]);
      txt->setScale(theScales[ct]);
      txt->setVisible(true);
      fightTexts->addElement(txt);
    }
    getOverlay().addOverlayObject(fightTexts);
  }
  /// overlay (final)
  {
    GLFont* font = getMainOverlayFont();
    finalTexts = new GLOverlayTexts(font);
    const float FONT_SCALE = 1.5f;
    const float FONT_SCALE2 = 2;
    const float FONT_height = font->getHeight();
    const float FONT_HEIGHT = font->getHeight()*FONT_SCALE;
    const float FONT_HEIGHT2 = font->getHeight()*FONT_SCALE2;
    const float HALF_W = float(getWidth()>>1);
    const float HALF_H = float(getHeight()>>1);
    const int STRINGS_COUNT = 4;
    char* theStrings[STRINGS_COUNT] = {
      "None",goalString[0],"The Winner is",
      "[ENTER]Exit [1]Repeat [2]Replay [3]Shuffle",
    };
    float theLocs[STRINGS_COUNT][2] = {
      {HALF_W,FONT_height+FONT_HEIGHT*2},
      {HALF_W,FONT_height+FONT_HEIGHT},
      {HALF_W,FONT_height+FONT_HEIGHT*2+FONT_HEIGHT2},
      {HALF_W,FONT_height},
    };
    float theScales[STRINGS_COUNT] = {
      FONT_SCALE2,FONT_SCALE,FONT_SCALE,1,
    };
    float theColors[STRINGS_COUNT][3] = {
      {0.75f,0.75f,1}, {1,1,0}, {1,1,0}, {1,1,1},
    };
    for(int ct = 0; ct < STRINGS_COUNT; ct++) {
      GLOverlayText* txt = new GLOverlayText(
        theStrings[ct],theColors[ct][0],theColors[ct][1],theColors[ct][2],
        theLocs[ct][0],theLocs[ct][1]
      );
      txt->setScale(theScales[ct]);
      txt->setVisible(true);
      finalTexts->addElement(txt);
    }
    getOverlay().addOverlayObject(finalTexts);
  }
  FILE* file = fopen(getOptionsFileName(),"r");
  const unsigned int MAX_STRING_LENGTH = 127;
  char string[MAX_STRING_LENGTH+1];
  if(file) {
    const unsigned int BUFFER_LENGTH = 16383;
    char buffer[BUFFER_LENGTH+1];
    int value;
    size_t bytesRead = fread(buffer,1,BUFFER_LENGTH,file);
    buffer[min(bytesRead,BUFFER_LENGTH)] = '\0';
    fclose(file);
    //
    if(strstr(buffer,"[SOUND] off"))
      isSoundEnabled = false;
    optioTexts->getElement(TXT_SOUND)->setText(isSoundEnabled? "on": "off");
    //
    if(strstr(buffer,"[MUSIC] off"))
      isMusicEnabled = false;
    optioTexts->getElement(TXT_MUSIC)->setText(isMusicEnabled? "on": "off");
    //
    if(strstr(buffer,"[EFFECTS] off"))
      areEffectsEnabled = false;
    optioTexts->getElement(TXT_FX)->setText(areEffectsEnabled? "on": "off");
    //
    getOptioString(buffer,"[SCRIPT] ",string);
    if(*string)
      optioTexts->getElement(TXT_SCRIPT)->setText(string);
    else
      optioTexts->getElement(TXT_SCRIPT)->setText(
        ngnScriptNames.getElement(0)->getText()
      );
    ngnScriptName.setText(optioTexts->getElement(TXT_SCRIPT)->getText());
    //
    getOptioString(buffer,"[PACKAGE] ",string);
    if(*string)
      optioTexts->getElement(TXT_PACKAGE)->setText(string);
    else
      optioTexts->getElement(TXT_PACKAGE)->setText(
        packageNames.getElement(0)->getText()
      );
    packageName.setText(optioTexts->getElement(TXT_PACKAGE)->getText());
    //
    loadLevels();
    getOptioString(buffer,"[LEVEL] ",string);
    if(*string) {
      optioTexts->getElement(TXT_LEVEL)->setText(string);
      int ct;
      for(ct = 0; ct < levelNames.getSize(); ct++)
        if(optioTexts->getElement(TXT_LEVEL)->equals(
          levelNames.getElement(ct)
        ))
          break;
      if(ct >= levelNames.getSize()) {
        optioTexts->getElement(TXT_LEVEL)->setText(
          levelNames.getElement(0)->getText()
        );
        ct = 0;
      }
      levelIndex = ct;
    } else {
      optioTexts->getElement(TXT_LEVEL)->setText(
        levelNames.getElement(0)->getText()
      );
      levelIndex = 0;
    }
    //
    getOptioString(buffer,"[TEAMS] ",string);
    value = atoi(string);
    if(value)
      teamsCount = value;
    else
      itoa(teamsCount,string,10);
    optioTexts->getElement(TXT_TEAMS)->setText(string);
    //
    getOptioString(buffer,"[MATES] ",string);
    value = atoi(string);
    if(value)
      matesCount = value;
    else
      itoa(matesCount,string,10);
    optioTexts->getElement(TXT_MATES)->setText(string);
    introTexts->getElement(TXT_TIME)->setText(string);
    //
    getOptioString(buffer,"[MIN HZ] ",string);
    value = atoi(string);
    if(value)
      minFrameRate = value;
    else
      itoa(minFrameRate,string,10);
    optioTexts->getElement(TXT_MINHZ)->setText(string);
    //
    getOptioString(buffer,"[TIMEOUT] ",string);
    value = atoi(string);
    if(value)
      matchDuration = value;
    else
      itoa(matchDuration,string,10);
    optioTexts->getElement(TXT_TIMEOUT)->setText(string);
    //
    getOptioString(buffer,"[GOAL] ",string);
    goalIndex = 0;
    if(*string) {
      for(; goalIndex < GOAL_STRINGS_COUNT; goalIndex++)
        if(String::equals(string,goalString[goalIndex]))
          break;
      if(goalIndex == GOAL_STRINGS_COUNT)
        goalIndex = 0;
    }
    optioTexts->getElement(TXT_GOAL)->setText(goalString[goalIndex]);
    //
    getOptioString(buffer,"[PLAY] ",string);
    playIndex = 0;
    if(*string) {
      for(; playIndex < PLAY_STRINGS_COUNT; playIndex++)
        if(String::equals(string,playString[playIndex]))
          break;
      if(playIndex == PLAY_STRINGS_COUNT)
        playIndex = 0;
    }
    optioTexts->getElement(TXT_PLAY)->setText(playString[playIndex]);
    //
    getOptioString(buffer,"[TEAM A] ",string);
    if(!scriptExists(string))
      strcpy(string,botScriptNames.getElement(0)->getText());
    optioTexts->getElement(TXT_TEAM_A)->setText(string);
    introTexts->getElement(TXT_NAME_A)->setText(string);
    //
    getOptioString(buffer,"[TEAM B] ",string);
    if(!scriptExists(string))
      strcpy(string,botScriptNames.getElement(0)->getText());
    optioTexts->getElement(TXT_TEAM_B)->setText(string);
    introTexts->getElement(TXT_NAME_B)->setText(string);
    //
    getOptioString(buffer,"[TEAM C] ",string);
    if(!scriptExists(string))
      strcpy(string,botScriptNames.getElement(0)->getText());
    optioTexts->getElement(TXT_TEAM_C)->setText(string);
    introTexts->getElement(TXT_NAME_C)->setText(string);
    //
    getOptioString(buffer,"[TEAM D] ",string);
    if(!scriptExists(string))
      strcpy(string,botScriptNames.getElement(0)->getText());
    optioTexts->getElement(TXT_TEAM_D)->setText(string);
    introTexts->getElement(TXT_NAME_D)->setText(string);
    //
    if(optioTexts->getElement(TXT_TEAM_A)->getText()[0] == '\0')
      setupDefaultTeams();
  }
  /// logo
  {
    glClear(GL_STENCIL_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);
    //
    DRPngResource pointerResource(RCDATA_ARRWPNG);
    DRImage* pointerImage = pointerResource.getImage();
    int pointerSize = pointerImage->getWidth();
    pointerImage->addAlpha(*pointerImage);
    GLTexture* pointerTexture = new GLTexture(*pointerImage);
    delete pointerImage;
    GLOverlaySprite* pointerSprite =
      new GLOverlaySprite(pointerSize,pointerSize,pointerTexture,true);
    pointerSprite->setLayer(-1);
    getOverlay().setPointer(pointerSprite,getWidth()/2,getHeight()/2);
    getOverlay().showPointer();
    //
    DRJpegResource logoResource(RCDATA_LOGOJPG);
    DRImage* logoImage = logoResource.getImage();
    //
    int imgWidth = logoImage->getWidth();
    int imgHeight = logoImage->getHeight();
    getCamera().setOrtho();
    getCamera().applyOrtho();
    glRasterPos2f(-0.5f*imgWidth,-0.5f*imgHeight);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glDrawPixels(
      imgWidth,imgHeight,GL_RGB,GL_UNSIGNED_BYTE,logoImage->getBuffer()
    );
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
    swapBuffers();
    //
    int logoSize = logoImage->getWidth();
    DRPngResource logopngResource(RCDATA_LOGOPNG);
    DRImage* alphaImage = logopngResource.getImage();
    logoImage->addAlpha(*alphaImage);
    delete alphaImage;
    GLTexture* logoTexture = new GLTexture(*logoImage);
    logoSprite = new GLOverlaySprite(logoSize,logoSize,logoTexture,true);
    delete logoImage;
    getOverlay().addOverlayObject(logoSprite);
  }
  /// overlay (arena)
  {
    dataOverlay = new GTOverlayArenaData(getMainOverlayFont());
    dataOverlay->setLayer(1);
    getOverlay().addOverlayObject(dataOverlay);
  }
  setupWorld();
  setHelpMode(GLWin::REDUCED_HELP);
  FMListener::setDistanceFactor(BSP_SCENE_SCALE);
  setPerspective(60,0.1f*BSP_SCENE_SCALE,500*BSP_SCENE_SCALE);
  getWorld().setAmbient(0.2f,0.2f,0.2f);
  deleteScenes();
  GLScene* scenes[] = {
    new IntroScene(),
    new FightScene(),
    new ResultsScene(),
    NULL,
  };
  addScenes((GLScene**)scenes);
  if(suddenStart) {
    setTeamsVisibility();
    for(int ct = 0; ct < teamsCount; ct++) {
      fightTexts->getElement(ct)->setText(
        introTexts->getElement(ct)->getText()
      );
    }
    acquireMouse(false);
    setHelpMode(GLWin::HIDDEN_HELP);
    getWorld().getBackground()->setVisible(false);
    getWorld().getSun()->setVisible(false);
    getWorld().getScenery()->setVisible(false);
    mode = MODE_CONT;
    selectedSeed = 0;
    if(getPlaylistFileName()) {
      setPlaylistFile(fopen(getPlaylistFileName(),"r"));
      setupTeams();
    }
    setCurrentScene(FIGHT_SCENE);
    currentScene = FIGHT_SCENE;
  } else {
    setCurrentScene(INTRO_SCENE);
  }
  return true;
}

void Game::finalizeScene() {
  if(getPlaylistFile())
    setPlaylistFile(NULL);
  finalizeCurrent();
  if(soundTrack) {
    soundTrack->stop();
    delete soundTrack;
    soundTrack = NULL;
  }
  if(shotSample) {
    delete shotSample;
    shotSample = NULL;
  }
  if(boomSample) {
    delete boomSample;
    boomSample = NULL;
  }
  if(deathSample) {
    delete deathSample;
    deathSample = NULL;
  }
  getWorld().empty();
  bsp = NULL;
  if(target) {
    delete target;
    target = NULL;
  }
  if(weapon) {
    delete weapon;
    weapon = NULL;
  }
  if(medikit) {
    delete medikit;
    medikit = NULL;
  }
  if(food) {
    delete food;
    food = NULL;
  }
  if(armor) {
    delete armor;
    armor = NULL;
  }
  if(bullets) {
    delete bullets;
    bullets = NULL;
  }
  if(grenades) {
    delete grenades;
    grenades = NULL;
  }
  if(sign) {
    delete sign;
    sign = NULL;
  }
  if(warrior) {
    delete warrior;
    warrior = NULL;
  }
  redLoMaterial->releaseReference();
  redLoMaterial = NULL;
  blueLoMaterial->releaseReference();
  blueLoMaterial = NULL;
  magentaLoMaterial->releaseReference();
  magentaLoMaterial = NULL;
  if(redHiMaterial) {
    redHiMaterial->releaseReference();
    redHiMaterial = NULL;
  }
  if(blueHiMaterial) {
    blueHiMaterial->releaseReference();
    blueHiMaterial = NULL;
  }
  if(magentaHiMaterial) {
    magentaHiMaterial->releaseReference();
    magentaHiMaterial = NULL;
  }
  if(boomTexture) {
    boomTexture->releaseReference();
    boomTexture = NULL;
  }
  if(shadowTexture) {
    shadowTexture->releaseReference();
    shadowTexture = NULL;
  }
  if(flash) {
    delete flash;
    flash = NULL;
  }
  getOverlay().empty();
  dataOverlay = NULL;
  mapOverlay = NULL;
  logoSprite = NULL;
  introTexts = NULL;
  crediTexts = NULL;
  fightTexts = NULL;
  finalTexts = NULL;
}

const char* Game::getHelpLine(int line) {
  return dynamic_cast<Scene*>(getCurrentScene())->getHelpLine(line);
}

void Game::setupWorld(bool newPackage, bool newLevel, bool newScript) {
  if(newPackage || newLevel) {
  try {
    String zipName(Game::optioTexts->getElement(TXT_PACKAGE)->getText(),".dat");
    DRZipFile zip(zipName.getText());
    if(newPackage) {
      getWorld().empty();
      /// music
      if(soundTrack) {
        soundTrack->stop();
        delete soundTrack;
      }
      soundTrack = zip.getMusic("soundtrack.mid");
      if(soundTrack) {
        soundTrack->setVolume(255);
        soundTrack->setLooping(true);
        if(Game::isMusicEnabled)
          soundTrack->play();
      }
      /// sound
      if(shotSample) delete shotSample;
      shotSample = zip.get3DSoundSample("shot.wav");
      shotSample->setLooping(false);
      shotSample->setMinDistance(15*BSP_SCENE_SCALE);
      shotSample->setVolume(255);
      if(boomSample) delete boomSample;
      boomSample = zip.get3DSoundSample("boom.wav");
      boomSample->setLooping(false);
      boomSample->setMinDistance(25*BSP_SCENE_SCALE);
      boomSample->setVolume(255);
      boomSample->setPriority(255);
      if(deathSample) delete deathSample;
      deathSample = zip.get3DSoundSample("death.wav");
      deathSample->setLooping(false);
      deathSample->setMinDistance(15*BSP_SCENE_SCALE);
      deathSample->setVolume(255);
      /// font
      DRImage* fontImage = zip.getImage("font.png");
      if(fontImage) {
        fontImage->addAlpha(*fontImage);
        GLTexture* fontTexture = new GLTexture(*fontImage);
        setMainOverlayFont(new GLTexturedFont(16,16,10,fontTexture));
        delete fontImage;
      }
      /// background
      const int texturesCount = 5;
      GLTexture* skyboxTextures[texturesCount] = {
        zip.getTexture("skyboxTop.jpg"), zip.getTexture("skyboxLeft.jpg"),
        zip.getTexture("skyboxFront.jpg"), zip.getTexture("skyboxRight.jpg"),
        zip.getTexture("skyboxBack.jpg"),
      };
      GLMirroredSkybox* skyBackground = new GLMirroredSkybox(skyboxTextures);
      skyBackground->setColor(1,1,1);
      // skyBackground->setGroundColor(0.522f,0.373f,0.298f); // halfSkybox
      getWorld().setBackground(skyBackground);
      /// sun
      M3Vector direc(0,0.2588f,0.9659f);
      GLSunLight* sun = new GLSunLight(
        zip.getTexture("light.jpg"),0.01f*BSP_SCENE_SCALE,direc,
        zip.getTexture("lensflares.png"),5,0.004f*BSP_SCENE_SCALE,
        400*BSP_SCENE_SCALE
      );
      sun->setVisible(true);
      sun->setColor(.855f,.475f,.298f);
      sun->setLensFlareShown(areEffectsEnabled);
      getWorld().setSun(sun);
      /// models
      if(target) delete target;
      target = zip.getModel("target.mdx");
      GLMaterial* material = new GLMaterial();
      material->setAmbient(0.8f,0.8f,0.5f);
      material->setDiffuse(0.8f,0.8f,0.5f);
      material->setSpecular(1,0,0);
      material->setEmissive(0,0,0);
      material->setShininess(64);
      target->setMaterial(material);
      if(weapon) delete weapon;
      weapon = zip.getModel("gun.mdx","gun.jpg");
      if(medikit) delete medikit;
      medikit = zip.getModel("medikit.mdx","medikit.jpg");
      if(food) delete food;
      food = zip.getModel("food.mdx","food.jpg");
      if(armor) delete armor;
      armor = zip.getModel("armor.mdx","armor.jpg");
      if(bullets) delete bullets;
      bullets = zip.getModel("bullets.mdx","bullets.jpg");
      if(grenades) delete grenades;
      grenades = zip.getModel("grenades.mdx","grenades.jpg");
      if(sign) delete sign;
      sign = zip.getModel("sign.mdx","sign.jpg");
      if(warrior) delete warrior;
      warrior = zip.getBot("warrior.mdl");
      warrior->pitch(-M_PI/2);
      // warrior->useVertexBuffer();
      warriorBaseTransform.set(*warrior);
      if(redLoMaterial) redLoMaterial->releaseReference();
      redLoMaterial = new GLMaterial()->acquireReference();
      redLoMaterial->setDiffuseTexture(zip.getTexture("bodyRed.jpg"));
      if(blueLoMaterial) blueLoMaterial->releaseReference();
      blueLoMaterial = new GLMaterial()->acquireReference();
      blueLoMaterial->setDiffuseTexture(zip.getTexture("bodyBlue.jpg"));
      if(magentaLoMaterial) magentaLoMaterial->releaseReference();
      magentaLoMaterial = new GLMaterial()->acquireReference();
      magentaLoMaterial->setDiffuseTexture(zip.getTexture("bodyMagenta.jpg"));
      if(zip.findZippedFile("torsoRed.jpg")) {
        if(redHiMaterial) redHiMaterial->releaseReference();
        redHiMaterial = new GLMaterial()->acquireReference();
        redHiMaterial->setDiffuseTexture(zip.getTexture("torsoRed.jpg"));
        if(blueHiMaterial) blueHiMaterial->releaseReference();
        blueHiMaterial = new GLMaterial()->acquireReference();
        blueHiMaterial->setDiffuseTexture(zip.getTexture("torsoBlue.jpg"));
        if(magentaHiMaterial) magentaHiMaterial->releaseReference();
        magentaHiMaterial = new GLMaterial()->acquireReference();
        magentaHiMaterial->setDiffuseTexture(zip.getTexture("torsoMagenta.jpg"));
      } else {
        if(redHiMaterial) redHiMaterial->releaseReference();
        redHiMaterial = NULL;
        if(blueHiMaterial) blueHiMaterial->releaseReference();
        blueHiMaterial = NULL;
        if(magentaHiMaterial) magentaHiMaterial->releaseReference();
        magentaHiMaterial = NULL;
      }
      if(boomTexture) boomTexture->releaseReference();
      boomTexture = zip.getTexture("boom.jpg")->acquireReference();
      if(shadowTexture) shadowTexture->releaseReference();
      DRImage* shadowImage = zip.getImage("shadow.png");
      shadowImage->convertGray2111A();
      shadowTexture = new GLTexture(*shadowImage)->acquireReference();
      delete shadowImage;
      if(flash) delete flash;
      flash = zip.getModel("flash.mdx","flash.jpg");
    }
    /// bsp
    if(newLevel) {
      String levelName(
        Game::optioTexts->getElement(TXT_LEVEL)->getText(),".bsx"
      );
      bsp = zip.getLevel(levelName.getText(),2.5f);
      bsp->setShadowed(areEffectsEnabled);
      bsp->setStaticLightDirection(0,0.64278761f,0.76604444f);
      bsp->setShadowsStatic(true);
      bsp->setShowUntexturedMeshes(true);
      bsp->setShowUntexturedPatches(true);
      bsp->setDefaultTexture(
        zip.getTexture("textures/guntactyx/bricks.jpg",true)
      );
      bsp->setVisible(true);
      getWorld().setScenery(bsp);
      getOverlay().removeOverlayObject(mapOverlay);
      String mapName(Game::optioTexts->getElement(TXT_LEVEL)->getText(),".png");
      DRImage* mapImage = zip.getPngImage(mapName.getText());
      mapImage->addAlpha(92);
      mapOverlay = new GTOverlayArenaMap(new GLTexture(*mapImage));
      delete mapImage;
      getOverlay().addOverlayObject(mapOverlay);
    }
  } catch(Exception& e) {
    showError("Error Loading DAT File");
  }
  }
  if(newScript) {
    if(!Game::optioTexts->getElement(TXT_SCRIPT)->equals("NONE")) {
      char* scriptName = Game::optioTexts->getElement(TXT_SCRIPT)->getText();
      char* fileName = new char[7+strlen(scriptName)+5];
      strcat(strcat(strcpy(fileName,"engine\\"),scriptName),".amx");
      interpreter.load(fileName);
      delete fileName;
      interpreter.findPublic("initialize",&Game::ENGINE_SCRIPT_INITIALIZE);
      interpreter.findPublic("finalize",&Game::ENGINE_SCRIPT_FINALIZE);
      interpreter.findPublic("keydown",&Game::ENGINE_SCRIPT_KEYDOWN);
      interpreter.findPublic("update",&Game::ENGINE_SCRIPT_UPDATE);
      interpreter.findPublic("step",&Game::ENGINE_SCRIPT_STEP);
      interpreter.execNoStop(AMX_EXEC_MAIN);
    } else {
      interpreter.unload();
      Game::ENGINE_SCRIPT_INITIALIZE = -1;
      Game::ENGINE_SCRIPT_FINALIZE = -1;
      Game::ENGINE_SCRIPT_KEYDOWN = -1;
      Game::ENGINE_SCRIPT_UPDATE = -1;
      Game::ENGINE_SCRIPT_STEP = -1;
    }
  }
}

bool Game::keyDownEventSound(GLWin& glWin, int key) {
  switch(key) {
    case 'M': {
      glWin.keyUp('M');
      Game::isMusicEnabled = !Game::isMusicEnabled;
      if(Game::isMusicEnabled) {
        if(Game::soundTrack) {
          Game::soundTrack->setLooping(true);
          Game::soundTrack->play();
        }
      } else {
        if(Game::soundTrack) {
          Game::soundTrack->setLooping(false);
          Game::soundTrack->stop();
        }
      }
      break;
    }
    case 'S': {
      glWin.keyUp('S');
      Game::isSoundEnabled = !Game::isSoundEnabled;
      break;
    }
    default:
      return false;
  }
  return true;
}

void Game::getOptioString(char* buf, char* cmp, char* res) {
  char* line = strstr(buf,cmp);
  if(line) {
    char* s = res;
    for(
      line += strlen(cmp);
      *line != '\r' && *line != '\n' && *line != '\0';
      line++, s++
    ) *s = *line;
    *s = '\0';
  } else
    *res = '\0';
}

bool Game::setupTeams() {
  if(getPlaylistFile()) {
    const int BUF_LEN = 1023;
    char line[BUF_LEN+1];
    char* theLine = line;
    if(fgets(line,BUF_LEN,getPlaylistFile())) {
      int len = strlen(line);
      if(len == 0)
        return false;
      line[len-1] = '\0';
      for(int ct = 0; ct < Game::teamsCount; ct++) {
        char* name = strtok(theLine,",");
        Game::introTexts->getElement(ct)->setText(name);
        Game::fightTexts->getElement(ct)->setText(name);
        int corner = atoi(strtok(theLine = NULL,","));
        Game::corners[ct] = corner;
      }
    } else {
      return false;
    }
  } else {
    int idx[4];
    setupTeamIndexes(idx);
    for(int ct = 0; ct < Game::teamsCount; ct++) {
      char* txt = Game::botScriptNames.getElement(idx[ct])->getText();
      Game::introTexts->getElement(ct)->setText(txt);
      Game::fightTexts->getElement(ct)->setText(txt);
    }
  }
  return true;
}

void Game::setupDefaultTeams() {
  int idx[4];
  setupTeamIndexes(idx);
  for(int ct = 0; ct < 4; ct++) {
    char* txt = Game::botScriptNames.getElement(idx[ct])->getText();
    Game::optioTexts->getElement(TXT_TEAM_A+ct)->setText(txt);
    Game::introTexts->getElement(ct)->setText(txt);
    Game::fightTexts->getElement(ct)->setText(txt);
  }
}

bool Game::scriptExists(char* scriptName) {
  for(int ct = 0; ct < Game::botScriptNames.getSize(); ct++) {
    if(strcmp(Game::botScriptNames.getElement(ct)->getText(),scriptName) == 0)
      return true;
  }
  return false;
}

void Game::loadLevels() {
  String zipName(Game::optioTexts->getElement(TXT_PACKAGE)->getText(),".dat");
  DRZipFile zip(zipName.getText());
  Game::levelNames.deleteElements();
  const int MAX_STRING_LENGTH = 127;
  char string[MAX_STRING_LENGTH+1];
  bool ret = zip.gotoFirstFile();
  if(ret) {
    do {
      zip.getZippedFileName(string,MAX_STRING_LENGTH);
      if(strstr(string,".bsx"))
        Game::levelNames.addElement(new String(strtok(string,".")));
      ret = zip.gotoNextFile();
    } while(ret);
    Game::optioTexts->getElement(TXT_LEVEL)->setText(
      Game::levelNames.getElement(0)->getText()
    );
  } else {
    Game::optioTexts->getElement(TXT_LEVEL)->setText("");
  }
}

//
// GLWin
//

GLWin* GLWin::newInstance(char* initStr) throw(ExceptionThrown) {
  return new Game(initStr);
}
