#ifndef GLOBJECT_H
#define GLOBJECT_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include <stddef.h> // for NULL

#include "glcamera.h"
#include "datasets.h"

class GLShadowedDelegate;

//
// GLClip
//
class GLClip {
protected:
  bool clipped;
  float distance;
  float maxRadius;
public:
  GLClip();
  void setMaxRadius(float rd) {maxRadius = rd;}
  float getMaxRadius() {return maxRadius;}
  bool isClipped() {return clipped;}
  void setClipped(bool c) {clipped = c;}
  float getDistance() {return distance;}
  virtual bool clip(GLCamera& camera, M3Matrix* parentTransform = NULL) = 0;
};

//
// GLVisible
//
class GLVisible {
protected:
  bool visible;
public:
  GLVisible();
  void setVisible(bool v) {visible = v;}
  bool isVisible() {return visible;}
};

//
// GLObject
//
class GLObject:
  public M3Reference, public GLClip, public DSSortableObject, public GLVisible
{
protected:
  bool transparent;
  bool scaled;
public:
  GLObject();
  virtual ~GLObject();
  void setTransparent(bool t) {transparent = t;}
  bool isTransparent() const {return transparent;}
  bool isScaled() {return scaled;}
  void setScaled(bool v) {scaled = v;}
  bool includes(float x, float y, float z) {
    float dx = getPositionX()-x;
    float dy = getPositionY()-y;
    float dz = getPositionZ()-z;
    return dx*dx+dy*dy+dz*dz <= maxRadius*maxRadius;
  }
  bool includes(const M3Vector& vec)
    {return includes(vec.getX(),vec.getY(),vec.getZ());}
  float getSortIndex() {return getDistance();}
  virtual bool clip(GLCamera& camera, M3Matrix* parentTransform = NULL);
  virtual bool climbSkeleton(const char* tagName, M3Matrix& m) {return false;}
  virtual void castShadowSkeleton(
    int mode, M3Vector& dir, GLShadowedDelegate& sd,
    M3Matrix* parentTransform = NULL
  ) {castShadow(mode,dir,sd,parentTransform);}
  virtual void castShadowBone(
    int mode, M3Vector& dir, GLShadowedDelegate& sd,
    M3Matrix* parentTransform = NULL
  );
  virtual void castShadow(
    int mode, M3Vector& dir, GLShadowedDelegate& sd,
    M3Matrix* parentTransform = NULL
  );
  virtual void castPlanarShadow() {}
  virtual void castShadowVolume(M3Vector& dir) {}
  virtual void renderSkeleton(GLCamera& camera) {render(camera);}
  virtual void render(GLCamera& camera) = 0;
};

//
// GLObjects
//
class GLObjects: public GLObject {
private:
  DSList<GLObject> objects;
public:
  void addObject(GLObject* obj) {
    obj->setVisible(true); objects.addElement(obj);
    if(getMaxRadius() < obj->getMaxRadius()) setMaxRadius(obj->getMaxRadius());
  }
  GLObject* getFirstObject() {return objects.resetToFirstElement();}
  GLObject* getNextObject() {return objects.nextElement();}
  int getObjectsCount() {return objects.getLength();}
  bool clip(GLCamera& camera, M3Matrix* parentTransform = NULL);
  virtual void castShadow(
    int mode, M3Vector& dir, GLShadowedDelegate& sd,
    M3Matrix* parentTransform = NULL
  );
  virtual void render(GLCamera& camera);
};

//
// GLLod
//
class GLLod: public GLObject {
private:
  DSStaticArray<float> dists;
  DSArray<GLObject> levels;
public:
  GLLod();
  void addLevel(float dist, GLObject* obj) {
    obj->setVisible(true); levels.addElement(obj); dists.addElement(dist);
    if(getMaxRadius() < obj->getMaxRadius()) setMaxRadius(obj->getMaxRadius());
  }
  virtual void castShadow(
    int mode, M3Vector& dir, GLShadowedDelegate& sd,
    M3Matrix* parentTransform = NULL
  );
  virtual void render(GLCamera& camera);
};

#endif // GLOBJECT_H
