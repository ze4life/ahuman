#ifndef MATH3D_H
#define MATH3D_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include <math.h>

#include "void.h"

//
// typedefs
//
typedef float M3Float;
typedef double M3Double;

//
// M3tVector
//

template <class T> class M3tVector {
private:
  enum {X = 0, Y, Z};
  T vector[3];
public:
  M3tVector(T x = 0, T y = 0, T z = 0);
  M3tVector(const T* v);
  M3tVector(const M3tVector& v);
  T getX() const {return vector[X];}
  T getY() const {return vector[Y];}
  T getZ() const {return vector[Z];}
  T get(int index) const {return vector[index];}
  void setX(T x) {vector[X] = x;}
  void setY(T y) {vector[Y] = y;}
  void setZ(T z) {vector[Z] = z;}
  void set(int index, T value) {vector[index] = value;}
  M3tVector& set(T x = 0, T y = 0, T z = 0)
    {setX(x); setY(y); setZ(z); return *this;}
  M3tVector& set(const T* v)
    {setX(v[X]); setY(v[Y]); setZ(v[Z]); return *this;}
  M3tVector& set(const M3tVector& v)
    {return set(v.getX(),v.getY(),v.getZ());}
  bool isNotZero() const {return getX() != 0 || getY() != 0 || getZ() != 0;}
  bool isEqual(const M3tVector& v) const
    {return getX() == v.getX() && getY() == v.getY() && getZ() == v.getZ();}
  M3tVector& add(T x, T y, T z)
    {return set(getX()+x,getY()+y,getZ()+z);}
  M3tVector& add(const T* v)
    {return set(getX()+v[X],getY()+v[Y],getZ()+v[Z]);}
  M3tVector& add(const M3tVector& v)
    {return add(v.getX(),v.getY(),v.getZ());}
  M3tVector& add(const M3tVector& v1, const M3tVector& v2)
    {return set(v1.getX()+v2.getX(),v1.getY()+v2.getY(),v1.getZ()+v2.getZ());}
  M3tVector& subtract(T x, T y, T z)
    {return set(getX()-x,getY()-y,getZ()-z);}
  M3tVector& subtract(const T* v)
    {return set(getX()-v[X],getY()-v[Y],getZ()-v[Z]);}
  M3tVector& subtract(const M3tVector& v)
    {return subtract(v.getX(),v.getY(),v.getZ());}
  M3tVector& subtract(const M3tVector& v1, const M3tVector& v2)
    {return set(v1.getX()-v2.getX(),v1.getY()-v2.getY(),v1.getZ()-v2.getZ());}
  M3tVector& scale(T s)
    {return set(s*getX(),s*getY(),s*getZ());}
  T dot(const M3tVector& v) const
    {return getX()*v.getX()+getY()*v.getY()+getZ()*v.getZ();}
  M3tVector& cross(const M3tVector& v) {return cross(*this,v);}
  M3tVector& cross(const M3tVector& v1, const M3tVector& v2) {
    return set(
      v1.getY()*v2.getZ()-v1.getZ()*v2.getY(),
      v1.getZ()*v2.getX()-v1.getX()*v2.getZ(),
      v1.getX()*v2.getY()-v1.getY()*v2.getX()
    );
  }
  void plane(M3tVector& v1, M3tVector& v2) const {
    if(getZ() == 0) v1.set(0,0,1);
    else v1.set(1,1,-(getX()+getY())/getZ()).normalize();
    v2.cross(v1,*this).normalize();
  }
  T norm2() const {return getX()*getX()+getY()*getY()+getZ()*getZ();}
  T norm() const {return sqrt(norm2());}
  T dist2(const M3tVector<T>& v)
    {M3tVector<T> d = *this; return d.subtract(v).norm2();}
  T dist(const M3tVector<T>& v1) {return sqrt(dist2(v1));}
  M3tVector& normalize()
    {T n2 = norm2(); return n2 <= 0? *this: scale(1/sqrt(n2));}
  M3tVector& multiply(const T* m) {
    return set(
      getX()*m[4*0+0]+getY()*m[4*1+0]+getZ()*m[4*2+0]+m[4*3+0],
      getX()*m[4*0+1]+getY()*m[4*1+1]+getZ()*m[4*2+1]+m[4*3+1],
      getX()*m[4*0+2]+getY()*m[4*1+2]+getZ()*m[4*2+2]+m[4*3+2]
    );
  }
  M3tVector& rotate(const T* m) {
    return set(
      getX()*m[4*0+0]+getY()*m[4*1+0]+getZ()*m[4*2+0],
      getX()*m[4*0+1]+getY()*m[4*1+1]+getZ()*m[4*2+1],
      getX()*m[4*0+2]+getY()*m[4*1+2]+getZ()*m[4*2+2]
    );
  }
  M3tVector& rotateT(const T* m) {
    return set(
      getX()*m[4*0+0]+getY()*m[4*0+1]+getZ()*m[4*0+2],
      getX()*m[4*1+0]+getY()*m[4*1+1]+getZ()*m[4*1+2],
      getX()*m[4*2+0]+getY()*m[4*2+1]+getZ()*m[4*2+2]
    );
  }
  T* getArray() {return vector;}
};

typedef M3tVector<M3Float> M3Vector;

//
// M3tMatrix
//

template <class T> class M3tMatrix: virtual public Void {
protected:
  T matrix[16];
public:
  M3tMatrix(
    T m11 = 1, T m12 = 0, T m13 = 0, T m14 = 0,
    T m21 = 0, T m22 = 1, T m23 = 0, T m24 = 0,
    T m31 = 0, T m32 = 0, T m33 = 1, T m34 = 0,
    T m41 = 0, T m42 = 0, T m43 = 0, T m44 = 1
  );
  M3tMatrix(const M3tMatrix& m);
  M3tMatrix(T* m);
  M3tMatrix(const M3tVector<T>& v1, const M3tVector<T>& v2, const M3tVector<T>& v3);
  M3tMatrix& set(
    T m11 = 1, T m12 = 0, T m13 = 0, T m14 = 0,
    T m21 = 0, T m22 = 1, T m23 = 0, T m24 = 0,
    T m31 = 0, T m32 = 0, T m33 = 1, T m34 = 0,
    T m41 = 0, T m42 = 0, T m43 = 0, T m44 = 1
  ) {
    set11(m11); set12(m12); set13(m13); set14(m14);
    set21(m21); set22(m22); set23(m23); set24(m24);
    set31(m31); set32(m32); set33(m33); set34(m34);
    set41(m41); set42(m42); set43(m43); set44(m44);
    return *this;
  }
  M3tMatrix& set(const M3tMatrix& m) {
    return set(
      m.get11(), m.get12(), m.get13(), m.get14(),
      m.get21(), m.get22(), m.get23(), m.get24(),
      m.get31(), m.get32(), m.get33(), m.get34(),
      m.get41(), m.get42(), m.get43(), m.get44()
    );
  }
  M3tMatrix& set(const T* m) {
    return set(
      m[ 0], m[ 1], m[ 2], m[ 3],
      m[ 4], m[ 5], m[ 6], m[ 7],
      m[ 8], m[ 9], m[10], m[11],
      m[12], m[13], m[14], m[15]
    );
  }
  T get(int idx) const {return matrix[idx];}
  T get11() const {return matrix[0*4+0];}
  T get12() const {return matrix[0*4+1];}
  T get13() const {return matrix[0*4+2];}
  T get14() const {return matrix[0*4+3];}
  T get21() const {return matrix[1*4+0];}
  T get22() const {return matrix[1*4+1];}
  T get23() const {return matrix[1*4+2];}
  T get24() const {return matrix[1*4+3];}
  T get31() const {return matrix[2*4+0];}
  T get32() const {return matrix[2*4+1];}
  T get33() const {return matrix[2*4+2];}
  T get34() const {return matrix[2*4+3];}
  T get41() const {return matrix[3*4+0];}
  T get42() const {return matrix[3*4+1];}
  T get43() const {return matrix[3*4+2];}
  T get44() const {return matrix[3*4+3];}
  void set(int idx, T f) {matrix[idx] = f;}
  void set11(T f) {matrix[0*4+0] = f;}
  void set12(T f) {matrix[0*4+1] = f;}
  void set13(T f) {matrix[0*4+2] = f;}
  void set14(T f) {matrix[0*4+3] = f;}
  void set21(T f) {matrix[1*4+0] = f;}
  void set22(T f) {matrix[1*4+1] = f;}
  void set23(T f) {matrix[1*4+2] = f;}
  void set24(T f) {matrix[1*4+3] = f;}
  void set31(T f) {matrix[2*4+0] = f;}
  void set32(T f) {matrix[2*4+1] = f;}
  void set33(T f) {matrix[2*4+2] = f;}
  void set34(T f) {matrix[2*4+3] = f;}
  void set41(T f) {matrix[3*4+0] = f;}
  void set42(T f) {matrix[3*4+1] = f;}
  void set43(T f) {matrix[3*4+2] = f;}
  void set44(T f) {matrix[3*4+3] = f;}
  M3tMatrix& exchangeYZX() {
  T tempX(get11()), tempY(get12()), tempZ(get13());
    set11(get21()); set12(get22()); set13(get23());
    set21(get31()); set22(get32()); set23(get33());
    set31(tempX  ); set32(tempY  ); set33(tempZ  );
    return *this;
  }
  T* multiply(T* vec) const {
    T x = vec[0]*get11()+vec[1]*get21()+vec[2]*get31()+get41();
    T y = vec[0]*get12()+vec[1]*get22()+vec[2]*get32()+get42();
    T z = vec[0]*get13()+vec[1]*get23()+vec[2]*get33()+get43();
    vec[0] = x; vec[1] = y; vec[2] = z;
    return vec;
  }
  M3tVector<T>& multiply(M3tVector<T>& v) const {
    return v.set(
      v.getX()*get11()+v.getY()*get21()+v.getZ()*get31()+get41(),
      v.getX()*get12()+v.getY()*get22()+v.getZ()*get32()+get42(),
      v.getX()*get13()+v.getY()*get23()+v.getZ()*get33()+get43()
    );
  }
  M3tVector<T>& multiply(M3tVector<T>& res, const M3tVector<T>& vec) const
    {res = vec; return multiply(res);}
  M3tMatrix& multiply(const M3tMatrix& mat) {return multiply(*this,mat);}
  M3tMatrix& multiplyT(const M3tMatrix& mat) {return multiply(mat,*this);}
  M3tMatrix& multiply(const M3tMatrix& m1, const M3tMatrix& m2) {
    return set(
      m1.get11()*m2.get11()+m1.get12()*m2.get21()+m1.get13()*m2.get31(),
      m1.get11()*m2.get12()+m1.get12()*m2.get22()+m1.get13()*m2.get32(),
      m1.get11()*m2.get13()+m1.get12()*m2.get23()+m1.get13()*m2.get33(),
      0,
      m1.get21()*m2.get11()+m1.get22()*m2.get21()+m1.get23()*m2.get31(),
      m1.get21()*m2.get12()+m1.get22()*m2.get22()+m1.get23()*m2.get32(),
      m1.get21()*m2.get13()+m1.get22()*m2.get23()+m1.get23()*m2.get33(),
      0,
      m1.get31()*m2.get11()+m1.get32()*m2.get21()+m1.get33()*m2.get31(),
      m1.get31()*m2.get12()+m1.get32()*m2.get22()+m1.get33()*m2.get32(),
      m1.get31()*m2.get13()+m1.get32()*m2.get23()+m1.get33()*m2.get33(),
      0,
      m1.get41()*m2.get11()+m1.get42()*m2.get21()+m1.get43()*m2.get31()
      +m2.get41(),
      m1.get41()*m2.get12()+m1.get42()*m2.get22()+m1.get43()*m2.get32()
      +m2.get42(),
      m1.get41()*m2.get13()+m1.get42()*m2.get23()+m1.get43()*m2.get33()
      +m2.get43(),
      1
    );
  }
  M3tMatrix& scale(T s) {
    return set(
      get11()*s,get12()*s,get13()*s,0,
      get21()*s,get22()*s,get23()*s,0,
      get31()*s,get32()*s,get33()*s,0,
      get41()  ,get42()  ,get43()  ,1
    );
  }
  M3tMatrix& scale(M3tVector<T>& s) {
    return set(
      get11()*s.getX(),get12()*s.getY(),get13()*s.getZ(),0,
      get21()*s.getX(),get22()*s.getY(),get23()*s.getZ(),0,
      get31()*s.getX(),get32()*s.getY(),get33()*s.getZ(),0,
      get41()  ,get42()  ,get43()  ,1
    );
  }
  T* rotate(T* vec) const {
    T x = vec[0]*get11()+vec[1]*get21()+vec[2]*get31();
    T y = vec[0]*get12()+vec[1]*get22()+vec[2]*get32();
    T z = vec[0]*get13()+vec[1]*get23()+vec[2]*get33();
    vec[0] = x; vec[1] = y; vec[2] = z;
    return vec;
  }
  M3tMatrix& rotate(const M3tMatrix& mat) {return rotate(*this,mat);}
  M3tMatrix& rotate(const M3tMatrix& m1, const M3tMatrix& m2) {
    return set(
      m1.get11()*m2.get11()+m1.get12()*m2.get21()+m1.get13()*m2.get31(),
      m1.get11()*m2.get12()+m1.get12()*m2.get22()+m1.get13()*m2.get32(),
      m1.get11()*m2.get13()+m1.get12()*m2.get23()+m1.get13()*m2.get33(),
      0,
      m1.get21()*m2.get11()+m1.get22()*m2.get21()+m1.get23()*m2.get31(),
      m1.get21()*m2.get12()+m1.get22()*m2.get22()+m1.get23()*m2.get32(),
      m1.get21()*m2.get13()+m1.get22()*m2.get23()+m1.get23()*m2.get33(),
      0,
      m1.get31()*m2.get11()+m1.get32()*m2.get21()+m1.get33()*m2.get31(),
      m1.get31()*m2.get12()+m1.get32()*m2.get22()+m1.get33()*m2.get32(),
      m1.get31()*m2.get13()+m1.get32()*m2.get23()+m1.get33()*m2.get33(),
      0,
      m1.get41(),m1.get42(),m1.get43(),1
    );
  }
  M3tMatrix& rotateC(const M3tMatrix& mat) {return rotateC(*this,mat);}
  M3tMatrix& rotateC(const M3tMatrix& m1, const M3tMatrix& m2) {
    return set(
      m2.get11()*m1.get11()+m2.get12()*m1.get21()+m2.get13()*m1.get31(),
      m2.get11()*m1.get12()+m2.get12()*m1.get22()+m2.get13()*m1.get32(),
      m2.get11()*m1.get13()+m2.get12()*m1.get23()+m2.get13()*m1.get33(),
      0,
      m2.get21()*m1.get11()+m2.get22()*m1.get21()+m2.get23()*m1.get31(),
      m2.get21()*m1.get12()+m2.get22()*m1.get22()+m2.get23()*m1.get32(),
      m2.get21()*m1.get13()+m2.get22()*m1.get23()+m2.get23()*m1.get33(),
      0,
      m2.get31()*m1.get11()+m2.get32()*m1.get21()+m2.get33()*m1.get31(),
      m2.get31()*m1.get12()+m2.get32()*m1.get22()+m2.get33()*m1.get32(),
      m2.get31()*m1.get13()+m2.get32()*m1.get23()+m2.get33()*m1.get33(),
      0,
      m1.get41(),m1.get42(),m1.get43(),1
    );
  }
  T* getArray() {return matrix;}
};

typedef M3tMatrix<M3Float> M3Matrix;

//
// M3tRotationX
//
template <class T> class M3tRotationX: public M3tMatrix<T> {
public:
  M3tRotationX(T angle);
};

typedef M3tRotationX<M3Float> M3RotationX;

//
// M3RotationY
//
template <class T> class M3tRotationY: public M3tMatrix<T> {
public:
  M3tRotationY(T angle);
};

typedef M3tRotationY<M3Float> M3RotationY;

//
// M3RotationZ
//
template <class T> class M3tRotationZ: public M3tMatrix<T> {
public:
  M3tRotationZ(T angle);
};

typedef M3tRotationZ<M3Float> M3RotationZ;

//
// M3tReference
//
template <class T> class M3tReference: public M3tMatrix<T> {
protected:
  enum {
    SIDE =  0, SIDEx =  0, SIDEy, SIDEz, SIDE_,
    UP   =  4, UPx   =  4, UPy,   UPz,   UP_,
    VIEW =  8, VIEWx =  8, VIEWy, VIEWz, VIEW_,
    POS  = 12, POSx  = 12, POSy,  POSz,  POS_,
  };
public:
  void move(T dx, T dy, T dz)
    {set(POSx,get(POSx)+dx); set(POSy,get(POSy)+dy); set(POSz,get(POSz)+dz);}
  void move(M3tVector<T>& step)
    {move(step.getX(),step.getY(),step.getZ());}
  void moveForward(T step)
    {M3tVector<T> dir(get(VIEWx),get(VIEWy),get(VIEWz)); move(dir.scale(step));}
  void moveSide(T step)
    {M3tVector<T> dir(get(SIDEx),get(SIDEy),get(SIDEz)); move(dir.scale(step));}
  void moveUp(T step)
    {M3tVector<T> dir(get(UPx),get(UPy),get(UPz)); move(dir.scale(step));}
  void moveStanding(T step) {
    M3tVector<T> dir(get(VIEWx),0,get(VIEWz));
    move(dir.normalize().scale(step));
  }
  void roll(T angle) {M3tRotationZ<T> rotZ(angle); rotateC(rotZ);}
  void yaw(T angle) {M3tRotationY<T> rotY(angle); rotateC(rotY);}
  void pitch(T angle) {M3tRotationX<T> rotX(angle); rotateC(rotX);}
  void rotateStanding(T angle) {M3tRotationY<T> rotY(angle); rotate(rotY);}
  void pointTo(T posX, T posY, T posZ) {
    M3tVector<T> dir(posX-get(POSx),posY-get(POSy),posZ-get(POSz));
    setViewDirection(dir.normalize());
    if(dir.getX() == 0 && dir.getZ() == 0) {
      setSideDirection(1,0,0);
      setUpDirection(0,0,dir.getZ() < 0? 1: -1);
    } else {
      M3tVector<T> up(0,1,0);
      setSideDirection(dir.cross(up,dir).normalize());
      M3tVector<T> view = getViewDirection();
      setUpDirection(dir.cross(view,dir));
    }
  }
  T* getPositionArray() {return &matrix[POS];}
  M3tVector<T> getPosition()
    {return M3tVector<T>(get(POSx),get(POSy),get(POSz));}
  T getPositionX() {return get(POSx);}
  T getPositionY() {return get(POSy);}
  T getPositionZ() {return get(POSz);}
  void setPosition(M3tVector<T>& v)
    {set(POSx,v.getX()); set(POSy,v.getY()); set(POSz,v.getZ());}
  void setPosition(T x, T y, T z)
    {set(POSx,x); set(POSy,y); set(POSz,z);}
  void setPositionX(T x) {set(POSx,x);}
  void setPositionY(T y) {set(POSy,y);}
  void setPositionZ(T z) {set(POSz,z);}
  T* getViewDirectionArray() {return &matrix[VIEW];}
  M3tVector<T> getViewDirection()
    {return M3tVector<T>(get(VIEWx),get(VIEWy),get(VIEWz));}
  T getViewDirectionX() {return get(VIEWx);}
  T getViewDirectionY() {return get(VIEWy);}
  T getViewDirectionZ() {return get(VIEWz);}
  void setViewDirection(T x, T y, T z)
    {set(VIEWx,x); set(VIEWy,y); set(VIEWz,z);}
  void setViewDirection(M3tVector<T>& v)
    {set(VIEWx,v.getX()); set(VIEWy,v.getY()); set(VIEWz,v.getZ());}
  T* getUpDirectionArray() {return &matrix[UP];}
  M3tVector<T> getUpDirection()
    {return M3tVector<T>(get(UPx),get(UPy),get(UPz));}
  T getUpDirectionX() {return get(UPx);}
  T getUpDirectionY() {return get(UPy);}
  T getUpDirectionZ() {return get(UPz);}
  void setUpDirection(T x, T y, T z)
    {set(UPx,x); set(UPy,y); set(UPz,z);}
  void setUpDirection(M3tVector<T>& v)
    {set(UPx,v.getX()); set(UPy,v.getY()); set(UPz,v.getZ());}
  T* getSideDirectionArray() {return &matrix[SIDE];}
  M3tVector<T> getSideDirection()
    {return M3tVector<T>(get(SIDEx),get(SIDEy),get(SIDEz));}
  T getSideDirectionX() {return get(SIDEx);}
  T getSideDirectionY() {return get(SIDEy);}
  T getSideDirectionZ() {return get(SIDEz);}
  void setSideDirection(T x, T y, T z)
    {set(SIDEx,x); set(SIDEy,y); set(SIDEz,z);}
  void setSideDirection(M3tVector<T>& v)
    {set(SIDEx,v.getX()); set(SIDEy,v.getY()); set(SIDEz,v.getZ());}
  void transform(T x, T y, T z, T theta, T phi, T rho);
  void transform(M3tVector<T>& pos, M3tVector<T>& rot) {
    transform(
      pos.getX(),pos.getY(),pos.getZ(),rot.getX(),rot.getY(),rot.getZ()
    );
  }
  void approxTransform(T x, T y, T z, T theta, T phi, T rho);
  void approxTransform(M3tVector<T>& pos, M3tVector<T>& rot) {
    approxTransform(
      pos.getX(),pos.getY(),pos.getZ(),rot.getX(),rot.getY(),rot.getZ()
    );
  }
  T* getTransform() {return getArray();}
};

typedef M3tReference<M3Float> M3Reference;

//
// M3tQuaternion
//
template <class T> class M3tQuaternion {
protected:
    T x, y, z, w;
public:
  M3tQuaternion(T* rot, int side = 3);
  M3tQuaternion& slerp(M3tQuaternion& target, T interpol);
  M3tQuaternion& slerpAccurate(M3tQuaternion& target, T interpol);
  T* fillArray(T* matrixPointer) { // 4x4
    T xx = x*x; T yy = y*y; T zz = z*z; T ww = w*w; T xy = x*y;
    T xz = x*z; T xw = x*w; T yz = y*z; T yw = y*w; T zw = z*w;
    matrixPointer[ 0] = 1-2*(yy+zz);
      matrixPointer[ 1] = 2*(xy-zw);
    matrixPointer[ 2] = 2*(xz+yw);
      matrixPointer[ 3] = 0;
    matrixPointer[ 4] = 2*(xy+zw);
    matrixPointer[ 5] = 1-2*(xx+zz);
    matrixPointer[ 6] = 2*(yz-xw);
    matrixPointer[ 7] = 0;
    matrixPointer[ 8] = 2*(xz-yw);
    matrixPointer[ 9] = 2*(yz+xw);
    matrixPointer[10] = 1-2*(xx+yy);
    matrixPointer[11] = 0;
    matrixPointer[12] = 0;
    matrixPointer[13] = 0;
    matrixPointer[14] = 0;
    matrixPointer[15] = 1;
    return matrixPointer;
  }
};

typedef M3tQuaternion<M3Float> M3Quaternion;

#endif //MATH3D_H
