/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gtoverlay.h"

#include "gtsim.h"

#include <stdlib.h> // for itoa()

//
// GTOverlayArenaData
//

GTOverlayArenaData::GTOverlayArenaData(GLFont* f, GTArena* a):
  arena(a), font(f->acquireReference())
{}

GTOverlayArenaData::~GTOverlayArenaData() {
  if(font) font->releaseReference();
}

void GTOverlayArenaData::render(GLCamera& camera) {
  if(arena == NULL) return;
  glPushMatrix();
  glEnable(GL_DEPTH_TEST);
  font->initialize();
  bool isFontTextured = font->isTextured();
  if(isFontTextured) {
    ((GLTexturedFont*)font)->applyTexture();
    glEnable(GL_ALPHA_TEST);
  } else {
    glDisable(GL_TEXTURE_2D);
  }
  double* modelMatrix = camera.getModelMatrix();
  double* projectionMatrix = camera.getProjectionMatrix();
  GLint viewport[4];
  glGetIntegerv(GL_VIEWPORT,viewport);
  const int TEXT_LENGTH = 16;
  char text[TEXT_LENGTH];
  for(int ct = 0; ct < arena->getItemsSize(); ct++) {
    GTItem* item = arena->getItem(ct);
    if(item == NULL)
      continue;
    switch(item->getClassID()) {
    case ID_ITEM_WARRIOR: {
      GTBot* bot = dynamic_cast<GTBot*>(item);
      GLTeamMate* tm = bot->getTeamMate();
      if((!tm->isDead()) && (!tm->isClipped()) && (tm->isVisible())) {
        double winX, winY, winZ;
        gluProject(
          bot->getX(),bot->getY()+GTBot::SIZE_Y+GTWeapon::HEIGHT,bot->getZ(),
          modelMatrix,projectionMatrix,viewport,
          &winX,&winY,&winZ
        );
        float posX =  (float)winX;
        float posY =  (float)winY;
        float posZ = -(float)winZ;
        posZ =
          posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
          camera.getClipPlaneNear();
        switch(bot->getTeamID()) {
          case 0: font->setColor(0.75f,1,0.75f); break;
          case 1: font->setColor(1,0.75f,0.25f); break;
          case 2: font->setColor(0.25f,0.75f,1); break;
          case 3: font->setColor(0.75f,0.25f,1); break;
        }
        font->setPosition(posX,posY,posZ);
        font->drawText(8,"bombs : ");
        int bombs = bot->getGrenadesCount();
        itoa(bombs,text,10);
        font->drawText(strlen(text),text);
        font->setPosition(posX,posY += font->getHeight(),posZ);
        font->drawText(8,"shots : ");
        int shots = (int)bot->getBulletsCount();
        itoa(shots,text,10);
        font->drawText(strlen(text),text);
        if(bot->getArmor() > 0) {
          font->setPosition(posX,posY += font->getHeight(),posZ);
          font->drawText(8,"armor : ");
          int armor = (int)bot->getArmor();
          itoa(armor,text,10);
          font->drawText(strlen(text),text);
        }
        font->setPosition(posX,posY += font->getHeight(),posZ);
        font->drawText(8,"energy: ");
        int energy = (int)bot->getEnergy();
        itoa(energy,text,10);
        font->drawText(strlen(text),text);
        font->setPosition(posX,posY += font->getHeight(),posZ);
        font->drawText(8,"health: ");
        int health = (int)bot->getHealth();
        itoa(health,text,10);
        font->drawText(strlen(text),text);
        font->setPosition(posX,posY += font->getHeight(),posZ);
        font->drawText(8,"kills : ");
        int kills = (int)bot->getKilledEnemies();
        itoa(kills,text,10);
        font->drawText(strlen(text),text);
        posY += font->getHeight();
        if(bot->isSaying()) {
          font->setPosition(posX,posY,posZ);
          font->drawText(5,"say: ");
          int what = bot->getTalkingAbout();
          itoa(what,text,16);
          font->drawText(strlen(text),text);
        }
        font->setPosition(posX,posY += font->getHeight(),posZ);
        font->drawText(4,"ID: ");
        int id = bot->getMateID();
        itoa(id,text,10);
        font->drawText(strlen(text),text);
      }
      break;
    }
    case ID_ITEM_MEDIKIT: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(item);
      if(p->isExhausted() || !p->isActive()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(9,"medikit: ");
      itoa(p->getValue(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_FOOD: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(item);
      if(p->isExhausted() || !p->isActive()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(6,"food: ");
      itoa(p->getValue(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_ARMOR: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(item);
      if(p->isExhausted() || !p->isActive()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(7,"armor: ");
      itoa(p->getValue(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_BULLETS: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(item);
      if(p->isExhausted() || !p->isActive()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(7,"shots: ");
      itoa(p->getValue(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_GRENADES: {
      GTPowerup* p = dynamic_cast<GTPowerup*>(item);
      if(p->isExhausted() || !p->isActive()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(7,"bombs: ");
      itoa(p->getValue(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_WEAPON: {
      GTWeapon* p = dynamic_cast<GTWeapon*>(item);
      if(p->isExhausted()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(7,"bombs: ");
      itoa(p->getGrenadesCount(),text,10);
      font->drawText(strlen(text),text);
      font->setPosition(posX,posY += font->getHeight(),posZ);
      font->drawText(7,"shots: ");
      itoa(p->getBulletsCount(),text,10);
      font->drawText(strlen(text),text);
      break;
    }
    case ID_ITEM_SIGN: {
      GTSign* p = dynamic_cast<GTSign*>(item);
      if(p->isExhausted()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X*2,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(4,"sign");
      break;
    }
    case ID_ITEM_TARGET: {
      GTTarget* p = dynamic_cast<GTTarget*>(item);
      if(p->isExhausted()) continue;
      double winX, winY, winZ;
      gluProject(
        p->getX(),p->getY()+GTBot::SIZE_X*2,p->getZ(),
        modelMatrix,projectionMatrix,viewport,
        &winX,&winY,&winZ
      );
      float posX =  (float)winX;
      float posY =  (float)winY;
      float posZ = -(float)winZ;
      posZ =
        posZ*(camera.getClipPlaneFar()-camera.getClipPlaneNear())+
        camera.getClipPlaneNear();
      font->setColor(1,1,1);
      font->setPosition(posX,posY,posZ);
      font->drawText(6,"target");
      break;
    }
    }
  }
  if(isFontTextured) {
    glDisable(GL_ALPHA_TEST);
  } else {
    glEnable(GL_TEXTURE_2D);
  }
  glDisable(GL_DEPTH_TEST);
  glPopMatrix();
}

//
// GTOverlayArenaMap
//

GTOverlayArenaMap::GTOverlayArenaMap(GLTexture* t, GTArena* a):
  arena(a), texture(t->acquireReference())
{}

GTOverlayArenaMap::~GTOverlayArenaMap() {
  if(texture) texture->releaseReference();
}

void GTOverlayArenaMap::render(GLCamera& camera) {
  if(arena == NULL) return;
  glPushMatrix();
  GLint viewport[4];
  glGetIntegerv(GL_VIEWPORT,viewport);
  float centerX = float(viewport[0]+viewport[2]/2);
  float centerY = float(viewport[1]+viewport[3]/2);
  const float VIEW = viewport[3];
  const float SCALE = VIEW*(0.5f/GTArena::ARENA_SIZE);
  glTranslatef(centerX,centerY,0);
  float angle = acos(camera.getHorizontalViewX())*180*float(1/M_PI);
  if(camera.getHorizontalViewZ() < 0)
    angle = -angle;
  glRotatef(angle,0,0,1);
  glTranslatef(-camera.getPositionZ()*SCALE,-camera.getPositionX()*SCALE,0);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  const float VIEW_4 = VIEW/4;
  glColor3f(1,1,1);
  texture->apply();
  const int VERTEXES_COUNT = 4;
  float arrays[(2+3)*VERTEXES_COUNT] = {
    0,0,-VIEW_4,-VIEW_4,0,
    1,0, VIEW_4,-VIEW_4,0,
    1,1, VIEW_4, VIEW_4,0,
    0,1,-VIEW_4, VIEW_4,0
  };
  glInterleavedArrays(GL_T2F_V3F,0,arrays);
  glDrawArrays(GL_QUADS,0,VERTEXES_COUNT);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisable(GL_TEXTURE_2D);
  glDisable(GL_BLEND);
  for(int ct = 0; ct < arena->getItemsSize(); ct++) {
    GTItem* item = arena->getItem(ct);
    if(item == NULL)
      continue;
    switch(item->getClassID()) {
      case ID_ITEM_WARRIOR: {
        GTBot* bot = dynamic_cast<GTBot*>(item);
        if(!bot->isDead()) {
           switch(bot->getTeamID()) {
            case 0: glColor3f(0.75f,1,0.75f); break;
            case 1: glColor3f(1,0.75f,0.25f); break;
            case 2: glColor3f(0.25f,0.75f,1); break;
            case 3: glColor3f(0.75f,0.25f,1); break;
          }
          float y = bot->getX()*SCALE;
          float x = bot->getZ()*SCALE;
          const float RECT_SIZE = 2;
          glRectf(x-RECT_SIZE,y-RECT_SIZE,x+RECT_SIZE,y+RECT_SIZE);
        }
        break;
      }
      case ID_ITEM_BULLET: {
        GTBullet* bullet = dynamic_cast<GTBullet*>(item);
        if(!bullet->isExhausted()) {
          glColor3f(1,1,0.5f);
          float y = bullet->getX()*SCALE;
          float x = bullet->getZ()*SCALE;
          const float RECT_SIZE = 1;
          glRectf(x-RECT_SIZE,y-RECT_SIZE,x+RECT_SIZE,y+RECT_SIZE);
        }
        break;
      }
      case ID_ITEM_GRENADE: {
        GTGrenade* grenade = dynamic_cast<GTGrenade*>(item);
        if(!grenade->isExhausted()) {
          glColor3f(1,0.25f,0);
          float y = grenade->getX()*SCALE;
          float x = grenade->getZ()*SCALE;
          const float RECT_SIZE = 1;
          glRectf(x-RECT_SIZE,y-RECT_SIZE,x+RECT_SIZE,y+RECT_SIZE);
        }
        break;
      }
      case ID_ITEM_WEAPON:
      case ID_ITEM_TARGET:
      case ID_ITEM_SIGN:
      {
        GTExhaustable* p = dynamic_cast<GTExhaustable*>(item);
        if(!p->isExhausted()) {
          glColor3f(1,1,1);
          float y = p->getX()*SCALE;
          float x = p->getZ()*SCALE;
          const float RECT_SIZE = 1;
          glRectf(x-RECT_SIZE,y-RECT_SIZE,x+RECT_SIZE,y+RECT_SIZE);
        }
        break;
      }
      case ID_ITEM_MEDIKIT:
      case ID_ITEM_FOOD:
      case ID_ITEM_ARMOR:
      case ID_ITEM_BULLETS:
      case ID_ITEM_GRENADES:
      {
        GTExhaustable* p = dynamic_cast<GTExhaustable*>(item);
        if(!p->isExhausted()) {
          glColor3f(0.5f,1,1);
          float y = p->getX()*SCALE;
          float x = p->getZ()*SCALE;
          const float RECT_SIZE = 1;
          glRectf(x-RECT_SIZE,y-RECT_SIZE,x+RECT_SIZE,y+RECT_SIZE);
        }
        break;
      }
    }
  }
  glColor3f(1,1,0);
  const float CAM_SIZE = 2;
  glRectf(
    camera.getPositionZ()*SCALE-CAM_SIZE,
    camera.getPositionX()*SCALE-CAM_SIZE,
    camera.getPositionZ()*SCALE+CAM_SIZE,
    camera.getPositionX()*SCALE+CAM_SIZE
  );
  glEnable(GL_TEXTURE_2D);
  glPopMatrix();
}

