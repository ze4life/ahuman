/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glshadow.h"

#include "math3d.inc"
#include "datasets.inc"

//
// GLShadowedDelegate
//
GLShadowedDelegate::GLShadowedDelegate(): shadowedDelegator(NULL) {}

//
// GLShadowed
//
GLShadowed::GLShadowed():
  shadowed(false), shadowsStatic(false), staticLightDirection(0,1,0),
  offset(0), fadeDistance(0), invFadeDistance(1), intensity(0.5f)
{
  setShadowedDelegator(this);
}

GLShadowedDelegate* GLShadowed::getShadowedDelegate(float x, float y, float z) {
  for(int ct = 0; ct < delegates.getSize(); ct++) {
    GLShadowedDelegate* sd = delegates.getElement(ct);
    if(sd->includes(x,y,z))
      return sd;
  }
  return this;
}

//
// GLShadow
//
GLShadow::GLShadow(GLObject& obj, float w, float h, GLTexture* txt):
  halfWidth(w*0.5f), halfHeight(h*0.5f), maxRadius(0),
  object(&obj), texture(NULL), mode(PLANAR_SHADOW)
{
  if(txt) {
    texture = txt->acquireReference();
    mode = QUAD_SHADOW;
  }
}

GLShadow::~GLShadow() {
  if(texture)
    texture->releaseReference();
}

bool GLShadow::checkClip(GLCamera& camera) {
  M3Vector& pos = object->getPosition();
  float posX = pos.getX();
  float posY = pos.getY();
  float posZ = pos.getZ();
  for(int ct = 0; ct < 6; ct++)
    if(camera.dot(ct,posX,posY,posZ) <= -getMaxRadius())
      return true;
  return false;
}

void GLShadow::cast(GLCamera& camera, GLShadowed& shadowed) {
  float x = getPositionX();
  float y = getPositionY();
  float z = getPositionZ();
  GLShadowedDelegate* sd = shadowed.getShadowedDelegate(x,y,z);
  M3Vector dir;
  if(shadowed.areShadowsStatic())
    dir = shadowed.getStaticLightDirection();
  else if(shadowed.getDynamicLightDirection(dir))
    ;
  else if(camera.isNearestLightDirectional())
    dir = camera.getNearestLightVector();
  else
    dir.set(0,1,0);
  switch(getMode()) {
    case GLShadow::QUAD_SHADOW: {
      M3Vector normal;
      M3Vector planePos(x,y,z);
      sd->getPlane(planePos,dir,normal);
      float h = y-planePos.getY();
      x = planePos.getX();
      y = planePos.getY()+shadowed.getShadowOffset();
      z = planePos.getZ();
      if(shadowed.getShadowFadeDistance() > 0) {
        float fade =
          (shadowed.getShadowFadeDistance()-h)*
          shadowed.getInvShadowFadeDistance();
        if(fade <= 0)
          return;
        glColor4f(0,0,0,fade);
      } else {
        glColor3f(0,0,0);
      }
      glDisable(GL_CULL_FACE);
      glDepthMask(GL_FALSE);
      glEnable(GL_BLEND);
      glEnable(GL_ALPHA_TEST);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
      glDisable(GL_LIGHTING);
      GLTexture* tex = getTexture();
      if(tex)
        tex->apply();
      else
        glDisable(GL_TEXTURE_2D);
      M3Vector U(0,-normal.getZ(),normal.getY());
      U.normalize();
      M3Vector S(
        U.getY()*normal.getZ()-U.getZ()*normal.getY(),
        U.getZ()*normal.getX(), -U.getY()*normal.getX()
      );
      U.scale(getHalfWidth());
      S.scale(getHalfWidth());
      const int VERTEXES_COUNT = 4;
      float arrays[(2+3)*VERTEXES_COUNT] = {
        0,0, x-S.getX()-U.getX(),y-S.getY()-U.getY(),z-S.getZ()-U.getZ(),
        1,0, x+S.getX()-U.getX(),y+S.getY()-U.getY(),z+S.getZ()-U.getZ(),
        1,1, x+S.getX()+U.getX(),y+S.getY()+U.getY(),z+S.getZ()+U.getZ(),
        0,1, x-S.getX()+U.getX(),y-S.getY()+U.getY(),z-S.getZ()+U.getZ(),
      };
      glInterleavedArrays(GL_T2F_V3F,0,arrays);
      glDrawArrays(GL_QUADS,0,VERTEXES_COUNT);
      glDisableClientState(GL_TEXTURE_COORD_ARRAY);
      glDisableClientState(GL_VERTEX_ARRAY);
      glEnable(GL_CULL_FACE);
      glDisable(GL_ALPHA_TEST);
      glDisable(GL_BLEND);
      if(!tex)
        glEnable(GL_TEXTURE_2D);
      glEnable(GL_LIGHTING);
      glDepthMask(GL_TRUE);
      break;
    }
    default:
    case GLShadow::PLANAR_SHADOW:
    case GLShadow::SHADOW_VOLUME:
    {
      getObject().castShadow(getMode(),dir,*sd);
      break;
    }
  }
}

