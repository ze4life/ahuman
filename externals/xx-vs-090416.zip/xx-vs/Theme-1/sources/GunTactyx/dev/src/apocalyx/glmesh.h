#ifndef GLMESH_H
#define GLMESH_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gldisplaylist.h"
#include "globject.h"
#include "glmaterial.h"
#include "glshadow.h"

//
// GLTriangles
//
class GLTriangles {
private:
  int count;
  unsigned short* indexes;
protected:
  int groupsCount;
  int stripsCount;
  int fansCount;
 	int* groupIndexesCount;
 	unsigned short** groupIndexes;
public:
  GLTriangles(int triCount, unsigned short* idx);
  ~GLTriangles();
  void optimize();
  int getCount() {return count;}
  int getGroupsCount() {return groupsCount;}
  int getStripsCount() {return stripsCount;}
  int getFansCount() {return fansCount;}
  unsigned short* getIndexes() {return indexes;}
  int* getGroupIndexesCount() {return groupIndexesCount;}
  int getGroupIndexesCount(int idx) {return groupIndexesCount[idx];}
  unsigned short** getGroupIndexes() {return groupIndexes;}
  unsigned short* getGroupIndexes(int idx) {return groupIndexes[idx];}
  int getA(int face) {return indexes[face*3+0];}
  int getB(int face) {return indexes[face*3+1];}
  int getC(int face) {return indexes[face*3+2];}
};

//
// GLVertices
//
class GLVertices: public DMReference {
public:
  enum {
    TEXCOO_OFFSET = 0,
    NORMAL_OFFSET = 2,
    VERTEX_OFFSET = 5,
    F_STRIDE = 8,
    B_STRIDE = 32
  };
protected:
  int count;
  float* arrays;
public:
  GLVertices* acquireReference()
    {return dynamic_cast<GLVertices*>(DMReference::acquireReference());}
protected:
  GLVertices();
  virtual void destroyObject();
public:
  GLVertices(int vertCount, float* arrays);
  GLVertices(int vertCount, float* coo, float* norm, float* map);
  int getCount() {return count;}
  float* getArrays() {return arrays;}
  virtual float* getCoord(int idx) {return &arrays[idx*F_STRIDE+VERTEX_OFFSET];}
  virtual float getCoordX(int idx) {return arrays[idx*F_STRIDE+VERTEX_OFFSET+0];}
  virtual float getCoordY(int idx) {return arrays[idx*F_STRIDE+VERTEX_OFFSET+1];}
  virtual float getCoordZ(int idx) {return arrays[idx*F_STRIDE+VERTEX_OFFSET+2];}
  virtual void setCoordX(int idx, float f) {arrays[idx*F_STRIDE+VERTEX_OFFSET+0] = f;}
  virtual void setCoordY(int idx, float f) {arrays[idx*F_STRIDE+VERTEX_OFFSET+1] = f;}
  virtual void setCoordZ(int idx, float f) {arrays[idx*F_STRIDE+VERTEX_OFFSET+2] = f;}
  virtual float* getNormal(int idx) {return &arrays[idx*F_STRIDE+NORMAL_OFFSET];}
  virtual float getNormalX(int idx) {return arrays[idx*F_STRIDE+NORMAL_OFFSET+0];}
  virtual float getNormalY(int idx) {return arrays[idx*F_STRIDE+NORMAL_OFFSET+1];}
  virtual float getNormalZ(int idx) {return arrays[idx*F_STRIDE+NORMAL_OFFSET+2];}
  virtual void setNormalX(int idx, float f) {arrays[idx*F_STRIDE+NORMAL_OFFSET+0] = f;}
  virtual void setNormalY(int idx, float f) {arrays[idx*F_STRIDE+NORMAL_OFFSET+1] = f;}
  virtual void setNormalZ(int idx, float f) {arrays[idx*F_STRIDE+NORMAL_OFFSET+2] = f;}
  float* getMap(int idx) {return &arrays[idx*F_STRIDE+TEXCOO_OFFSET];}
  float getMapU(int idx) {return arrays[idx*F_STRIDE+TEXCOO_OFFSET+0];}
  float getMapV(int idx) {return arrays[idx*F_STRIDE+TEXCOO_OFFSET+1];}
  void setMapU(int idx, float f) {arrays[idx*F_STRIDE+TEXCOO_OFFSET+0] = f;}
  void setMapV(int idx, float f) {arrays[idx*F_STRIDE+TEXCOO_OFFSET+1] = f;}
};

//
// GLShaderVertices
//
class GLShaderVertices: public GLVertices {
private:
  short vertexDim;
  float* normalPointer;
  short colorDim;
  unsigned char* colorPointer;
  unsigned char* secondaryColorPointer;
  float* fogCoordPointer;
  short texCoordCount;
  short* texCoordDims;
  float** texCoordPointer;
public:
  GLShaderVertices* acquireReference()
    {return dynamic_cast<GLShaderVertices*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLShaderVertices();
  GLShaderVertices(int vertCount, float* coo, float* norm, float* map);
  void setVertices(int vertCount, float* vertPtr, int vertDim = 3);
  void setNormals(float* normPtr);
  void setColors(unsigned char* clrPtr, int clrDim = 3);
  void setSecondaryColors(unsigned char* clrPtr);
  void setFogCoords(float* fogPtr);
  void setTexCoords(int texCount, float** texPtr, short* texDims);
  void setTexCoord(float* texPtr, short texDim = 2);
  int getVertexCount() {return count;}
  int getVertexDim() {return vertexDim;}
  float* getVertexPointer() {return arrays;}
  bool hasNormals() {return normalPointer != NULL;}
  float* getNormalPointer() {return normalPointer;}
  bool hasColors() {return colorPointer != NULL;}
  int getColorDim() {return colorDim;}
  unsigned char* getColorPointer() {return colorPointer;}
  bool hasSecondaryColors() {return secondaryColorPointer != NULL;}
  unsigned char* getSecondaryColorPointer() {return secondaryColorPointer;}
  bool hasFogCoords() {return fogCoordPointer != NULL;}
  float* getFogCoordPointer() {return fogCoordPointer;}
  int getTexCoordCount() {return texCoordCount;}
  int getTexCoordDims(int idx) {return texCoordDims[idx];}
  float* getTexCoordPointer(int idx) {return texCoordPointer[idx];}
  virtual float* getCoord(int idx) {return &arrays[idx*vertexDim];}
  virtual float getCoordX(int idx) {return arrays[idx*vertexDim+0];}
  virtual float getCoordY(int idx) {return arrays[idx*vertexDim+1];}
  virtual float getCoordZ(int idx) {return arrays[idx*vertexDim+2];}
  virtual float getCoordW(int idx) {return arrays[idx*vertexDim+3];}
  virtual void setCoordX(int idx, float f) {arrays[idx*vertexDim+0] = f;}
  virtual void setCoordY(int idx, float f) {arrays[idx*vertexDim+1] = f;}
  virtual void setCoordZ(int idx, float f) {arrays[idx*vertexDim+2] = f;}
  virtual void setCoordW(int idx, float f) {arrays[idx*vertexDim+3] = f;}
  virtual float* getNormal(int idx) {return &normalPointer[idx*3];}
  virtual float getNormalX(int idx) {return normalPointer[idx*3+0];}
  virtual float getNormalY(int idx) {return normalPointer[idx*3+1];}
  virtual float getNormalZ(int idx) {return normalPointer[idx*3+2];}
  virtual void setNormalX(int idx, float f) {normalPointer[idx*3+0] = f;}
  virtual void setNormalY(int idx, float f) {normalPointer[idx*3+1] = f;}
  virtual void setNormalZ(int idx, float f) {normalPointer[idx*3+2] = f;}
  unsigned char* getColor(int idx) {return &colorPointer[idx*colorDim];}
  unsigned char getColorR(int idx) {return colorPointer[idx*colorDim+0];}
  unsigned char getColorG(int idx) {return colorPointer[idx*colorDim+1];}
  unsigned char getColorB(int idx) {return colorPointer[idx*colorDim+2];}
  unsigned char getColorA(int idx) {return colorPointer[idx*colorDim+3];}
  void setColorR(int idx, unsigned char c) {colorPointer[idx*colorDim+0] = c;}
  void setColorG(int idx, unsigned char c) {colorPointer[idx*colorDim+1] = c;}
  void setColorB(int idx, unsigned char c) {colorPointer[idx*colorDim+2] = c;}
  void setColorA(int idx, unsigned char c) {colorPointer[idx*colorDim+3] = c;}
  unsigned char* getSecondaryColor(int idx) {return &secondaryColorPointer[idx*3];}
  unsigned char getSecondaryColorR(int idx) {return secondaryColorPointer[idx*3+0];}
  unsigned char getSecondaryColorG(int idx) {return secondaryColorPointer[idx*3+1];}
  unsigned char getSecondaryColorB(int idx) {return secondaryColorPointer[idx*3+2];}
  unsigned char getSecondaryColorA(int idx) {return secondaryColorPointer[idx*3+3];}
  void setSecondaryColorR(int idx, unsigned char c) {secondaryColorPointer[idx*3+0] = c;}
  void setSecondaryColorG(int idx, unsigned char c) {secondaryColorPointer[idx*3+1] = c;}
  void setSecondaryColorB(int idx, unsigned char c) {secondaryColorPointer[idx*3+2] = c;}
  void setSecondaryColorA(int idx, unsigned char c) {secondaryColorPointer[idx*3+3] = c;}
  float getFogCoord(int idx) {return fogCoordPointer[idx];}
  void setFogCoord(int idx, float f) {fogCoordPointer[idx] = f;}
  float* getTexCoord(int idx, int tex = 0) {return &texCoordPointer[tex][idx*texCoordDims[tex]];}
  float getTexCoordS(int idx, int tex = 0) {return texCoordPointer[tex][idx*texCoordDims[tex]+0];}
  float getTexCoordT(int idx, int tex = 0) {return texCoordPointer[tex][idx*texCoordDims[tex]+1];}
  float getTexCoordP(int idx, int tex = 0) {return texCoordPointer[tex][idx*texCoordDims[tex]+2];}
  float getTexCoordQ(int idx, int tex = 0) {return texCoordPointer[tex][idx*texCoordDims[tex]+3];}
  void setTexCoordS(int idx, float f, int tex = 0) {texCoordPointer[tex][idx*texCoordDims[tex]+0] = f;}
  void setTexCoordT(int idx, float f, int tex = 0) {texCoordPointer[tex][idx*texCoordDims[tex]+1] = f;}
  void setTexCoordP(int idx, float f, int tex = 0) {texCoordPointer[tex][idx*texCoordDims[tex]+2] = f;}
  void setTexCoordQ(int idx, float f, int tex = 0) {texCoordPointer[tex][idx*texCoordDims[tex]+3] = f;}
};

//
// GLShape
//
class GLShape: public DMReference
#ifdef USE_OGLES
#else // !USE_OGLES
  , public GLDisplayList
#endif // !USE_OGLES
{
protected:
  GLTriangles triangles;
  GLVertices* vertices;
  float maxRadius;
  bool dynamic;
  bool twoSided;
public:
  GLShape* acquireReference()
    {return dynamic_cast<GLShape*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLShape(
    int vertCount, float* arrays, int triCount, unsigned short* triIndexes,
    bool dyn = false, bool twoSid = false
  );
  GLShape(
    int vertCount, float* vertCoo, float* vertNorm, float* vertMap,
    int triCount, unsigned short* triIndexes, bool dyn = false,
    bool twoSid = false
  );
  GLShape(
    GLVertices& verts, int triCount, unsigned short* triIndexes,
    bool dyn = false, bool twoSid = false
  );
  GLVertices& getVertices() {return *vertices;}
  GLTriangles& getTriangles() {return triangles;}
  void setTwoSided(bool ts) {twoSided = ts;}
  bool isTwoSided() {return twoSided;}
  virtual void computeNormals();
  void computeMaxRadius();
  float getMaxRadius() {return maxRadius;}
#ifdef USE_OGLES
  void setDynamic(bool d) {d;}
  bool isDynamic() {return true;}
#else // !USE_OGLES
  void setDynamic(bool d) {dynamic = d;}
  bool isDynamic() {return dynamic;}
#endif // !USE_OGLES
  void optimize() {triangles.optimize();}
  void compile();
  virtual void drawInit();
  virtual void drawFinal();
  void draw();
  void renderInit(GLCamera& camera) {
    if(isTwoSided()) {
      glLightModelf(GL_LIGHT_MODEL_TWO_SIDE,1);
      glDisable(GL_CULL_FACE);
      if(camera.isRenderingReflections())
        glFrontFace(GL_CW);
    }
    if(isDynamic()) drawInit();
  }
  void renderFinal(GLCamera& camera) {
    if(isDynamic()) drawFinal();
    if(isTwoSided()) {
      glLightModelf(GL_LIGHT_MODEL_TWO_SIDE,0);
      glEnable(GL_CULL_FACE);
      if(camera.isRenderingReflections())
        glFrontFace(GL_CCW);
    }
  }
  void render() {
#ifdef USE_OGLES
    draw();
#else // !USE_OGLES
    isDynamic()? draw(): execute();
#endif // !USE_OGLES
  }
};

//
// GLShaderShape
//
class GLShaderShape: public GLShape {
public:
  GLShaderShape* acquireReference()
    {return dynamic_cast<GLShaderShape*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject() {GLShape::destroyObject();}
public:
  GLShaderShape(
    int vertCount, float* vertCoo, float* vertNorm, float* vertMap,
    int triCount, unsigned short* triIndexes, bool dyn = false,
    bool twoSid = false
  );
  GLShaderShape(
    GLShaderVertices& verts, int triCount, unsigned short* triIndexes,
    bool dyn = false, bool twoSid = false
  );
  GLShaderVertices& getShaderVertices()
    {return dynamic_cast<GLShaderVertices&>(getVertices());}
  virtual void computeNormals();
  virtual void drawInit();
  virtual void drawFinal();
};

//
// GLBasicMesh
//
class GLBasicMesh: public GLObject, public GLBasicMaterialOwner {
protected:
  GLShape* shape;
public:
  GLBasicMesh(GLShape& shp, GLBasicMaterial* mat = NULL, bool optimize = true);
  virtual ~GLBasicMesh();
  GLShape* getShape() {return shape;}
  GLVertices& getVertices() {return shape->getVertices();}
  GLTriangles& getTriangles() {return shape->getTriangles();}
  void compile() {shape->compile(); setMaxRadius(shape->getMaxRadius());}
  virtual GLBasicMesh* clone()
    {return new GLBasicMesh(*shape,getBasicMaterial());}
  virtual void castPlanarShadow();
  virtual void castShadowVolume(M3Vector& dir);
  virtual void render(GLCamera& camera);
};

//
// GLHalo
//
class GLHalo {
private:
  float depth;
  GLColor color;
public:
  GLHalo();
  float getDepth() {return depth;}
  GLColor& getColor() {return color;}
  bool isEnabled() {return depth > 0;}
  void hide() {depth = -1;}
  void show(GLColor& clr, float dpt) {color.set(clr); depth = dpt;}
};

//
// GLMesh
//
class GLMesh: public GLBasicMesh {
protected:
  GLHalo halo;
public:
  GLMesh(GLShape& shp, GLBasicMaterial* mat = NULL, bool optimize = true);
  void hideHalo() {setTransparent(false); halo.hide();}
  void showHalo(GLColor& clr, float dpt)
    {setTransparent(true); halo.show(clr,dpt);}
  virtual GLMesh* clone() {return new GLMesh(*shape,getBasicMaterial());}
  virtual void render(GLCamera& camera);
};

#ifdef USE_EMBOSS

//
// GLBumpedMesh
//
class GLBumpedMesh: public GLMesh {
private:
  float* diffU;
  float* diffV;
  M3Vector* dirU;
  M3Vector* dirV;
protected:
  void bumpOffsets(GLCamera& camera);
public:
  GLBumpedMesh(GLShape& shp, GLBasicMaterial* mat = NULL);
  virtual ~GLBumpedMesh();
  virtual GLBumpedMesh* clone()
    {return new GLBumpedMesh(*shape,getBasicMaterial());}
  virtual void render(GLCamera& camera);
};

#endif // USE_EMBOSS

//
// GLFlat
//
class GLFlat: public GLObject,
#ifdef USE_OGLES
#else // !USE_OGLES
  public GLDisplayList,
#endif // !USE_OGLES
  public GLBasicMaterialOwner
{
private:
  float halfSize;
  float invSide;
  int tiles;
public:
  GLFlat(GLBasicMaterial* mat, float siz, int sid = 1, int tils = 1);
  virtual void render(GLCamera& camera);
};

#endif // GLMESH_H
