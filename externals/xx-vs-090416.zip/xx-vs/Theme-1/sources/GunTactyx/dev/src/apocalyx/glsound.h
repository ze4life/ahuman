#ifndef GLSOUND_H
#define GLSOUND_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#ifdef USE_SOUND

#include "fmsound.h"

#include "datasets.h"
#include "globject.h"

#include "void.h"

//
// GLSoundSource
//
class GLSoundSource: public DSSortableObject {
private:
  FM3DSound* sound;
  GLObject* object;
  M3Vector lastRenderingPosition;
  float distance2;
public:
  GLSoundSource(FM3DSample* s, GLObject* o, bool playing = true);
  ~GLSoundSource();
  FM3DSound* get3DSound() {return sound;}
  void setObject(GLObject* o) {object = o;}
  GLObject* getObject() {return object;}
  void set3DSound(FM3DSound* s) {sound->stop(); delete sound; sound = s;}
  void setVelocityToZero() {lastRenderingPosition.set(
    object->getPositionX(),object->getPositionY(),-object->getPositionZ()
  );}
  void computeDistance2(GLCamera& camera) {
    float d;
    d = object->getPositionX()-camera.getPositionX();
    distance2 = d*d;
    d = object->getPositionY()-camera.getPositionY();
    distance2 += d*d;
    d = object->getPositionZ()-camera.getPositionZ();
    distance2 += d*d;
  }
  float getDistance2() {return distance2;}
  float getSortIndex()
    {return getDistance2()*sound->getInvMinDistance2();}
  void render(GLCamera& camera);
};

#endif // USE_SOUND
#endif // GLSOUND_H
