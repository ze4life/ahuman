#ifndef GLBACKGROUND_H
#define GLBACKGROUND_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glcolor.h"
#include "gltexture.h"
#include "gldisplaylist.h"

//
// GLBackground
//
class GLBackground: public M3Reference, public GLVisible {
private:
  GLColor color;
  int srcBlend;
  int dstBlend;
public:
  GLBackground(
    float r = 1, float g = 1, float b = 1, float a = 1,
    int src = GL_ONE, int dst = GL_ZERO
  );
  virtual ~GLBackground();
  void setColor(float r, float g, float b) {color.set(r,g,b);}
  void setColor(float r, float g, float b, float a) {color.set(r,g,b,a);}
  void setBlendFactors(int src, int dst) {srcBlend = src; dstBlend = dst;}
  int getSrcBlend() {return srcBlend;}
  int getDstBlend() {return dstBlend;}
  GLColor& getColor() {return color;}
  virtual void render(bool blend = false) = 0;
};

//
// GLStarfield
//
class GLStarfield: public GLBackground
#ifdef USE_OGLES
#else // !USE_OGLES
  , public GLDisplayLists
#endif // !USE_OGLES
{
#ifdef USE_OGLES
private:
  int nebulaeLength;
  float* nebulaeArrays;
  int starsLength;
  float* starsArrays;
private:
  void generateStars(float* pointer, float rr, int num, bool blend = false);
#else // !USE_OGLES
private:
  void generateStars(float rr, int num, bool blend = false);
#endif // !USE_OGLES
private:
  GLTexture* texture;
public:
  GLStarfield(
    float rr, int num, GLTexture* txt = NULL, float sz = 0, bool blend = false
  );
  ~GLStarfield();
  virtual void render(bool blend = false);
};

//
// GLSkydome
//

class GLSkydome: public GLBackground {
public:
  enum {DEF_MERIDIANS = 24, DEF_PARALLELS = 6, DEF_RADIUS = 100};
private:
  int meridians;
  int parallels;
	int vertexesCount;
  float* vertArray;
  unsigned char* colArray;
  int indexesCount;
  unsigned short* indexArray;
  int groupsCount;
  int* groupIndexesCount;
  unsigned short** groupIndexesArrays;
  GLColor atmosphereColor;
  float redShiftMinSin;
  float redShiftMaxSin;
  float atmosphereHeight;
  float atmosphereDensity;
  float atmosphereMinSin;
  float atmosphereMaxSin;
  GLColor hazeColor;
  float hazeHeight;
  float hazeDensity;
  float hazeMinSin;
  float hazeMaxSin;
  GLColor sunColor;
  float sunIntensity;
  M3Vector sunDirection;
  GLColor fogColor;
  GLColor cloudColor;
  GLColor actualSunColor;
  bool mirrored;
protected:
	float getAtmosphereLight();
	float getHazeLight();
	void getRedShift(float shift, GLColor& redShift);
	float getRedShiftDensity();
  void draw(bool blend = false);
public:
	GLSkydome(
    int merid = DEF_MERIDIANS, int paral = DEF_PARALLELS,
    float radius = DEF_RADIUS, int src = GL_ONE, int dst = GL_ONE
  );
	~GLSkydome();
  void setMirrored(bool m) {mirrored = m;}
  bool isMirrored() {return mirrored;}
	void setAtmosphere(
  	GLColor& color, float height, float density,
    float minDeg, float maxDeg
  ) {
    atmosphereColor.set(color);
    atmosphereHeight = height;
    atmosphereDensity = density;
    atmosphereMinSin = sin(minDeg*M_PI/180);
    atmosphereMaxSin = sin(maxDeg*M_PI/180);
  }
	void setHaze(
  	GLColor& color, float height, float density, float minDeg, float maxDeg
  ) {
  	hazeColor.set(color); hazeHeight = height; hazeDensity = density;
    hazeMinSin = sin(minDeg*M_PI/180); hazeMaxSin = sin(maxDeg*M_PI/180);
  }
  void setRedShift(float minDeg, float maxDeg)
    {redShiftMinSin = sin(minDeg*M_PI/180); redShiftMaxSin = sin(maxDeg*M_PI/180);}
	void setSun(GLColor& color, float intensity, M3Vector& dir)
    {sunColor.set(color); sunIntensity = intensity; sunDirection = dir;}
	GLColor& getSunColor() {return actualSunColor;}
	GLColor& getFogColor() {return fogColor;}
	GLColor& getCloudColor() {return cloudColor;}
	void update();
	virtual void render(bool blend = false);
};

//
// GLSkybox
//
class GLSkybox: public GLBackground
#ifdef USE_OGLES
#else // ! USE_OGLES
  , public GLDisplayLists
#endif // !USE_OGLES
{
protected:
  int texturesCount;
  GLTexture** textures;
private:
  void init(int txtCount, GLTexture** txts);
protected:
  GLSkybox(int txtCount, GLTexture** txts, int src = GL_ONE, int dst = GL_ONE);
public:
  GLSkybox(GLTexture** txts);
  virtual ~GLSkybox();
  virtual void render(bool blend = false);
};

//
// GLHalfSkybox
//
class GLHalfSkybox: public GLSkybox {
private:
	GLColor ground;
protected:
  GLHalfSkybox(int txtCount, GLTexture** txts, int src = GL_ONE, int dst = GL_ONE);
public:
  GLHalfSkybox(GLTexture** txts, int src = GL_ONE, int dst = GL_ONE);
  void setGroundColor(float r, float g, float b) {ground.set(r,g,b);}
  virtual void render(bool blend = false);
};

//
// GLPanorama
//
class GLPanorama: public GLHalfSkybox {
public:
  GLPanorama(GLTexture** txts, int src = GL_ONE, int dst = GL_ONE);
#ifdef USE_OGLES
  virtual void render(bool blend = false);
#endif // USE_OGLES
};

//
// GLMirroredSkybox
//
class GLMirroredSkybox: public GLSkybox {
public:
  GLMirroredSkybox(GLTexture** txts, int src = GL_ONE, int dst = GL_ONE);
#ifdef USE_OGLES
  virtual void render(bool blend = false);
#endif // USE_OGLES
};

#endif // GLBACKGROUND_H
