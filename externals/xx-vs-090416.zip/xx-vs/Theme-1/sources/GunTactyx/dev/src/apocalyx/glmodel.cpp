/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"
#include "mathtables.h"
#include "glmodel.h"
#include "glwin.h"

#include "datasets.inc"
#include "math3d.inc"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h> // for isalpha()
#include <dir.h> // for MAX_PATH

//
// GLAnimationData
//
GLAnimationData::GLAnimationData():
  firstFrame(0), lastFrame(0), backFrames(1), fps(1), invFPS(1)
{}

GLAnimationData::GLAnimationData(int ff, int lf, int bf, int iFps):
  firstFrame(ff), lastFrame(lf), backFrames(bf), fps(iFps),
  invFPS((iFps == 0)? 1: (1.0f/iFps))
{}

//
// GLMD2AnimatedShape
//

GLMD2AnimatedShape::GLMD2AnimatedShape():
  vertexesCount(0), vertex(NULL), commands(NULL)
{}

GLMD2AnimatedShape::~GLMD2AnimatedShape() {
  if(commands) delete[] commands;
  if(vertex) delete[] vertex;
}

//
// GLAnimatedShape
//

GLAnimatedShape::GLAnimatedShape():
  trianglesCount(0), triangle(NULL),
  vertexesCount(0), vertex(NULL), texCoord(NULL)
{}

GLAnimatedShape::~GLAnimatedShape() {
  if(triangle) delete[] triangle;
  if(texCoord) delete[] texCoord;
  if(vertex) delete[] vertex;
}

//
// GLMD2Bone
//

GLMD2Bone::GLMD2Bone(): framesCount(0) {
}

void GLMD2Bone::destroyObject() {
  delete this;
}

GLAnimationData GLMD2Bone::MD2_ANIMATION_DATA[GLMD2Bone::MD2_MAX_ANIMATIONS] = {
	GLAnimationData(    0,  39, 39,  9),	// STAND
	GLAnimationData(   40,  45,  5, 10),	// RUN
	GLAnimationData(   46,  53,  0, 10),	// ATTACK
	GLAnimationData(   54,  57,  0,  7),	// PAIN_A
	GLAnimationData(   58,  61,  0,  7),	// PAIN_B
	GLAnimationData(   62,  65,  0,  7),	// PAIN_C
	GLAnimationData(   66,  71,  0,  7),	// JUMP
	GLAnimationData(   72,  83,  0,  7),	// FLIP
	GLAnimationData(   84,  94,  0,  7),	// SALUTE
	GLAnimationData(   95, 111,  0, 10),	// FALLBACK
	GLAnimationData(  112, 122,  0,  7),	// WAVE
	GLAnimationData(  123, 134,  0,  6),	// POINT
	GLAnimationData(  135, 153,  0, 10),	// CROUCH_STAND
	GLAnimationData(  154, 159,  5,  7),	// CROUCH_WALK
	GLAnimationData(  160, 168,  0, 10),	// CROUCH_ATTACK
	GLAnimationData(  169, 172,  0,  7),	// CROUCH_PAIN
	GLAnimationData(  173, 177,  0,  5),	// CROUCH_DEATH
	GLAnimationData(  178, 183,  0,  7),	// DEATH_FALLBACK
	GLAnimationData(  184, 189,  0,  7),	// DEATH_FALLFORWARD
	GLAnimationData(  190, 197,  0,  7),	// DEATH_FALLBACKSLOW
//	GLAnimationData(  198, 198,  0,  5),	// BOOM
};

//
// GLBone
//

GLBone::GLBone():
  framesCount(0), shapesCount(0), shapes(NULL), linksCount(0), linkNames(NULL),
  transformsCount(0), transforms(NULL), animationsCount(0), animations(NULL)
{}

void GLBone::destroyObject() {
  if(shapes) delete[] shapes;
  if(transforms) delete[] transforms;
  if(animations)
    delete[] animations;
  if(linkNames) {
    for(int ct = 0; ct < linksCount; ct++)
      if(linkNames[ct]) delete linkNames[ct];
    delete linkNames;
  }
  delete this;
}

//
// GLBasicModel
//

GLBasicModel::GLBasicModel():
  currFrame(-1), nextFrame(-1), interpolation(0), lastUpdate(0), bone(NULL),
  scale(1/128.0f), currAnimation(-1), stopAnimation(-1), playBackward(false)
{}

GLBasicModel::GLBasicModel(GLBasicModel& model) {
	playBackward = model.playBackward;
  currFrame = model.currFrame;
  nextFrame = model.nextFrame;
  lastUpdate = model.lastUpdate;
  interpolation = model.interpolation;
  currAnimation = model.currAnimation;
  stopAnimation = -1;
  bone = model.bone;
  bone->acquireReference();
  setBasicMaterial(model.getBasicMaterial());
  setTransparent(model.isTransparent());
  setMaxRadius(model.getMaxRadius());
  setScale(model.getScale());
}

float GLBasicModel::animationTime = -1;

GLBasicModel::~GLBasicModel() {
  if(bone) bone->releaseReference();
}

#ifdef USE_DATA_FILES

GLBasicModel::GLBasicModel(
  const char* path, const char* md2Name, const char* imgName, const char* alphaImgName
):
  currFrame(-1), nextFrame(-1), interpolation(0), lastUpdate(0), bone(NULL),
  scale(1/128.0f), currAnimation(-1), stopAnimation(-1), playBackward(false)
{
	load(path,md2Name,imgName,alphaImgName);
}

bool GLBasicModel::load(
  const char* path, const char* md2Name, const char* imgName, const char* alphaImgName
) {
  char fileName[MAX_PATH];
  if(path)
	  strcat(strcpy(fileName,path),md2Name);
  else
	  strcpy(fileName,md2Name);
  FILE* file = fopen(fileName,"rb");
  if(file && strstr(md2Name,".md2")) {
    MD2ModelHeader header;
    fread((char*)&header,sizeof(header),1,file);
    if((header.ident == *(int*)&"IDP2") && (header.version == 8)) {
      int framesCount  = header.num_frames;
      int vertexesCount = header.num_xyz;
      int commandsCount = header.num_glcmds;
      bone = new GLMD2Bone();
      bone->acquireReference();
      bone->framesCount = framesCount;
      GLMD2AnimatedShape& shape = bone->animatedShape;
      shape.vertexesCount = vertexesCount;
      shape.vertex = new MD2FinalVertex[vertexesCount*framesCount];
      shape.commands = new int[commandsCount];
      char* frameBuffer = new char[framesCount*header.framesize];
      fseek(file,header.ofs_frames,SEEK_SET);
      fread(frameBuffer,framesCount,header.framesize,file);
      fseek(file,header.ofs_glcmds,SEEK_SET);
      fread(shape.commands,sizeof(int),commandsCount,file);
      for(int frameCt = 0; frameCt < framesCount; frameCt++) {
        MD2Frame* frame =
          reinterpret_cast<MD2Frame*>(&frameBuffer[header.framesize*frameCt]);
        int offset = frameCt*vertexesCount;
        for(int vertCt = 0; vertCt < vertexesCount; vertCt++) {
          shape.vertex[offset+vertCt].coord[0] = (signed short)(128*
            (frame->verts[vertCt].v[0]*frame->scale[0]+frame->translate[0]));
          shape.vertex[offset+vertCt].coord[1] = (signed short)(128*
            (frame->verts[vertCt].v[1]*frame->scale[1]+frame->translate[1]));
          shape.vertex[offset+vertCt].coord[2] = (signed short)(128*
            (frame->verts[vertCt].v[2]*frame->scale[2]+frame->translate[2]));
          shape.vertex[offset+vertCt].normal = (unsigned char)
            frame->verts[vertCt].lightnormalindex;
        }
      }
      delete[] frameBuffer;
    }
    computeMaxRadius();
    fclose(file);
    if(imgName && isalpha(imgName[0])) {
      char fileName[MAX_PATH];
      if(path)
	      strcat(strcpy(fileName,path),imgName);
      else
	      strcpy(fileName,imgName);
      DRImage* image = DRImage::getImageFromFile(fileName);
      if(alphaImgName) {
      	if(path)
	        strcat(strcpy(fileName,path),alphaImgName);
        else
	        strcpy(fileName,alphaImgName);
        DRImage* alphaImage = DRImage::getImageFromFile(fileName);
        image->addAlpha(*alphaImage);
        delete alphaImage;
        setTransparent(true);
      }
      GLMaterial* material = new GLMaterial();
      material->setDiffuseTexture(new GLTexture(*image));
      material->setShininess(64);
      delete image;
      setBasicMaterial(material);
    }
    return true;
  }
  return false;
}

#endif // USE_DATA_FILES

float GLBasicModel::computeMaxRadius() {
  if(maxRadius)
    return maxRadius;
  int maxX = 0;
  int maxY = 0;
  int maxZ = 0;
  int vertexesCount = bone->animatedShape.vertexesCount;
  for(int frm = 0; frm < bone->framesCount; frm++) {
    int curOffsetVertex = frm*vertexesCount;
    for(int ct = 0; ct < vertexesCount; ct++) {
      MD2FinalVertex& vertex = bone->animatedShape.vertex[curOffsetVertex+ct];
      int coo = abs((int)vertex.coord[0]);
      if(maxX < coo) maxX = coo;
      coo = abs((int)vertex.coord[1]);
      if(maxY < coo) maxY = coo;
      coo = abs((int)vertex.coord[2]);
      if(maxZ < coo) maxZ = coo;
    }
  }
  float dx = maxX*scale;
  float dy = maxY*scale;
  float dz = maxZ*scale;
  return maxRadius = sqrt(dx*dx+dy*dy+dz*dz);
}

void GLBasicModel::setAnimation(int anim, bool playBack) {
	if((anim >= GLMD2Bone::MD2_MAX_ANIMATIONS) || (anim < 0))
  	return;
	playBackward = playBack;
  currAnimation = anim;
  stopAnimation = -1;
  lastUpdate = GLBasicModel::getAnimationTime() < 0?
    GLWin::getElapsedTime(): GLBasicModel::getAnimationTime();
  GLAnimationData& animation = GLMD2Bone::MD2_ANIMATION_DATA[currAnimation];
  int animationLastFrame = playBackward?
  	(-animation.lastFrame): animation.lastFrame;
  if(animationLastFrame < 0) { // play backward
	  if(currFrame < 0) {
  	  currFrame = -animationLastFrame;
    	nextFrame = currFrame-1;
	    if(nextFrame < animation.firstFrame)
  	    nextFrame = currFrame;
	  } else {
  	  nextFrame = -animationLastFrame;
    	if(currFrame == nextFrame) {
      	nextFrame = currFrame-1;
	      if(nextFrame < animation.firstFrame)
  	      nextFrame = currFrame;
    	}
	  }
  } else { // play forward
	  if(currFrame < 0) {
  	  currFrame = animation.firstFrame;
    	nextFrame = currFrame+1;
	    if(nextFrame > animationLastFrame)
  	    nextFrame = currFrame;
	  } else {
  	  nextFrame = animation.firstFrame;
    	if(currFrame == nextFrame) {
      	nextFrame = currFrame+1;
	      if(nextFrame > animationLastFrame)
  	      nextFrame = currFrame;
    	}
	  }
  }
}

void GLBasicModel::drawNI() {
  GLMD2AnimatedShape& shp = bone->animatedShape;
  int curOffsetVertex = currFrame <= 0? 0: currFrame*shp.vertexesCount;
  int* cmd = shp.commands;
#ifdef USE_OGLES
  int arraySize = 0;
  float* arrays = NULL;
  unsigned int arrayType;
  const int STRIDE = 8*sizeof(float);
  const int NORM_OFFS = 2;
  const int VERT_OFFS = NORM_OFFS+3;
  while(int val = *(cmd++)) {
    if(val < 0 ) {
      arrayType = GL_TRIANGLE_FAN;
      val = -val;
    } else {
      arrayType = GL_TRIANGLE_STRIP;
    }
    int currentSize = val*8;
    if(currentSize > arraySize) {
      arraySize = currentSize;
      if(arrays)
        delete arrays;
      arrays = new float[currentSize*8];
    }
    int vertexesCount = val;
    for(int index = 0; val > 0; val--, cmd += 3, index += 8) {
      arrays[index  ] = ((float*)cmd)[0];
      arrays[index+1] = 1-((float*)cmd)[1];
      MD2FinalVertex& vertex = shp.vertex[curOffsetVertex+cmd[2]];
      float* n = MTNormals1D::getNormal(vertex.normal);
      arrays[index+2] = n[0];
      arrays[index+3] = n[1];
      arrays[index+4] = n[2];
      arrays[index+5] = vertex.coord[0]*scale;
      arrays[index+6] = vertex.coord[1]*scale;
      arrays[index+7] = vertex.coord[2]*scale;
    }
    glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
    glNormalPointer(GL_FLOAT,STRIDE,arrays+NORM_OFFS);
    glVertexPointer(3,GL_FLOAT,STRIDE,arrays+VERT_OFFS);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawArrays(arrayType,0,vertexesCount);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
  }
  if(arrays)
    delete arrays;
#else // !USE_OGLES
  while(int val = *(cmd++)) {
    if(val < 0 ) {
      glBegin(GL_TRIANGLE_FAN);
      val = -val;
    } else {
      glBegin(GL_TRIANGLE_STRIP);
    }
    for(; val > 0; val--, cmd += 3) {
      glTexCoord2f(((float*)cmd)[0],1-((float*)cmd)[1]);
      MD2FinalVertex& vertex = shp.vertex[curOffsetVertex+cmd[2]];
      glNormal3fv(MTNormals1D::getNormal(vertex.normal));
      glVertex3f(
        vertex.coord[0]*scale,vertex.coord[1]*scale,vertex.coord[2]*scale
      );
    }
    glEnd();
  }
#endif // !USE_OGLES
}

void GLBasicModel::draw() {
  if(currFrame == nextFrame) {
    drawNI();
  } else {
    GLMD2AnimatedShape& shp = bone->animatedShape;
    int curOffsetVertex = currFrame*shp.vertexesCount;
    int nexOffsetVertex = nextFrame*shp.vertexesCount;
    int* cmd = shp.commands;
#ifdef USE_OGLES
    int arraySize = 0;
    float* arrays = NULL;
    unsigned int arrayType;
    const int STRIDE = 8*sizeof(float);
    const int NORM_OFFS = 2*sizeof(float);
    const int VERT_OFFS = NORM_OFFS+3*sizeof(float);
    while(int val = *(cmd++)) {
      if(val < 0 ) {
        arrayType = GL_TRIANGLE_FAN;
        val = -val;
      } else {
        arrayType = GL_TRIANGLE_STRIP;
      }
      int currentSize = val*8;
      if(currentSize > arraySize) {
        arraySize = currentSize;
        if(arrays)
          delete arrays;
        arrays = new float[currentSize*8];
      }
      int vertexesCount = val;
      for(int index = 0; val > 0; val--, cmd += 3, index += 8) {
        arrays[index  ] = ((float*)cmd)[0];
        arrays[index+1] = 1-((float*)cmd)[1];
        MD2FinalVertex& curVertex = shp.vertex[curOffsetVertex+cmd[2]];
        MD2FinalVertex& nexVertex = shp.vertex[nexOffsetVertex+cmd[2]];
        float curN[3] = {
          MTNormals1D::getNormal(curVertex.normal,0),
          MTNormals1D::getNormal(curVertex.normal,1),
          MTNormals1D::getNormal(curVertex.normal,2)
        };
        float nexN[3] = {
          MTNormals1D::getNormal(nexVertex.normal,0),
          MTNormals1D::getNormal(nexVertex.normal,1),
          MTNormals1D::getNormal(nexVertex.normal,2)
        };
        arrays[index+2] = curN[0]+interpolation*(nexN[0]-curN[0]);
        arrays[index+3] = curN[1]+interpolation*(nexN[1]-curN[1]);
        arrays[index+4] = curN[2]+interpolation*(nexN[2]-curN[2]);
        float curV[3] =
          {curVertex.coord[0],curVertex.coord[1],curVertex.coord[2]};
        float nexV[3] =
          {nexVertex.coord[0],nexVertex.coord[1],nexVertex.coord[2]};
        arrays[index+5] = (curV[0]+interpolation*(nexV[0]-curV[0]))*scale;
        arrays[index+6] = (curV[1]+interpolation*(nexV[1]-curV[1]))*scale;
        arrays[index+7] = (curV[2]+interpolation*(nexV[2]-curV[2]))*scale;
      }
      glTexCoordPointer(2,GL_FLOAT,STRIDE,arrays);
      glNormalPointer(GL_FLOAT,STRIDE,arrays+NORM_OFFS);
      glVertexPointer(3,GL_FLOAT,STRIDE,arrays+VERT_OFFS);
      glEnableClientState(GL_TEXTURE_COORD_ARRAY);
      glEnableClientState(GL_NORMAL_ARRAY);
      glEnableClientState(GL_VERTEX_ARRAY);
      glDrawArrays(arrayType,0,vertexesCount);
      glDisableClientState(GL_TEXTURE_COORD_ARRAY);
      glDisableClientState(GL_NORMAL_ARRAY);
      glDisableClientState(GL_VERTEX_ARRAY);
    }
    if(arrays)
      delete arrays;
#else // !USE_OGLES
    while(int val = *(cmd++)) {
      if(val < 0 ) {
        glBegin(GL_TRIANGLE_FAN);
        val = -val;
      } else {
        glBegin(GL_TRIANGLE_STRIP);
      }
      for(; val > 0; val--, cmd += 3) {
        glTexCoord2f(((float*)cmd)[0],1-((float*)cmd)[1]);
        MD2FinalVertex& curVertex = shp.vertex[curOffsetVertex+cmd[2]];
        MD2FinalVertex& nexVertex = shp.vertex[nexOffsetVertex+cmd[2]];
        float curN[3] = {
          MTNormals1D::getNormal(curVertex.normal,0),
          MTNormals1D::getNormal(curVertex.normal,1),
          MTNormals1D::getNormal(curVertex.normal,2)
        };
        float nexN[3] = {
          MTNormals1D::getNormal(nexVertex.normal,0),
          MTNormals1D::getNormal(nexVertex.normal,1),
          MTNormals1D::getNormal(nexVertex.normal,2)
        };
        glNormal3f(
          curN[0]+interpolation*(nexN[0]-curN[0]),
          curN[1]+interpolation*(nexN[1]-curN[1]),
          curN[2]+interpolation*(nexN[2]-curN[2])
        );
        float curV[3] =
          {curVertex.coord[0],curVertex.coord[1],curVertex.coord[2]};
        float nexV[3] =
          {nexVertex.coord[0],nexVertex.coord[1],nexVertex.coord[2]};
        glVertex3f(
          (curV[0]+interpolation*(nexV[0]-curV[0]))*scale,
          (curV[1]+interpolation*(nexV[1]-curV[1]))*scale,
          (curV[2]+interpolation*(nexV[2]-curV[2]))*scale
        );
      }
      glEnd();
    }
#endif // !USE_OGLES
  }
}

void GLBasicModel::castPlanarShadow() {
  glCullFace(GL_FRONT);
  GLMD2AnimatedShape& shp = bone->animatedShape;
  if(currFrame == nextFrame) {
    int curOffsetVertex = currFrame <= 0? 0: currFrame*shp.vertexesCount;
    int* cmd = shp.commands;
#ifdef USE_OGLES
#else // !USE_OGLES
    while(int val = *(cmd++)) {
      if(val < 0 ) {
        glBegin(GL_TRIANGLE_FAN);
        val = -val;
      } else {
        glBegin(GL_TRIANGLE_STRIP);
      }
      for(; val > 0; val--, cmd += 3) {
        MD2FinalVertex& vertex = shp.vertex[curOffsetVertex+cmd[2]];
        float x = vertex.coord[0]*scale;
        float y = vertex.coord[1]*scale;
        float z = vertex.coord[2]*scale;
        glVertex3f(x,y,z);
      }
      glEnd();
    }
#endif // !USE_OGLES
  } else {
    int curOffsetVertex = currFrame*shp.vertexesCount;
    int nexOffsetVertex = nextFrame*shp.vertexesCount;
    int* cmd = shp.commands;
#ifdef USE_OGLES
#else // !USE_OGLES
    while(int val = *(cmd++)) {
      if(val < 0 ) {
        glBegin(GL_TRIANGLE_FAN);
        val = -val;
      } else {
        glBegin(GL_TRIANGLE_STRIP);
      }
      for(; val > 0; val--, cmd += 3) {
        MD2FinalVertex& curVertex = shp.vertex[curOffsetVertex+cmd[2]];
        MD2FinalVertex& nexVertex = shp.vertex[nexOffsetVertex+cmd[2]];
        float curV[3] =
          {curVertex.coord[0],curVertex.coord[1],curVertex.coord[2]};
        float nexV[3] =
          {nexVertex.coord[0],nexVertex.coord[1],nexVertex.coord[2]};
        glVertex3f(
          (curV[0]+interpolation*(nexV[0]-curV[0]))*scale,
          (curV[1]+interpolation*(nexV[1]-curV[1]))*scale,
          (curV[2]+interpolation*(nexV[2]-curV[2]))*scale
        );
      }
      glEnd();
    }
#endif // !USE_OGLES
  }
  glCullFace(GL_BACK);
}

void GLBasicModel::castShadowVolume(M3Vector& dir) {
	//...
}

void GLBasicModel::render(GLCamera& camera) {
  updateFrame();
  glPushMatrix();
  glMultMatrixf(getTransform());
  int cullMode;
  glGetIntegerv(GL_CULL_FACE_MODE,&cullMode);
  if(cullMode == GL_BACK)
    glCullFace(GL_FRONT);
  else
    glCullFace(GL_BACK);
  GLBasicMaterial* basMat = getBasicMaterial();
  GLMaterial* mat = getMaterial();
  if((mat == NULL) || (!mat->hasEnvironment())) {
    if(isTransparent()) {
      glDisable(GL_CULL_FACE);
      glDepthMask(GL_FALSE);
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }
    basMat->apply();
    draw();
    basMat->unapply();
    if(isTransparent()) {
      glEnable(GL_CULL_FACE);
      glDepthMask(GL_TRUE);
      glDisable(GL_BLEND);
    }
  } else {
    if(mat->hasGloss()) {
      mat->apply();
      draw();
      mat->unapply();
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE);
      if(IS_TEXTURE_ENV_ADD_SUPPORTED) {
        glActiveTextureARB(GL_TEXTURE0_ARB);
        mat->enableEnvironment(camera);
        glActiveTextureARB(GL_TEXTURE1_ARB);
        glEnable(GL_TEXTURE_2D);
        mat->applyGloss();
        glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
        draw();
        glActiveTextureARB(GL_TEXTURE1_ARB);
        glDisable(GL_TEXTURE_2D);
        glActiveTextureARB(GL_TEXTURE0_ARB);
        mat->disableEnvironment();
      } else {
        mat->enableEnvironment(camera);
        draw();
        mat->disableEnvironment();
        glEnable(GL_BLEND);
        glBlendFunc(GL_DST_COLOR,GL_ZERO);
        mat->applyGloss();
        draw();
      }
      glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
      glDisable(GL_BLEND);
    } else {
      mat->apply();
      draw();
      mat->unapply();
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE);
      mat->enableEnvironment(camera);
      draw();
      mat->disableEnvironment();
      glDisable(GL_BLEND);
    }
  }
  if(cullMode == GL_BACK)
    glCullFace(GL_BACK);
  else
    glCullFace(GL_FRONT);
  glPopMatrix();
}

void GLBasicModel::updateFrame() {
  if(currAnimation < 0)
    return;
  const float elapsedTime = GLBasicModel::getAnimationTime() < 0?
    GLWin::getElapsedTime(): GLBasicModel::getAnimationTime();
  interpolation = elapsedTime-lastUpdate;
  GLAnimationData& animation = bone->MD2_ANIMATION_DATA[currAnimation];
  int animationLastFrame = playBackward?
  	(-animation.lastFrame): animation.lastFrame;
  if(interpolation >= animation.invFPS) {
    interpolation -= animation.invFPS;
    if(interpolation >= animation.invFPS) {
      if(animationLastFrame < 0) { // play backward
	      currFrame -= int(interpolation*animation.fps+1);
  	    interpolation = float(fmod(interpolation,animation.invFPS));
	      if(currFrame < animation.firstFrame) {
  	      if(animation.backFrames) {
    	      currFrame =
      	      (animation.firstFrame-currFrame)%(animation.backFrames+1)+
        	    animation.firstFrame+animation.backFrames-1;
          	if(currFrame == animation.firstFrame) {
	            nextFrame = animation.firstFrame+animation.backFrames;
  	        } else {
    	        nextFrame = currFrame-1;
      	    }
        	} else {
	          currFrame = nextFrame = animation.firstFrame;
  	        stopAnimation = currAnimation;
    	      currAnimation = -1;
      	    return;
        	}
	      } else if(currFrame == animation.firstFrame) {
  	      if(animation.backFrames) {
    	      nextFrame = animation.firstFrame+animation.backFrames;
      	  } else {
        	  currFrame = nextFrame = animation.firstFrame;
          	stopAnimation = currAnimation;
	          currAnimation = -1;
  	        return;
    	    }
	      } else {
  	      nextFrame = currFrame-1;
    	  }
      } else { // play forward
	      currFrame += int(interpolation*animation.fps+1);
  	    interpolation = float(fmod(interpolation,animation.invFPS));
	      if(currFrame > animationLastFrame) {
  	      if(animation.backFrames) {
    	      currFrame =
      	      (currFrame-animationLastFrame)%(animation.backFrames+1)+
        	    animationLastFrame-animation.backFrames-1;
          	if(currFrame == animationLastFrame) {
	            nextFrame = animationLastFrame-animation.backFrames;
  	        } else {
    	        nextFrame = currFrame+1;
      	    }
        	} else {
	          currFrame = nextFrame = animationLastFrame;
  	        stopAnimation = currAnimation;
    	      currAnimation = -1;
      	    return;
        	}
	      } else if(currFrame == animationLastFrame) {
  	      if(animation.backFrames) {
    	      nextFrame = animationLastFrame-animation.backFrames;
      	  } else {
        	  currFrame = nextFrame = animationLastFrame;
          	stopAnimation = currAnimation;
	          currAnimation = -1;
  	        return;
    	    }
	      } else {
  	      nextFrame = currFrame+1;
    	  }
      }
    } else {
      currFrame = nextFrame;
    	if(animationLastFrame < 0) { // play backward
  	    if(nextFrame == animation.firstFrame) {
    	    if(animation.backFrames) {
      	    nextFrame += animation.backFrames;
        	} else {
	          currFrame = nextFrame = animation.firstFrame;
  	        stopAnimation = currAnimation;
    	      currAnimation = -1;
      	    return;
        	}
	      } else {
  	      nextFrame--;
    	  }
      } else { // play forward
  	    if(nextFrame == animationLastFrame) {
    	    if(animation.backFrames) {
      	    nextFrame -= animation.backFrames;
        	} else {
	          currFrame = nextFrame = animationLastFrame;
  	        stopAnimation = currAnimation;
    	      currAnimation = -1;
      	    return;
        	}
	      } else {
  	      nextFrame++;
    	  }
      }
    }
    lastUpdate = elapsedTime-interpolation;
  }
  interpolation *= animation.fps;
}

void GLBasicModel::rescale(float s) {
  scale *= s;
  maxRadius *= s;
}

//
// GLModel
//
GLModel::GLModel(bool ownsCache):
  currFrame(-1), nextFrame(-1), interpolation(0), lastUpdate(0), bone(NULL),
  links(NULL), yawAngle(0), pitchAngle(0), scale(1/64.0f), cache(NULL),
  currAnimation(-1), stopAnimation(-1), playBackward(false)
#ifdef USE_OGLES
#else // !USE_OGLES
  , vertexBuffer(NULL)
#endif // !USE_OGLES
{
  if(!MTNormals2D::isInitialized())
    MTNormals2D::initialize();
  if(ownsCache)
    initPrivateCache();
  else
    acquireStaticCache();
}

GLModel::GLModel(GLModel& model): yawAngle(0), pitchAngle(0), cache(NULL)
#ifdef USE_OGLES
#else // !USE_OGLES
  , vertexBuffer(NULL)
#endif // !USE_OGLES
{
  if(model.hasPrivateCache())
    initPrivateCache();
  else
    acquireStaticCache();
  playBackward = model.playBackward;
  currFrame = model.currFrame;
  nextFrame = model.nextFrame;
  lastUpdate = model.lastUpdate;
  interpolation = model.interpolation;
  currAnimation = model.currAnimation;
  stopAnimation = -1;
  bone = model.bone;
  bone->acquireReference();
  links = new GLObject*[bone->linksCount];
  for(int ct = 0; ct < bone->linksCount; ct++)
    links[ct] = model.links[ct];
  setBasicMaterial(model.getBasicMaterial());
  setTransparent(model.isTransparent());
  setMaxRadius(model.getMaxRadius());
  setScale(model.getScale());
}

float GLModel::animationTime = -1;

DMCache* GLModel::staticCache = NULL;
#ifdef USE_OGLES
#else // !USE_OGLES
GLVertexProgram* GLModel::lerpVP = NULL;
#endif // !USE_OGLES

GLModel::~GLModel() {
#ifdef USE_OGLES
#else // !USE_OGLES
  if(vertexBuffer) {
    vertexBuffer->releaseReference();
    if(lerpVP && lerpVP->releaseReference())
      lerpVP = NULL;
  }
#endif // !USE_OGLES
  if(hasPrivateCache())
    cache->releaseReference();
  else if(staticCache && staticCache->releaseReference())
    staticCache = NULL;
  if(bone) bone->releaseReference();
  if(links) delete[] links;
}

#ifdef USE_DATA_FILES

GLModel::GLModel(
  const char* path, const char* md3Name, const char* imgName,
  const char* alphaImgName, bool ownsCache
):
  currFrame(-1), nextFrame(-1), interpolation(0), lastUpdate(0), bone(NULL),
  links(NULL), yawAngle(0), pitchAngle(0), scale(1/64.0f), cache(NULL),
  currAnimation(-1), stopAnimation(-1), playBackward(false)
#ifdef USE_OGLES
#else // !USE_OGLES
  , vertexBuffer(NULL)
#endif // !USE_OGLES
{
  if(!MTNormals2D::isInitialized())
    MTNormals2D::initialize();
  if(ownsCache)
    initPrivateCache();
  else
    acquireStaticCache();
  load(path,md3Name,imgName,alphaImgName);
}

bool GLModel::load(
  const char* path, const char* md3Name, const char* imgName,
  const char* alphaImgName
) {
  char fileName[MAX_PATH];
  if(path)
	  strcat(strcpy(fileName,path),md3Name);
  else
	  strcpy(fileName,md3Name);
  FILE* file = fopen(fileName,"rb");
  if(file) {
    if(strstr(md3Name,".md3")) {
      MD3ModelHeader header;
      fread(&header,sizeof(header),1,file);
      if((strncmp(header.id,"IDP3",4) == 0) && (header.version == 15)) {
        bone = new GLBone();
        bone->acquireReference();
        bone->framesCount = header.numBoneFrames;
	      if(bone->framesCount == 1)
  	      currFrame = nextFrame = 0;
        fseek(file,sizeof(MD3BoneFrame)*header.numBoneFrames,SEEK_CUR);
        bone->linksCount = header.numTags;
        bone->linkNames = new char*[bone->linksCount];
        bone->transformsCount = header.numBoneFrames*header.numTags;
        bone->transforms = new MD3Transform[bone->transformsCount];
        MD3Tag* tags = new MD3Tag[bone->transformsCount];
        fread(tags,sizeof(MD3Tag),bone->transformsCount,file);
        for(int ct = 0; ct < bone->linksCount; ct++) {
          bone->linkNames[ct] = new char[strlen(tags[ct].name)+1];
          strcpy(bone->linkNames[ct],tags[ct].name);
        }
        for(int ct = 0; ct < bone->transformsCount; ct++)
          bone->transforms[ct] = tags[ct].transform;
        delete tags;
        links = new GLObject*[header.numTags];
        for(int ct = 0; ct < header.numTags; ct++) {
          links[ct] = NULL;
					float* r = bone->transforms[ct].rotation.matrix;
			    float val = r[0]*r[0]+r[3]*r[3]+r[6]*r[6];
					const float EPS = 0.0001f;
			    if((val > 1+EPS) || (val < 1-EPS)) {
				   	val = 1/sqrt(val);
						for(
            	int ct2 = 0; ct2 < bone->transformsCount; ct2 += header.numTags
            ) {
							r = bone->transforms[ct+ct2].rotation.matrix;
				     	r[0] *= val; r[1] *= val; r[2] *= val;
				     	r[3] *= val; r[4] *= val; r[5] *= val;
				     	r[6] *= val; r[7] *= val; r[8] *= val;
				    }
          }
        }
        bone->shapesCount = header.numMeshes;
        bone->shapes = new GLAnimatedShape[bone->shapesCount];
        long meshOffset = ftell(file);
        for(int ct = 0; ct < header.numMeshes; ct++) {
          int len;
          fseek(file,meshOffset,SEEK_SET);
          MD3MeshHeader meshHeader;
          fread(&meshHeader,sizeof(MD3MeshHeader),1,file);
          bone->shapes[ct].trianglesCount = meshHeader.numTriangles;
          bone->shapes[ct].vertexesCount = meshHeader.numVertexes;
          // fseek(file,sizeof(MD3Skin)*meshHeader.numSkins,SEEK_CUR);
          fseek(file,meshOffset+meshHeader.triStart,SEEK_SET);
          len = meshHeader.numTriangles;
          bone->shapes[ct].triangle = new MD3Triangle[len];
#ifdef USE_OGLES
          struct IntTri {int vertex[3];};
          IntTri *intTri = new IntTri[len];
          fread(intTri,sizeof(IntTri),len,file);
          MD3Triangle* md3Tri = bone->shapes[ct].triangle;
          for(int idx = 0; idx < len; idx++) {
            md3Tri[idx].vertex[0] = short(intTri[idx].vertex[0]);
            md3Tri[idx].vertex[1] = short(intTri[idx].vertex[1]);
            md3Tri[idx].vertex[2] = short(intTri[idx].vertex[2]);
          }
#else // !USE_OGLES
          fread(bone->shapes[ct].triangle,sizeof(MD3Triangle),len,file);
#endif // !USE_OGLES
          fseek(file,meshOffset+meshHeader.texVectorStart,SEEK_SET);
          len = meshHeader.numVertexes;
          bone->shapes[ct].texCoord = new MD3TexCoord[len];
          fread(bone->shapes[ct].texCoord,sizeof(MD3TexCoord),len,file);
          for(int texCoo = 0; texCoo < len; texCoo++) {
            float t = bone->shapes[ct].texCoord[texCoo].coord[1];
            bone->shapes[ct].texCoord[texCoo].coord[1] = 1-t;
          }
          fseek(file,meshOffset+meshHeader.vertexStart,SEEK_SET);
          len = meshHeader.numVertexes*meshHeader.numMeshFrames;
          bone->shapes[ct].vertex = new MD3Vertex[len];
          fread(bone->shapes[ct].vertex,sizeof(MD3Vertex),len,file);
          meshOffset += meshHeader.meshSize;
        }
      }
    } else if(strstr(md3Name,".mdx")) {
      int numBoneFrames;
      fread(&numBoneFrames,sizeof(int),1,file);
      int numTags;
      fread(&numTags,sizeof(int),1,file);
      int numMeshes;
      fread(&numMeshes,sizeof(int),1,file);
      bone = new GLBone();
      bone->acquireReference();
      bone->framesCount = numBoneFrames;
      if(bone->framesCount == 1)
        currFrame = nextFrame = 0;
      bone->linksCount = numTags;
      bone->linkNames = new char*[numTags];
      int numAnimations;
      fread(&numAnimations,sizeof(int),1,file);
      bone->animationsCount = numAnimations;
      bone->animations = new GLAnimationData[numAnimations];
      for(int ct = 0; ct < numAnimations; ct++) {
        int first;
        fread(&first,sizeof(int),1,file);
        int last;
        fread(&last,sizeof(int),1,file);
        int back;
        fread(&back,sizeof(int),1,file);
        int fps;
        fread(&fps,sizeof(int),1,file);
        bone->animations[ct].firstFrame = first;
        bone->animations[ct].lastFrame = last;
        bone->animations[ct].backFrames = back;
        bone->animations[ct].fps = fps;
        bone->animations[ct].invFPS = fps == 0? 1: 1.0f/fps;
      }
      bone->transformsCount = numBoneFrames*numTags;
      bone->transforms = new MD3Transform[bone->transformsCount];
      for(int ct = 0; ct < bone->linksCount; ct++) {
        char tagName[16];
        fread(&tagName,16,1,file);
        bone->linkNames[ct] = new char[strlen(tagName)+1];
        strcpy(bone->linkNames[ct],tagName);
      }
      fread(bone->transforms,sizeof(MD3Transform),bone->transformsCount,file);
      links = new GLObject*[numTags];
      for(int ct = 0; ct < numTags; ct++) {
        links[ct] = NULL;
				float* r = bone->transforms[ct].rotation.matrix;
		    float val = r[0]*r[0]+r[3]*r[3]+r[6]*r[6];
				const float EPS = 0.0001f;
		    if((val > 1+EPS) || (val < 1-EPS)) {
			   	val = 1/sqrt(val);
					for(
           	int ct2 = 0; ct2 < bone->transformsCount; ct2 += numTags
          ) {
						r = bone->transforms[ct+ct2].rotation.matrix;
			     	r[0] *= val; r[1] *= val; r[2] *= val;
			     	r[3] *= val; r[4] *= val; r[5] *= val;
			     	r[6] *= val; r[7] *= val; r[8] *= val;
			    }
        }
      }
      bone->shapesCount = numMeshes;
      bone->shapes = new GLAnimatedShape[bone->shapesCount];
      for(int ct = 0; ct < numMeshes; ct++) {
        int numMeshFrames;
        fread(&numMeshFrames,sizeof(int),1,file);
        int numTriangles;
        fread(&numTriangles,sizeof(int),1,file);
        int numVertexes;
        fread(&numVertexes,sizeof(int),1,file);
        bone->shapes[ct].trianglesCount = numTriangles;
        bone->shapes[ct].vertexesCount = numVertexes;
        int len = numTriangles;
        bone->shapes[ct].triangle = new MD3Triangle[len];
        fread(bone->shapes[ct].triangle,sizeof(MD3Triangle),len,file);
        len = numVertexes;
        bone->shapes[ct].texCoord = new MD3TexCoord[len];
        fread(bone->shapes[ct].texCoord,sizeof(MD3TexCoord),len,file);
        len = numVertexes*numMeshFrames;
        bone->shapes[ct].vertex = new MD3Vertex[len];
        fread(bone->shapes[ct].vertex,sizeof(MD3Vertex),len,file);
      }
    }
    computeMaxRadius();
    fclose(file);
    if(imgName && isalpha(imgName[0])) {
      char fileName[MAX_PATH];
      if(path)
	      strcat(strcpy(fileName,path),imgName);
      else
	      strcpy(fileName,imgName);
      DRImage* image = DRImage::getImageFromFile(fileName);
      if(alphaImgName) {
      	if(path)
	        strcat(strcpy(fileName,path),alphaImgName);
        else
	        strcpy(fileName,alphaImgName);
        DRImage* alphaImage = DRImage::getImageFromFile(fileName);
        image->addAlpha(*alphaImage);
        delete alphaImage;
        setTransparent(true);
      }
      GLMaterial* material = new GLMaterial();
      material->setDiffuseTexture(new GLTexture(*image));
      material->setShininess(64);
      delete image;
      setMaterial(material);
    }
    return true;
  }
  return false;
}

#endif // USE_DATA_FILES

float GLModel::computeMaxRadius() {
  if(maxRadius)
    return maxRadius;
  int maxX = 0;
  int maxY = 0;
  int maxZ = 0;
  for(int cur = 0; cur < bone->shapesCount; cur++) {
    int vertexesCount = bone->shapes[cur].vertexesCount;
    for(int frm = 0; frm < bone->framesCount; frm++) {
      int curOffsetVertex = frm*vertexesCount;
      for(int ct = 0; ct < vertexesCount; ct++) {
        MD3Vertex& vertex = bone->shapes[cur].vertex[curOffsetVertex+ct];
        int coo = abs(vertex.coord[0]);
        if(maxX < coo) maxX = coo;
        coo = abs(vertex.coord[1]);
        if(maxY < coo) maxY = coo;
        coo = abs(vertex.coord[2]);
        if(maxZ < coo) maxZ = coo;
      }
    }
  }
  float dx = maxX*scale;
  float dy = maxY*scale;
  float dz = maxZ*scale;
  return maxRadius = sqrt(dx*dx+dy*dy+dz*dz);
}

void GLModel::setAnimation(int anim, bool playBack) {
	if((anim >= bone->animationsCount) || (anim < 0))
  	return;
	playBackward = playBack;
  currAnimation = anim;
  stopAnimation = -1;
  lastUpdate = GLModel::getAnimationTime() < 0?
    GLWin::getElapsedTime(): GLModel::getAnimationTime();
  GLAnimationData& animation = bone->animations[currAnimation];
  int animationLastFrame = playBackward?
  	(-animation.lastFrame): animation.lastFrame;
  if(animationLastFrame < 0) { // play backward
	  if(currFrame < 0) {
  	  currFrame = -animationLastFrame;
    	nextFrame = currFrame-1;
	    if(nextFrame < animation.firstFrame)
  	    nextFrame = currFrame;
	  } else {
  	  nextFrame = -animationLastFrame;
    	if(currFrame == nextFrame) {
      	nextFrame = currFrame-1;
	      if(nextFrame < animation.firstFrame)
  	      nextFrame = currFrame;
    	}
	  }
  } else { // play forward
	  if(currFrame < 0) {
  	  currFrame = animation.firstFrame;
    	nextFrame = currFrame+1;
	    if(nextFrame > animationLastFrame)
  	    nextFrame = currFrame;
	  } else {
  	  nextFrame = animation.firstFrame;
    	if(currFrame == nextFrame) {
      	nextFrame = currFrame+1;
	      if(nextFrame > animationLastFrame)
  	      nextFrame = currFrame;
    	}
	  }
  }
}

#ifdef USE_OGLES
#else // !USE_OGLES

const char* lerpProgram =
"!!ARBvp1.0"
"PARAM mvp[4] = {state.matrix.mvp};"
"PARAM mvi[4] = {state.matrix.modelview.invtrans};"
"PARAM lerp = program.local[0];"
"ATTRIB pos0 = vertex.position;"
"ATTRIB pos1 = vertex.color;"
"ATTRIB tex0 = vertex.texcoord[0];"
"ATTRIB nor0 = vertex.normal;"
"MOV result.texcoord[0], tex0;"
"TEMP v;"
"ADD v, pos1, -pos0;"
"MAD v, lerp, v, pos0;"
"DP4 result.position.x, mvp[0], v;"
"DP4 result.position.y, mvp[1], v;"
"DP4 result.position.z, mvp[2], v;"
"DP4 result.position.w, mvp[3], v;"
"PARAM light = state.light[0].position;"
"PARAM half = state.light[0].half;"
"PARAM specExp = state.material.shininess;"
"PARAM ambientCol = state.lightprod[0].ambient;"
"PARAM diffuseCol = state.lightprod[0].diffuse;"
"PARAM specularCol = state.lightprod[0].specular;"
"TEMP nor, temp, dots;"
"OUTPUT oColor = result.color;"
"DP3 nor.x, mvi[0], nor0;"
"DP3 nor.y, mvi[1], nor0;"
"DP3 nor.z, mvi[2], nor0;"
"DP3 dots.x, nor, light;"
"DP3 dots.y, nor, half;"
"MOV dots.w, specExp.x;"
"LIT dots, dots;"
"MAD temp, dots.y, diffuseCol, ambientCol;"
"MAD oColor.xyz, dots.z, specularCol, temp;"
"MOV oColor.w, diffuseCol.w;"
"END"
;

#endif // !USE_OGLES

void GLModel::useVertexBuffer() {
#ifdef USE_OGLES
  return;
#else // !USE_OGLES
  const bool EXTS_SUPPORTED =
    IS_VERTEX_PROGRAM_SUPPORTED && IS_VERTEX_BUFFER_SUPPORTED;
  if(vertexBuffer || !EXTS_SUPPORTED)
    return;
  if(lerpVP)
    lerpVP->acquireReference();
  else
    lerpVP = (new GLVertexProgram(lerpProgram))->acquireReference();
  int totalVertexesCount = 0;
  for(int currShape = 0; currShape < bone->shapesCount; currShape++) {
    GLAnimatedShape& shp = bone->shapes[currShape];
    totalVertexesCount += shp.vertexesCount;
  }
  int arraySize = (2+3+3)*totalVertexesCount*bone->framesCount;
  float* array = new float[arraySize];
  float* arrayPointer = array-1;
  for(int currShape = 0; currShape < bone->shapesCount; currShape++) {
    GLAnimatedShape& shp = bone->shapes[currShape];
    int vertexesCount = shp.vertexesCount;
    for(int currFrame = 0; currFrame < bone->framesCount; currFrame++) {
      int curOffsetVertex = currFrame*vertexesCount;
      for(int ct = 0; ct < vertexesCount; ct++) {
        MD3TexCoord& texCoord = shp.texCoord[ct];
        *(++arrayPointer) = texCoord.coord[0];
        *(++arrayPointer) = texCoord.coord[1];
        MD3Vertex& vertex = shp.vertex[curOffsetVertex+ct];
        int normU = vertex.normal[0];
        int normV = vertex.normal[1];
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,0);
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,1);
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,2);
        *(++arrayPointer) = vertex.coord[0]*scale;
        *(++arrayPointer) = vertex.coord[1]*scale;
        *(++arrayPointer) = vertex.coord[2]*scale;
      }
    }
  }
  vertexBuffer = (new GLVertexBuffer(
    arraySize*sizeof(float),array
  ))->acquireReference();
  delete array;
#endif // !USE_OGLES
}

void GLModel::drawNI(bool drawCached) {
#ifndef USE_OGLES
if(vertexBuffer) {
  vertexBuffer->apply();
  int arraysOffset = 0;
  for(int currShape = 0; currShape < bone->shapesCount; currShape++) {
    GLAnimatedShape& shp = bone->shapes[currShape];
    int vertexesCount = shp.vertexesCount;
    int trianglesCount = shp.trianglesCount;
    int currOffsetVertex = currFrame <= 0? arraysOffset:
      arraysOffset+currFrame*vertexesCount*(2+3+3)*sizeof(float);
    glInterleavedArrays(
      GL_T2F_N3F_V3F,0,vertexBuffer->getOffset(currOffsetVertex)
    );
    glDrawElements(
      GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle
    );
    arraysOffset += vertexesCount*bone->framesCount*(2+3+3)*sizeof(float);
  }
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisableClientState(GL_NORMAL_ARRAY);
  glDisableClientState(GL_VERTEX_ARRAY);
  vertexBuffer->disable();
} else {
#endif // !USE_OGLES
  int arraysOffset = 0;
  for(int cur = 0; cur < bone->shapesCount; cur++) {
    GLAnimatedShape& shp = bone->shapes[cur];
    int vertexesCount = shp.vertexesCount;
    int trianglesCount = shp.trianglesCount;
    float* arrays = getArrays((3+3)*vertexesCount+arraysOffset)+arraysOffset;
    arraysOffset += (3+3)*vertexesCount;
    if(!drawCached) {
      float* arrayPointer = arrays-1;
      int curOffsetVertex = currFrame <= 0? 0: currFrame*vertexesCount;
      for(int ct = 0; ct < vertexesCount; ct++) {
        MD3Vertex& vertex = shp.vertex[curOffsetVertex+ct];
        int normU = vertex.normal[0];
        int normV = vertex.normal[1];
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,0);
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,1);
        *(++arrayPointer) = MTNormals2D::getNormal(normU,normV,2);
        *(++arrayPointer) = vertex.coord[0]*scale;
        *(++arrayPointer) = vertex.coord[1]*scale;
        *(++arrayPointer) = vertex.coord[2]*scale;
      }
    }
    if(IS_MULTITEXTURING_ENABLED) {
      glClientActiveTextureARB(GL_TEXTURE1_ARB);
      glEnableClientState(GL_TEXTURE_COORD_ARRAY);
      glTexCoordPointer(2,GL_FLOAT,0,shp.texCoord);
      glClientActiveTextureARB(GL_TEXTURE0_ARB);
    }
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2,GL_FLOAT,0,shp.texCoord);
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT,sizeof(float)*(3+3),arrays);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3,GL_FLOAT,sizeof(float)*(3+3),arrays+3);
#ifdef USE_OGLES
    glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_SHORT,shp.triangle);
#else // !USE_OGLES
    glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle);
#endif // !USE_OGLES
    if(IS_MULTITEXTURING_ENABLED) {
      glClientActiveTextureARB(GL_TEXTURE1_ARB);
      glDisableClientState(GL_TEXTURE_COORD_ARRAY);
      glClientActiveTextureARB(GL_TEXTURE0_ARB);
    }
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
  }
#ifndef USE_OGLES
}
#endif // !USE_OGLES
}

void GLModel::draw(bool drawCached) {
  if(currFrame == nextFrame) {
    drawNI(drawCached);
  } else
#ifndef USE_OGLES
  if(vertexBuffer) {
    lerpVP->enable();
    lerpVP->apply();
    lerpVP->setLocalParameter(0,interpolation,interpolation,interpolation,1);
    vertexBuffer->apply();
    int arraysOffset = 0;
    for(int currShape = 0; currShape < bone->shapesCount; currShape++) {
      GLAnimatedShape& shp = bone->shapes[currShape];
      int vertexesCount = shp.vertexesCount;
      int trianglesCount = shp.trianglesCount;
      int currOffsetVertex =
        arraysOffset+currFrame*vertexesCount*(2+3+3)*sizeof(float);
      glInterleavedArrays(
        GL_T2F_N3F_V3F,0,vertexBuffer->getOffset(currOffsetVertex)
      );
      glEnableClientState(GL_COLOR_ARRAY);
      glColorPointer(
        3,GL_FLOAT,(2+3+3)*sizeof(float),
        vertexBuffer->getOffset(currOffsetVertex+5*sizeof(float))
      );
      glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle);
      arraysOffset += vertexesCount*bone->framesCount*(2+3+3)*sizeof(float);
    }
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    vertexBuffer->disable();
    lerpVP->disable();
  } else
#endif // !USE_OGLES
  {
    int arraysOffset = 0;
    for(int cur = 0; cur < bone->shapesCount; cur++) {
      GLAnimatedShape& shp = bone->shapes[cur];
      int vertexesCount = shp.vertexesCount;
      int trianglesCount = shp.trianglesCount;
      float* arrays = getArrays((3+3)*vertexesCount+arraysOffset)+arraysOffset;
      arraysOffset += (3+3)*vertexesCount;
      if(!drawCached) {
        float* arrayPointer = arrays-1;
        int curOffsetVertex = currFrame*vertexesCount;
        int nexOffsetVertex = nextFrame*vertexesCount;
        for(int ct = 0; ct < vertexesCount; ct++) {
          MD3Vertex& curVertex = shp.vertex[curOffsetVertex+ct];
          MD3Vertex& nexVertex = shp.vertex[nexOffsetVertex+ct];
          float curN[3];
          float nexN[3];
          int normU = curVertex.normal[0];
          int normV = curVertex.normal[1];
          curN[0] = MTNormals2D::getNormal(normU,normV,0);
          curN[1] = MTNormals2D::getNormal(normU,normV,1);
          curN[2] = MTNormals2D::getNormal(normU,normV,2);
          normU = nexVertex.normal[0];
          normV = nexVertex.normal[1];
          nexN[0] = MTNormals2D::getNormal(normU,normV,0);
          nexN[1] = MTNormals2D::getNormal(normU,normV,1);
          nexN[2] = MTNormals2D::getNormal(normU,normV,2);
          *(++arrayPointer) = curN[0]+interpolation*(nexN[0]-curN[0]);
          *(++arrayPointer) = curN[1]+interpolation*(nexN[1]-curN[1]);
          *(++arrayPointer) = curN[2]+interpolation*(nexN[2]-curN[2]);
          float curV[3] = {
            curVertex.coord[0],curVertex.coord[1],curVertex.coord[2]
          };
          float nexV[3] = {
            nexVertex.coord[0],nexVertex.coord[1],nexVertex.coord[2]
          };
          *(++arrayPointer) = (curV[0]+interpolation*(nexV[0]-curV[0]))*scale;
          *(++arrayPointer) = (curV[1]+interpolation*(nexV[1]-curV[1]))*scale;
          *(++arrayPointer) = (curV[2]+interpolation*(nexV[2]-curV[2]))*scale;
        }
      }
      if(IS_MULTITEXTURING_ENABLED) {
        glClientActiveTextureARB(GL_TEXTURE1_ARB);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glTexCoordPointer(2,GL_FLOAT,0,shp.texCoord);
        glClientActiveTextureARB(GL_TEXTURE0_ARB);
      }
      glEnableClientState(GL_TEXTURE_COORD_ARRAY);
      glTexCoordPointer(2,GL_FLOAT,0,shp.texCoord);
      glEnableClientState(GL_NORMAL_ARRAY);
      glNormalPointer(GL_FLOAT,sizeof(float)*(3+3),arrays);
      glEnableClientState(GL_VERTEX_ARRAY);
      glVertexPointer(3,GL_FLOAT,sizeof(float)*(3+3),arrays+3);
#ifdef USE_OGLES
      glDrawElements(
        GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_SHORT,shp.triangle
      );
#else // !USE_OGLES
      glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle);
#endif // !USE_OGLES
      if(IS_MULTITEXTURING_ENABLED) {
        glClientActiveTextureARB(GL_TEXTURE1_ARB);
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glClientActiveTextureARB(GL_TEXTURE0_ARB);
      }
      glDisableClientState(GL_TEXTURE_COORD_ARRAY);
      glDisableClientState(GL_NORMAL_ARRAY);
      glDisableClientState(GL_VERTEX_ARRAY);
    }
  }
}

void GLModel::castPlanarShadow() {
  glCullFace(GL_FRONT);
  if(currFrame == nextFrame) {
#ifndef USE_OGLES
    if(vertexBuffer) {
      vertexBuffer->apply();
      int arraysOffset = 0;
      glEnableClientState(GL_VERTEX_ARRAY);
      for(int currShape = 0; currShape < bone->shapesCount; currShape++) {
        GLAnimatedShape& shp = bone->shapes[currShape];
        int vertexesCount = shp.vertexesCount;
        int trianglesCount = shp.trianglesCount;
        int currOffsetVertex = currFrame <= 0? arraysOffset:
          arraysOffset+currFrame*vertexesCount*(2+3+3)*sizeof(float);
        glVertexPointer(
          3,GL_FLOAT,sizeof(float)*(2+3+3),
          vertexBuffer->getOffset(currOffsetVertex)+5
        );
        glDrawElements(
          GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle
        );
        arraysOffset += vertexesCount*bone->framesCount*(2+3+3)*sizeof(float);
      }
      glDisableClientState(GL_VERTEX_ARRAY);
      vertexBuffer->disable();
    } else {
#endif // !USE_OGLES
      int arraysOffset = 0;
      for(int cur = 0; cur < bone->shapesCount; cur++) {
        GLAnimatedShape& shp = bone->shapes[cur];
        int vertexesCount = shp.vertexesCount;
        int trianglesCount = shp.trianglesCount;
        float* arrays = getArrays((3+3)*vertexesCount+arraysOffset)+arraysOffset;
        arraysOffset += (3+3)*vertexesCount;
        if(!hasPrivateCache()) {
          float* arrayPointer = arrays-1;
          int curOffsetVertex = currFrame*vertexesCount;
          for(int ct = 0; ct < vertexesCount; ct++) {
            MD3Vertex& vertex = shp.vertex[curOffsetVertex+ct];
            arrayPointer += 3;
            *(++arrayPointer) = vertex.coord[0]*scale;
            *(++arrayPointer) = vertex.coord[1]*scale;
            *(++arrayPointer) = vertex.coord[2]*scale;
          }
        }
        glEnableClientState(GL_VERTEX_ARRAY);
        glVertexPointer(3,GL_FLOAT,sizeof(float)*(3+3),arrays+3);
#ifdef USE_OGLES
        glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_SHORT,shp.triangle);
#else // !USE_OGLES
        glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle);
#endif // !USE_OGLES
        glDisableClientState(GL_VERTEX_ARRAY);
      }
#ifndef USE_OGLES
    }
#endif // !USE_OGLES
  } else {
    int arraysOffset = 0;
    for(int cur = 0; cur < bone->shapesCount; cur++) {
      GLAnimatedShape& shp = bone->shapes[cur];
      int vertexesCount = shp.vertexesCount;
      int trianglesCount = shp.trianglesCount;
      float* arrays = getArrays(arraysOffset+(3+3)*vertexesCount)+arraysOffset;
      arraysOffset += (3+3)*vertexesCount;
      if(!hasPrivateCache()) {
        float* arrayPointer = arrays-1;
        int curOffsetVertex = currFrame*vertexesCount;
        int nexOffsetVertex = nextFrame*vertexesCount;
        for(int ct = 0; ct < vertexesCount; ct++) {
          MD3Vertex& curVertex = shp.vertex[curOffsetVertex+ct];
          MD3Vertex& nexVertex = shp.vertex[nexOffsetVertex+ct];
          arrayPointer += 3;
          float curV[3] = {
            curVertex.coord[0],curVertex.coord[1],curVertex.coord[2]
          };
          float nexV[3] = {
            nexVertex.coord[0],nexVertex.coord[1],nexVertex.coord[2]
          };
          *(++arrayPointer) = (curV[0]+interpolation*(nexV[0]-curV[0]))*scale;
          *(++arrayPointer) = (curV[1]+interpolation*(nexV[1]-curV[1]))*scale;
          *(++arrayPointer) = (curV[2]+interpolation*(nexV[2]-curV[2]))*scale;
        }
      }
      glEnableClientState(GL_VERTEX_ARRAY);
      glVertexPointer(3,GL_FLOAT,sizeof(float)*(3+3),arrays+3);
#ifdef USE_OGLES
      glDrawElements(
        GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_SHORT,shp.triangle
      );
#else // !USE_OGLES
      glDrawElements(GL_TRIANGLES,3*trianglesCount,GL_UNSIGNED_INT,shp.triangle);
#endif // !USE_OGLES
      glDisableClientState(GL_VERTEX_ARRAY);
    }
  }
  glCullFace(GL_BACK);
}

void GLModel::castShadowVolume(M3Vector& dir) {
	//...
}

void GLModel::renderBone(GLCamera& camera) {
  int cullMode;
  glGetIntegerv(GL_CULL_FACE_MODE,&cullMode);
  if(cullMode == GL_BACK)
    glCullFace(GL_FRONT);
  else
    glCullFace(GL_BACK);
  GLBasicMaterial* basMat = getBasicMaterial();
  GLMaterial* mat = getMaterial();
  if((mat == NULL) || (!mat->hasEnvironment())) {
    if(isTransparent()) {
      glDisable(GL_CULL_FACE);
      glDepthMask(GL_FALSE);
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }
    basMat->apply();
    draw();
    basMat->unapply();
    if(isTransparent()) {
      glEnable(GL_CULL_FACE);
      glDepthMask(GL_TRUE);
      glDisable(GL_BLEND);
    }
  } else {
    if(mat->hasGloss()) {
      mat->apply();
      draw();
      mat->unapply();
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE);
      if(IS_TEXTURE_ENV_ADD_SUPPORTED) {
        glActiveTextureARB(GL_TEXTURE0_ARB);
        mat->enableEnvironment(camera);
        glActiveTextureARB(GL_TEXTURE1_ARB);
        glEnable(GL_TEXTURE_2D);
        mat->applyGloss();
        glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
        draw(true);
        glActiveTextureARB(GL_TEXTURE1_ARB);
        glDisable(GL_TEXTURE_2D);
        glActiveTextureARB(GL_TEXTURE0_ARB);
        mat->disableEnvironment();
      } else {
        mat->enableEnvironment(camera);
        draw(true);
        mat->disableEnvironment();
        glEnable(GL_BLEND);
        glBlendFunc(GL_DST_COLOR,GL_ZERO);
        mat->applyGloss();
        draw(true);
      }
      glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
      glDisable(GL_BLEND);
    } else {
      mat->apply();
      draw();
      mat->unapply();
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE);
      mat->enableEnvironment(camera);
      draw(true);
      mat->disableEnvironment();
      glDisable(GL_BLEND);
    }
  }
  if(cullMode == GL_BACK)
    glCullFace(GL_BACK);
  else
    glCullFace(GL_FRONT);
}

void GLModel::render(GLCamera& camera) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  renderBone(camera);
  glPopMatrix();
}

bool GLModel::climbSkeleton(const char* tagName, M3Matrix& finalTransform) {
  M3Matrix copy = finalTransform;
  if((yawAngle != 0) || (pitchAngle != 0))
    finalTransform.multiplyT(dynamic_cast<M3Matrix&>(*this));
  for(int ct = 0; ct < bone->linksCount; ct++) {
  	bool targetFound = (strcmp(tagName+4,bone->linkNames[ct]+4) == 0);
    GLObject* obj = links[ct];
    if(obj || targetFound) {
      M3Matrix copy2 = finalTransform;
      float transform[16];
      if(currFrame == nextFrame) {
      	if(currFrame <= 0)
		      bone->transforms[ct].fillArray(transform);
        else
		      bone->transforms[currFrame*(bone->linksCount)+ct].fillArray(transform);
      } else {
        MD3Transform& startTr =
          bone->transforms[currFrame*(bone->linksCount)+ct];
        M3Quaternion start(startTr.rotation.matrix);
        MD3Transform& endTr =
          bone->transforms[nextFrame*(bone->linksCount)+ct];
        M3Quaternion end(endTr.rotation.matrix);
        start.slerp(end,interpolation);
        start.fillArray(transform);
        float* startPos = startTr.position.coord;
        float* endPos = endTr.position.coord;
        transform[12] = startPos[0]+interpolation*(endPos[0]-startPos[0]);
        transform[13] = startPos[1]+interpolation*(endPos[1]-startPos[1]);
        transform[14] = startPos[2]+interpolation*(endPos[2]-startPos[2]);
      }
      finalTransform.multiplyT(M3Matrix(transform));
      if(targetFound || obj->climbSkeleton(tagName,finalTransform))
        return true;
      finalTransform = copy2;
    }
  }
  finalTransform = copy;
  return false;
}

void GLModel::castShadowSkeleton(
  int mode, M3Vector& dir, GLShadowedDelegate& sd, M3Matrix* parentTransform
) {
  glPushMatrix();
  if((yawAngle != 0) || (pitchAngle != 0))
    glMultMatrixf(getTransform());
  glPushMatrix();
  castShadowBone(mode,dir,sd,parentTransform);
  glPopMatrix();
  M3Reference groupTransform;
  groupTransform.set(*static_cast<M3Matrix*>(this));
  if(parentTransform)
    groupTransform.multiply(*parentTransform);
  for(int ct = 0; ct < bone->linksCount; ct++) {
    GLObject* obj = links[ct];
    if(obj) {
      glPushMatrix();
      M3Reference localTransform;
      if(currFrame == nextFrame) {
      	if(currFrame <= 0)
	        bone->transforms[ct].fillArray(localTransform.getArray());
        else
	        bone->transforms[currFrame*(bone->linksCount)+ct].fillArray(
 		        localTransform.getArray()
   		    );
      } else {
        MD3Transform& startTr =
          bone->transforms[currFrame*(bone->linksCount)+ct];
        M3Quaternion start(startTr.rotation.matrix);
        MD3Transform& endTr =
          bone->transforms[nextFrame*(bone->linksCount)+ct];
        M3Quaternion end(endTr.rotation.matrix);
        start.slerp(end,interpolation);
        start.fillArray(localTransform.getArray());
        float* startPos = startTr.position.coord;
        float* endPos = endTr.position.coord;
        localTransform.setPosition(
          startPos[0]+interpolation*(endPos[0]-startPos[0]),
          startPos[1]+interpolation*(endPos[1]-startPos[1]),
          startPos[2]+interpolation*(endPos[2]-startPos[2])
        );
      }
      glMultMatrixf(localTransform.getArray());
      localTransform.multiply(groupTransform);
      obj->castShadowSkeleton(mode,dir,sd,&localTransform);
      glPopMatrix();
    }
  }
  glPopMatrix();
}

void GLModel::renderSkeleton(GLCamera& camera) {
  glPushMatrix();
  if((yawAngle != 0) || (pitchAngle != 0))
    glMultMatrixf(getTransform());
  renderBone(camera);
  for(int ct = 0; ct < bone->linksCount; ct++) {
    GLObject* obj = links[ct];
    if(obj) {
      glPushMatrix();
      float transform[16];
      if(currFrame == nextFrame) {
      	if(currFrame <= 0)
	 	      bone->transforms[ct].fillArray(transform);
        else
	 	      bone->transforms[currFrame*(bone->linksCount)+ct].fillArray(transform);
      } else {
        MD3Transform& startTr =
          bone->transforms[currFrame*(bone->linksCount)+ct];
        M3Quaternion start(startTr.rotation.matrix);
        MD3Transform& endTr =
          bone->transforms[nextFrame*(bone->linksCount)+ct];
        M3Quaternion end(endTr.rotation.matrix);
        start.slerp(end,interpolation);
        start.fillArray(transform);
        float* startPos = startTr.position.coord;
        float* endPos = endTr.position.coord;
        transform[12] = startPos[0]+interpolation*(endPos[0]-startPos[0]);
        transform[13] = startPos[1]+interpolation*(endPos[1]-startPos[1]);
        transform[14] = startPos[2]+interpolation*(endPos[2]-startPos[2]);
      }
      glMultMatrixf(transform);
      obj->renderSkeleton(camera);
      glPopMatrix();
    }
  }
  glPopMatrix();
}

void GLModel::updateFrame() {
  if(currAnimation < 0)
    return;
  const float elapsedTime = GLModel::getAnimationTime() < 0?
    GLWin::getElapsedTime(): GLModel::getAnimationTime();
  interpolation = elapsedTime-lastUpdate;
  GLAnimationData& animation = bone->animations[currAnimation];
  int animationLastFrame = playBackward?
  	(-animation.lastFrame): animation.lastFrame;
  if(interpolation >= animation.invFPS) {
    interpolation -= animation.invFPS;
    if(interpolation >= animation.invFPS) {
    	if(animationLastFrame < 0) { // play backward
	      currFrame -= int(interpolation*animation.fps+1);
  	    interpolation = float(fmod(interpolation,animation.invFPS));
    	  if(currFrame < animation.firstFrame) {
      	  if(animation.backFrames) {
        	  currFrame =
          	  (animation.firstFrame-currFrame)%(animation.backFrames+1)+
            	animation.firstFrame+animation.backFrames-1;
	          if(currFrame == animation.firstFrame) {
  	          nextFrame = animation.firstFrame+animation.backFrames;
    	      } else {
      	      nextFrame = currFrame-1;
        	  }
	        } else {
  	        currFrame = nextFrame = animation.firstFrame;
    	      stopAnimation = currAnimation;
      	    currAnimation = -1;
        	  return;
	        }
  	    } else if(currFrame == animation.firstFrame) {
    	    if(animation.backFrames) {
      	    nextFrame = animation.firstFrame+animation.backFrames;
        	} else {
          	currFrame = nextFrame = animation.firstFrame;
	          stopAnimation = currAnimation;
  	        currAnimation = -1;
    	      return;
      	  }
	      } else {
  	      nextFrame = currFrame-1;
    	  }
      } else { // play forward
	      currFrame += int(interpolation*animation.fps+1);
  	    interpolation = float(fmod(interpolation,animation.invFPS));
    	  if(currFrame > animationLastFrame) {
      	  if(animation.backFrames) {
        	  currFrame =
          	  (currFrame-animationLastFrame)%(animation.backFrames+1)+
            	animationLastFrame-animation.backFrames-1;
	          if(currFrame == animationLastFrame) {
  	          nextFrame = animationLastFrame-animation.backFrames;
    	      } else {
      	      nextFrame = currFrame+1;
        	  }
	        } else {
  	        currFrame = nextFrame = animationLastFrame;
    	      stopAnimation = currAnimation;
      	    currAnimation = -1;
        	  return;
	        }
  	    } else if(currFrame == animationLastFrame) {
    	    if(animation.backFrames) {
      	    nextFrame = animationLastFrame-animation.backFrames;
        	} else {
          	currFrame = nextFrame = animationLastFrame;
	          stopAnimation = currAnimation;
  	        currAnimation = -1;
    	      return;
      	  }
	      } else {
  	      nextFrame = currFrame+1;
    	  }
      }
    } else {
      currFrame = nextFrame;
      if(animationLastFrame < 0) { // play backward
	      if(nextFrame == animation.firstFrame) {
  	      if(animation.backFrames) {
    	      nextFrame += animation.backFrames;
      	  } else {
        	  currFrame = nextFrame = animation.firstFrame;
          	stopAnimation = currAnimation;
	          currAnimation = -1;
  	        return;
    	    }
      	} else {
        	nextFrame--;
	      }
      } else { // play forward
	      if(nextFrame == animationLastFrame) {
  	      if(animation.backFrames) {
    	      nextFrame -= animation.backFrames;
      	  } else {
        	  currFrame = nextFrame = animationLastFrame;
          	stopAnimation = currAnimation;
	          currAnimation = -1;
  	        return;
    	    }
      	} else {
        	nextFrame++;
	      }
      }
    }
    lastUpdate = elapsedTime-interpolation;
  }
  interpolation *= animation.fps;
}

void GLModel::rescale(float s) {
  scale *= s;
  maxRadius *= s;
  for(int ct = 0; ct < bone->transformsCount; ct++) {
    MD3Vector& v = bone->transforms[ct].position;
    v.coord[0] *= s;
    v.coord[1] *= s;
    v.coord[2] *= s;
  }
}

void GLModel::link(const char* tagName, GLObject* obj) {
  for(int ct = 0; ct < bone->linksCount; ct++) {
    if(strcmp(tagName+4,bone->linkNames[ct]+4) == 0) {
      links[ct] = obj;
      break;
    }
  }
}

float GLModel::addYawAngle(float a, float maxA, float minA) {
  float oldAngle = yawAngle;
  yawAngle += a;
  float diff = 0;
  if(maxA) {
    if(yawAngle > maxA) {
      diff = yawAngle-maxA;
      yawAngle = maxA;
    } else {
      if(minA) {
        if(yawAngle < minA) {
          diff = yawAngle-minA;
          yawAngle = minA;
        }
      } else {
        if(yawAngle < -maxA) {
          diff = yawAngle+maxA;
          yawAngle = -maxA;
        }
      }
    }
  }
  if(yawAngle != oldAngle)
    updateRotations();
  return diff;
}

float GLModel::addPitchAngle(float a, float maxA, float minA) {
  float oldAngle = pitchAngle;
  pitchAngle += a;
  float diff = 0;
  if(maxA) {
    if(pitchAngle > maxA) {
      diff = pitchAngle-maxA;
      pitchAngle = maxA;
    } else {
      if(minA) {
        if(pitchAngle < minA) {
          diff = pitchAngle-minA;
          pitchAngle = minA;
        }
      } else {
        if(pitchAngle < -maxA) {
          diff = pitchAngle+maxA;
          pitchAngle = -maxA;
        }
      }
    }
  }
  if(pitchAngle != oldAngle)
    updateRotations();
  return diff;
}

//
// GLBot
//
GLBot::GLBot(bool ownsCache): GLModel(ownsCache), upper(NULL), head(NULL) {
}

GLBot::GLBot(GLBot& bot): GLModel(static_cast<GLModel&>(bot)) {
  head = new GLModel(bot.getHead());
  upper = new GLModel(bot.getUpper());
  link("tag_torso",upper);
  upper->link("tag_head",head);
}

#ifdef USE_DATA_FILES

bool GLBot::loadBot(const char* path, const char* modelName, bool ownsCaches) {
  char fileName[MAX_PATH];
  if(path)
	  strcat(strcpy(fileName,path),modelName);
  else
	  strcpy(fileName,modelName);
  FILE* file = fopen(fileName,"rt");
  if(file) {
    const int MAX_LINE_LEN = 1023;
    char line[MAX_LINE_LEN+1];
    const char* SEP = " \t,\n";
    fgets(line,MAX_LINE_LEN,file);
    bool IS_MOD;
    int BOTH_ANIMS;
    int UPPER_ANIMS;
    int LOWER_ANIMS;
    if(strncmp(line,"MOD ",4) == 0) {
    	IS_MOD = true;
      char* tok;
      strtok(line,SEP);
      tok = strtok(NULL,SEP);
      BOTH_ANIMS = atoi(tok);
      tok = strtok(NULL,SEP);
      int UP_ANIMS = atoi(tok);
      tok = strtok(NULL,SEP);
      int LO_ANIMS = atoi(tok);
	    UPPER_ANIMS = BOTH_ANIMS+UP_ANIMS;
    	LOWER_ANIMS = BOTH_ANIMS+LO_ANIMS;
	    fgets(line,MAX_LINE_LEN,file);
    } else {
    	IS_MOD = false;
      BOTH_ANIMS  = MAX_BOTH_ANIMATIONS;
  	  UPPER_ANIMS = MAX_UPPER_ANIMATIONS;
	    LOWER_ANIMS = MAX_LOWER_ANIMATIONS;
    }
    GLBasicMaterial* mat;
    char *md3Name, *imgName;
    md3Name = strtok(line,SEP);
    imgName = strtok(NULL,SEP);
    load(path,md3Name,imgName);
    mat = getBasicMaterial();
    md3Name = strtok(NULL,SEP);
    imgName = strtok(NULL,SEP);
    bool isMD3 = (bool)strstr(md3Name,".md3");
    if(upper)
    	delete upper;
    upper = new GLModel(path,md3Name,imgName,NULL,ownsCaches);
    if(imgName[0] == '*')
      upper->setBasicMaterial(mat);
    mat = upper->getBasicMaterial();
    md3Name = strtok(NULL,SEP);
    imgName = strtok(NULL,SEP);
    if(head)
    	delete head;
    head = new GLModel(path,md3Name,imgName,NULL,ownsCaches);
    if(imgName[0] == '*')
      head->setBasicMaterial(mat);
    setMaxRadius(getMaxRadius()+upper->getMaxRadius()+head->getMaxRadius());
    if(isMD3) {
      GLAnimationData* lowerAnimation =
        new GLAnimationData[LOWER_ANIMS];
      GLAnimationData* upperAnimation =
        new GLAnimationData[UPPER_ANIMS];
      int ct = 0;
      while((ct < BOTH_ANIMS) && fgets(line,MAX_LINE_LEN,file)) {
        int first = atoi(strtok(line,SEP));
        lowerAnimation[ct].firstFrame = upperAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        lowerAnimation[ct].lastFrame = upperAnimation[ct].lastFrame =
          next < 0? -(first-next-1): (first+next-1);
        lowerAnimation[ct].backFrames = upperAnimation[ct].backFrames =
          atoi(strtok(NULL,SEP));
        if(lowerAnimation[ct].backFrames != 0) {
          lowerAnimation[ct].backFrames--;
          upperAnimation[ct].backFrames--;
        }
        char *val = strtok(NULL,SEP);
        lowerAnimation[ct].fps = upperAnimation[ct].fps = val? atoi(val): 1;
        lowerAnimation[ct].invFPS = upperAnimation[ct].invFPS =
          1.0f/lowerAnimation[ct].fps;
        ct++;
      }
      while((ct < UPPER_ANIMS) && fgets(line,MAX_LINE_LEN,file)) {
        int first = atoi(strtok(line,SEP));
        upperAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        upperAnimation[ct].lastFrame = next < 0? -(first-next-1): (first+next-1);
        upperAnimation[ct].backFrames = atoi(strtok(NULL,SEP));
        if(upperAnimation[ct].backFrames != 0)
          upperAnimation[ct].backFrames--;
        char *val = strtok(NULL,SEP);
        upperAnimation[ct].fps = val? atoi(val): 1;
        upperAnimation[ct].invFPS = 1.0f/upperAnimation[ct].fps;
        ct++;
      }
      ct = BOTH_ANIMS;
      while((ct < LOWER_ANIMS) && fgets(line,MAX_LINE_LEN,file)) {
        int first = atoi(strtok(line,SEP));
        lowerAnimation[ct].firstFrame = first;
        int next = atoi(strtok(NULL,SEP));
        lowerAnimation[ct].lastFrame = next < 0? -(first-next-1): (first+next-1);
        lowerAnimation[ct].backFrames = atoi(strtok(NULL,SEP));
        if(lowerAnimation[ct].backFrames != 0)
          lowerAnimation[ct].backFrames--;
        char *val = strtok(NULL,SEP);
        lowerAnimation[ct].fps = val? atoi(val): 1;
        lowerAnimation[ct].invFPS = 1.0f/lowerAnimation[ct].fps;
        ct++;
      }
      if(!IS_MOD) {
	      int skip =
  	      lowerAnimation[BOTH_ANIMS].firstFrame-
    	    upperAnimation[BOTH_ANIMS].firstFrame;
      	for(int ct = BOTH_ANIMS; ct < LOWER_ANIMS; ct++) {
  	      lowerAnimation[ct].firstFrame -= skip;
    	    lowerAnimation[ct].lastFrame -= skip;
      	}
      }
      setAnimations(LOWER_ANIMS,lowerAnimation);
      upper->setAnimations(UPPER_ANIMS,upperAnimation);
      if(!IS_MOD) {
	      setLowerAnimation(LEGS_IDLE);
  	    setUpperAnimation(TORSO_STAND);
      } else {
	      setLowerAnimation(0);
  	    setUpperAnimation(0);
      }
    }
    fclose(file);
    link("tag_torso",upper);
    upper->link("tag_head",head);
    return true;
  }
  return false;
}

#endif // USE_DATA_FILES

GLBot::~GLBot() {
  if(upper) delete upper;
  if(head) delete head;
}

void GLBot::setUpper(GLModel* u) {
  if(upper) delete upper;
  link("tag_torso",upper = u);
}

void GLBot::setHead(GLModel* h) {
  if(head) delete head;
  upper->link("tag_head",head = h);
}

void GLBot::useVertexBuffer() {
  GLModel::useVertexBuffer();
  upper->useVertexBuffer();
}

bool GLBot::getLinkTransform(const char* tagName, M3Matrix& transform) {
  updateFrame();
  upper->updateFrame();
  head->updateFrame();
  transform.set(getTransform());
  return climbSkeleton(tagName,transform);
}

void GLBot::castShadow(
  int mode, M3Vector& dir, GLShadowedDelegate& sd, M3Matrix* pt
) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  castShadowSkeleton(mode,dir,sd,pt);
  glPopMatrix();
}

void GLBot::render(GLCamera& camera) {
  updateFrame();
  upper->updateFrame();
  head->updateFrame();
  glPushMatrix();
  glMultMatrixf(getTransform());
  renderSkeleton(camera);
  glPopMatrix();
}

#ifdef USE_CAL3D

//
// GLAdvancedCoreModel
//

GLAdvancedCoreModel::GLAdvancedCoreModel(): CalCoreModel("dummy"), textures() {
};

void GLAdvancedCoreModel::destroyObject() {
  for(int ct = 0; ct < textures.getSize(); ct++)
    textures.getElement(ct)->releaseReference();
  delete this;
}

#ifdef USE_DATA_FILES

bool GLAdvancedCoreModel::load(const char* fileName) {
  std::ifstream file;
  file.open(fileName,std::ios::in|std::ios::binary);
  if(!file)
    return false;
  bool ret = true;
  for(int line = 1; ret; line++) {
    std::string strBuffer;
    std::getline(file,strBuffer);
    if(file.eof())
      break;
    std::string::size_type pos;
    pos = strBuffer.find_first_not_of(" \t");
    if(
      (pos == std::string::npos) || (strBuffer[pos] == '\n') ||
      (strBuffer[pos] == '\r') || (strBuffer[pos] == 0)
    ) continue;
    if(strBuffer[pos] == '#')
      continue;
    std::string strKey;
    strKey = strBuffer.substr(pos, strBuffer.find_first_of(" =\t\n\r", pos) - pos);
    pos += strKey.size();
    pos = strBuffer.find_first_not_of(" \t", pos);
    if((pos == std::string::npos) || (strBuffer[pos] != '=')) {
      ret = false;
      break;
    }
    pos = strBuffer.find_first_not_of(" \t", pos + 1);
    std::string strData;
    strData = strBuffer.substr(pos, strBuffer.find_first_of("\n\r", pos) - pos);
    if(strKey == "skeleton") {
      if(!loadCoreSkeleton(strData.c_str()))
        ret = false;
    } else if(strKey == "animation") {
      if(loadCoreAnimation(strData.c_str()) == -1)
        ret = false;
    } else if(strKey == "mesh") {
      if(loadCoreMesh(strData.c_str()) == -1)
        ret = false;
    } else if(strKey == "material") {
      if(loadCoreMaterial(strData.c_str()) == -1)
        ret = false;
    }
  }
  if(ret) {
    for(int mat = 0; mat < getCoreMaterialCount(); mat++) {
      createCoreMaterialThread(mat);
      setCoreMaterialId(mat,0,mat);
      CalCoreMaterial *coreMaterial = getCoreMaterial(mat);
      for(int map = 0; map < coreMaterial->getMapCount(); map++) {
        std::string strFilename = coreMaterial->getMapFilename(map);
        GLTexture* tex = DRImage::getTextureFromFile(strFilename.c_str(),true);
        if(tex) {
          coreMaterial->setMapUserData(map,(Cal::UserData)tex);
          addTexture(tex->acquireReference());
        }
      }
    }
    for(int meshId = 0; meshId < getCoreMeshCount(); meshId++) {
      CalCoreMesh *mesh = getCoreMesh(meshId);
      for(int subMeshId = 0; subMeshId < mesh->getCoreSubmeshCount(); subMeshId++) {
        CalCoreSubmesh *subMesh = mesh->getCoreSubmesh(subMeshId);
        std::vector<std::vector<CalCoreSubmesh::TextureCoordinate> >& texCoords =
          subMesh->getVectorVectorTextureCoordinate();
        for(int texId = 0; texId < texCoords.size(); texId++) {
          std::vector<CalCoreSubmesh::TextureCoordinate>& texCoord = texCoords[texId];
          for(int cooId = 0; cooId < texCoord.size(); cooId++) {
            CalCoreSubmesh::TextureCoordinate& coord = texCoord[cooId];
            coord.v = 1-coord.v;
          }
        }
      }
    }
  }
  file.close();
  return ret;
}

#endif // USE_DATA_FILES

//
// GLAdvancedModel
//

GLAdvancedModel::GLAdvancedModel(GLAdvancedCoreModel& cm, bool hwSupport):
  coreModel((GLAdvancedCoreModel*)cm.acquireReference()), CalModel(&cm),
  hwModel(NULL), culled(true), lastUpdate(0)
{
  for(int mesh = 0; mesh < coreModel->getCoreMeshCount(); mesh++)
    attachMesh(mesh);
  setMaterialSet(0);
  if(!IS_VERTEX_PROGRAM_SUPPORTED || !IS_VERTEX_BUFFER_SUPPORTED)
    hwSupport = false;
  if(hwSupport) {
    disableInternalData();
    float *vertexBuffer = new float[MAX_VERTEX_COUNT*3];
    float *weightBuffer = new float[MAX_VERTEX_COUNT*4];
    float *matrixIndexBuffer = new float[MAX_VERTEX_COUNT*4];
    float *normalBuffer = new float[MAX_VERTEX_COUNT*3];
    float *texCoordBuffer = new float[MAX_VERTEX_COUNT*2];
    CalIndex *indexBuffer = new CalIndex[MAX_FACE_COUNT*3];
    hwModel = new CalHardwareModel(&cm);
    hwModel->setVertexBuffer((char*)vertexBuffer,3*sizeof(float));
    hwModel->setNormalBuffer((char*)normalBuffer,3*sizeof(float));
    hwModel->setWeightBuffer((char*)weightBuffer,4*sizeof(float));
    hwModel->setMatrixIndexBuffer((char*)matrixIndexBuffer,4*sizeof(float));
    hwModel->setTextureCoordNum(1);
    hwModel->setTextureCoordBuffer(0,(char*)texCoordBuffer,2*sizeof(float));
    hwModel->setIndexBuffer(indexBuffer);
    const int MAXBONESPERMESH = 29;
    hwModel->load(0,0,MAXBONESPERMESH);
    for(int mesh = 0; mesh < hwModel->getHardwareMeshCount(); mesh++) {
	    hwModel->selectHardwareMesh(mesh);
	    for(int face = 0; face < hwModel->getFaceCount(); face++) {
		    indexBuffer[face*3  +hwModel->getStartIndex()] += hwModel->getBaseVertexIndex();
  		  indexBuffer[face*3+1+hwModel->getStartIndex()] += hwModel->getBaseVertexIndex();
	  	  indexBuffer[face*3+2+hwModel->getStartIndex()] += hwModel->getBaseVertexIndex();
	    }
    }
    glGenBuffersARB(6,bufferObject);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[0]);
    glBufferDataARB(
      GL_ARRAY_BUFFER_ARB,hwModel->getTotalVertexCount()*3*sizeof(float),
      (const void*)vertexBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[1]);
    glBufferDataARB(
      GL_ARRAY_BUFFER_ARB,hwModel->getTotalVertexCount()*4*sizeof(float),
      (const void*)weightBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[2]);
    glBufferDataARB(
      GL_ARRAY_BUFFER_ARB,hwModel->getTotalVertexCount()*3*sizeof(float),
      (const void*)normalBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[3]);
    glBufferDataARB(
      GL_ARRAY_BUFFER_ARB,hwModel->getTotalVertexCount()*4*sizeof(float),
      (const void*)matrixIndexBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[4]);
    glBufferDataARB(
      GL_ARRAY_BUFFER_ARB,hwModel->getTotalVertexCount()*2*sizeof(float),
      (const void*)texCoordBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB,bufferObject[5]);
    glBufferDataARB(
      GL_ELEMENT_ARRAY_BUFFER_ARB,hwModel->getTotalFaceCount()*3*sizeof(CalIndex),
      (const void*)indexBuffer,GL_STATIC_DRAW_ARB
    );
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,0);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB,0);
    delete vertexBuffer;
    delete weightBuffer;
    delete normalBuffer;
    delete matrixIndexBuffer;
    delete texCoordBuffer;
    delete indexBuffer;
    programReferenceCount++;
    if(vertexProgramId == 0) {
    	glGenProgramsARB(1,&vertexProgramId);
  	  glBindProgramARB(GL_VERTEX_PROGRAM_ARB,vertexProgramId);
    	glProgramStringARB(
        GL_VERTEX_PROGRAM_ARB,GL_PROGRAM_FORMAT_ASCII_ARB,
		    strlen(vertexProgramStr),vertexProgramStr
      );
    	glBindProgramARB(GL_VERTEX_PROGRAM_ARB,0);
    }
  } else {
    meshReferenceCount++;
    if(meshVertices == NULL) {
      meshVertices = new float[MAX_VERTEX_COUNT*3];
      meshNormals = new float[MAX_VERTEX_COUNT*3];
      meshFaces = new CalIndex[MAX_FACE_COUNT*3];
      meshTextureCoordinates = new float[MAX_VERTEX_COUNT*2];
    }
  }
}

float GLAdvancedModel::animationTime = -1;

int GLAdvancedModel::meshReferenceCount = 0;
float* GLAdvancedModel::meshVertices = NULL;
float* GLAdvancedModel::meshNormals = NULL;
CalIndex* GLAdvancedModel::meshFaces = NULL;
float* GLAdvancedModel::meshTextureCoordinates = NULL;

int GLAdvancedModel::programReferenceCount = 0;
unsigned int GLAdvancedModel::vertexProgramId = 0;

const char GLAdvancedModel::vertexProgramStr[] =
"!!ARBvp1.0"
"PARAM constant = { 1, 3, 0, 0 };"
"TEMP R0, R1, R2, R3, R4, R5;"
"ADDRESS A0;"
"ATTRIB texCoord = vertex.attrib[8];"
"ATTRIB normal = vertex.attrib[2];"
"ATTRIB index = vertex.attrib[3];"
"ATTRIB weight = vertex.attrib[1];"
"ATTRIB position = vertex.attrib[0];"
"PARAM modelViewInvMatrix[4] = {state.matrix.modelview.inverse};"
"PARAM worldViewProjMatrix[4] = {state.matrix.mvp};"
"PARAM diffuse = state.material.diffuse;"
"PARAM ambient = state.material.ambient;"
"PARAM lightDir = state.light[0].position;"
"PARAM matrix[87] = {program.local[0..86]};"
"MOV result.texcoord[0].xy, texCoord.xyxx;	"
"MUL R4, index, constant.y;	"
"ARL A0.x, R4.y;"
"DP3 R0.x, matrix[A0.x].xyzx, normal.xyzx;"
"DP3 R0.y, matrix[A0.x + 1].xyzx, normal.xyzx;"
"DP3 R0.z, matrix[A0.x + 2].xyzx, normal.xyzx;"
"MUL R1.yzw, R0.xxyz, weight.y;"
"ARL A0.x, R4.x;"
"DP3 R0.x, matrix[A0.x].xyzx, normal.xyzx;"
"DP3 R0.y, matrix[A0.x + 1].xyzx, normal.xyzx;"
"DP3 R0.z, matrix[A0.x + 2].xyzx, normal.xyzx;"
"MAD R1.yzw, R0.xxyz, weight.x, R1.yyzw;"
"DP3 R0.x, R1.yzwy, R1.yzwy;"
"RSQ R0.x, R0.x;"
"MUL R0.xyz, R0.x, R1.yzwy;"
"DP3 R5.x, modelViewInvMatrix[0], lightDir;"
"DP3 R5.y, modelViewInvMatrix[1], lightDir;"
"DP3 R5.z, modelViewInvMatrix[2], lightDir;"
"DP3 R1.x, R5.xyzx, R5.xyzx;"
"RSQ R1.x, R1.x;"
"MUL R2.xyz, R1.x, R5.xyzx;"
"DP3 R0.x, R0.xyzx, R2.xyzx;"
"MAX R0.x, R0.x, constant.z;"
"ADD R0, R0.x, ambient;"
"MUL result.color.front.primary, R0, diffuse;"
"ARL A0.x, R4.w;"
"DPH R0.x, position.xyzx, matrix[A0.x];"
"DPH R0.y, position.xyzx, matrix[A0.x + 1];"
"DPH R0.z, position.xyzx, matrix[A0.x + 2];"
"ARL A0.x, R4.z;"
"DPH R3.x, position.xyzx, matrix[A0.x];"
"DPH R3.y, position.xyzx, matrix[A0.x + 1];"
"DPH R3.z, position.xyzx, matrix[A0.x + 2];"
"ARL A0.x, R4.y;"
"DPH R1.y, position.xyzx, matrix[A0.x];"
"DPH R1.z, position.xyzx, matrix[A0.x + 1];"
"DPH R1.w, position.xyzx, matrix[A0.x + 2];"
"MUL R2.xyz, R1.yzwy, weight.y;"
"ARL A0.x, R4.x;"
"DPH R1.x, position.xyzx, matrix[A0.x];"
"DPH R1.y, position.xyzx, matrix[A0.x + 1];"
"DPH R1.z, position.xyzx, matrix[A0.x + 2];"
"MAD R1.xyz, R1.xyzx, weight.x, R2.xyzx;"
"MAD R1.xyz, R3.xyzx, weight.z, R1.xyzx;"
"MAD R0.xyz, R0.xyzx, weight.w, R1.xyzx;"
"DPH result.position.x, R0.xyzx, worldViewProjMatrix[0];"
"DPH result.position.y, R0.xyzx, worldViewProjMatrix[1];"
"DPH result.position.z, R0.xyzx, worldViewProjMatrix[2];"
"DPH result.position.w, R0.xyzx, worldViewProjMatrix[3];"
"END";

GLAdvancedModel::~GLAdvancedModel() {
  if(coreModel)
    coreModel->releaseReference();
  if(hwModel) {
    programReferenceCount--;
    if(programReferenceCount == 0) {
      if(vertexProgramId)
        glDeleteProgramsARB(1,&vertexProgramId);
      vertexProgramId = 0;
    }
    glDeleteBuffersARB(6,bufferObject);
    delete hwModel;
  } else {
    meshReferenceCount--;
    if(meshReferenceCount == 0) {
      if(meshVertices) {
        delete[] meshVertices;
        meshVertices == NULL;
      }
      if(meshNormals) {
        delete[] meshNormals;
        meshNormals = NULL;
      }
      if(meshFaces) {
        delete[] meshFaces;
        meshFaces = NULL;
      }
      if(meshTextureCoordinates) {
        delete[] meshTextureCoordinates;
        meshTextureCoordinates = NULL;
      }
    }
  }
}

GLAdvancedModel* GLAdvancedModel::clone() {
  GLAdvancedModel* am = new GLAdvancedModel(*coreModel,(hwModel != NULL));
  return am;
}

void GLAdvancedModel::updateFrame() {
  float currentTime = GLAdvancedModel::getAnimationTime() < 0?
    GLWin::getElapsedTime(): GLBasicModel::getAnimationTime();
  float elapsedTime = currentTime-lastUpdate;
  lastUpdate = currentTime;
  update(elapsedTime);
}

void GLAdvancedModel::castPlanarShadow() {
  if(!culled)
    glDisable(GL_CULL_FACE);
  CalRenderer *renderer = getRenderer();
  if(renderer->beginRendering()) {
    glEnableClientState(GL_VERTEX_ARRAY);
    int meshCount = renderer->getMeshCount();
    for(int mesh = 0; mesh < meshCount; mesh++) {
      int submeshCount = renderer->getSubmeshCount(mesh);
      for(int submesh = 0; submesh < submeshCount; submesh++) {
        if(renderer->selectMeshSubmesh(mesh,submesh)) {
          renderer->getVertices(&meshVertices[0]);
          int faceCount = renderer->getFaces(&meshFaces[0]);
          glVertexPointer(3,GL_FLOAT,0,&meshVertices[0]);
          if(sizeof(CalIndex) == 2)
            glDrawElements(GL_TRIANGLES,faceCount*3,GL_UNSIGNED_SHORT,&meshFaces[0]);
          else
            glDrawElements(GL_TRIANGLES,faceCount*3,GL_UNSIGNED_INT,&meshFaces[0]);
        }
      }
    }
    glDisableClientState(GL_VERTEX_ARRAY);
    renderer->endRendering();
  }
  if(!culled)
    glEnable(GL_CULL_FACE);
}

void GLAdvancedModel::castShadowVolume(M3Vector& dir) {
	//...
}

void GLAdvancedModel::render(GLCamera& camera) {
  updateFrame();
  glPushMatrix();
  glMultMatrixf(getTransform());
  glDisable(GL_TEXTURE_2D);
  if(!culled)
    glDisable(GL_CULL_FACE);
  if(scaled)
    glEnable(GL_NORMALIZE);
  if(hwModel) {
  	glBindProgramARB(GL_VERTEX_PROGRAM_ARB,vertexProgramId);
	  glEnableVertexAttribArrayARB(0);
    glEnableVertexAttribArrayARB(1);
    glEnableVertexAttribArrayARB(2);
	  glEnableVertexAttribArrayARB(3);
	  glEnable(GL_VERTEX_PROGRAM_ARB);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[0]);
	  glVertexAttribPointerARB(0,3,GL_FLOAT,false,0,NULL);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[1]);
	  glVertexAttribPointerARB(1,4,GL_FLOAT,false,0,NULL);
  	glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[2]);
    glVertexAttribPointerARB(2,3,GL_FLOAT,false,0,NULL);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[3]);
	  glVertexAttribPointerARB(3,4,GL_FLOAT,false,0,NULL);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB,bufferObject[5]);
  	for(
      int hardwareMesh = 0;
      hardwareMesh < hwModel->getHardwareMeshCount();
      hardwareMesh++
    ) {
	  	hwModel->selectHardwareMesh(hardwareMesh);
		  unsigned char meshColor[4];
  		float materialColor[4];
	  	hwModel->getAmbientColor(&meshColor[0]);
		  materialColor[0] = meshColor[0]/255.0f;
      materialColor[1] = meshColor[1]/255.0f;
      materialColor[2] = meshColor[2]/255.0f;
      materialColor[3] = meshColor[3]/255.0f;
  		glMaterialfv(GL_FRONT,GL_AMBIENT,materialColor);
	  	hwModel->getDiffuseColor(&meshColor[0]);
		  materialColor[0] = meshColor[0]/255.0f;
      materialColor[1] = meshColor[1]/255.0f;
      materialColor[2] = meshColor[2]/255.0f;
      materialColor[3] = meshColor[3]/255.0f;
  		glMaterialfv(GL_FRONT,GL_DIFFUSE,materialColor);
	  	hwModel->getSpecularColor(&meshColor[0]);
		  materialColor[0] = meshColor[0]/255.0f;
      materialColor[1] = meshColor[1]/255.0f;
      materialColor[2] = meshColor[2]/255.0f;
      materialColor[3] = meshColor[3]/255.0f;
  		glMaterialfv(GL_FRONT,GL_SPECULAR,materialColor);
      float shininess = hwModel->getShininess();
      if(shininess < 1) shininess = 64;
  		glMaterialfv(GL_FRONT,GL_SHININESS,&shininess);
	  	for(int bone = 0; bone < hwModel->getBoneCount(); bone++) {
		  	CalQuaternion rotationBoneSpace =
          hwModel->getRotationBoneSpace(bone,getSkeleton());
  			CalVector translationBoneSpace =
          hwModel->getTranslationBoneSpace(bone,getSkeleton());
		  	CalMatrix rotationMatrix = rotationBoneSpace;
			  float transformation[12];
  			transformation[ 0] = rotationMatrix.dxdx;
        transformation[ 1] = rotationMatrix.dxdy;
        transformation[ 2] = rotationMatrix.dxdz;
        transformation[ 3] = translationBoneSpace.x;
  			transformation[ 4] = rotationMatrix.dydx;
        transformation[ 5] = rotationMatrix.dydy;
        transformation[ 6] = rotationMatrix.dydz;
        transformation[ 7] = translationBoneSpace.y;
  			transformation[ 8] = rotationMatrix.dzdx;
        transformation[ 9] = rotationMatrix.dzdy;
        transformation[10] = rotationMatrix.dzdz;
        transformation[11] = translationBoneSpace.z;
  			glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB,bone*3  ,&transformation[0]);
	  		glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB,bone*3+1,&transformation[4]);
		  	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB,bone*3+2,&transformation[8]);
  		}
      GLTexture* tex = reinterpret_cast<GLTexture*>(hwModel->getMapUserData(0));
      if(tex) {
        glEnable(GL_TEXTURE_2D);
        glEnableVertexAttribArrayARB(8);
        glBindBufferARB(GL_ARRAY_BUFFER_ARB,bufferObject[4]);
    	  glVertexAttribPointerARB(8,2,GL_FLOAT,false,0,NULL);
        tex->apply();
        glEnable(GL_COLOR_MATERIAL);
      }
	  	if(sizeof(CalIndex) == 2)
		  	glDrawElements(
          GL_TRIANGLES,hwModel->getFaceCount()*3,GL_UNSIGNED_SHORT,
          (((CalIndex *)NULL)+hwModel->getStartIndex())
        );
	  	else
		  	glDrawElements(
          GL_TRIANGLES,hwModel->getFaceCount()*3,GL_UNSIGNED_INT,
          (((CalIndex *)NULL)+hwModel->getStartIndex())
        );
      if(tex) {
        glDisableVertexAttribArrayARB(8);
        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_TEXTURE_2D);
      }
	  }
  	glDisableVertexAttribArrayARB(0);
	  glDisableVertexAttribArrayARB(1);
    glDisableVertexAttribArrayARB(2);
	  glDisableVertexAttribArrayARB(3);
    glBindBufferARB(GL_ARRAY_BUFFER_ARB,0);
  	glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB,0);
	  glDisable(GL_VERTEX_PROGRAM_ARB);
  	glBindProgramARB(GL_VERTEX_PROGRAM_ARB,0);
  } else {
    CalRenderer *renderer = getRenderer();
    if(renderer->beginRendering()) {
      glEnableClientState(GL_VERTEX_ARRAY);
      glEnableClientState(GL_NORMAL_ARRAY);
      int meshCount = renderer->getMeshCount();
      for(int mesh = 0; mesh < meshCount; mesh++) {
        int submeshCount = renderer->getSubmeshCount(mesh);
        for(int submesh = 0; submesh < submeshCount; submesh++) {
          if(renderer->selectMeshSubmesh(mesh,submesh)) {
            unsigned char meshColor[4];
            GLfloat materialColor[4];
            renderer->getAmbientColor(&meshColor[0]);
            materialColor[0] = meshColor[0] / 255.0f;
            materialColor[1] = meshColor[1] / 255.0f;
            materialColor[2] = meshColor[2] / 255.0f;
            materialColor[3] = meshColor[3] / 255.0f;
            glMaterialfv(GL_FRONT,GL_AMBIENT,materialColor);
            renderer->getDiffuseColor(&meshColor[0]);
            materialColor[0] = meshColor[0] / 255.0f;
            materialColor[1] = meshColor[1] / 255.0f;
            materialColor[2] = meshColor[2] / 255.0f;
            materialColor[3] = meshColor[3] / 255.0f;
            glMaterialfv(GL_FRONT,GL_DIFFUSE,materialColor);
            renderer->getSpecularColor(&meshColor[0]);
            materialColor[0] = meshColor[0] / 255.0f;
            materialColor[1] = meshColor[1] / 255.0f;
            materialColor[2] = meshColor[2] / 255.0f;
            materialColor[3] = meshColor[3] / 255.0f;
            glMaterialfv(GL_FRONT,GL_SPECULAR,materialColor);
            float shininess = renderer->getShininess();
            if(shininess < 1) shininess = 64;
            glMaterialf(GL_FRONT,GL_SHININESS,shininess);
            renderer->getVertices(&meshVertices[0]);
            renderer->getNormals(&meshNormals[0]);
            int faceCount = renderer->getFaces(&meshFaces[0]);
            glVertexPointer(3,GL_FLOAT,0,&meshVertices[0]);
            glNormalPointer(GL_FLOAT,0,&meshNormals[0]);
            int textureCoordinateCount =
              renderer->getTextureCoordinates(0,&meshTextureCoordinates[0]);
            if((renderer->getMapCount() > 0) && (textureCoordinateCount > 0)) {
              glEnable(GL_TEXTURE_2D);
              glEnableClientState(GL_TEXTURE_COORD_ARRAY);
              glEnable(GL_COLOR_MATERIAL);
              (reinterpret_cast<GLTexture*>(renderer->getMapUserData(0)))->apply();
              glTexCoordPointer(2,GL_FLOAT,0,&meshTextureCoordinates[0]);
            }
            if(sizeof(CalIndex) == 2)
              glDrawElements(GL_TRIANGLES,faceCount*3,GL_UNSIGNED_SHORT,&meshFaces[0]);
            else
              glDrawElements(GL_TRIANGLES,faceCount*3,GL_UNSIGNED_INT,&meshFaces[0]);
            if((renderer->getMapCount() > 0) && (textureCoordinateCount > 0)) {
              glDisable(GL_COLOR_MATERIAL);
              glDisableClientState(GL_TEXTURE_COORD_ARRAY);
              glDisable(GL_TEXTURE_2D);
            }
          }
        }
      }
      glDisableClientState(GL_NORMAL_ARRAY);
      glDisableClientState(GL_VERTEX_ARRAY);
      renderer->endRendering();
    }
  }
  if(scaled)
    glDisable(GL_NORMALIZE);
  if(!culled)
    glEnable(GL_CULL_FACE);
  glEnable(GL_TEXTURE_2D);
  glPopMatrix();
}

#endif // USE_CAL3D
