#ifndef GLSCENERY_H
#define GLSCENERY_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glcamera.h"
#include "globject.h"
#include "glshadow.h"

#include "void.h"

class GLScenery;

//
// GLFurniture
//
class GLFurniture: public GLVisible, virtual public Void {
public:
  GLFurniture();
  virtual ~GLFurniture();
  virtual void initRender(GLCamera& camera, GLScenery& scenery) {}
	virtual void render(GLCamera& camera, GLScenery& scenery) = 0;
};

//
// GLScenery
//
class GLScenery: public GLShadowed, public GLVisible {
private:
  DSArray<GLFurniture> furnitures;
public:
  GLScenery();
  virtual ~GLScenery();
  int getFurnituresCount() {return furnitures.getSize();}
  GLFurniture* getFurniture(int idx) {return furnitures.getElement(idx);}
  void addFurniture(GLFurniture* f) {furnitures.addElement(f);}
  bool removeFurniture(GLFurniture* f) {return furnitures.removeElement(f);}
  void deleteFurnitures() {furnitures.deleteElements();}
  void empty() {deleteFurnitures();}
  virtual bool hasTransparencies() = 0;
  virtual void initRender(GLCamera& camera) {};
	virtual void render(GLCamera& camera) = 0;
	virtual void renderOpaque(GLCamera& camera) = 0;
	virtual void renderTransparent(GLCamera& camera) = 0;
  virtual void initRender(GLCamera& camera, float x, float y, float z) {};
  void initRender(GLCamera& camera, GLObject* obj) {
    initRender(
      camera,obj->getPositionX(),obj->getPositionY(),obj->getPositionZ()
    );
  };
  virtual void render(GLCamera& camera, GLObject* obj) = 0;
  virtual bool checkVisibility(GLCamera& camera, float x, float y, float z) = 0;
  virtual bool checkVisibility(GLCamera& camera, GLObject* obj) {
    return checkVisibility(
      camera,obj->getPositionX(),obj->getPositionY(),obj->getPositionZ()
    );
  }
};

#endif // GLSCENERY_H
