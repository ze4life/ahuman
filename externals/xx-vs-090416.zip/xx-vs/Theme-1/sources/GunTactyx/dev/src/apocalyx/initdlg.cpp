/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glwin.h"

#if !defined(USE_GLFW) && ! defined(USE_OGLES)

#include "initdlg.h"

#include <stdlib.h> // for itoa()
#include <stdio.h> // for FILE

//
// InitDlgProc
//
BOOL CALLBACK InitDlgProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  static GLWin* glWin = NULL;
  const int MODESTR_LEN = 32;
  static char initModeStr[MODESTR_LEN] = "\0";
  static bool initFullscreen = false;
  static bool initVSync = false;
  static int initDepthBits = 16;
  static int initStencilBits = 8;
  switch(msg) {
    case WM_INITDIALOG: {
      glWin = reinterpret_cast<GLWin*>(lp);
      bool initFile = false;
      FILE* file = fopen(glWin->getSetupFileName(),"rb");
      if(file != NULL) {
        initFile = true;
        const int BUFFER_LENGTH = 128;
        char buffer[BUFFER_LENGTH];
        fread(buffer,1,BUFFER_LENGTH,file);
        fclose(file);
        char *token = strtok(buffer,",");
        strncpy(initModeStr,token,MODESTR_LEN-1);
        initModeStr[MODESTR_LEN-1] = '\0';
        token = strtok(NULL,",");
        initFullscreen = token[0] == 'F' || token[0] == 'f';
        token = strtok(NULL,",");
        initVSync = token[0] == 'V' || token[0] == 'v';
        token = strtok(NULL,",");
        initDepthBits = atoi(token);
        token = strtok(NULL,",");
        initStencilBits = atoi(token);
        token = strtok(NULL,",");
        if (token[0] == 'D' || token[0] == 'd') { // SHOW | DON'T SHOW
          int width, height, depth, freq;
          token = strtok(initModeStr,"x");
          if(token) {
            width = atoi(token);
            token = strtok(NULL,"x");
            if(token) {
              height = atoi(token);
              token = strtok(NULL,"x");
              if(token) {
                depth = atoi(token);
                token = strtok(NULL,"@");
                if(token) {
                  freq = atoi(token);
                }
              }
            }
          }
          glWin->setFullSize(width,height);
          glWin->setColorDepth(depth);
          glWin->setFrequency(freq);
          glWin->setDepthDepth(initDepthBits);
          glWin->setStencilDepth(initStencilBits);
          glWin->setFullscreen(initFullscreen);
          glWin->setVSyncOn(initVSync);
          EndDialog(hwnd, IDOK);
          // Fall through to dialog initialization code, otherwise
          // glWin->setVideoModes() won't be called.
        }
      }
      SendDlgItemMessage(
        hwnd,IDC_Logo,STM_SETIMAGE,IMAGE_BITMAP,
        (LPARAM)LoadImage(
          GetModuleHandle(NULL),MAKEINTRESOURCE(1),IMAGE_BITMAP,0,0,
          LR_DEFAULTCOLOR|LR_CREATEDIBSECTION
        )
      );
      HWND modeList = GetDlgItem(hwnd,IDC_ScreenSize);
      DEVMODE devMode;
      int index = 0, modeCount = 0;
      while(EnumDisplaySettings(NULL,index++,&devMode)) {
        if(devMode.dmBitsPerPel >= 16) {
          modeCount++;
          char modeStr[MODESTR_LEN], valStr[8];
          sprintf(
            modeStr,"%dx%dx%d",
            devMode.dmPelsWidth,
            devMode.dmPelsHeight,
            devMode.dmBitsPerPel
          );
          //if(devMode.dmDisplayFrequency != 0)
          //  strcat(strcat(modeStr,"@"),
          //    itoa(devMode.dmDisplayFrequency,valStr,10)
          //  );
          LRESULT lr = SendMessage(modeList,LB_FINDSTRING,0,(LPARAM)modeStr);
          if(lr == LB_ERR)
            SendMessage(modeList,LB_INSERTSTRING,0,(LPARAM)modeStr);
        }
      }
      if(modeCount) {
        VideoMode* videoModes = new VideoMode[modeCount];
        for(int ct = 0; ct < modeCount; ct++) {
          int width = 640, height = 480, depth = 16;
          char modeStr[MODESTR_LEN];
          SendMessage(modeList,LB_GETTEXT,ct,(LPARAM)modeStr);
          char *token = strtok(modeStr,"x");
          if(token) {
            width = atoi(token);
            token = strtok(NULL,"x");
            if(token) {
              height = atoi(token);
              token = strtok(NULL,"x");
              if(token) {
                depth = atoi(token);
              }
            }
          }
          videoModes[ct].width = width;
          videoModes[ct].height = height;
          videoModes[ct].colorDepth = depth;
        }
        glWin->setVideoModes(modeCount,videoModes);
      }
      if(initFile)
        SendMessage(modeList,LB_SELECTSTRING,(WPARAM)0,(LPARAM)initModeStr);
      else
        SendMessage(modeList,LB_SETCURSEL,(WPARAM)0,(LPARAM)0);
      CheckDlgButton(
        hwnd,initFullscreen?IDC_Fullscreen:IDC_Windowed,BST_CHECKED
      );
      CheckDlgButton(hwnd,initVSync?IDC_VSyncOn:IDC_VSyncOff,BST_CHECKED);
      CheckDlgButton(hwnd,
        initDepthBits == 32? IDC_32depth:
        initDepthBits == 24? IDC_24depth:
        IDC_16depth, BST_CHECKED
      );
      CheckDlgButton(
        hwnd, initStencilBits == 0? IDC_0stencil: IDC_8stencil,BST_CHECKED
      );
      return TRUE;
    }
    case WM_COMMAND: {
      WORD id = LOWORD(wp);
      switch(id) {
        case IDOK: {
          bool valuesChanged = false;
          HWND modeList = GetDlgItem(hwnd,IDC_ScreenSize);
          LRESULT idx = SendMessage(modeList,LB_GETCURSEL,(WPARAM)0,(LPARAM)0);
          if(idx == LB_ERR) {
            EndDialog(hwnd,-1);
            return TRUE;
          }
          char modeStr[MODESTR_LEN], copyModeStr[MODESTR_LEN];
          SendMessage(modeList,LB_GETTEXT,(WPARAM)idx,(LPARAM)modeStr);
          strcpy(copyModeStr,modeStr);
          if(stricmp(copyModeStr,initModeStr) != 0) valuesChanged = true;
          int width = 640, height = 480, depth = 16, freq = 0;
          char *token = strtok(copyModeStr,"x");
          if(token) {
            width = atoi(token);
            token = strtok(NULL,"x");
            if(token) {
              height = atoi(token);
              token = strtok(NULL,"x");
              if(token) {
                depth = atoi(token);
                token = strtok(NULL,"@");
                if(token) {
                  freq = atoi(token);
                }
              }
            }
          }
          glWin->setFullSize(width,height);
          glWin->setColorDepth(depth);
          glWin->setFrequency(freq);
          if(IsDlgButtonChecked(hwnd,IDC_32depth) == BST_CHECKED) {
            glWin->setDepthDepth(32);
          } else if(IsDlgButtonChecked(hwnd,IDC_24depth) == BST_CHECKED) {
            glWin->setDepthDepth(24);
          } else if(IsDlgButtonChecked(hwnd,IDC_16depth) == BST_CHECKED) {
            glWin->setDepthDepth(16);
          } else {
            EndDialog(hwnd,-1);
            return TRUE;
          }
          if(glWin->getDepthDepth() != initDepthBits) valuesChanged = true;
          if(IsDlgButtonChecked(hwnd,IDC_8stencil) == BST_CHECKED) {
            glWin->setStencilDepth(8);
          } else if(IsDlgButtonChecked(hwnd,IDC_0stencil) == BST_CHECKED) {
            glWin->setStencilDepth(0);
          } else {
            EndDialog(hwnd,-1);
            return TRUE;
          }
          if(glWin->getStencilDepth() != initStencilBits) valuesChanged = true;
          if(IsDlgButtonChecked(hwnd,IDC_Fullscreen) == BST_CHECKED) {
            glWin->setFullscreen(true);
          } else if(IsDlgButtonChecked(hwnd,IDC_Windowed) == BST_CHECKED) {
            glWin->setFullscreen(false);
          } else {
            EndDialog(hwnd,-1);
            return TRUE;
          }
          if(glWin->isFullscreen() != initFullscreen) valuesChanged = true;
          if(IsDlgButtonChecked(hwnd,IDC_VSyncOn) == BST_CHECKED) {
            glWin->setVSyncOn(true);
          } else if(IsDlgButtonChecked(hwnd,IDC_VSyncOff) == BST_CHECKED) {
            glWin->setVSyncOn(false);
          } else {
            EndDialog(hwnd,-1);
            return TRUE;
          }
          if(glWin->isVSyncOn() != initVSync) valuesChanged = true;
          bool dontShow = false;
          if(IsDlgButtonChecked(hwnd,IDC_DontShow) == BST_CHECKED) {
            valuesChanged = true;
            dontShow = true;
          }
          EndDialog(hwnd,IDOK);
          if(valuesChanged) {
            FILE* file = fopen(glWin->getSetupFileName(),"wb");
            if(file != NULL) {
              fprintf(
              	file,"%s,%s,%s,%d,%d,%s,",modeStr,
                glWin->isFullscreen()?"FULLSCREEN":"WINDOWED",
                glWin->isVSyncOn()?"VSYNC":"NO VSYNC",
                glWin->getDepthDepth(),
                glWin->getStencilDepth(),
                dontShow? "DON'T SHOW": "SHOW"               
              );
              fclose(file);
            }
          }
          return TRUE;
        }
        case IDCANCEL: {
          EndDialog(hwnd,IDCANCEL);
          return TRUE;
        }
        default:
          return FALSE;
      }
    }
    default:
      return FALSE;
  }
}

#endif // !USE_GLFW && !USE_OGLES
