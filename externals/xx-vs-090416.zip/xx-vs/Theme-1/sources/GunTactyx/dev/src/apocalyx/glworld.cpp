/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glworld.h"

#include "math3d.inc"
#include "datasets.inc"

//
// GLWorld
//

GLWorld::GLWorld():
  moon(NULL), sun(NULL), terrain(NULL), scenery(NULL), backgrounds(1),
  cloudLayers(1), transparentObjects(8), opaqueObjects(32), lights(1),
  shadows(8), shadowVolumesCount(0), ambient(1,1,1,1)
#ifdef USE_SOUND
  , soundSources(8)
#endif
{}

GLWorld::~GLWorld() {
  removeEnvironment();
}

bool GLWorld::removeShadow(GLObject* o) {
  for(int ct = 0; shadows.getSize(); ct++) {
    GLShadow* s = shadows.getElement(ct);
    if(&(s->getObject()) == o) {
      if(s->getMode() == GLShadow::SHADOW_VOLUME) shadowVolumesCount--;
      shadows.removeElement(ct);
      return true;
    }
  }
  return false;
}

#ifdef USE_SOUND
bool GLWorld::removeSoundSource(GLObject* o) {
  for(int ct = 0; soundSources.getSize(); ct++) {
    GLSoundSource* s = soundSources.getElement(ct);
    if(s->getObject() == o) {
      soundSources.removeElement(ct);
      return true;
    }
  }
  return false;
}
#endif

void GLWorld::removeEnvironment() {
  backgrounds.deleteElements();
  cloudLayers.deleteElements();
  if(scenery) {
    delete scenery;
    scenery = NULL;
  }
  if(terrain) {
    delete terrain;
    terrain = NULL;
  }
  if(moon) {
    delete moon;
    moon = NULL;
  }
  if(sun) {
    delete sun;
    sun = NULL;
  }
}

void GLWorld::setBackground(GLBackground* bg, bool deleteOld) {
  if(deleteOld) {
    backgrounds.deleteElements();
    addBackground(bg);
  } else {
    backgrounds.setElement(0,bg);
  }
}

void GLWorld::setCloudLayer(GLCloudLayer* cl, bool deleteOld) {
  if(deleteOld) {
    cloudLayers.deleteElements();
    addCloudLayer(cl);
  } else {
    cloudLayers.setElement(0,cl);
  }
}

void GLWorld::setMoon(GLMoonLight* m) {
  if(moon) delete moon;
  moon = m;
}

void GLWorld::setSun(GLSunLight* s) {
  if(sun) delete sun;
  sun = s;
}

void GLWorld::setTerrain(GLTerrain* t) {
  if(terrain) delete terrain;
  terrain = t;
}

void GLWorld::setScenery(GLScenery* s) {
  if(scenery) delete scenery;
  scenery = s;
}

void GLWorld::render(GLCamera& camera) {
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambient.getFloatArray());
  renderFog();
  if(sun && (!sun->isClipped()) && sun->isVisible())
    sun->checkOcclusion(camera);
  bool hasBackground =
  	backgrounds.getSize() > 0 && backgrounds.getElement(0)->isVisible();
  if(camera.isScissorUsed()) {
  	if(camera.isMainView()) {
			glClearColor(clear.getRed(),clear.getGreen(),clear.getBlue(),1);
 			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    } else {
 			glClear(GL_DEPTH_BUFFER_BIT);
    }
	  glEnable(GL_SCISSOR_TEST);
		glScissor(
 			(int)camera.getViewX(),(int)camera.getViewY(),
      (int)camera.getViewWidth(),(int)camera.getViewHeight()
	  );
  } else if(hasBackground) {
  	glClear(GL_DEPTH_BUFFER_BIT);
  } else {
		glClearColor(clear.getRed(),clear.getGreen(),clear.getBlue(),1);
  	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
  }
  glViewport(
  	(int)camera.getViewX(),(int)camera.getViewY(),
    (int)camera.getViewWidth(),(int)camera.getViewHeight()
  );
	if(camera.isOrtho())
  	camera.applyOrtho();
  else
  	camera.applyPerspective();
  if(hasBackground) {
    camera.applyRotation();
    backgrounds.getElement(0)->render();
    for(int ct = 1; ct < backgrounds.getSize(); ct++)
      if(backgrounds.getElement(ct)->isVisible())
        backgrounds.getElement(ct)->render(true);
  }
  camera.applyTransform();
  if(sun && sun->isVisible()) {
    M3Vector sunPosition(sun->getDirection());
    sunPosition.scale(sun->getCameraDistance()).add(
      camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
    );
    sun->setPosition(sunPosition);
    if(!sun->clip(camera))
      sun->render(camera);
  }
  if(moon && moon->isVisible()) {
    M3Vector moonPosition(moon->getDirection());
    moonPosition.scale(moon->getCameraDistance()).add(
      camera.getPositionX(),camera.getPositionY(),camera.getPositionZ()
    );
    moon->setPosition(moonPosition);
    if(!moon->clip(camera))
      moon->render(camera);
  }
  if(scenery && scenery->isVisible()) {
    scenery->initRender(camera);
    if(scenery->hasTransparencies())
	    scenery->renderOpaque(camera);
    else
	    scenery->render(camera);
    for(int ct = 0; ct < scenery->getFurnituresCount(); ct++) {
      GLFurniture* f = scenery->getFurniture(ct);
      f->initRender(camera,*scenery);
      f->render(camera,*scenery);
    }
    if(getOpaqueObjectsCount()) {
      for(int ct = 0; ct < getOpaqueObjectsCount(); ct++) {
        GLObject* obj = getOpaqueObject(ct);
        if(obj->isVisible()) obj->clip(camera);
      }
      opaqueObjects.quickSort(0,getOpaqueObjectsCount()-1);
      for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
        GLObject* obj = getOpaqueObject(ct);
        if(!obj->isClipped() && obj->isVisible()) {
          if(scenery->checkVisibility(camera,obj)) {
            scenery->initRender(camera,obj);
            scenery->render(camera,obj);
          }
        }
      }
    }
    if(terrain && terrain->isVisible())
      terrain->render(camera);
    if(scenery->isShadowed() && getShadowsCount()) {
    	if(IS_STENCIL_AVAILABLE && (shadowVolumesCount > 0))
      	glClear(GL_STENCIL_BUFFER_BIT);
      for(int ct = getShadowsCount()-1; ct >= 0; ct--) {
        GLShadow* shd = getShadow(ct);
        GLObject& obj = shd->getObject();
        if(
          obj.isVisible() && scenery->checkVisibility(camera,&obj) &&
          ((!obj.isClipped()) || (!shd->checkClip(camera)))
        )
          shd->cast(camera,*scenery);
      }
    	if(IS_STENCIL_AVAILABLE && (shadowVolumesCount > 0)) {
		    glEnable(GL_STENCIL_TEST);
		    glStencilFunc(GL_NOTEQUAL,0,0xff);
		    glDisable(GL_DEPTH_TEST);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_LIGHTING);
				glDisable(GL_CULL_FACE);
		    glEnable(GL_BLEND);
    		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
		    glMatrixMode(GL_PROJECTION);
    		glPushMatrix();
		    glLoadIdentity();
#ifdef USE_OGLES
    		glOrthof(0,1,0,1,-1,1);
#else // !USE_OGLES
		    glOrtho(0,1,0,1,-1,1);
#endif // !USE_OGLES
		    glMatrixMode(GL_MODELVIEW);
    		glPushMatrix();
	      glLoadIdentity();
        glColor4f(0,0,0,scenery->getShadowIntensity());
        glRectf(0,0,1,1);
		    glPopMatrix();
		    glMatrixMode(GL_PROJECTION);
    		glPopMatrix();
		    glMatrixMode(GL_MODELVIEW);
		    glDisable(GL_BLEND);
				glEnable(GL_CULL_FACE);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_LIGHTING);
		    glEnable(GL_DEPTH_TEST);
		    glDisable(GL_STENCIL_TEST);
      }
    }
    for(int ct = 0; ct < cloudLayers.getSize(); ct++)
      if(cloudLayers.getElement(ct)->isVisible())
        cloudLayers.getElement(ct)->render(camera);
    if(scenery->hasTransparencies())
	    scenery->renderTransparent(camera);
    if(getTransparentObjectsCount()) {
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if(obj->isVisible()) obj->clip(camera);
      }
      transparentObjects.quickSort(0,getTransparentObjectsCount()-1);
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if(!obj->isClipped() && obj->isVisible()) {
          if(scenery->checkVisibility(camera,obj)) {
            scenery->initRender(camera,obj);
            scenery->render(camera,obj);
          }
        }
      }
    }
  } else {
    bool isTerrainVisible = terrain && terrain->isVisible();
    bool isTerrainReflective = isTerrainVisible && terrain->isReflective();
    bool isTerrainTransparent = isTerrainVisible && terrain->isTransparent();
    bool isTerrainShadowed = isTerrainVisible && terrain->isShadowed();
    if(isTerrainReflective) {
      glPushMatrix();
      glScalef(1,-1,1);
    }
    int enabledLights = 0;
    if(sun && sun->isVisible()) {
      sun->applyPropertiesTo(enabledLights++);
    } else if(moon && moon->isVisible()) {
      moon->applyPropertiesTo(enabledLights++);
    }
    bool nearestLightFound = false;
    for(int ct = 0; ct < lights.getSize(); ct++) {
      GLObject* lgh = getLight(ct);
      if(lgh->isVisible()) lgh->clip(camera);
    }
    lights.quickSort(0,lights.getSize()-1);
    for(int ct = lights.getSize()-1; (ct >= 0) && (enabledLights < 8); ct--) {
      GLLight* light = dynamic_cast<GLLight*>(getLight(ct));
      if(light->isVisible()) {
        if(!nearestLightFound) {
          bool isDirectional = light->isDirectional();
          camera.setNearestLight(isDirectional,
            isDirectional? light->getDirection(): light->getPosition()
          );
          nearestLightFound = true;
        }
        light->applyPropertiesTo(enabledLights++);
      }
    }
    if(!nearestLightFound) {
      if(sun && sun->isVisible()) {
        camera.setNearestLight(true,sun->getDirection());
      } else if(moon && moon->isVisible()) {
        camera.setNearestLight(true,moon->getDirection());
      }
    }
    camera.setRenderingShadows(isTerrainShadowed);
    camera.setRenderingReflections(isTerrainReflective);
    camera.setRenderingTransparencies(isTerrainTransparent);
    for(int ct = 0; ct < getOpaqueObjectsCount(); ct++) {
      GLObject* obj = getOpaqueObject(ct);
      if(obj->isVisible()) obj->clip(camera);
    }
    for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
      GLObject* obj = getTransparentObject(ct);
      if(obj->isVisible()) obj->clip(camera);
    }
    opaqueObjects.quickSort(0,getOpaqueObjectsCount()-1);
    transparentObjects.quickSort(0,getTransparentObjectsCount()-1);
    if(isTerrainReflective) {
      glCullFace(GL_FRONT);
      for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
        GLObject* obj = getOpaqueObject(ct);
        if((!obj->isClipped()) && (obj->isVisible()))
          obj->render(camera);
      }
      for(int ct = 0; ct < cloudLayers.getSize(); ct++)
        if(cloudLayers.getElement(ct)->isVisible())
          cloudLayers.getElement(ct)->render(camera);
      for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
        GLObject* obj = getTransparentObject(ct);
        if((!obj->isClipped()) && (obj->isVisible()))
          obj->render(camera);
      }
      glCullFace(GL_BACK);
      glPopMatrix();
      camera.setRenderingReflections(false);
      int index = 0;
      if(sun && sun->isVisible())
        sun->applyPositionTo(index++);
      else if(moon && moon->isVisible())
        moon->applyPositionTo(index++);
      for(int ct = lights.getSize()-1; ct >= 0; ct--) {
        GLLight* light = dynamic_cast<GLLight*>(getLight(ct));
        if(light->isVisible())
          light->applyPositionTo(index++);
      }
    }
    if(isTerrainVisible && !terrain->isTransparent())
      terrain->render(camera);
    for(int ct = getOpaqueObjectsCount()-1; ct >= 0; ct--) {
      GLObject* obj = getOpaqueObject(ct);
      if((!obj->isClipped()) && (obj->isVisible()))
        obj->render(camera);
    }
    if(isTerrainTransparent)
      terrain->render(camera);
    if(isTerrainShadowed) {
    	if(IS_STENCIL_AVAILABLE && (shadowVolumesCount > 0))
      	glClear(GL_STENCIL_BUFFER_BIT);
      for(int ct = getShadowsCount()-1; ct >= 0; ct--) {
        GLShadow* shd = getShadow(ct);
        GLObject& obj = shd->getObject();
        if(
          obj.isVisible() && ((!obj.isClipped()) || (!shd->checkClip(camera)))
        )
          shd->cast(camera,*terrain);
      }
    	if(IS_STENCIL_AVAILABLE && (shadowVolumesCount > 0)) {
		    glEnable(GL_STENCIL_TEST);
		    glStencilFunc(GL_NOTEQUAL,0,0xff);
		    glDisable(GL_DEPTH_TEST);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_LIGHTING);
				glDisable(GL_CULL_FACE);
		    glEnable(GL_BLEND);
    		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
		    glMatrixMode(GL_PROJECTION);
    		glPushMatrix();
		    glLoadIdentity();
#ifdef USE_OGLES
    		glOrthof(0,1,0,1,-1,1);
#else // !USE_OGLES
		    glOrtho(0,1,0,1,-1,1);
#endif // !USE_OGLES
		    glMatrixMode(GL_MODELVIEW);
    		glPushMatrix();
	      glLoadIdentity();
        glColor4f(0,0,0,terrain->getShadowIntensity());
        glRectf(0,0,1,1);
		    glPopMatrix();
		    glMatrixMode(GL_PROJECTION);
    		glPopMatrix();
		    glMatrixMode(GL_MODELVIEW);
		    glDisable(GL_BLEND);
				glEnable(GL_CULL_FACE);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_LIGHTING);
		    glEnable(GL_DEPTH_TEST);
		    glDisable(GL_STENCIL_TEST);
      }
    }
    for(int ct = 0; ct < cloudLayers.getSize(); ct++)
      if(cloudLayers.getElement(ct)->isVisible())
        cloudLayers.getElement(ct)->render(camera);
    for(int ct = 0; ct < getTransparentObjectsCount(); ct++) {
      GLObject* obj = getTransparentObject(ct);
      if((!obj->isClipped()) && (obj->isVisible()))
        obj->render(camera);
    }
    for(int ct = 0; ct < enabledLights; ct++)
      glDisable(GL_LIGHT0+ct);
  }
  for(int ct = 0; ct < lights.getSize(); ct++) {
    GLObject* light = getLight(ct);
    if((!light->isClipped()) && (light->isVisible()))
      light->render(camera);
  }
  if(camera.isMainView()) {
	  if(sun && (!sun->isClipped()) && sun->isVisible())
  	  sun->renderLensFlare(camera);
#ifdef USE_SOUND
	  for(int ct = getSoundSourcesCount()-1; ct >= 0; ct--)
  	  getSoundSource(ct)->computeDistance2(camera);
	  soundSources.quickSort(0,getSoundSourcesCount()-1);
  	for(int ct = getSoundSourcesCount()-1; ct >= 0; ct--) {
    	GLSoundSource* src = getSoundSource(ct);
	    FM3DSound* snd = src->get3DSound();
  	  switch(snd->getSoundStatus()) {
    	  case FMSound::IS_SOUND_PLAYING:
      	  snd->setPriority(ct);
        	src->render(camera);
	        break;
  	    case FMSound::IS_CHANNEL_LOST:
    	    snd->play(ct);
      	  if(snd->isAudible())
        	  src->render(camera);
	        break;
  	    case FMSound::WAS_SOUND_STOPPED:
    	  default:
      	  break;
	    }
  	}
#endif
	}
  glDisable(GL_SCISSOR_TEST);
}

