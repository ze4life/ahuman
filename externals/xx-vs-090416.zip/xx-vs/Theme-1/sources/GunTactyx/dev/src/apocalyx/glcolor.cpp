/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glcolor.h"

GLColor::GLColor(float r, float g, float b, float a) {
  set(r,g,b,a);
}

void GLColor::gammaCorrection(float gamma) {
  float r = color[0]*gamma;
	float	g = color[1]*gamma;
 	float b = color[2]*gamma;
  float theScale = 1.0f;
	float temp;
	if((r > 1) && (temp = 1/r) < theScale) theScale = temp;
  if((g > 1) && (temp = 1/g) < theScale) theScale = temp;
	if((b > 1) && (temp = 1/b) < theScale) theScale = temp;
  color[0] = r*theScale;
  color[1] = g*theScale;
  color[2] = b*theScale;
}

void GLColor::gammaCorrection(unsigned char* color, float gamma) {
  const float SCALE_FACTOR = gamma/255;
  float r = color[0]*SCALE_FACTOR;
	float	g = color[1]*SCALE_FACTOR;
 	float b = color[2]*SCALE_FACTOR;
  float theScale = 1.0f;
	float temp;
	if((r > 1) && (temp = 1/r) < theScale) theScale = temp;
  if((g > 1) && (temp = 1/g) < theScale) theScale = temp;
	if((b > 1) && (temp = 1/b) < theScale) theScale = temp;
	theScale *= 255;
  color[0] = (unsigned char)(r*theScale);
	color[1] = (unsigned char)(g*theScale);
  color[2] = (unsigned char)(b*theScale);
}

