/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glprogram.h"

#define PROGRAM_DEBUG

#ifdef PROGRAM_DEBUG
#include <stdio.h>
#define WRITE_ERROR \
  FILE* f = fopen("shader_error.txt","wt"); \
  fprintf(f,(const char*)glGetString(GL_PROGRAM_ERROR_STRING_ARB)); \
  fclose(f);
#endif // PROGRAM_DEBUG

//
// GLProgram
//

GLProgram::GLProgram(const char* asciiProgram, int iTarget):
  programID(0), target(iTarget)
{
  if(IS_FRAGMENT_PROGRAM_SUPPORTED) {
    init();
    load(asciiProgram);
    if(glGetError() == GL_INVALID_OPERATION) {
      glDeleteProgramsARB(1,&programID);
      programID = 0;
#ifdef PROGRAM_DEBUG
      WRITE_ERROR;
#endif
    }
    disable();
  }
}

GLProgram::GLProgram(DRData* data, int iTarget): programID(0), target(iTarget) {
  if(IS_FRAGMENT_PROGRAM_SUPPORTED) {
    init();
    load(data);
    if(data)
      delete data;
    if(glGetError() == GL_INVALID_OPERATION) {
      glDeleteProgramsARB(1,&programID);
      programID = 0;
#ifdef PROGRAM_DEBUG
      WRITE_ERROR;
#endif
    }
    disable();
  }
}

void GLProgram::destroyObject() {
  if(IS_FRAGMENT_PROGRAM_SUPPORTED && isValid())
    glDeleteProgramsARB(1,&programID);
  delete this;
}

//
// GLVertexProgram
//

GLVertexProgram::GLVertexProgram(const char* asciiP):
  GLProgram(asciiP,GL_VERTEX_PROGRAM_ARB)
{}

GLVertexProgram::GLVertexProgram(DRData* data):
  GLProgram(data,GL_VERTEX_PROGRAM_ARB)
{}

//
// GLFragmentProgram
//

GLFragmentProgram::GLFragmentProgram(const char* asciiP):
  GLProgram(asciiP,GL_FRAGMENT_PROGRAM_ARB)
{}

GLFragmentProgram::GLFragmentProgram(DRData* data):
  GLProgram(data,GL_FRAGMENT_PROGRAM_ARB)
{}

