#ifndef GLDISPLAYLIST_H
#define GLDISPLAYLIST_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "opengl.h"

#ifdef USE_OGLES
#else // !USE_OGLES

//
// GLDisplayList
//
class GLDisplayList {
private:
  unsigned int list;
  bool compiled;
protected:
  void unlink() {if(compiled) {glDeleteLists(list,1); compiled = false;}}
  void relink() {unlink(); list = glGenLists(1);}
public:
  GLDisplayList();
  ~GLDisplayList();
  void compileBegin() {relink(); glNewList(list,GL_COMPILE);}
  void compileAndExecute() {relink(); glNewList(list,GL_COMPILE_AND_EXECUTE);}
  void compileEnd() {glEndList(); compiled = true;}
  bool isCompiled() {return compiled;}
  void execute() {glCallList(list);}
};

//
// GLDisplayLists
//
class GLDisplayLists {
private:
  int count;
  unsigned int list;
protected:
  void unlink() {if(count) glDeleteLists(list,count);}
  void relink(int ct) {unlink(); list = glGenLists(count = ct);}
public:
  GLDisplayLists(int ct = 0);
  ~GLDisplayLists();
  void compileBegin(int idx = 0) {glNewList(list+idx,GL_COMPILE);}
  void compileAndExecute(int idx = 0)
    {glNewList(list+idx,GL_COMPILE_AND_EXECUTE);}
  void compileEnd() {glEndList();}
  void execute(int idx = 0) {glCallList(list+idx);}
};

#endif // !USE_OGLES

#endif // GLDISPLAYLIST_H
