#ifndef GLMODEL_H
#define GLMODEL_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "datamanager.h"
#include "glmaterial.h"
#include "glvertexbuffer.h"
#include "glprogram.h"
#include "glwin.h"

#ifdef USE_CAL3D

#include "cal3d/cal3d.h"

#endif // USE_CAL3D

//
// MD2 structs
//

struct MD2ModelHeader {
  int ident;
  int version;
  int skinwidth;
  int skinheight;
  int framesize;
  int num_skins;
  int num_xyz;
  int num_st;
  int num_tris;
  int num_glcmds;
  int num_frames;
  int ofs_skins;
  int ofs_st;
  int ofs_tris;
  int ofs_frames;
  int ofs_glcmds;
  int ofs_end;
};

struct MD2Vertex {
  unsigned char v[3];
  unsigned char lightnormalindex;
};

struct MD2FinalVertex {
  float coord[3];
  unsigned char normal;
};

struct MD2TexCoord {
  short s;
  short t;
};

struct MD2Frame {
  float scale[3];
  float translate[3];
  char name[16];
  MD2Vertex verts[1];
};

struct MD2Triangle {
  short index_xyz[3];
  short index_st[3];
};

//
// MD3 structs
//
struct MD3Rotation {
  float matrix[9];
};

struct MD3Vector {
  float coord[3];
};

struct MD3Transform {
  MD3Vector position;
  MD3Rotation rotation;
public:
  void fillArray(float *array) { // 4x4
    array[ 0] = rotation.matrix[0];
    array[ 1] = rotation.matrix[1];
    array[ 2] = rotation.matrix[2];
    array[ 3] = 0;
    array[ 4] = rotation.matrix[3];
    array[ 5] = rotation.matrix[4];
    array[ 6] = rotation.matrix[5];
    array[ 7] = 0;
    array[ 8] = rotation.matrix[6];
    array[ 9] = rotation.matrix[7];
    array[10] = rotation.matrix[8];
    array[11] = 0;
    array[12] = position.coord[0];
    array[13] = position.coord[1];
    array[14] = position.coord[2];
    array[15] = 1;
  }
};

struct MD3Triangle {
#ifdef USE_OGLES
  short vertex[3];
#else // !USE_OGLES
  int vertex[3];
#endif // !USE_OGLES
};

struct MD3TexCoord {
  float coord[2];
};

struct MD3Vertex {
  signed short coord[3];
  unsigned char normal[2];
};

const int MAX_ID_LEN = 4;
const int MAX_NAMES_LEN = 68;

struct MD3ModelHeader {
  char id[MAX_ID_LEN];
  int version;
  char fileName[MAX_NAMES_LEN];
  int numBoneFrames;
  int numTags;
  int numMeshes;
  int numMaxSkins;
  int headerLength;
  int tagStart;
  int tagEnd;
  int fileSize;
};

struct MD3BoneFrame {
  float mins[3];
  float maxs[3];
  float position[3];
  float scale;
  char creator[16];
};

struct MD3Tag {
  char name[64];
  MD3Transform transform;
};

struct MD3Skin {
  char name[MAX_NAMES_LEN];
};

struct MD3MeshHeader {
  char id[MAX_ID_LEN];
  char name[MAX_NAMES_LEN];
  int numMeshFrames;
  int numSkins;
  int numVertexes;
  int numTriangles;
  int triStart;
  int headerSize;
  int texVectorStart;
  int vertexStart;
  int meshSize;
};

//
// GLAnimationData
//
class GLAnimationData {
public:
  int firstFrame;
  int lastFrame;
  int backFrames;
  int fps;
  float invFPS;
public:
  GLAnimationData();
  GLAnimationData(int ff, int lf, int bf, int iFps);
};

//
// GLMD2AnimatedShape
//
class GLMD2AnimatedShape {
public:
  int vertexesCount;
  MD2FinalVertex* vertex;
  int* commands;
public:
  GLMD2AnimatedShape();
  ~GLMD2AnimatedShape();
};

//
// GLAnimatedShape
//
class GLAnimatedShape {
public:
  int vertexesCount;
  MD3Vertex* vertex;
  MD3TexCoord* texCoord;
  int trianglesCount;
  MD3Triangle* triangle;
public:
  GLAnimatedShape();
  ~GLAnimatedShape();
};

//
// GLMD2Bone
//
class GLMD2Bone: public DMReference {
public:
  enum MD2Animation {
	  STAND = 0, RUN, ATTACK,	PAIN_A,	PAIN_B,	PAIN_C,	JUMP,	FLIP,	SALUTE,
    FALLBACK,	WAVE,	POINT, CROUCH_STAND, CROUCH_WALK, CROUCH_ATTACK,
    CROUCH_PAIN, CROUCH_DEATH, DEATH_FALLBACK, DEATH_FALLFORWARD,
    DEATH_FALLBACKSLOW, MD2_MAX_ANIMATIONS
  };
  static GLAnimationData MD2_ANIMATION_DATA[MD2_MAX_ANIMATIONS];
  GLMD2AnimatedShape animatedShape;
  int framesCount;
public:
  GLMD2Bone();
  virtual void destroyObject();
};

//
// GLBone
//
class GLBone: public DMReference {
public:
  int framesCount;
  int animationsCount;
  GLAnimationData* animations;
  int shapesCount;
  GLAnimatedShape* shapes;
  int linksCount;
  char** linkNames;
  int transformsCount;
  MD3Transform* transforms;
public:
  GLBone();
  void setAnimations(int animsCount, GLAnimationData* anims)
    {animationsCount = animsCount; animations = anims;}
  virtual void destroyObject();
};

//
// GLBasicModel
//
class GLBasicModel: public GLObject, public GLBasicMaterialOwner {
private:
  static float animationTime;
public:
  static void setAnimationTime(float at) {animationTime = at;}
  static float getAnimationTime() {return animationTime;}
public:
	bool playBackward;
  int currFrame;
  int nextFrame;
  float lastUpdate;
  float interpolation;
  int currAnimation;
  int stopAnimation;
  GLMD2Bone* bone;
  float scale;
protected:
  void drawNI();
  void draw();
  virtual void castPlanarShadow();
  virtual void castShadowVolume(M3Vector& dir);
  virtual void render(GLCamera& camera);
public:
  GLBasicModel();
  GLBasicModel(GLBasicModel& toBeCloned);
  ~GLBasicModel();
#ifdef USE_DATA_FILES
  GLBasicModel(
    const char* path, const char* md2Name,
    const char* imgName = NULL, const char* alphaImgName = NULL
  );
  bool load(
    const char* path, const char* md2Name,
    const char* imgName = NULL, const char* alphaImgName = NULL
  );
#endif // USE_DATA_FILES
  float computeMaxRadius();
  float getScale() {return scale;}
  void setScale(float s) {scale = s;}
  void rescale(float s);
  int getStoppedAnimation()
    {int a = stopAnimation; stopAnimation = -1; return a;}
  int getCurrentAnimation() {return currAnimation;}
  void setAnimation(int anim, bool playBack = false);
  void updateFrame();
  void drawPrimitives() {draw();}
  void drawPrimitivesNoInterpol() {drawNI();}
};

//
// GLModel
//
class GLModel: public GLObject, public GLBasicMaterialOwner {
private:
  static float animationTime;
  static DMCache* staticCache;
  DMCache* cache;
#ifdef USE_OGLES
#else // !USE_OGLES
  static GLVertexProgram* lerpVP;
  GLVertexBuffer* vertexBuffer;
#endif // !USE_OGLES
public:
  static void setAnimationTime(float at) {animationTime = at;}
  static float getAnimationTime() {return animationTime;}
  void acquireStaticCache() {
    if(!staticCache)
      staticCache = new DMCache();
    staticCache->acquireReference();
  }
  bool hasPrivateCache() {return (bool)(cache != NULL);}
  void initPrivateCache() {
    if(!cache) {
      cache = new DMCache();
      cache->acquireReference();
    }
  }
  float* getArrays(int siz) {
    DMCache* c = hasPrivateCache()? cache: staticCache;
    c->checkSize(4*siz,true);
    return (float*)c->getDataPointer();
  }
  float* getArraysPointer() {
    DMCache* c = hasPrivateCache()? cache: staticCache;
    return (float*)c->getDataPointer();
  }
public:
	bool playBackward;
  int currFrame;
  int nextFrame;
  float lastUpdate;
  float interpolation;
  int currAnimation;
  int stopAnimation;
  GLBone* bone;
  GLObject** links;
  float scale;
protected:
  void drawNI(bool drawCached = false);
  void draw(bool drawCached = false);
  void renderBone(GLCamera& camera);
  virtual void castPlanarShadow();
  virtual void castShadowVolume(M3Vector& dir);
  virtual void render(GLCamera& camera);
public:
  GLModel(bool ownsCache = false);
  GLModel(GLModel& toBeCloned);
  ~GLModel();
#ifdef USE_DATA_FILES
  GLModel(
    const char* path, const char* md3Name,
    const char* imgName = NULL, const char* alphaImgName = NULL,
    bool ownsCache = false
  );
  bool load(
    const char* path, const char* md3Name,
    const char* imgName = NULL, const char* alphaImgName = NULL
  );
#endif // USE_DATA_FILES
  float computeMaxRadius();
  float getScale() {return scale;}
  void setScale(float s) {scale = s;}
  void rescale(float s);
  int getStoppedAnimation()
    {int a = stopAnimation; stopAnimation = -1; return a;}
  int getCurrentAnimation() {return currAnimation;}
  void setAnimation(int anim, bool playBack = false);
  void setAnimations(int animsCount, GLAnimationData* anims)
    {if(bone) bone->setAnimations(animsCount,anims);}
  void updateFrame();
  void link(const char* tagName, GLObject* obj);
  void unlink(const char* tagName) {link(tagName,NULL);}
  virtual bool climbSkeleton(const char* tagName, M3Matrix& transform);
  virtual void castShadowSkeleton(
    int mode, M3Vector& dir, GLShadowedDelegate& sd, M3Matrix* pt = NULL
  );
  virtual void renderSkeleton(GLCamera& camera);
  void drawPrimitives() {draw();}
  void drawPrimitivesNoInterpol() {drawNI();}
  void useVertexBuffer();
protected:
  void updateRotations() {
    M3RotationY rot(pitchAngle);
    M3RotationZ rotZ(yawAngle);
    rot.multiply(rotZ);
    set(rot);
  }
public:
  float yawAngle;
  float pitchAngle;
  float getYawAngle() {return yawAngle;}
  float getPitchAngle() {return pitchAngle;}
  void setYawAngle(float a) {yawAngle = a; updateRotations();}
  void setPitchAngle(float a) {pitchAngle = a; updateRotations();}
  float addYawAngle(float a, float maxA = 0, float minA = 0);
  float addPitchAngle(float a, float maxA = 0, float minA = 0);
};

//
// GLBot
//
class GLBot: public GLModel {
public:
  enum UpperAnimation {
    BOTH_DEATH1, BOTH_DEAD1, BOTH_DEATH2, BOTH_DEAD2, BOTH_DEATH3, BOTH_DEAD3,
    MAX_BOTH_ANIMATIONS,
    TORSO_GESTURE = MAX_BOTH_ANIMATIONS, TORSO_ATTACK, TORSO_ATTACK2,
    TORSO_DROP, TORSO_RAISE, TORSO_STAND, TORSO_STAND2,
    MAX_UPPER_ANIMATIONS
  };
  enum LowerAnimation {
    LEGS_WALKCR = MAX_BOTH_ANIMATIONS, LEGS_WALK, LEGS_RUN, LEGS_BACK,
    LEGS_SWIM, LEGS_JUMP, LEGS_LAND, LEGS_JUMPB, LEGS_LANDB, LEGS_IDLE,
    LEGS_IDLECR, LEGS_TURN,
    MAX_LOWER_ANIMATIONS
  };
protected:
  GLModel* head;
  GLModel* upper;
public:
  GLBot(bool ownsCache = false);
  GLBot(GLBot& toBeCloned);
#ifdef USE_DATA_FILES
  bool loadBot(const char* path, const char* modelName, bool ownsCaches = false);
#endif // USE_DATA_FILES
  ~GLBot();
  void walk(float step) {moveSide(step);}
  void setUpper(GLModel* u);
  void setHead(GLModel* h);
  GLModel& getLower() {return *this;}
  GLModel& getUpper() {return *upper;}
  GLModel& getHead() {return *head;}
  int getLowerAnimation() {return GLModel::getCurrentAnimation();}
  int getUpperAnimation() {return upper? upper->getCurrentAnimation(): -1;}
  void setLowerAnimation(int anim, bool playBack = false)
  	{GLModel::setAnimation(anim,playBack);}
  void setUpperAnimation(int anim, bool playBack = false)
  	{if(upper) upper->setAnimation(anim,playBack);}
  void setAnimation(int a, bool playBack = false)
  	{setLowerAnimation(a,playBack); setUpperAnimation(a,playBack);}
  void rescale(float s) {
    GLModel::rescale(s);
    if(upper) upper->rescale(s);
    if(head) head->rescale(s);
  }
  bool getLinkTransform(const char* tagName, M3Matrix& transform);
  void useVertexBuffer();
  virtual void castShadow(
    int mode, M3Vector& dir, GLShadowedDelegate& sd, M3Matrix* pt = NULL
  );
  virtual void render(GLCamera& camera);
};

#ifdef USE_CAL3D

//
// GLAdvancedCoreModel
//
class GLAdvancedCoreModel: public CalCoreModel, public DMReference {
private:
  DSArray<GLTexture,false> textures;
public:
  GLAdvancedCoreModel();
  virtual void destroyObject();
  void addTexture(GLTexture* tex) {textures.addElement(tex);}
#ifdef USE_DATA_FILES
  bool load(const char* fileName);
#endif // USE_DATA_FILES
};

//
// GLAdvancedModel
//

class GLAdvancedModel: public GLObject, public CalModel {
private:
  static float animationTime;
public:
  static void setAnimationTime(float at) {animationTime = at;}
  static float getAnimationTime() {return animationTime;}
private:
  GLAdvancedCoreModel* coreModel;
  CalHardwareModel* hwModel;
private:
  static int programReferenceCount;
  static const char vertexProgramStr[];
  static unsigned int vertexProgramId;
  unsigned int bufferObject[6];
public:
  enum {MAX_VERTEX_COUNT = 30000, MAX_FACE_COUNT = 50000};
private:
  static int meshReferenceCount;
  static float* meshVertices;
  static float* meshNormals;
  static CalIndex* meshFaces;
  static float* meshTextureCoordinates;
protected:
  float lastUpdate;
  bool culled;
public:
  GLAdvancedModel(GLAdvancedCoreModel& cm, bool useHardware = false);
  ~GLAdvancedModel();
  GLAdvancedModel* clone();
  bool isCulled() {return culled;}
  void setCulled(bool v) {culled = v;}
  void setLod(float l) {setLodLevel(l);}
  int getAnimationCount() {return coreModel->getCoreAnimationCount();}
  bool blendCycle(int id, float weight = 1, float delay = 0)
    {return getMixer()->blendCycle(id,weight,delay);}
  bool clearCycle(int id, float delay = 0)
    {return getMixer()->clearCycle(id,delay);}
  bool executeAction(
    int id, float delayIn = 0, float delayOut = 0,
    float weightTarget = 1.0f, bool autoLock = false
  ) {
    return getMixer()->executeAction(id,delayIn,delayOut,weightTarget,autoLock);
  }
  bool removeAction(int id) {return getMixer()->removeAction(id);}
  void updateFrame();
  virtual void castPlanarShadow();
  virtual void castShadowVolume(M3Vector& dir);
  virtual void render(GLCamera& camera);
};

#endif // USE_CAL3D

#endif // GLMODEL_H
