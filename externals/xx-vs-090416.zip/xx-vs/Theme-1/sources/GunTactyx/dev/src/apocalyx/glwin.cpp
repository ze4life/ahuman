/*
  Copyright (C) 2001-2006 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glwin.h"
#include "initdlg.h"
#ifdef USE_CONSOLE
#include "glconsole.h"
#endif // USE_CONSOLE
#ifdef USE_SOUND
#include "fmsound.h"
#endif // USE_SOUND

#include "_stdlib.h" // for itoa()

#ifdef USE_OGLES

//
// callbacks
//

void keyCallback(unsigned char key, int x, int y) {
  GLWin& glWin = GLWin::get();
  glWin.keyDown(key);
  switch(key) {
    case 27: { // KEY_ESCAPE
      glWin.running = false;
      break;
    }
    default: {
#ifdef USE_CONSOLE
      if(glWin.isConsoleShown()) {
        glWin.keyUp(key);
        GLConsole& console = GLConsole::get();
#ifdef USE_SMALL
        if(
          !console.getSmallInterpreter().isRunning() ||
          console.isSuspended()
        )
#endif // USE_SMALL
          console.keyPressed(key);
      } else {
#endif // USE_CONSOLE
#ifdef USE_SJGUI
        sjgui::OnKeyDownEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
        glWin.keyDownEvent(key);
#ifdef USE_CONSOLE
      }
#endif // USE_CONSOLE
      break;
    }
  }
}

void keyUpCallback(unsigned char key, int x, int y) {
  GLWin& glWin = GLWin::get();
  glWin.keyUp(key);
#ifdef USE_SJGUI
  sjgui::OnKeyUpEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
}

void specialCallback(int key, int x, int y) {
  GLWin& glWin = GLWin::get();
  glWin.keyDown(0x100|key);
#ifdef USE_SJGUI
  sjgui::OnKeyDownEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
  switch(key) {
    case GLUT_KEY_F1: {
      switch(glWin.getHelpMode()) {
        default:
        case GLWin::REDUCED_HELP:
        case GLWin::HIDDEN_HELP:
        case GLWin::USER_HELP:
          glWin.setHelpMode(GLWin::FULL_HELP);
          break;
        case GLWin::FULL_HELP:
          glWin.setHelpMode(GLWin::HIDDEN_HELP);
          break;
      }
      break;
    }
    case GLUT_KEY_F2: {
      glWin.setShowFramerate(!glWin.isFramerateShown());
      break;
    }
#ifdef USE_CONSOLE
    case GLUT_KEY_F3: {
      glWin.setShowConsole(!glWin.isConsoleShown());
      break;
    }
#ifdef USE_SMALL
    case GLUT_KEY_F5: {
      GLConsole& console = GLConsole::get();
      if(console.isSuspended())
        console.resume();
      else
        console.suspend();
      break;
    }
#endif // USE_SMALL
#endif // USE_CONSOLE
    case GLUT_KEY_F10: {
      glWin.acquireMouse(!glWin.isMouseAcquired());
      if(glWin.isMouseAcquired())
        glutSetCursor(GLUT_CURSOR_NONE);
      else
        glutSetCursor(GLUT_CURSOR_RIGHT_ARROW);
      break;
    }
    default: {
      break;
    }
  }
}

void specialUpCallback(int key, int x, int y) {
  GLWin& glWin = GLWin::get();
  glWin.keyUp(0x100|key);
#ifdef USE_SJGUI
  sjgui::OnKeyUpEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
}

void mouseCallback(int button, int state, int x, int y) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired()) {
    glWin.mouseDX += x;
    glWin.mouseDY -= y;
    glWin.centerMouse();
    int mod = glutGetModifiers();
    if((mod & GLUT_ACTIVE_SHIFT) != 0)
      glWin.mouseKeys |= GLWin::OGLES_SHIFT;
    if((mod & GLUT_ACTIVE_CTRL) != 0)
      glWin.mouseKeys |= GLWin::OGLES_CTRL;
    switch (button) {
      case GLUT_LEFT_BUTTON: {
        switch(state) {
          case GLUT_DOWN:
#ifdef USE_SJGUI
            sjgui::OnKeyDownEvent(&glWin.getGui(),SJ_KEY_MOUSE_LEFT);
#endif // USE_SJGUI
            glWin.mouseKeys |= GLWin::OGLES_LEFT;
            break;
          case GLUT_UP:
#ifdef USE_SJGUI
            sjgui::OnKeyUpEvent(&glWin.getGui(),SJ_KEY_MOUSE_LEFT);
#endif // USE_SJGUI
            glWin.mouseKeys ^= GLWin::OGLES_LEFT;
            break;
        }
        break;
      }
      case GLUT_MIDDLE_BUTTON: {
        switch(state) {
          case GLUT_DOWN:
#ifdef USE_SJGUI
            sjgui::OnKeyDownEvent(&glWin.getGui(),SJ_KEY_MOUSE_MIDDLE);
#endif // USE_SJGUI
            glWin.mouseKeys |= GLWin::OGLES_MIDDLE;
            break;
          case GLUT_UP:
#ifdef USE_SJGUI
            sjgui::OnKeyUpEvent(&glWin.getGui(),SJ_KEY_MOUSE_MIDDLE);
#endif // USE_SJGUI
            glWin.mouseKeys ^= GLWin::OGLES_MIDDLE;
            break;
        }
        break;
      }
      case GLUT_RIGHT_BUTTON: {
        switch(state) {
          case GLUT_DOWN:
#ifdef USE_SJGUI
            sjgui::OnKeyDownEvent(&glWin.getGui(),SJ_KEY_MOUSE_RIGHT);
#endif // USE_SJGUI
            glWin.mouseKeys |= GLWin::OGLES_RIGHT;
            break;
          case GLUT_UP:
#ifdef USE_SJGUI
            sjgui::OnKeyUpEvent(&glWin.getGui(),SJ_KEY_MOUSE_RIGHT);
#endif // USE_SJGUI
            glWin.mouseKeys ^= GLWin::OGLES_RIGHT;
            break;
        }
        break;
      }
    }
  }
}

void motionCallback(int x, int y) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired()) {
    glWin.mouseDX += x;
    glWin.mouseDY -= y;
    glWin.centerMouse();
#ifdef USE_SJGUI
    sjgui::OnMouseMoveEvent(&glWin.getGui(),
      glWin.centerX+glWin.mouseDX,glWin.centerY-glWin.mouseDY
    );
#endif // USE_SJGUI
  }
}

void passiveMotionCallback(int x, int y) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired()) {
    glWin.mouseDX += x;
    glWin.mouseDY -= y;
    glWin.centerMouse();
#ifdef USE_SJGUI
    sjgui::OnMouseMoveEvent(&glWin.getGui(),
      glWin.centerX+glWin.mouseDX,glWin.centerY-glWin.mouseDY
    );
#endif // USE_SJGUI
  }
}

void reshape(int w, int h) {
  GLWin& glWin = GLWin::get();
  glWin.resizeWindow(w,h);
}

void windowStatus(int state) {
  switch(state) {
    case GLUT_VISIBLE: {
      break;
    }
    case GLUT_NOT_VISIBLE: {
      break;
    }
  }
}

void display() {
  GLWin& glWin = GLWin::get();
  glWin.executeRendering();
  glWin.swapBuffers();
}

void idle() {
  GLWin& glWin = GLWin::get();
  if(!glWin.isRunning()) {
    glWin.destroyWindow();
    exit(0);
  }
  float newElapsedTime = 0.001f*glutGet(GLUT_ELAPSED_TIME);
  GLWin::timeStep = newElapsedTime - GLWin::elapsedTime;
  if(GLWin::timeStep == 0)
    GLWin::timeStep = 0.001f;
  GLWin::invTimeStep = 1/GLWin::timeStep;
  GLWin::elapsedTime = newElapsedTime;
#if defined(USE_CONSOLE) && defined (USE_SMALL)
  GLConsole& console = GLConsole::get();
  if(!console.isSuspended())
    console.continueExecution(GLWin::timeStep);
#endif // USE_CONSOLE && USE_SMALL
  glWin.updateScene();
#ifdef USE_SOUND
  FMSoundManager::update3DSound();
#endif // USE_SOUND
  glutPostRedisplay();
}

#elif defined(USE_GLFW)

//
// callbacks
//

void GLFWCALL keyCallback(int key, int action) {
  GLWin& glWin = GLWin::get();
  switch(action) {
    case GLFW_PRESS: {
      glWin.keyDown(key);
#ifdef USE_SJGUI
      sjgui::OnKeyDownEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
      switch(key) {
        case GLFW_KEY_ESC: {
          if(glWin.isVideoModesShown()) {
            glWin.setShowVideoModes(false);
          } else {
            glWin.running = false;
          }
          break;
        }
        case GLFW_KEY_F1: {
          switch(glWin.getHelpMode()) {
            default:
            case GLWin::REDUCED_HELP:
            case GLWin::HIDDEN_HELP:
            case GLWin::USER_HELP:
              glWin.setHelpMode(GLWin::FULL_HELP);
              break;
            case GLWin::FULL_HELP:
              glWin.setHelpMode(GLWin::HIDDEN_HELP);
              break;
          }
          break;
        }
        case GLFW_KEY_F2: {
          glWin.setShowFramerate(!glWin.isFramerateShown());
          break;
        }
#ifdef USE_CONSOLE
        case GLFW_KEY_F3: {
          glWin.setShowConsole(!glWin.isConsoleShown());
          break;
        }
#ifdef USE_SMALL
        case GLFW_KEY_F5: {
          GLConsole& console = GLConsole::get();
          if(console.isSuspended())
            console.resume();
          else
            console.suspend();
          break;
        }
#endif // USE_SMALL
#endif // USE_CONSOLE
        case GLFW_KEY_F9: {
          glWin.setVSyncOn(!glWin.isVSyncOn());
          glWin.applyVSync();
          break;
        }
        case GLFW_KEY_F10: {
          glWin.acquireMouse(!glWin.isMouseAcquired());
          if(glWin.isMouseAcquired())
            glfwDisable(GLFW_MOUSE_CURSOR);
          else
            glfwEnable(GLFW_MOUSE_CURSOR);
          break;
        }
        case GLFW_KEY_F11: {
          if(glWin.isVideoModesShown()) {
            GLFWvidmode* mode = glWin.getVideoMode(glWin.getCurrentVideoMode());
            glWin.setFullWidth(mode->Width);
            glWin.setFullHeight(mode->Height);
            glWin.setRedDepth(mode->RedBits);
            glWin.setGreenDepth(mode->GreenBits);
            glWin.setBlueDepth(mode->BlueBits);
          }
          break;
        }
        case GLFW_KEY_F12: {
          if(glWin.isVideoModesShown()) {
            int idx = glWin.getCurrentVideoMode()+1;
            glWin.setCurrentVideoMode(idx < glWin.getVideoModesCount()? idx: 0);
          } else {
            glWin.setShowVideoModes(true);
          }
          break;
        }
        default: {
#ifdef USE_CONSOLE
          if(glWin.isConsoleShown()) {
            glWin.keyUp(key);
            GLConsole& console = GLConsole::get();
#ifdef USE_SMALL
            if(
              !console.getSmallInterpreter().isRunning() ||
              console.isSuspended()
            )
#endif // USE_SMALL
              if(key & 0x100 == 0)
                console.keyPressed(key);
          } else {
#endif // USE_CONSOLE
            glWin.keyDownEvent(key);
#ifdef USE_CONSOLE
          }
#endif // USE_CONSOLE
          break;
        }
      }
      break;
    }
    case GLFW_RELEASE: {
#ifdef USE_SJGUI
      sjgui::OnKeyUpEvent(&glWin.getGui(),glWin.convertGuiKey(key));
#endif // USE_SJGUI
      glWin.keyUp(key);
      break;
    }
    default:
      break;
  }
}

void GLFWCALL mouseButtonCallback(int button, int action) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired()) {
#ifdef USE_SJGUI
    int guiKey;
    switch(button) {
      default:
      case GLFW_MOUSE_BUTTON_LEFT: guiKey = SJ_KEY_MOUSE_LEFT; break;
      case GLFW_MOUSE_BUTTON_RIGHT: guiKey = SJ_KEY_MOUSE_RIGHT; break;
      case GLFW_MOUSE_BUTTON_MIDDLE: guiKey = SJ_KEY_MOUSE_MIDDLE; break;
    }
    if(action == GLFW_PRESS) {
      sjgui::OnKeyDownEvent(&glWin.getGui(),guiKey);
      glWin.mouseKeys |= 1<<button;
    } else {
      sjgui::OnKeyUpEvent(&glWin.getGui(),guiKey);
      glWin.mouseKeys ^= 1<<button;
    }
#else // !USE_SJGUI
    if(action == GLFW_PRESS) {
      glWin.mouseKeys |= 1<<button;
    } else {
      glWin.mouseKeys ^= 1<<button;
    }
#endif // !USE_SJGUI
  }
}

void GLFWCALL mousePosCallback(int x, int y) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired()) {
    glWin.mouseDX += x;
    glWin.mouseDY -= y;
    glWin.centerMouse();
#ifdef USE_SJGUI
    sjgui::OnMouseMoveEvent(&glWin.getGui(),
      glWin.centerX+glWin.mouseDX,glWin.centerY-glWin.mouseDY
    );
#endif // USE_SJGUI
  }
}

void GLFWCALL mouseWheelCallback(int wheel) {
  GLWin& glWin = GLWin::get();
  if(glWin.isMouseAcquired())
    glWin.mouseWheel = wheel;
}

void GLFWCALL windowSizeCallback(int width, int height) {
  GLWin& glWin = GLWin::get();
  glWin.resizeWindow(width,height);
}

#else // !USE_OGLES && !USE_GLFW

//
// WndProc
//

LRESULT CALLBACK WndProc(
  HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam
) {
  static GLWin* glWin = NULL;
  switch(uMsg) {
    case WM_CREATE: {
      glWin = reinterpret_cast<GLWin*>(((LPCREATESTRUCT)lParam)->lpCreateParams);
      break;
    }
    case WM_ACTIVATE: {
      if(!HIWORD(wParam)) {
        glWin->setActive(TRUE);
      } else {
        glWin->setActive(FALSE);
      }
      break;
    }
    case WM_SYSCOMMAND: {
      switch(wParam) {
        case SC_SCREENSAVE:
        case SC_MONITORPOWER:
          return 0;
      }
      break;
    }
    case WM_CLOSE: {
      PostQuitMessage(0);
      return 0;
    }
    case WM_SYSKEYDOWN:
    case WM_KEYDOWN:
    {
      switch(wParam) {
        case VK_ESCAPE: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          if(glWin->isVideoModesShown()) {
            glWin->setShowVideoModes(false);
          } else {
            glWin->running = false;
          }
          break;
        }
        case VK_PAUSE: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          glWin->paused = !glWin->paused;
          break;
        }
        case VK_F1: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          switch(glWin->getHelpMode()) {
            default:
            case GLWin::REDUCED_HELP:
            case GLWin::HIDDEN_HELP:
            case GLWin::USER_HELP:
              glWin->setHelpMode(GLWin::FULL_HELP);
              break;
            case GLWin::FULL_HELP:
              glWin->setHelpMode(GLWin::HIDDEN_HELP);
              break;
          }
          break;
        }
        case VK_F2: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          glWin->setShowFramerate(!glWin->isFramerateShown());
          break;
        }
#ifdef USE_CONSOLE
        case VK_F3: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          glWin->setShowConsole(!glWin->isConsoleShown());
          break;
        }
#ifdef USE_SMALL
        case VK_F5: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          GLConsole& console = GLConsole::get();
          if(console.isSuspended())
            console.resume();
          else
            console.suspend();
          break;
        }
#endif // USE_SMALL
#endif // USE_CONSOLE
        case VK_F7: {
          glWin->keyDown(wParam);
          glWin->setGammaCorrection(glWin->getGammaCorrection()*1.05f);
          break;
        }
        case VK_F8: {
          glWin->keyDown(wParam);
          glWin->setGammaCorrection(glWin->getGammaCorrection()/1.05f);
          break;
        }
        case VK_F9: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          glWin->setVSyncOn(!glWin->isVSyncOn());
          glWin->applyVSync();
          break;
        }
        case VK_F10: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          glWin->acquireMouse(!glWin->isMouseAcquired());
          ShowCursor(glWin->isMouseAcquired()?FALSE:TRUE);
          break;
        }
        case VK_F11: {
          if(HIWORD(lParam) & KF_REPEAT)
            break;
          glWin->keyDown(wParam);
          if(glWin->isVideoModesShown()) {
            VideoMode* mode = glWin->getVideoMode(glWin->getCurrentVideoMode());
            glWin->setFullWidth(mode->width);
            glWin->setFullHeight(mode->height);
            glWin->setColorDepth(mode->colorDepth);
          }
          break;
        }
        case VK_F12: {
          glWin->keyDown(wParam);
          if(glWin->isVideoModesShown()) {
            int idx = glWin->getCurrentVideoMode()+1;
            glWin->setCurrentVideoMode(idx < glWin->getVideoModesCount()? idx: 0);
          } else {
            glWin->setShowVideoModes(true);
          }
          break;
        }
        default: {
#ifdef USE_CONSOLE
          if(glWin->isConsoleShown()) {
            MSG msg;
            if(
              (HIWORD(lParam) & KF_EXTENDED) == 0 &&
              PeekMessage(&msg,NULL,0,0,PM_REMOVE)
            ) {
              TranslateMessage(&msg);
              DispatchMessage(&msg);
            } else {
              GLConsole::get().keyPressed(
                (TCHAR)wParam,
                bool(HIWORD(lParam) & KF_EXTENDED),
                bool(HIWORD(lParam) & KF_ALTDOWN)
              );
            }
          } else {
#endif // USE_CONSOLE
            if(HIWORD(lParam) & KF_REPEAT)
              break;
            glWin->keyDown(wParam);
#ifdef USE_SJGUI
            sjgui::OnKeyDownEvent(&glWin->getGui(),glWin->convertGuiKey(wParam));
#endif // USE_SJGUI
            glWin->keyDownEvent(wParam);
#ifdef USE_CONSOLE
          }
#endif // USE_CONSOLE
          break;
        }
      }
      return 0; // message processed
    }
    case WM_KEYUP: {
      glWin->keyUp(wParam);
#ifdef USE_SJGUI
      sjgui::OnKeyUpEvent(&glWin->getGui(),glWin->convertGuiKey(wParam));
#endif // USE_SJGUI
      break;
    }
#ifdef USE_CONSOLE
    case WM_SYSCHAR:
    case WM_CHAR:
    {
      if(glWin->isConsoleShown()) {
        GLConsole& console = GLConsole::get();
#ifdef USE_SMALL
        if(!console.getSmallInterpreter().isRunning() || console.isSuspended())
#endif // USE_SMALL
          console.keyPressed(
            (TCHAR)wParam,
            bool(HIWORD(lParam) & KF_EXTENDED),
            bool(HIWORD(lParam) & KF_ALTDOWN)
          );
      }
      return 0; // message processed
    }
#endif // USE_CONSOLE
    case WM_LBUTTONUP: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyUpEvent(&glWin->getGui(),SJ_KEY_MOUSE_LEFT);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_MBUTTONUP: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyUpEvent(&glWin->getGui(),SJ_KEY_MOUSE_MIDDLE);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_RBUTTONUP: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyUpEvent(&glWin->getGui(),SJ_KEY_MOUSE_RIGHT);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_LBUTTONDOWN: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyDownEvent(&glWin->getGui(),SJ_KEY_MOUSE_LEFT);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_MBUTTONDOWN: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyDownEvent(&glWin->getGui(),SJ_KEY_MOUSE_MIDDLE);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_RBUTTONDOWN: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
#ifdef USE_SJGUI
        sjgui::OnKeyDownEvent(&glWin->getGui(),SJ_KEY_MOUSE_RIGHT);
#endif // USE_SJGUI
      }
      return 0;
    }
    case WM_MOUSEMOVE: {
      if(glWin->isMouseAcquired()) {
        static bool centeringMouse = true;
        if(!centeringMouse) {
          glWin->mouseKeys = (short)LOWORD(wParam);
          glWin->mouseDX += (short)LOWORD(lParam)-glWin->centerX;
          glWin->mouseDY += glWin->centerY-(short)HIWORD(lParam);
          glWin->mouseWheel += (short)HIWORD(wParam);
          glWin->centerMouse();
          centeringMouse = true;
#ifdef USE_SJGUI
          sjgui::OnMouseMoveEvent(&glWin->getGui(),
            glWin->centerX+glWin->mouseDX,glWin->centerY-glWin->mouseDY
          );
#endif // USE_SJGUI
        } else {
          centeringMouse = false;
        }
      }
      return 0;
    }
    case WM_MOUSEWHEEL: {
      if(glWin->isMouseAcquired()) {
        glWin->mouseKeys = (short)LOWORD(wParam);
        glWin->mouseWheel += (short)HIWORD(wParam);
      }
      return 0;
    }
    case WM_SIZE:   {
      glWin->resizeWindow(LOWORD(lParam),HIWORD(lParam));
      return 0;
    }
    default:
      break;
  }
  return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

#endif // !USE_OGLES && !USE_GLFW

//
// GLWin
//

GLWin::GLWin() throw(ExceptionThrown):
  paused(false), running(true), mouseAcquired(false), mainOverlayFont(NULL),
  helpMode(REDUCED_HELP), showFramerate(true),
  mouseKeys(0), mouseDX(0), mouseDY(0), mouseWheel(0),
  showVideoModes(false), setupFileName(NULL)
#ifdef USE_OGLES
  , winID(0)
#elif defined(USE_GLFW)
#else // !USE_GLFW && !USE_OGLES
  , lastMouseWheel(0), gammaCorrection(1)
#endif // !USE_GLFW && !USE_OGLES
#ifdef USE_CONSOLE
  , showConsole(false), consoleOffset(0)
#endif // USE_CONSOLE
{
  window = this;
#ifdef USE_SJGUI
  sjgui::OnInitEvent(&getGui());
#endif // USE_SJGUI
  for(int ct = 0; ct < 512; ct++)
    keys[ct] = false;
#if !defined(USE_GLFW) && !defined(USE_OGLES)
  LARGE_INTEGER queryTicksPerSec;
  QueryPerformanceFrequency(&queryTicksPerSec);
  ticksPeriod = 1.0f/queryTicksPerSec.QuadPart;
#else // !USE_GLFW && !USE_OGLES
#ifdef USE_OGLES
#else // !USE_OGLES
  setFullscreen(getFullscreenOn());
#endif // !USE_OGLES
#endif // !USE_GLFW && !USE_OGLES
#ifdef USE_SOUND
  FMSoundManager::initialize();
#endif // USE_SOUND
}

GLWin* GLWin::window = NULL;
float GLWin::timeStep = 0;
float GLWin::invTimeStep = 0;
float GLWin::elapsedTime = 0;
#if !defined(USE_GLFW) && !defined(USE_OGLES)
float GLWin::ticksPeriod = 0;
#endif // !USE_GLFW && !USE_OGLES

GLWin::~GLWin() {
  if(setupFileName) delete setupFileName;
#ifdef USE_SOUND
  FMSoundManager::finalize();
#endif // USE_SOUND
}

bool GLWin::createWindow() {
#ifdef USE_OGLES
	glutInitWindowSize(getWidth(),getHeight());
  winID = glutCreateWindow(getTitle());
#elif defined(USE_GLFW)
  int ret = glfwOpenWindow(
    getWidth(),getHeight(),
    getRedDepth(),getGreenDepth(),getBlueDepth(),
    0,getDepthDepth(),getStencilDepth(),
    isFullscreen()? GLFW_FULLSCREEN: GLFW_WINDOW
  );
  IS_STENCIL_AVAILABLE = true;
  if(ret == GL_FALSE) {
    shutdown("glfwOpenWindow failed");
    return false;
  }
  glfwSetWindowTitle(getTitle());
  if(!isFullscreen())
    glfwDisable(GLFW_MOUSE_CURSOR);
  if(!initializeRenderer()) {
    shutdown("Can't Initialize The GL Rendering");
    return false;
  }
#else // !USE_OGLES && !USE_GLFW
  GLuint   pixelFormat;
  WNDCLASS wc;
  DWORD    dwExStyle;
  DWORD    dwStyle;
  RECT     windowRect;
  windowRect.left   = (long)0;
  windowRect.right  = (long)getWidth();
  windowRect.top    = (long)0;
  windowRect.bottom = (long)getHeight();
  hInstance      = GetModuleHandle(NULL);
  wc.style       = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
  wc.lpfnWndProc = (WNDPROC)WndProc;
  wc.cbClsExtra  = 0;
  wc.cbWndExtra  = sizeof(LONG);
  wc.hInstance   = hInstance;
  wc.hIcon       = LoadIcon(hInstance, MAKEINTRESOURCE(1));
  wc.hCursor     = LoadCursor(NULL,IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName  = NULL;
  wc.lpszClassName = "GLWin";
  if(!RegisterClass(&wc)) {
    showError("Failed To Register The Window Class");
    return false;
  }
  if(isFullscreen()) {
    DEVMODE dmScreenSettings;
    ZeroMemory(&dmScreenSettings,sizeof(dmScreenSettings));
    dmScreenSettings.dmSize = sizeof(dmScreenSettings);
    dmScreenSettings.dmPelsWidth = getWidth();
    dmScreenSettings.dmPelsHeight = getHeight();
    dmScreenSettings.dmBitsPerPel = getColorDepth();
    dmScreenSettings.dmFields = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;
    if(getFrequency() != 0) {
      dmScreenSettings.dmDisplayFrequency = getFrequency();
      dmScreenSettings.dmFields |= DM_DISPLAYFREQUENCY;
    }
    if(
      ChangeDisplaySettings(
        &dmScreenSettings,CDS_FULLSCREEN
      ) != DISP_CHANGE_SUCCESSFUL
    ) {
      if(
        askQuestion(
          "The requested fullscreen mode is not supported by\n"
          "your video card. Use windowed mode instead?"
        ) == IDYES
      ) {
        setFullscreen(false);
      } else {
        showError("Program Will Now Close");
        return false;
      }
    }
  }
  if(isFullscreen()) {
    dwExStyle = WS_EX_APPWINDOW;
    dwStyle = WS_POPUP|WS_SYSMENU|WS_VISIBLE;
    ShowCursor(FALSE);
  } else {
    dwExStyle = WS_EX_APPWINDOW|WS_EX_WINDOWEDGE;
    dwStyle = WS_OVERLAPPEDWINDOW;
  }
  AdjustWindowRectEx(&windowRect,dwStyle,FALSE,dwExStyle);
  if((hWnd = CreateWindowEx(
    dwExStyle,
    "GLWin",
    getTitle(),
    dwStyle|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
    0, 0,
    windowRect.right-windowRect.left,
    windowRect.bottom-windowRect.top,
    NULL,
    NULL,
    hInstance,
    (LPVOID)this
  )) == NULL) {
    destroyWindow();
    showError("Window Creation Error");
    return false;
  }
  PIXELFORMATDESCRIPTOR pfd = {
    sizeof(PIXELFORMATDESCRIPTOR),
    1,
    PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER,
    PFD_TYPE_RGBA,
    (short)getColorDepth(),
    0, 0, 0, 0, 0, 0,
    0,
    0,
    0,
    0, 0, 0, 0,
    (short)getDepthDepth(),
    (short)getStencilDepth(),
    0,
    PFD_MAIN_PLANE,
    0,
    0, 0, 0
  };
  if((hDC = GetDC(hWnd)) == NULL) {
    shutdown("Can't Create A GL Device Context");
    return false;
  }
  if((pixelFormat = ChoosePixelFormat(hDC,&pfd)) == 0) {
    shutdown("Can't Find A Suitable PixelFormat");
    return false;
  }
  IS_STENCIL_AVAILABLE = (pfd.cStencilBits > 0);
  if(!SetPixelFormat(hDC,pixelFormat,&pfd)) {
    shutdown("Can't Set The PixelFormat");
    return false;
  }
  if((hRC = wglCreateContext(hDC)) == NULL) {
    shutdown("Can't Create A GL Rendering Context");
    return false;
  }
  if(!wglMakeCurrent(hDC,hRC)) {
    shutdown("Can't Activate The GL Rendering Context");
    return false;
  }
  if(!initializeRenderer()) {
    shutdown("Can't Initialize The GL Rendering");
    return false;
  }
  ShowWindow(hWnd,SW_SHOW);
  SetForegroundWindow(hWnd);
  SetFocus(hWnd);
  resizeWindow(getWidth(),getHeight());
  if(!getMainOverlayFont())
    setMainOverlayFont(new GLBitmapFont(hDC,"Arial",16,0,FW_BOLD));
  GetDeviceGammaRamp(getHDC(),oldGammaCorrections);
#endif // !USE_OGLES && !USE_GLFW
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
  swapBuffers();
  acquireMouse(true);
#ifdef USE_CONSOLE
  GLConsole& console = GLConsole::get();
  console.setWin(this);
  consoleOffset = (float)getWidth();
#endif // USE_CONSOLE
  if(!initializeScene()) {
    shutdown("Can't Initialize The Scene");
    return false;
  }
  return true;
}

void GLWin::destroyWindow() {
  finalizeScene();
  finalizeRenderer();
  if(getMainOverlayFont())
    setMainOverlayFont(NULL);
#ifdef USE_OGLES
  glutDestroyWindow(winID);
  winID = 0;
#elif defined(USE_GLFW)
  glfwCloseWindow();
#else // !USE_OGLES && !USE_GLFW
  SetDeviceGammaRamp(getHDC(),oldGammaCorrections);
  if(fullscreen) {
    ChangeDisplaySettings(NULL,0);
    ShowCursor(TRUE);
  }
  if(hRC) {
    if(!wglMakeCurrent(NULL,NULL)) {
      showError("Release Of DC And RC Failed");
    }
    if(!wglDeleteContext(hRC)) {
      showError("Release Rendering Context Failed");
    }
    hRC = NULL;
  }
  if(hDC && !ReleaseDC(hWnd,hDC)) {
    showError("Release Device Context Failed");
    hDC = NULL;
  }
  if(hWnd && !DestroyWindow(hWnd)) {
    showError("Could Not Release The Window");
    hWnd = NULL;
  }
  if(!UnregisterClass("GLWin",hInstance)) {
    //showError("Could Not Unregister Class");
    hInstance = NULL;
  }
#endif // !USE_OGLES && !USE_GLFW
}

void GLWin::resizeWindow(GLsizei w, GLsizei h) {
#ifdef USE_SJGUI
  sjgui::OnResizeEvent(&getGui(),w,h);
#endif // USE_SJGUI
  if(h == 0) h = 1;
  setSize(w,h);
  centerX = w>>1;
  centerY = h>>1;
  if(isMouseAcquired())
    centerMouse();
  updateAspect();
}

#ifdef USE_SJGUI
int GLWin::convertGuiKey(int key) {
#ifdef USE_OGLES
  switch(key) {
    case GLUT_KEY_F1: return SJ_KEY_F1; break;
    case GLUT_KEY_F2: return SJ_KEY_F2; break;
    case GLUT_KEY_F3: return SJ_KEY_F3; break;
    case GLUT_KEY_F4: return SJ_KEY_F4; break;
    case GLUT_KEY_F5: return SJ_KEY_F5; break;
    case GLUT_KEY_F6: return SJ_KEY_F6; break;
    case GLUT_KEY_F7: return SJ_KEY_F7; break;
    case GLUT_KEY_F8: return SJ_KEY_F8; break;
    case GLUT_KEY_F9: return SJ_KEY_F9; break;
    case GLUT_KEY_F10: return SJ_KEY_F10; break;
    case GLUT_KEY_F11: return SJ_KEY_F11; break;
    case GLUT_KEY_F12: return SJ_KEY_F12; break;
    case GLUT_KEY_LEFT: return SJ_KEY_LEFT; break;
    case GLUT_KEY_UP: return SJ_KEY_UP; break;
    case GLUT_KEY_RIGHT: return SJ_KEY_RIGHT; break;
    case GLUT_KEY_DOWN: return SJ_KEY_DOWN; break;
    case GLUT_KEY_PAGE_UP: return SJ_KEY_PAGE_UP; break;
    case GLUT_KEY_PAGE_DOWN: return SJ_KEY_PAGE_DOWN; break;
    case GLUT_KEY_HOME: return SJ_KEY_HOME; break;
    case GLUT_KEY_END: return SJ_KEY_END; break;
    case GLUT_KEY_INSERT: return SJ_KEY_INSERT; break;
    default:
    return key; break;
  }
#elif defined(USE_GLFW)
  switch(key) {
    case GLFW_KEY_ESC: return SJ_KEY_ESC;
    case GLFW_KEY_F1: return SJ_KEY_F1;
    case GLFW_KEY_F2: return SJ_KEY_F2;
    case GLFW_KEY_F3: return SJ_KEY_F3;
    case GLFW_KEY_F4: return SJ_KEY_F4;
    case GLFW_KEY_F5: return SJ_KEY_F5;
    case GLFW_KEY_F6: return SJ_KEY_F6;
    case GLFW_KEY_F7: return SJ_KEY_F7;
    case GLFW_KEY_F8: return SJ_KEY_F8;
    case GLFW_KEY_F9: return SJ_KEY_F9;
    case GLFW_KEY_F10: return SJ_KEY_F10;
    case GLFW_KEY_F11: return SJ_KEY_F11;
    case GLFW_KEY_F12: return SJ_KEY_F12;
    case GLFW_KEY_F13: return SJ_KEY_F13;
    case GLFW_KEY_F14: return SJ_KEY_F14;
    case GLFW_KEY_F15: return SJ_KEY_F15;
    case GLFW_KEY_F16: return SJ_KEY_F16;
    case GLFW_KEY_F17: return SJ_KEY_F17;
    case GLFW_KEY_F18: return SJ_KEY_F18;
    case GLFW_KEY_F19: return SJ_KEY_F19;
    case GLFW_KEY_F20: return SJ_KEY_F20;
    case GLFW_KEY_F21: return SJ_KEY_F21;
    case GLFW_KEY_F22: return SJ_KEY_F22;
    case GLFW_KEY_F23: return SJ_KEY_F23;
    case GLFW_KEY_F24: return SJ_KEY_F24;
    case GLFW_KEY_UP: return SJ_KEY_UP;
    case GLFW_KEY_DOWN: return SJ_KEY_DOWN;
    case GLFW_KEY_LEFT: return SJ_KEY_LEFT;
    case GLFW_KEY_RIGHT: return SJ_KEY_RIGHT;
    case GLFW_KEY_LSHIFT: return SJ_KEY_SHIFT;
    case GLFW_KEY_RSHIFT: return SJ_KEY_SHIFT;
    case GLFW_KEY_LCTRL: return SJ_KEY_ALT;
    case GLFW_KEY_RCTRL: return SJ_KEY_ALT;
    case GLFW_KEY_LALT: return SJ_KEY_CTRL;
    case GLFW_KEY_RALT: return SJ_KEY_CTRL;
    case GLFW_KEY_TAB: return SJ_KEY_TAB;
    case GLFW_KEY_ENTER: return SJ_KEY_ENTER;
    case GLFW_KEY_BACKSPACE: return SJ_KEY_BACKSPACE;
    case GLFW_KEY_INSERT: return SJ_KEY_INSERT;
    case GLFW_KEY_DEL: return SJ_KEY_DEL;
    case GLFW_KEY_PAGEUP: return SJ_KEY_PAGE_UP;
    case GLFW_KEY_PAGEDOWN: return SJ_KEY_PAGE_DOWN;
    case GLFW_KEY_HOME: return SJ_KEY_HOME;
    case GLFW_KEY_END: return SJ_KEY_END;
    case GLFW_KEY_KP_0: return SJ_KEY_NUMPAD0;
    case GLFW_KEY_KP_1: return SJ_KEY_NUMPAD1;
    case GLFW_KEY_KP_2: return SJ_KEY_NUMPAD2;
    case GLFW_KEY_KP_3: return SJ_KEY_NUMPAD3;
    case GLFW_KEY_KP_4: return SJ_KEY_NUMPAD4;
    case GLFW_KEY_KP_5: return SJ_KEY_NUMPAD5;
    case GLFW_KEY_KP_6: return SJ_KEY_NUMPAD6;
    case GLFW_KEY_KP_7: return SJ_KEY_NUMPAD7;
    case GLFW_KEY_KP_8: return SJ_KEY_NUMPAD8;
    case GLFW_KEY_KP_9: return SJ_KEY_NUMPAD9;
    case GLFW_KEY_KP_DIVIDE: return SJ_KEY_DIVIDE;
    case GLFW_KEY_KP_MULTIPLY: return SJ_KEY_MULTIPLY;
    case GLFW_KEY_KP_SUBTRACT: return SJ_KEY_SUBTRACT;
    case GLFW_KEY_KP_ADD: return SJ_KEY_ADD;
    case GLFW_KEY_KP_DECIMAL: return SJ_KEY_DECIMAL;
    case GLFW_KEY_KP_EQUAL: return SJ_KEY_ENTER;
    case GLFW_KEY_KP_ENTER: return SJ_KEY_ENTER;
    default: return key;
  }
#else // !USE_OGLES && !USE_GLFW
  #define RET(x,y) case x: return y
	switch(key)	{
		RET(VK_TAB,SJ_KEY_TAB);
		RET(VK_RETURN,SJ_KEY_ENTER);
		RET(VK_SHIFT,SJ_KEY_SHIFT);
		RET(VK_CONTROL,SJ_KEY_CTRL);
		RET(VK_MENU,SJ_KEY_MENU);
		RET(VK_PAUSE,SJ_KEY_PAUSE);
		RET(VK_CAPITAL,SJ_KEY_CAPSLOCK);
		RET(VK_ESCAPE,SJ_KEY_ESC);
		RET(VK_SPACE,SJ_KEY_SPACE);
		RET(VK_END,SJ_KEY_END);
		RET(VK_HOME,SJ_KEY_HOME);
		RET(VK_LEFT,SJ_KEY_LEFT);
		RET(VK_UP,SJ_KEY_UP);
		RET(VK_RIGHT,SJ_KEY_RIGHT);
		RET(VK_DOWN,SJ_KEY_DOWN);
		RET(VK_INSERT,SJ_KEY_INSERT);
		RET(VK_DELETE,SJ_KEY_DEL);
		RET(VK_NUMPAD0,SJ_KEY_NUMPAD0);
		RET(VK_NUMPAD1,SJ_KEY_NUMPAD1);
		RET(VK_NUMPAD2,SJ_KEY_NUMPAD2);
		RET(VK_NUMPAD3,SJ_KEY_NUMPAD3);
		RET(VK_NUMPAD4,SJ_KEY_NUMPAD4);
		RET(VK_NUMPAD5,SJ_KEY_NUMPAD5);
		RET(VK_NUMPAD6,SJ_KEY_NUMPAD6);
		RET(VK_NUMPAD7,SJ_KEY_NUMPAD7);
		RET(VK_NUMPAD8,SJ_KEY_NUMPAD8);
		RET(VK_NUMPAD9,SJ_KEY_NUMPAD9);
		RET(VK_MULTIPLY,SJ_KEY_MULTIPLY);
		RET(VK_ADD,SJ_KEY_ADD);
		RET(VK_SUBTRACT,SJ_KEY_MINUS);
		RET(VK_DECIMAL,SJ_KEY_DECIMAL);
		RET(VK_DIVIDE,SJ_KEY_DIVIDE);
		RET(VK_F1,SJ_KEY_F1);
		RET(VK_F2,SJ_KEY_F2);
		RET(VK_F3,SJ_KEY_F3);
		RET(VK_F4,SJ_KEY_F4);
		RET(VK_F5,SJ_KEY_F5);
		RET(VK_F6,SJ_KEY_F6);
		RET(VK_F7,SJ_KEY_F7);
		RET(VK_F8,SJ_KEY_F8);
		RET(VK_F9,SJ_KEY_F9);
		RET(VK_F10,SJ_KEY_F10);
		RET(VK_F11,SJ_KEY_F11);
		RET(VK_F12,SJ_KEY_F12);
		RET(VK_F13,SJ_KEY_F13);
		RET(VK_F14,SJ_KEY_F14);
		RET(VK_F15,SJ_KEY_F15);
		RET(VK_F16,SJ_KEY_F16);
		RET(VK_F17,SJ_KEY_F17);
		RET(VK_F18,SJ_KEY_F18);
		RET(VK_F19,SJ_KEY_F19);
		RET(VK_F20,SJ_KEY_F20);
		RET(VK_F21,SJ_KEY_F21);
		RET(VK_F22,SJ_KEY_F22);
		RET(VK_F23,SJ_KEY_F23);
		RET(VK_F24,SJ_KEY_F24);
		RET(VK_NUMLOCK,SJ_KEY_NUMLOCK);
		RET(VK_SCROLL,SJ_KEY_SCROLL);
		RET(VK_PRIOR,SJ_KEY_PAGE_UP);
		RET(VK_NEXT,SJ_KEY_PAGE_DOWN);
		RET(VK_CLEAR,SJ_KEY_BACKSPACE);
	}
	if(key >= 0x41 && key <= 0x5A)
		if(!sjgui::CKeys::IsKey(SJ_KEY_SHIFT))
			return key+32;
	if(sjgui::CKeys::IsKey(SJ_KEY_SHIFT) && key >= 0x30 && key <= 0x39)
		switch(key) {
			RET('1','!');
			RET('2','@');
			RET('3','#');
			RET('4','$');
			RET('5','%');
			RET('6','^');
			RET('7','&');
			RET('8','*');
			RET('9','(');
			RET('0',')');
		}
  #undef RET
  #define RET(x,a,b) \
    if(key == x && sjgui::CKeys::IsKey(SJ_KEY_SHIFT)) return (int)b; \
    else return (int)a;
	RET(191,'/','?');
	RET(190,'.','>');
	RET(188,',','<');
	RET(219,'[','{');
	RET(221,']','}');
	RET(220,'\\','|');
	RET(287,'=','+');
	RET(189,'-','_');
	RET(192,'`','~');
	RET(222,'\'','"');
	RET(186,';',':');
  #undef RET
	return (int)key;
#endif // !USE_OGLES && !USE_GLFW
}
#endif // USE_SJGUI

#if !defined(USE_GLFW) && !defined(USE_OGLES)
bool GLWin::setGammaCorrection(float gamma) {
  gammaCorrection = gamma;
  unsigned short ramp[256*3];
  for(int ct = 0; ct < 256; ct++)
    ramp[ct] = ramp[ct+256] = ramp[ct+256*2] =
      (unsigned short)(pow(ct*(1.0f/255),gamma)*65280);
  return(bool)SetDeviceGammaRamp(getHDC(),ramp);
}
#endif // !USE_GLFW && !USE_OGLES

void GLWin::drawMainOverlay() {
  GLFont* font = getMainOverlayFont();
  if(font == NULL) return;
  font->initialize();
  const int FONT_HEIGHT = font->getHeight();
  const int BASE_ROW = FONT_HEIGHT>>1;
  bool isFontTextured = font->isTextured();
  if(isFontTextured) {
    dynamic_cast<GLTexturedFont*>(font)->applyTexture();
    glEnable(GL_ALPHA_TEST);
  } else {
    glDisable(GL_TEXTURE_2D);
  }
 	const float SCROLL_SPEED = 1000.0f;
  if(isVideoModesShown()) {
    const int col = BASE_ROW+getWidth()>>1;
    int row = BASE_ROW;
    font->setColor(1,1,0);
    font->drawText(col,row,12,"[ESC] Cancel");
    font->drawText(col,row += FONT_HEIGHT,12,"[F11] Accept");
    font->drawText(col,row += FONT_HEIGHT,12,"[F12] Select");
    font->setColor(1,1,1);
    for(int ct = 0; ct < getVideoModesCount(); ct++) {
      char valStr[8];
      char modeStr[64] = "  ";
      strcat(modeStr,ct == getCurrentVideoMode()? "--> ": "    ");
      int width, height, colorDepth;
#ifdef USE_OGLES
#elif defined(USE_GLFW)
      GLFWvidmode* mode = getVideoMode(ct);
      width = mode->Width;
      height = mode->Height;
      colorDepth = mode->RedBits+mode->GreenBits+mode->BlueBits;
#else // !USE_OGLES && !USE_GLFW
      VideoMode* mode = getVideoMode(ct);
      width = mode->width;
      height = mode->height;
      colorDepth = mode->colorDepth;
#endif // !USE_OGLES && !USE_GLFW
      strcat(modeStr,itoa(width,valStr,10));
      strcat(modeStr,"x");
      strcat(modeStr,itoa(height,valStr,10));
      strcat(modeStr,"x");
      strcat(modeStr,itoa(colorDepth,valStr,10));
      int len = strlen(modeStr);
      font->drawText(col,row += FONT_HEIGHT,len,modeStr);
    }
  } else if(getHelpMode() != HIDDEN_HELP) {
    if(getHelpMode() == REDUCED_HELP) {
      font->setColor(1,1,0);
      font->drawText(BASE_ROW,BASE_ROW+FONT_HEIGHT<<1,20,"[F1]  Show/Hide Help");
    } else {
      int row = BASE_ROW+FONT_HEIGHT;
      if(getHelpMode() == FULL_HELP) {
        const char* helpTextLines[] = {
#if !defined(USE_OGLES)
          "[F12] Change Resolution",
          "[F11] Fullscreen/Windowed",
#endif // !USE_OGLES
          "[F10] Release/Acquire Mouse",
#if !defined(USE_OGLES)
          "[F9]  On/Off Vertical Sync",
#endif // !USE_OGLES
#if !defined(USE_GLFW) && !defined(USE_OGLES)
          "[F8]  Gamma Correction +5%",
          "[F7]  Gamma Correction -5%",
#endif // !USE_GLFW && !USE_OGLES
#ifdef USE_CONSOLE
#ifdef USE_SMALL
          "[F5]  Suspend/Resume Script",
#endif // USE_SMALL
          "[F3]  Show/Hide Console",
#endif // USE_CONSOLE
          "[F2]  Show/Hide FPS",
          "[F1]  Show/Hide Help",
          "[ESC] Quit",
          NULL
        };
        font->setColor(1,1,0);
        for(int ct = 0; helpTextLines[ct] != NULL; ct++) {
          int len = strlen(helpTextLines[ct]);
          row += FONT_HEIGHT;
          font->drawText(BASE_ROW,row,len,helpTextLines[ct]);
        }
        row += FONT_HEIGHT;
      }
      const char* userHelpLine;
      font->setColor(1,1,1);
      for(int ct = 0; (userHelpLine = getHelpLine(ct)) != NULL; ct++) {
        row += FONT_HEIGHT;
        font->drawText(BASE_ROW,row,strlen(userHelpLine),userHelpLine);
      }
    }
  }
  if(isFramerateShown()) {
    static char fpsStr[16] = "";
    static int fpsLen = 0;
    static int frames = 0;
    frames++;
    static float startTime = GLWin::getElapsedTime();
    if(GLWin::getElapsedTime()-startTime >= 2) {
      strcat(itoa(frames>>1,fpsStr,10)," fps");
      fpsLen = strlen(fpsStr);
      frames = 0;
      startTime = GLWin::getElapsedTime();
    }
    font->setColor(1,1,0);
    font->drawText(BASE_ROW,BASE_ROW,fpsLen,fpsStr);
  }
#ifdef USE_CONSOLE
  if(isConsoleShown() || (consoleOffset < getWidth())) {
  	if(isConsoleShown()) {
	  	if(consoleOffset > 0) {
    		consoleOffset -= getTimeStep()*SCROLL_SPEED;
      	if(consoleOffset < 0)
      		consoleOffset = 0;
	    }
    } else {
   		consoleOffset += getTimeStep()*SCROLL_SPEED;
     	if(consoleOffset > getWidth())
     		consoleOffset = (float)getWidth();
    }
    GLConsole& console = GLConsole::get();
    const int FONT_WIDTH = font->getSpacing();
    const int BASE_COL = FONT_WIDTH>>1;
    int rows = console.getRows();
    int consoleHeight = FONT_HEIGHT*rows;
    int consoleWidth = FONT_WIDTH*console.getCols();
    bool leftAligned = getWidth() < consoleWidth+BASE_COL*6;
    glLoadIdentity();
    glColor3f(0,0,0.2f);
    glEnable(GL_BLEND);
    if(isFontTextured) {
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_ALPHA_TEST);
    }
    glBlendFunc(GL_ONE,GL_ONE_MINUS_DST_COLOR);
    glBegin(GL_QUADS);
    if(leftAligned) {
      glVertex2i(int(consoleOffset)+BASE_COL*4+consoleWidth,BASE_ROW);
      glVertex2i(int(consoleOffset)+BASE_COL*4+consoleWidth,BASE_ROW*3+consoleHeight);
      glVertex2i(int(consoleOffset)+BASE_COL*2,BASE_ROW*3+consoleHeight);
      glVertex2i(int(consoleOffset)+BASE_COL*2,BASE_ROW);
    } else {
      glVertex2i(int(consoleOffset)+getWidth()-BASE_COL*2,BASE_ROW);
      glVertex2i(int(consoleOffset)+getWidth()-BASE_COL*2,BASE_ROW*3+consoleHeight);
      glVertex2i(int(consoleOffset)+getWidth()-BASE_COL*4-consoleWidth,BASE_ROW*3+consoleHeight);
      glVertex2i(int(consoleOffset)+getWidth()-BASE_COL*4-consoleWidth,BASE_ROW);
    }
    glEnd();
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    if(isFontTextured) {
      glEnable(GL_TEXTURE_2D);
      glEnable(GL_ALPHA_TEST);
    }
    glDisable(GL_BLEND);
    int baseHorPosition = leftAligned?
      BASE_COL*2+FONT_WIDTH: getWidth()-consoleWidth-FONT_WIDTH-2*BASE_COL;
    baseHorPosition += int(consoleOffset);
    font->setColor(1,1,1);
    for(int ct = 0; ct < rows; ct++) {
      char* row = console.getRow(ct);
      if(row)
        font->drawText(
          baseHorPosition,2*BASE_ROW+(rows-ct-1)*FONT_HEIGHT,strlen(row),row
        );
    }
    if(console.isEditMode() && float(fmod(getElapsedTime(),1)) < 0.5f) {
      int row = console.getCursorRow()-console.getCursorBase();
      int col = console.getCursorCol();
      font->setColor(1,1,0);
      font->drawText(
        baseHorPosition+col*FONT_WIDTH,2*BASE_ROW+(rows-row-1)*FONT_HEIGHT,1,"_"
      );
    }
  }
#endif
  if(isFontTextured)
    glDisable(GL_ALPHA_TEST);
  else
    glEnable(GL_TEXTURE_2D);
}

#ifdef USE_OGLES

//
// main
//

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  GLWin* glWin;
  try {
    glWin = GLWin::newInstance(argv[1]);
  } catch(Exception& e) {
    exit(0);
    return 0;
  }
  int width = 800, height = 600;
  glWin->setFullSize(width,height);
  if(glWin->createWindow()) {
    glutKeyboardFunc(keyCallback);
    glutKeyboardUpFunc(keyUpCallback);
  	glutSpecialFunc(specialCallback);
  	glutSpecialUpFunc(specialUpCallback);
  	glutMouseFunc(mouseCallback);
  	glutMotionFunc(motionCallback);
  	glutPassiveMotionFunc(passiveMotionCallback);
	  glutReshapeFunc(reshape);
	  glutWindowStatusFunc(windowStatus);
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutMainLoop();
  }
  return 1;
}

#elif defined(USE_GLFW)

//
// main
//

int main(int argc, char * argv[]) {
  if(glfwInit() == GL_TRUE) {
    GLWin* glWin;
    try {
      glWin = GLWin::newInstance(argv[1]);
    } catch(Exception& e) {
      glfwTerminate();
      return 0;
    }
    const int MODESTR_LEN = 32;
    char initModeStr[MODESTR_LEN] = "";
    bool initFullScreen = false;
    bool initVSync = false;
    int initDepthBits = 16;
    int initStencilBits = 0;
    FILE* file = fopen(glWin->getSetupFileName(),"rb");
    if(file != NULL) {
      const int BUFFER_LENGTH = 128;
      char buffer[BUFFER_LENGTH];
      fread(buffer,1,BUFFER_LENGTH,file);
      fclose(file);
      char *token = strtok(buffer,",");
      strncpy(initModeStr,token,15);
      initModeStr[15] = '\0';
      token = strtok(NULL,",");
      initFullScreen = token[0] == 'F' || token[0] == 'f';
      token = strtok(NULL,",");
      initVSync = token[0] == 'V' || token[0] == 'v';
      token = strtok(NULL,",");
      initDepthBits = atoi(token);
      token = strtok(NULL,",");
      initStencilBits = atoi(token);
    }
    int width = 640, height = 480, depth = 16, freq = 0;
    char *token = strtok(initModeStr,"x");
    if(token) {
      width = atoi(token);
      token = strtok(NULL,"x");
      if(token) {
        height = atoi(token);
        token = strtok(NULL,"@");
        if(token) {
          depth = atoi(token);
          token = strtok(NULL,"@");
          if(token) {
            freq = atoi(token);
          }
        }
      }
    }
    glWin->setFullSize(width,height);
    int colorDepth = depth/3;
    glWin->setRedDepth(depth);
    glWin->setGreenDepth(depth);
    glWin->setBlueDepth(depth);
    glWin->setFrequency(freq);
    glWin->setDepthDepth(initDepthBits);
    glWin->setStencilDepth(initStencilBits);
    glWin->setFullscreen(initFullScreen);
    glWin->setVSyncOn(initVSync);
    if(glWin->createWindow()) {
      glfwSetKeyCallback(keyCallback);
      glfwSetWindowSizeCallback(windowSizeCallback);
      glfwSetMouseButtonCallback(mouseButtonCallback);
      glfwSetMousePosCallback(mousePosCallback);
      glfwSetMouseWheelCallback(mouseWheelCallback);
      while(glWin->isRunning() && glfwGetWindowParam(GLFW_OPENED)) {
        if(
          glfwGetWindowParam(GLFW_ACTIVE) && !glfwGetWindowParam(GLFW_ICONIFIED)
        ) {
          if(glWin->isKeyPressed(GLFW_KEY_F11)) {
            glWin->keyUp(GLFW_KEY_F11);
            glWin->destroyWindow();
            if(glWin->isVideoModesShown()) {
              glWin->setShowVideoModes(false);
            } else {
              glWin->setFullscreen(!glWin->isFullscreen());
            }
            glWin->setSize(glWin->getFullWidth(),glWin->getFullHeight());
            if(!glWin->createWindow())
              return 0;
            glfwSetKeyCallback(keyCallback);
            glfwSetWindowSizeCallback(windowSizeCallback);
            glfwSetMouseButtonCallback(mouseButtonCallback);
            glfwSetMousePosCallback(mousePosCallback);
			      glfwSetMouseWheelCallback(mouseWheelCallback);
            FILE* file = fopen(glWin->getSetupFileName(),"wb");
            if(file != NULL) {
              char buffer[64] = "\0";
              char valStr[8];
              int colorDepth =
                glWin->getRedDepth()+glWin->getGreenDepth()+glWin->getBlueDepth();
              strcat(strcat(buffer,itoa(glWin->getWidth(),valStr,10)),"x");
              strcat(strcat(buffer,itoa(glWin->getHeight(),valStr,10)),"x");
              strcat(strcat(buffer,itoa(colorDepth,valStr,10)),",");
              strcat(buffer,glWin->isFullscreen()?"FULLSCREEN,":"WINDOWED,");
              strcat(buffer,glWin->isVSyncOn()?"VSYNC,":"NO VSYNC,");
              strcat(strcat(buffer,itoa(glWin->getDepthDepth(),valStr,10)),",");
              strcat(strcat(buffer,itoa(glWin->getStencilDepth(),valStr,10)),",");
              fwrite(buffer,1,strlen(buffer),file);
              fclose(file);
            }
          } else {
            float newElapsedTime = float(glfwGetTime());
            GLWin::timeStep = newElapsedTime - GLWin::elapsedTime;
            GLWin::invTimeStep = 1/GLWin::timeStep;
            GLWin::elapsedTime = newElapsedTime;
#if defined(USE_CONSOLE) && defined (USE_SMALL)
            GLConsole& console = GLConsole::get();
            if(!console.isSuspended())
              console.continueExecution(GLWin::timeStep);
#endif // USE_CONSOLE && USE_SMALL
            glWin->updateScene();
            glWin->executeRendering();
#ifdef USE_SOUND
            FMSoundManager::update3DSound();
#endif // USE_SOUND
            glWin->swapBuffers();
          }
        }
      }
    }
    glWin->destroyWindow();
    delete glWin;
  }
  glfwTerminate();
  return 1;
}

#else // !USE_OGLES && !USE_GLFW

//
// WinMain
//

int WINAPI WinMain(
  HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow
) {
  hPrevInstance, lpCmdLine, nCmdShow;
  GLWin* glWin;
  try {
    glWin = GLWin::newInstance(lpCmdLine);
  } catch(Exception& e) {
    return FALSE;
  }
  char* chrPtr;
  if((chrPtr = strstr(lpCmdLine,"-setup\"")) != NULL) {
    chrPtr += 7;
    char* chr;
    for(chr = chrPtr; (*chr != '\"') && (*chr != '\0'); chr++);
    int nameLen = chr-chrPtr;
    char* newFileName = new char[nameLen+1];
    strncpy(newFileName,chrPtr,nameLen);
    newFileName[nameLen] = '\0';
    glWin->setSetupFileName(newFileName);
  }
  HRESULT hr;
  if(strstr(lpCmdLine,"-nosetup")) { // taken from initdlg.cpp
    hr = IDOK;
    const int MODESTR_LEN = 32;
    char initModeStr[MODESTR_LEN] = "";
    bool initFullScreen = false;
    bool initVSync = false;
    int initDepthBits = 16;
    int initStencilBits = 0;
    FILE* file = fopen(glWin->getSetupFileName(),"rb");
    if(file != NULL) {
      const int BUFFER_LENGTH = 128;
      char buffer[BUFFER_LENGTH];
      fread(buffer,1,BUFFER_LENGTH,file);
      fclose(file);
      char *token = strtok(buffer,",");
      strncpy(initModeStr,token,15);
      initModeStr[15] = '\0';
      token = strtok(NULL,",");
      initFullScreen = token[0] == 'F' || token[0] == 'f';
      token = strtok(NULL,",");
      initVSync = token[0] == 'V' || token[0] == 'v';
      token = strtok(NULL,",");
      initDepthBits = atoi(token);
      token = strtok(NULL,",");
      initStencilBits = atoi(token);
    }
    int width = 640, height = 480, depth = 16, freq = 0;
    char *token = strtok(initModeStr,"x");
    if(token) {
      width = atoi(token);
      token = strtok(NULL,"x");
      if(token) {
        height = atoi(token);
        token = strtok(NULL,"@");
        if(token) {
          depth = atoi(token);
          token = strtok(NULL,"@");
          if(token) {
            freq = atoi(token);
          }
        }
      }
    }
    glWin->setFullSize(width,height);
    glWin->setColorDepth(depth);
    glWin->setFrequency(freq);
    glWin->setDepthDepth(initDepthBits);
    glWin->setStencilDepth(initStencilBits);
    glWin->setFullscreen(initFullScreen);
    glWin->setVSyncOn(initVSync);
  } else {
    hr = DialogBoxParam(
      hInstance,MAKEINTRESOURCE(1),NULL,(DLGPROC)InitDlgProc,(LPARAM)glWin
    );
  }
  int retVal = FALSE;
  if(hr == IDCANCEL) {
    GLWin::showError("Configuration cancelled");
    delete glWin;
    return retVal;
  } else if(hr < 0) {
    GLWin::showError("Error during configuration");
    delete glWin;
    return retVal;
  } else if(glWin->createWindow()) {
    MSG msg;
    while(glWin->isRunning()) {
      if(PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
        if(msg.message == WM_QUIT) {
          break;
        } else {
          TranslateMessage(&msg);
          DispatchMessage(&msg);
        }
      } else {
        if(glWin->isActive()) {
          if(glWin->isKeyPressed(VK_F11)) {
            glWin->keyUp(VK_F11);
            glWin->destroyWindow();
            if(glWin->isVideoModesShown()) {
              glWin->setShowVideoModes(false);
            } else {
              glWin->setFullscreen(!glWin->isFullscreen());
            }
            glWin->setSize(glWin->getFullWidth(),glWin->getFullHeight());
            if(!glWin->createWindow())
              return FALSE;
            FILE* file = fopen(glWin->getSetupFileName(),"wb");
            if(file != NULL) {
              char buffer[64] = "\0";
              char valStr[8];
              strcat(strcat(buffer,itoa(glWin->getWidth(),valStr,10)),"x");
              strcat(strcat(buffer,itoa(glWin->getHeight(),valStr,10)),"x");
              strcat(strcat(buffer,itoa(glWin->getColorDepth(),valStr,10)),",");
              strcat(buffer,glWin->isFullscreen()?"FULLSCREEN,":"WINDOWED,");
              strcat(buffer,glWin->isVSyncOn()?"VSYNC,":"NO VSYNC,");
              strcat(strcat(buffer,itoa(glWin->getDepthDepth(),valStr,10)),",");
              strcat(strcat(buffer,itoa(glWin->getStencilDepth(),valStr,10)),",");
              fwrite(buffer,1,strlen(buffer),file);
              fclose(file);
            }
          } else {
            LARGE_INTEGER queryTicks;
            QueryPerformanceCounter(&queryTicks);
            static LONGLONG lastTicks = queryTicks.QuadPart;
            GLWin::timeStep = GLWin::ticksPeriod*(
              queryTicks.QuadPart-lastTicks
            );
            GLWin::invTimeStep = 1/GLWin::timeStep;
            GLWin::elapsedTime += GLWin::timeStep;
            lastTicks = queryTicks.QuadPart;
#if defined(USE_CONSOLE) && defined (USE_SMALL)
            GLConsole& console = GLConsole::get();
            if(!console.isSuspended())
              console.continueExecution(GLWin::timeStep);
#endif // USE_CONSOLE && USE_SMALL
            glWin->updateScene();
            glWin->executeRendering();
#ifdef USE_SOUND
            FMSoundManager::update3DSound();
#endif // USE_SOUND
            glWin->swapBuffers();
          }
        }
      }
    }
    retVal = msg.wParam;
  }
  glWin->destroyWindow();
  delete glWin;
  return retVal;
}

#endif // !USE_OGLES && !USE_GLFW
