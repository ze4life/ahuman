/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "opengl.h"
#include "globject.h"

#include "glshadow.h"

#include "datasets.inc"
#include "math3d.inc"

//
// GLClip
//
GLClip::GLClip(): maxRadius(0), clipped(false), distance(0) {
}

//
// GLVisible
//
GLVisible::GLVisible(): visible(false) {
}

//
// GLObject
//

GLObject::GLObject(): transparent(false), scaled(false) {
}

GLObject::~GLObject() {
}

bool GLObject::clip(GLCamera& camera, M3Matrix* parentTransform) {
  clipped = false;
  M3Vector pos(getPositionX(),getPositionY(),getPositionZ());
  if(parentTransform) parentTransform->multiply(pos);
  for(int ct = 0; ct < 5; ct++) {
    float dist = camera.dot(ct,pos.getX(),pos.getY(),pos.getZ());
    if(dist <= -getMaxRadius()) {
      clipped = true;
      break;
    }
  }
  distance = camera.dot(5,pos.getX(),pos.getY(),pos.getZ());
  if(distance <= -getMaxRadius())
    clipped = true;
  distance = fabs(distance);
  if(camera.isRenderingReflections() && clipped) {
    clipped = false;
    pos.setY(-pos.getY());
    for(int ct = 0; ct < 6; ct++) {
      float dist = camera.dot(ct,pos.getX(),pos.getY(),pos.getZ());
      if(dist <= -getMaxRadius()) {
        clipped = true;
        break;
      }
    }
  }
  return clipped;
}

void GLObject::castShadowBone(
  int mode, M3Vector& d, GLShadowedDelegate& sd, M3Matrix* parentTransform
) {
  M3Vector dir = d;
  switch(mode) {
    default:
    case GLShadow::PLANAR_SHADOW: {
      M3Vector& position = getPosition();
      float* transform = getTransform();
      M3Reference groupTransform;
      if(parentTransform) {
        groupTransform.set(*static_cast<M3Matrix*>(this));
        groupTransform.multiply(*parentTransform);
        position = groupTransform.getPosition();
        transform = groupTransform.getArray();
      }
      M3Vector planePos = position;
      M3Vector normal;
      GLShadowed* shadowed = sd.getShadowedDelegator();
      float dist = shadowed->getPlane(planePos,dir,normal);
      float normalDotDir = normal.dot(dir);
      if(normalDotDir <= 0)
        return;
      float fade;
      if(shadowed->getShadowFadeDistance() > 0) {
        float h = dir.dot(position)-dist/normalDotDir;
        fade = (shadowed->getShadowFadeDistance()-h)*
          shadowed->getInvShadowFadeDistance();
        if(fade <= 0)
          return;
      } else {
        fade = 1;
      }
      dist += shadowed->getShadowOffset()-normal.dot(position);
      normal.rotateT(transform);
      dir.rotateT(transform);
      if(isScaled()) {
        normal.normalize();
        dir.normalize();
      }
      float planeProjection[16] = {
        -dir.getX()*normal.getX()+normalDotDir,
        -dir.getY()*normal.getX(),
        -dir.getZ()*normal.getX(),
        0,
        -dir.getX()*normal.getY(),
        -dir.getY()*normal.getY()+normalDotDir,
        -dir.getZ()*normal.getY(),
        0,
        -dir.getX()*normal.getZ(),
        -dir.getY()*normal.getZ(),
        -dir.getZ()*normal.getZ()+normalDotDir,
        0,
        dist*dir.getX(),
        dist*dir.getY(),
        dist*dir.getZ(),
        normalDotDir
      };
      glMultMatrixf(planeProjection);
      glDepthMask(GL_FALSE);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_LIGHTING);
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
      glColor4f(0,0,0,shadowed->getShadowIntensity()*fade);
      castPlanarShadow();
      glDepthMask(GL_TRUE);
      glDisable(GL_BLEND);
      glEnable(GL_TEXTURE_2D);
      glEnable(GL_LIGHTING);
      break;
    }
    case GLShadow::SHADOW_VOLUME: {
		  glEnable(GL_STENCIL_TEST);
		  glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);
		  glDepthMask(GL_FALSE);
			glStencilFunc(GL_ALWAYS,0,0);
		  glDisable(GL_LIGHTING);
		  glDisable(GL_TEXTURE_2D);
      float* transform = getTransform();
      M3Reference groupTransform;
      if(parentTransform) {
        groupTransform.set(*static_cast<M3Matrix*>(this));
        groupTransform.multiply(*parentTransform);
        transform = groupTransform.getArray();
      }
      dir.rotateT(transform).scale(-1);
      castShadowVolume(dir);
		  glEnable(GL_LIGHTING);
		  glEnable(GL_TEXTURE_2D);
		  glDepthMask(GL_TRUE);
		  glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
		  glDisable(GL_STENCIL_TEST);
      break;
    }
  }
}

void GLObject::castShadow(
  int mode, M3Vector& dir, GLShadowedDelegate& sd, M3Matrix* parentTransform
) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  castShadowBone(mode,dir,sd,parentTransform);
  glPopMatrix();
}

//
// GLObjects
//
bool GLObjects::clip(GLCamera& camera, M3Matrix* parentTransform) {
  GLObject::clip(camera,parentTransform);
  if(!isClipped()) {
    GLObject* obj = getFirstObject();
    if(parentTransform) {
      while(obj) {
        M3Matrix groupTransform(*static_cast<M3Matrix*>(this));
        groupTransform.multiply(*parentTransform);
        obj->clip(camera,&groupTransform);
        obj = getNextObject();
      }
    } else {
      while(obj) {
        obj->clip(camera,static_cast<M3Matrix*>(this));
        obj = getNextObject();
      }
    }
    return true;
  }
  return false;
}

void GLObjects::castShadow(
  int mode, M3Vector& d, GLShadowedDelegate& sd, M3Matrix* parentTransform
) {
  glPushMatrix();
  glMultMatrixf(getTransform());
  GLObject* obj = getFirstObject();
  if(parentTransform) {
    while(obj) {
      M3Matrix groupTransform(*static_cast<M3Matrix*>(this));
      groupTransform.multiply(*parentTransform);
      obj->castShadow(mode,d,sd,&groupTransform);
      obj = getNextObject();
    }
  } else {
    while(obj) {
      obj->castShadow(mode,d,sd,static_cast<M3Matrix*>(this));
      obj = getNextObject();
    }
  }
  glPopMatrix();
}

void GLObjects::render(GLCamera& camera) {
	glPushMatrix();
	glMultMatrixf(getTransform());
  GLObject* obj = getFirstObject();
  while(obj) {
    if((!obj->isClipped()) && obj->isVisible())
      obj->render(camera);
    obj = getNextObject();
  }
	glPopMatrix();
}

//
// GLLod
//

GLLod::GLLod() {}

void GLLod::castShadow(
  int mode, M3Vector& d, GLShadowedDelegate& sd, M3Matrix* parentTransform
) {
  GLObject* obj = NULL;
  for(int ct = 0; ct < levels.getSize(); ct++) {
    if(getDistance() < dists.getElement(ct)) {
      obj = levels.getElement(ct);
      break;
    }
  }
  if(obj) {
    glPushMatrix();
    glMultMatrixf(getTransform());
    if(parentTransform) {
      M3Matrix groupTransform(*static_cast<M3Matrix*>(this));
      groupTransform.multiply(*parentTransform);
      obj->castShadow(mode,d,sd,&groupTransform);
    } else {
      obj->castShadow(mode,d,sd,static_cast<M3Matrix*>(this));
    }
    glPopMatrix();
  }
}

void GLLod::render(GLCamera& camera) {
	glPushMatrix();
	glMultMatrixf(getTransform());
  for(int ct = 0; ct < levels.getSize(); ct++) {
    if(getDistance() < dists.getElement(ct)) {
      levels.getElement(ct)->render(camera);
      break;
    }
  }
	glPopMatrix();
}
