#ifndef GLMATERIAL_H
#define GLMATERIAL_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glcolor.h"
#include "gltexture.h"
#include "glprogram.h"
#include "glshader.h"

#include "datamanager.h"

#include <typeinfo> // for typeid()

//
// GLBasicMaterial
//
class GLBasicMaterial: public DMReference {
protected:
  bool enlighted;
  GLColor ambient;
  GLColor diffuse;
  GLColor specular;
  GLColor emissive;
  float shininess;
  GLTexture* diffuseTexture;
public:
  GLBasicMaterial* acquireReference()
    {return dynamic_cast<GLBasicMaterial*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLBasicMaterial();
  void setEnlighted(bool e) {enlighted = e;}
  bool isEnlighted() {return enlighted;}
  void setAmbient(float r, float g, float b, float a = 1)
    {ambient.set(r,g,b,a);}
  void setDiffuse(float r, float g, float b, float a = 1)
    {diffuse.set(r,g,b,a);}
  void setSpecular(float r, float g, float b, float a = 1)
    {specular.set(r,g,b,a);}
  void setEmissive(float r, float g, float b, float a = 1)
    {emissive.set(r,g,b,a);}
  void setShininess(float s) {shininess = s;}
  GLColor& getAmbient() {return ambient;}
  GLColor& getDiffuse() {return diffuse;}
  GLColor& getSpecular() {return specular;}
  GLColor& getEmissive() {return emissive;}
  float getShininess() {return shininess;}
  void setTransparency(float a) {
    ambient.setAlpha(a); diffuse.setAlpha(a);
    specular.setAlpha(a); emissive.setAlpha(a);
  }
  bool hasDiffuse() {return diffuseTexture != NULL;}
  GLTexture* getDiffuseTexture() {return diffuseTexture;}
  void setDiffuseTexture(GLTexture* txt) {
    if(diffuseTexture) diffuseTexture->releaseReference();
    diffuseTexture = (txt? txt->acquireReference(): NULL);
  }
  void applyColor();
  void unapplyColor() {if(!isEnlighted()) glEnable(GL_LIGHTING);}
  void applyDiffuse() {diffuseTexture->apply();}
  virtual void apply() {
    applyColor(); glDisable(GL_TEXTURE_2D);
    if(hasDiffuse())
      {glEnable(getDiffuseTexture()->getTextureDim()); applyDiffuse();}
  }
  virtual void unapply() {unapplyColor(); glEnable(GL_TEXTURE_2D);}
};

//
// GLMaterial
//
class GLMaterial: public GLBasicMaterial {
protected:
  float environment;
  GLTexture* glossTexture;
  GLTexture* environmentTexture;
public:
  GLMaterial* acquireReference()
    {return dynamic_cast<GLMaterial*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLMaterial();
  bool hasGloss() {return glossTexture != NULL;}
  GLTexture* getGlossTexture() {return glossTexture;}
  void setGlossTexture(GLTexture* txt) {
    if(glossTexture) glossTexture->releaseReference();
    glossTexture = (txt? txt->acquireReference(): NULL);
  }
  bool hasEnvironment() {return environmentTexture && environment > 0;}
  bool isEnvironmentCubeMapped()
    {return typeid(*environmentTexture) == typeid(GLCubeMapTexture);}
  bool isEnvironmentSphereMapped() {return !isEnvironmentCubeMapped();}
  void setEnvironment(float env) {environment = env;}
  GLTexture* getEnvironmentTexture() {return environmentTexture;}
  void setEnvironmentTexture(GLTexture* txt, float env = 1.0f) {
    environment = env;
    if(environmentTexture) environmentTexture->releaseReference();
    environmentTexture = (txt? txt->acquireReference(): NULL);
  }
  void applyGloss() {glossTexture->apply();}
  void enableEnvironment(GLCamera& camera);
  void disableEnvironment();
};

#ifdef USE_EMBOSS

//
// GLBumpedMaterial
//
class GLBumpedMaterial: public GLMaterial {
private:
  float bump;
  GLBumpedTexture* bumpedTexture;
public:
  GLBumpedMaterial* acquireReference()
    {return dynamic_cast<GLBumpedMaterial*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLBumpedMaterial();
  void setBump(float b) {bump = b;}
  float getBump() {return bump;}
  bool hasBump() {return bumpedTexture && bump != 0;}
  void setBumpedTexture(GLBumpedTexture* txt, float bmp = 0.1f) {
    bump = bmp;
    if(bumpedTexture) bumpedTexture->releaseReference();
    bumpedTexture = (txt? txt->acquireReference(): NULL);
  }
  void applyBumpDirect() {bumpedTexture->applyDirect();}
  void applyBumpInverse() {bumpedTexture->applyInverse();}
};

#endif // USE_EMBOSS

//
// GLProgramMaterial
//
class GLProgramMaterial: public GLMaterial {
protected:
  GLVertexProgram* vertexProgram;
  GLFragmentProgram* fragmentProgram;
  DSArray<GLTexture,false> textures;
public:
  GLProgramMaterial* acquireReference()
    {return dynamic_cast<GLProgramMaterial*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLProgramMaterial(GLVertexProgram* vp = NULL, GLFragmentProgram* fp = NULL);
  GLVertexProgram* getVertexProgram() {return vertexProgram;}
  GLFragmentProgram* getFragmentProgram() {return fragmentProgram;}
  void addTexture(GLTexture* t) {textures.addElement(t->acquireReference());}
  void setVertexProgram(GLVertexProgram* vp) {
    if(vertexProgram) vertexProgram->releaseReference();
    if(vp) vp->acquireReference();
    vertexProgram = vp;
  }
  void setFragmentProgram(GLFragmentProgram* fp) {
    if(fragmentProgram) fragmentProgram->releaseReference();
    if(fp) fp->acquireReference();
    fragmentProgram = fp;
  }
  virtual void apply();
  virtual void unapply();
};

//
// GLShaderMaterial
//
class GLShaderMaterial: public GLMaterial {
protected:
  GLShaderProgram* shaderProgram;
  DSArray<GLTexture,false> textures;
public:
  GLShaderMaterial* acquireReference()
    {return dynamic_cast<GLShaderMaterial*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
public:
  GLShaderMaterial(GLShaderProgram* sp = NULL);
  GLShaderProgram* getShader() {return shaderProgram;}
  void addTexture(GLTexture* t) {textures.addElement(t->acquireReference());}
  void setShader(GLShaderProgram* sp) {
    if(shaderProgram) shaderProgram->releaseReference();
    if(sp) sp->acquireReference();
    shaderProgram = sp;
  }
  virtual void apply();
  virtual void unapply();
};

//
// GLBasicMaterialOwner
//
class GLBasicMaterialOwner {
protected:
  GLBasicMaterial* material;
public:
  GLBasicMaterialOwner(GLBasicMaterial* mat = NULL);
  ~GLBasicMaterialOwner();
  GLBasicMaterial* getBasicMaterial() {return material;}
  GLMaterial* getMaterial() {return dynamic_cast<GLMaterial*>(material);}
#ifdef USE_EMBOSS
  GLBumpedMaterial* getBumpedMaterial()
    {return dynamic_cast<GLBumpedMaterial*>(material);}
#endif // USE_EMBOSS
  GLShaderMaterial* getShaderMaterial()
    {return dynamic_cast<GLShaderMaterial*>(material);}
  GLProgramMaterial* getProgramMaterial()
    {return dynamic_cast<GLProgramMaterial*>(material);}
  void setBasicMaterial(GLBasicMaterial* mat) {
    if(mat == NULL) return;
    if(material) material->releaseReference();
    material = mat->acquireReference();
  }
  void setMaterial(GLMaterial* mat) {setBasicMaterial(mat);}
#ifdef USE_EMBOSS
  void setBumpedMaterial(GLBumpedMaterial* mat) {setBasicMaterial(mat);}
#endif // USE_EMBOSS
  void setShaderMaterial(GLShaderMaterial* mat) {setBasicMaterial(mat);}
  void setProgramMaterial(GLProgramMaterial* mat) {setBasicMaterial(mat);}
};

#endif // GLMATERIAL_H

