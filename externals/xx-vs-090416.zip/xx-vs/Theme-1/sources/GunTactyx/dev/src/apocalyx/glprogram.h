#ifndef GLPROGRAM_H
#define GLPROGRAM_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "glextensions.h"

#include "dataread.h"
#include "datamanager.h"

#ifdef USE_OGLES
#else // !USE_OGLES

//
// GLProgram
//
class GLProgram: public DMReference {
protected:
  unsigned int target;
  unsigned int programID;
public:
  unsigned int getID() {return programID;}
  bool isValid() {return getID() > 0;}
  void setLocalParameter(int idx, float x, float y, float z, float w)
    {glProgramLocalParameter4fARB(target,idx,x,y,z,w);}
  void setEnvParameter(int idx, float x, float y, float z, float w)
    {glProgramEnvParameter4fARB(target,idx,x,y,z,w);}
  void enable() {glEnable(target);}
  void disable() {glDisable(target);}
  void gen() {glGenProgramsARB(1,&programID);}
  void apply() {glBindProgramARB(target,programID);}
  void unapply() {glBindProgramARB(target,0);}
protected:
  void init() {enable(); gen(); apply();}
  void load(const char* asciiProgram) {
    glProgramStringARB(
      target,GL_PROGRAM_FORMAT_ASCII_ARB,strlen(asciiProgram),asciiProgram
    );
  }
  void load(DRData* data) {
    glProgramStringARB(
      target,GL_PROGRAM_FORMAT_ASCII_ARB,data->getSize(),data->getBuffer()
    );
  }
  virtual void destroyObject();
protected:
  GLProgram(const char* asciiProgram, int iTarget);
  GLProgram(DRData* data, int iTarget);
  virtual GLProgram* acquireReference()
    {return dynamic_cast<GLProgram*>(DMReference::acquireReference());}
};

//
// GLVertexProgram
//
class GLVertexProgram: public GLProgram {
public:
  static bool isSupported() {return IS_VERTEX_PROGRAM_SUPPORTED;}
  GLVertexProgram(const char* asciiProgram);
  GLVertexProgram(DRData* data);
  virtual GLVertexProgram* acquireReference()
    {return dynamic_cast<GLVertexProgram*>(GLProgram::acquireReference());}
};

//
// GLFragmentProgram
//
class GLFragmentProgram: public GLProgram {
public:
  static bool isSupported() {return IS_FRAGMENT_PROGRAM_SUPPORTED;}
  GLFragmentProgram(const char* asciiProgram);
  GLFragmentProgram(DRData* data);
  virtual GLFragmentProgram* acquireReference()
    {return dynamic_cast<GLFragmentProgram*>(GLProgram::acquireReference());}
};

#endif // !USE_OGLES

#endif // GLPROGRAM_H
