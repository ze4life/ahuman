/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "gtengine.h"

#include "gtsim.h"

//
// Small AI Library
//

// setVariable(int:variable,float:value);
static cell AMX_NATIVE_CALL setVariable(AMX *amx, cell *param) {amx;param;
  float p = SLInterpreter::cell2Float(param[2]);
  switch(param[1]) {
  case I_BOT_MEMORY_SIZE: GTBotBrain::MEMORY_SIZE = int(p); break;
  case I_BOT_CPU_FREQUENCY: GTBotBrain::CPU_FREQUENCY = int(p); break;
  case I_SIMULATION_TIME_STEP: GTBotBrain::SIMULATION_TIME_STEP = p; break;
  case I_POWERUP_MEDIKIT_VALUE_INIT: GTPowerup::MEDIKIT_VALUE_INIT = p; break;
  case I_POWERUP_FOOD_VALUE_INIT: GTPowerup::FOOD_VALUE_INIT = p; break;
  case I_POWERUP_ARMOR_VALUE_INIT: GTPowerup::ARMOR_VALUE_INIT = p; break;
  case I_POWERUP_BULLETS_VALUE_INIT: GTPowerup::BULLETS_VALUE_INIT = p; break;
  case I_POWERUP_GRENADES_VALUE_INIT: GTPowerup::GRENADES_VALUE_INIT = p; break;
  case I_POWERUP_MEDIKIT_RESPAWN_TIME: GTPowerup::MEDIKIT_RESPAWN_TIME = p; break;
  case I_POWERUP_FOOD_RESPAWN_TIME: GTPowerup::FOOD_RESPAWN_TIME = p; break;
  case I_POWERUP_ARMOR_RESPAWN_TIME: GTPowerup::ARMOR_RESPAWN_TIME = p; break;
  case I_POWERUP_BULLETS_RESPAWN_TIME: GTPowerup::BULLETS_RESPAWN_TIME = p; break;
  case I_POWERUP_GRENADES_RESPAWN_TIME: GTPowerup::GRENADES_RESPAWN_TIME = p; break;
  case I_BOT_SIZE_X: GTBot::SIZE_X = p*BSP_SCENE_SCALE*0.5f; break;
  case I_BOT_SIZE_Y: GTBot::SIZE_Y = p*BSP_SCENE_SCALE*0.5f; break;
  case I_BOT_SIZE_Y_CROUCHED: GTBot::SIZE_Y_CROUCHED = p*BSP_SCENE_SCALE*0.5f; break;
  case I_BOT_SIZE_Z: GTBot::SIZE_Z = p*BSP_SCENE_SCALE*0.5f; break;
  case I_BOT_SPACING: GTBot::SPACING = p*BSP_SCENE_SCALE; break;
  case I_BOT_TIME_LOST_TO_SIGHT: GTBot::TIME_LOST_TO_SIGHT = p; break;
  case I_BOT_TIME_LOST_TO_AIM: GTBot::TIME_LOST_TO_AIM = p; break;
  case I_BOT_TIME_LOST_TO_HEAR: GTBot::TIME_LOST_TO_HEAR = p; break;
  case I_BOT_TIME_LOST_TO_WATCH: GTBot::TIME_LOST_TO_WATCH = p; break;
  case I_BOT_TIME_LOST_TO_LISTEN: GTBot::TIME_LOST_TO_LISTEN = p; break;
  case I_BOT_TIME_NEEDED_TO_SAY: GTBot::TIME_NEEDED_TO_SAY = p; break;
  case I_BOT_TIME_NEEDED_TO_SPEAK: GTBot::TIME_NEEDED_TO_SPEAK = p; break;
  case I_BOT_TIME_NEEDED_TO_MOVE: GTBot::TIME_NEEDED_TO_MOVE = p; break;
  case I_BOT_TIME_NEEDED_TO_DROP: GTBot::TIME_NEEDED_TO_DROP = p; break;
  case I_BOT_TIME_NEEDED_TO_SHOOT: GTBot::TIME_NEEDED_TO_SHOOT = p; break;
  case I_BOT_KICK_SPEED_MAX: GTBot::KICK_SPEED_MAX = p; break;
  case I_BOT_SPEED_VERTICAL_MAX: GTBot::SPEED_VERTICAL_MAX = p; break;
  case I_BOT_SPEED_ROTATION: GTBot::SPEED_ROTATION = p; break;
  case I_BOT_SPEED_WALKCR: GTBot::SPEED_WALKCR = p; break;
  case I_BOT_SPEED_WALKBK: GTBot::SPEED_WALKBK = p; break;
  case I_BOT_SPEED_WALK: GTBot::SPEED_WALK = p; break;
  case I_BOT_SPEED_RUN: GTBot::SPEED_RUN = p; break;
  case I_BOT_ENERGY_MAX: GTBot::ENERGY_MAX = p; break;
  case I_BOT_ENERGY_INIT: GTBot::ENERGY_INIT = p; break;
  case I_BOT_ENERGY_RUN: GTBot::ENERGY_RUN = p; break;
  case I_BOT_ENERGY_STAND: GTBot::ENERGY_STAND = p; break;
  case I_BOT_ENERGY_DROP_MAX: GTBot::ENERGY_DROP_MAX = p; break;
  case I_BOT_HEALTH_MAX: GTBot::HEALTH_MAX = p; break;
  case I_BOT_HEALTH_INIT: GTBot::HEALTH_INIT = p; break;
  case I_BOT_HEALTH_BULLET: GTBot::HEALTH_BULLET = p; break;
  case I_BOT_HEALTH_GRENADE_MAX: GTBot::HEALTH_GRENADE_MAX = p; break;
  case I_BOT_HEALTH_DROP_MAX: GTBot::HEALTH_DROP_MAX = p; break;
  case I_BOT_ARMOR_MAX: GTBot::ARMOR_MAX = p; break;
  case I_BOT_ARMOR_INIT: GTBot::ARMOR_INIT = p; break;
  case I_BOT_ARMOR_DROP_MAX: GTBot::ARMOR_DROP_MAX = p; break;
  case I_BOT_TORSO_YAW_MAX: GTBot::TORSO_YAW_MAX = p; break;
  case I_BOT_TORSO_YAW_MIN: GTBot::TORSO_YAW_MIN = p; break;
  case I_BOT_TORSO_PITCH_MAX: GTBot::TORSO_PITCH_MAX = p; break;
  case I_BOT_TORSO_PITCH_MIN: GTBot::TORSO_PITCH_MIN = p; break;
  case I_BOT_TORSO_SPEED_ROT: GTBot::TORSO_SPEED_ROT = p; break;
  case I_BOT_HEAD_YAW_MAX: GTBot::HEAD_YAW_MAX = p; break;
  case I_BOT_HEAD_YAW_MIN: GTBot::HEAD_YAW_MIN = p; break;
  case I_BOT_HEAD_PITCH_MAX: GTBot::HEAD_PITCH_MAX = p; break;
  case I_BOT_HEAD_PITCH_MIN: GTBot::HEAD_PITCH_MIN = p; break;
  case I_BOT_HEAD_SPEED_ROT: GTBot::HEAD_SPEED_ROT = p; break;
  case I_BOT_HEAD_ANGLE_OF_VIEW:
    GTBot::HEAD_ANGLE_OF_VIEW = p;
    GTBot::HEAD_COS_ANGLE_OF_VIEW = (float)cos(p);
    break;
  case I_BOT_SENSORS_DISTANCE_MAX:
    GTBot::SENSORS_DISTANCE_MAX = p*BSP_SCENE_SCALE; break;
  case I_WEAPON_LENGTH: GTWeapon::LENGTH = p*BSP_SCENE_SCALE; break;
  case I_WEAPON_HEIGHT: GTWeapon::HEIGHT = p*BSP_SCENE_SCALE; break;
  case I_WEAPON_BULLET_SPEED: GTWeapon::BULLET_SPEED = p; break;
  case I_WEAPON_BULLET_LOAD_MAX: GTWeapon::BULLET_LOAD_MAX = p; break;
  case I_WEAPON_BULLET_LOAD_INIT: GTWeapon::BULLET_LOAD_INIT = p; break;
  case I_WEAPON_BULLET_DROP_MAX: GTWeapon::BULLET_DROP_MAX = p; break;
  case I_WEAPON_GRENADE_SPEED: GTWeapon::GRENADE_SPEED = p; break;
  case I_WEAPON_GRENADE_EXPL_DELAY: GTWeapon::GRENADE_EXPL_DELAY = p; break;
  case I_WEAPON_GRENADE_EXPL_DURATION: GTWeapon::GRENADE_EXPL_DURATION = p; break;
  case I_WEAPON_GRENADE_RANGE_MAX: GTWeapon::GRENADE_RANGE_MAX = p; break;
  case I_WEAPON_GRENADE_LOAD_MAX: GTWeapon::GRENADE_LOAD_MAX = p; break;
  case I_WEAPON_GRENADE_LOAD_INIT: GTWeapon::GRENADE_LOAD_INIT = p; break;
  case I_WEAPON_GRENADE_DROP_MAX: GTWeapon::GRENADE_DROP_MAX = p; break;
  case I_WORLD_GRAVITY: GTArena::WORLD_GRAVITY = p; break;
  case I_ARENA_SIZE: GTArena::ARENA_SIZE = p*BSP_SCENE_SCALE; break;
  case I_GOAL_SIZE: GTArena::GOAL_SIZE = p; break;
  case I_TARGET_SIZE: GTTarget::SIZE = p; break;
  case I_TARGET_MAX_SPEED: GTTarget::MAX_SPEED = p; break;
  case I_GROUND_RESTITUTION: GTArena::GROUND_RESTITUTION = p; break;
  }
}

// float:getVariable(int:variable);

static cell AMX_NATIVE_CALL getVariable(AMX *amx, cell *param) {amx;param;
  switch(param[1]) {
  case I_BOT_MEMORY_SIZE: return SLInterpreter::float2Cell(GTBotBrain::MEMORY_SIZE);
  case I_BOT_CPU_FREQUENCY: return SLInterpreter::float2Cell(GTBotBrain::CPU_FREQUENCY);
  case I_SIMULATION_TIME_STEP: return SLInterpreter::float2Cell(GTBotBrain::SIMULATION_TIME_STEP);
  case I_POWERUP_MEDIKIT_VALUE_INIT: return SLInterpreter::float2Cell(GTPowerup::MEDIKIT_VALUE_INIT);
  case I_POWERUP_FOOD_VALUE_INIT: return SLInterpreter::float2Cell(GTPowerup::FOOD_VALUE_INIT);
  case I_POWERUP_ARMOR_VALUE_INIT: return SLInterpreter::float2Cell(GTPowerup::ARMOR_VALUE_INIT);
  case I_POWERUP_BULLETS_VALUE_INIT: return SLInterpreter::float2Cell(GTPowerup::BULLETS_VALUE_INIT);
  case I_POWERUP_GRENADES_VALUE_INIT: return SLInterpreter::float2Cell(GTPowerup::GRENADES_VALUE_INIT);
  case I_POWERUP_MEDIKIT_RESPAWN_TIME: return SLInterpreter::float2Cell(GTPowerup::MEDIKIT_RESPAWN_TIME);
  case I_POWERUP_FOOD_RESPAWN_TIME: return SLInterpreter::float2Cell(GTPowerup::FOOD_RESPAWN_TIME);
  case I_POWERUP_ARMOR_RESPAWN_TIME: return SLInterpreter::float2Cell(GTPowerup::ARMOR_RESPAWN_TIME);
  case I_POWERUP_BULLETS_RESPAWN_TIME: return SLInterpreter::float2Cell(GTPowerup::BULLETS_RESPAWN_TIME);
  case I_POWERUP_GRENADES_RESPAWN_TIME: return SLInterpreter::float2Cell(GTPowerup::GRENADES_RESPAWN_TIME);
  case I_BOT_SIZE_X: return SLInterpreter::float2Cell(2*GTBot::SIZE_X*BSP_SCENE_SCALE_INV);
  case I_BOT_SIZE_Y: return SLInterpreter::float2Cell(2*GTBot::SIZE_Y*BSP_SCENE_SCALE_INV);
  case I_BOT_SIZE_Y_CROUCHED: return SLInterpreter::float2Cell(2*GTBot::SIZE_Y_CROUCHED*BSP_SCENE_SCALE_INV);
  case I_BOT_SIZE_Z: return SLInterpreter::float2Cell(2*GTBot::SIZE_Z*BSP_SCENE_SCALE_INV);
  case I_BOT_SPACING: return SLInterpreter::float2Cell(GTBot::SPACING*BSP_SCENE_SCALE_INV);
  case I_BOT_TIME_LOST_TO_SIGHT: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_SIGHT);
  case I_BOT_TIME_LOST_TO_AIM: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_AIM);
  case I_BOT_TIME_LOST_TO_HEAR: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_HEAR);
  case I_BOT_TIME_LOST_TO_WATCH: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_WATCH);
  case I_BOT_TIME_LOST_TO_LISTEN: return SLInterpreter::float2Cell(GTBot::TIME_LOST_TO_LISTEN);
  case I_BOT_TIME_NEEDED_TO_SAY: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SAY);
  case I_BOT_TIME_NEEDED_TO_SPEAK: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SPEAK);
  case I_BOT_TIME_NEEDED_TO_MOVE: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_MOVE);
  case I_BOT_TIME_NEEDED_TO_DROP: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_DROP);
  case I_BOT_TIME_NEEDED_TO_SHOOT: return SLInterpreter::float2Cell(GTBot::TIME_NEEDED_TO_SHOOT);
  case I_BOT_KICK_SPEED_MAX: return SLInterpreter::float2Cell(GTBot::KICK_SPEED_MAX);
  case I_BOT_SPEED_VERTICAL_MAX: return SLInterpreter::float2Cell(GTBot::SPEED_VERTICAL_MAX);
  case I_BOT_SPEED_ROTATION: return SLInterpreter::float2Cell(GTBot::SPEED_ROTATION);
  case I_BOT_SPEED_WALKCR: return SLInterpreter::float2Cell(GTBot::SPEED_WALKCR);
  case I_BOT_SPEED_WALKBK: return SLInterpreter::float2Cell(GTBot::SPEED_WALKBK);
  case I_BOT_SPEED_WALK: return SLInterpreter::float2Cell(GTBot::SPEED_WALK);
  case I_BOT_SPEED_RUN: return SLInterpreter::float2Cell(GTBot::SPEED_RUN);
  case I_BOT_ENERGY_MAX: return SLInterpreter::float2Cell(GTBot::ENERGY_MAX);
  case I_BOT_ENERGY_INIT: return SLInterpreter::float2Cell(GTBot::ENERGY_INIT);
  case I_BOT_ENERGY_RUN: return SLInterpreter::float2Cell(GTBot::ENERGY_RUN);
  case I_BOT_ENERGY_STAND: return SLInterpreter::float2Cell(GTBot::ENERGY_STAND);
  case I_BOT_ENERGY_DROP_MAX: return SLInterpreter::float2Cell(GTBot::ENERGY_DROP_MAX);
  case I_BOT_HEALTH_MAX: return SLInterpreter::float2Cell(GTBot::HEALTH_MAX);
  case I_BOT_HEALTH_INIT: return SLInterpreter::float2Cell(GTBot::HEALTH_INIT);
  case I_BOT_HEALTH_BULLET: return SLInterpreter::float2Cell(GTBot::HEALTH_BULLET);
  case I_BOT_HEALTH_GRENADE_MAX: return SLInterpreter::float2Cell(GTBot::HEALTH_GRENADE_MAX);
  case I_BOT_HEALTH_DROP_MAX: return SLInterpreter::float2Cell(GTBot::HEALTH_DROP_MAX);
  case I_BOT_ARMOR_MAX: return SLInterpreter::float2Cell(GTBot::ARMOR_MAX);
  case I_BOT_ARMOR_INIT: return SLInterpreter::float2Cell(GTBot::ARMOR_INIT);
  case I_BOT_ARMOR_DROP_MAX: return SLInterpreter::float2Cell(GTBot::ARMOR_DROP_MAX);
  case I_BOT_TORSO_YAW_MAX: return SLInterpreter::float2Cell(GTBot::TORSO_YAW_MAX);
  case I_BOT_TORSO_YAW_MIN: return SLInterpreter::float2Cell(GTBot::TORSO_YAW_MIN);
  case I_BOT_TORSO_PITCH_MAX: return SLInterpreter::float2Cell(GTBot::TORSO_PITCH_MAX);
  case I_BOT_TORSO_PITCH_MIN: return SLInterpreter::float2Cell(GTBot::TORSO_PITCH_MIN);
  case I_BOT_TORSO_SPEED_ROT: return SLInterpreter::float2Cell(GTBot::TORSO_SPEED_ROT);
  case I_BOT_HEAD_YAW_MAX: return SLInterpreter::float2Cell(GTBot::HEAD_YAW_MAX);
  case I_BOT_HEAD_YAW_MIN: return SLInterpreter::float2Cell(GTBot::HEAD_YAW_MIN);
  case I_BOT_HEAD_PITCH_MAX: return SLInterpreter::float2Cell(GTBot::HEAD_PITCH_MAX);
  case I_BOT_HEAD_PITCH_MIN: return SLInterpreter::float2Cell(GTBot::HEAD_PITCH_MIN);
  case I_BOT_HEAD_SPEED_ROT: return SLInterpreter::float2Cell(GTBot::HEAD_SPEED_ROT);
  case I_BOT_HEAD_ANGLE_OF_VIEW: return SLInterpreter::float2Cell(GTBot::HEAD_ANGLE_OF_VIEW);
  case I_BOT_SENSORS_DISTANCE_MAX: return SLInterpreter::float2Cell(GTBot::SENSORS_DISTANCE_MAX*BSP_SCENE_SCALE_INV);
  case I_WEAPON_LENGTH: return SLInterpreter::float2Cell(GTWeapon::LENGTH*BSP_SCENE_SCALE_INV);
  case I_WEAPON_HEIGHT: return SLInterpreter::float2Cell(GTWeapon::HEIGHT*BSP_SCENE_SCALE_INV);
  case I_WEAPON_BULLET_SPEED: return SLInterpreter::float2Cell(GTWeapon::BULLET_SPEED);
  case I_WEAPON_BULLET_LOAD_MAX: return SLInterpreter::float2Cell(GTWeapon::BULLET_LOAD_MAX);
  case I_WEAPON_BULLET_LOAD_INIT: return SLInterpreter::float2Cell(GTWeapon::BULLET_LOAD_INIT);
  case I_WEAPON_BULLET_DROP_MAX: return SLInterpreter::float2Cell(GTWeapon::BULLET_DROP_MAX);
  case I_WEAPON_GRENADE_SPEED: return SLInterpreter::float2Cell(GTWeapon::GRENADE_SPEED);
  case I_WEAPON_GRENADE_EXPL_DELAY: return SLInterpreter::float2Cell(GTWeapon::GRENADE_EXPL_DELAY);
  case I_WEAPON_GRENADE_EXPL_DURATION: return SLInterpreter::float2Cell(GTWeapon::GRENADE_EXPL_DURATION);
  case I_WEAPON_GRENADE_RANGE_MAX: return SLInterpreter::float2Cell(GTWeapon::GRENADE_RANGE_MAX);
  case I_WEAPON_GRENADE_LOAD_MAX: return SLInterpreter::float2Cell(GTWeapon::GRENADE_LOAD_MAX);
  case I_WEAPON_GRENADE_LOAD_INIT: return SLInterpreter::float2Cell(GTWeapon::GRENADE_LOAD_INIT);
  case I_WEAPON_GRENADE_DROP_MAX: return SLInterpreter::float2Cell(GTWeapon::GRENADE_DROP_MAX);
  case I_WORLD_GRAVITY: return SLInterpreter::float2Cell(GTArena::WORLD_GRAVITY);
  case I_ARENA_SIZE: return SLInterpreter::float2Cell(GTArena::ARENA_SIZE*BSP_SCENE_SCALE_INV);
  case I_GOAL_SIZE: return SLInterpreter::float2Cell(GTArena::GOAL_SIZE);
  case I_TARGET_SIZE: return SLInterpreter::float2Cell(GTTarget::SIZE);
  case I_TARGET_MAX_SPEED: return SLInterpreter::float2Cell(GTTarget::MAX_SPEED);
  case I_GROUND_RESTITUTION: return SLInterpreter::float2Cell(GTArena::GROUND_RESTITUTION);
  }
}

// natives
#define FUNC(NAME) {#NAME,NAME}
AMX_NATIVE_INFO engineNatives[] = {
  FUNC(getVariable),
  FUNC(setVariable),
  {0,0}
};

//
// GTEngineScript
//
GTEngineScript::GTEngineScript(): timerCountdown(0) {
  setCPUFrequency(ENGINE_CPU_FREQUENCY_INIT);
}

bool GTEngineScript::load(char* scriptName) {
  char* newName = NULL;
  if(!strstr(scriptName,".amx")) {
    newName = new char[5+strlen(scriptName)+5];
    strcat(strcat(strcpy(newName,"engine\\"),scriptName),".amx");
    scriptName = newName;
  }
  SLInterpreter::load(scriptName);
  if(newName)
    delete newName;
  if(isLoaded() && registerNatives(engineNatives)) {
    initMain();
    return isRunning();
  }
  return false;
}

