#ifndef INITDLG_H
#define INITDLG_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#define IDC_Fullscreen 107
#define IDC_Windowed   108
#define IDC_VSyncOn	   109
#define IDC_VSyncOff	 110
#define IDC_Logo	111
#define IDC_32depth	113
#define IDC_ScreenSize	117
#define IDC_8stencil	102
#define IDC_0stencil	101
#define IDC_24depth	115
#define IDC_16depth	114
#define IDC_DontShow 118

#endif // INITDLG_H
