#ifndef GLFONT_H
#define GLFONT_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "opengl.h"
#include "gltexture.h"
#include "glmaterial.h"

//
// GLFont
//
class GLFont: public DMReference {
#ifdef USE_OGLES
#else // !USE_OGLES
private:
  unsigned int listBase;
public:
  unsigned int getListBase() {return listBase;}
  static int getListLength() {return 256;}
#endif // ! USE_OGLES
private:
  int height;
  int width;
  int spacing;
protected:
  virtual void destroyObject();
public:
  GLFont(int h, int w = 0, int s = 0);
  virtual ~GLFont();
  void setHeight(int value) {height = value;}
  void setWidth(int value) {width = value;}
  void setSpacing(int spac) {spacing = spac;}
  int getHeight() {return height;}
  int getWidth() {return width;}
  int getSpacing() {return spacing;}
  void setColor(float r, float g, float b) {
#ifdef USE_OGLES
    glColor4f(r,g,b,1);
#else // !USE_OGLES
    glColor3f(r,g,b);
#endif // ! USE_OGLES
  }
  void setColor(float r, float g, float b, float a) {glColor4f(r,g,b,a);}
  virtual void initialize() {
#ifdef USE_OGLES
#else // !USE_OGLES
    glListBase(getListBase());
#endif // ! USE_OGLES
  }
#ifdef USE_OGLES
  virtual void drawText(int length, const char* text) = 0;
#else // !USE_OGLES
  void drawText(int length, const char* text)
    {glCallLists(length,GL_UNSIGNED_BYTE,text);}
#endif // ! USE_OGLES
  void drawText(float x, float y, int length, const char* text)
    {setPosition(x,y); drawText(length,text);}
  void drawText(float x, float y, float z, int length, const char* text)
    {setPosition(x,y,z); drawText(length,text);}
  virtual void setPosition(float x, float y, float z = 0) = 0;
  virtual bool isTextured() = 0;
  virtual GLFont* acquireReference()
    {return dynamic_cast<GLFont*>(DMReference::acquireReference());}
};

//
// GLTexturedFont
//
class GLTexturedFont: public GLFont {
#ifdef USE_OGLES
public:
  virtual void drawText(int length, const char* text);
#else // USE_OGLES
private:
  int listOffset;
public:
  void initialize() {glListBase(getListBase()-listOffset);}
#endif // !USE_OGLES
private:
  GLTexture* texture;
public:
  GLTexturedFont(int h, int w, int spac, GLTexture* txt);
  ~GLTexturedFont();
  void applyTexture() {texture->apply();}
  void setPosition(float x, float y, float z = 0)
    {glLoadIdentity(); glTranslatef(x,y,z);}
  bool isTextured() {return true;}
  virtual GLTexturedFont* acquireReference()
    {return dynamic_cast<GLTexturedFont*>(DMReference::acquireReference());}
};

#if !defined(USE_GLFW) && !defined(USE_OGLES)

//
// GLBitmapFont
//
class GLBitmapFont: public GLFont {
public:
  GLBitmapFont(
    HDC hDC, const char* face, int height, int width = 0,
    int weight = FW_NORMAL, bool italic = false
  );
  void setPosition(float x, float y, float z = 0) {glRasterPos3f(x,y,z);}
  bool isTextured() {return false;}
  virtual GLBitmapFont* acquireReference()
    {return dynamic_cast<GLBitmapFont*>(DMReference::acquireReference());}
};

//
// GLOutlineFont
//
class GLOutlineFont: public GLFont {
private:
  GLYPHMETRICSFLOAT glyphMetricsFloat[256];
public:
  GLOutlineFont(
    HDC hDC, const char* face, int h, int w = 0, float depth = 0.0f,
    int weight = FW_NORMAL, bool italic = false
  );
  float getBoxWidth(char c) {return glyphMetricsFloat[c].gmfBlackBoxX;}
  float getBoxHeight(char c) {return glyphMetricsFloat[c].gmfBlackBoxY;}
  float getCellWidth(char c) {return glyphMetricsFloat[c].gmfCellIncX;}
  float getCellHeight(char c) {return glyphMetricsFloat[c].gmfCellIncY;}
  void setPosition(float x, float y, float z = 0) {glTranslatef(x,y,z);}
  bool isTextured() {return false;}
  virtual GLOutlineFont* acquireReference()
    {return dynamic_cast<GLOutlineFont*>(DMReference::acquireReference());}
};

//
// GLText
//
class GLText: public GLObject, public GLBasicMaterialOwner {
private:
  GLOutlineFont* font;
  const char* text;
  float textWidth;
protected:
  void computeMaxRadius();
public:
  GLText(const char* t, GLOutlineFont* f, GLBasicMaterial* m = NULL);
  ~GLText();
  const char* getText() {return text;}
  void setText(char* txt) {text = txt; computeMaxRadius();}
  float getTextWidth() {return textWidth;}
  void render(GLCamera& camera);
};

//
// GLParagraph
//
class GLParagraph: public GLObjects {
public:
  void addText(GLText* txt) {addObject(txt);}
};

#endif // !USE_GLFW && !USE_OGLES

#endif // GLFONT_H
