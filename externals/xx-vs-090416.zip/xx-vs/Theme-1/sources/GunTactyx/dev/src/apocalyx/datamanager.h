#ifndef DATAMANAGER_H
#define DATAMANAGER_H

/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "void.h"

//#define CHECK_MEMORY_LEAKS

#ifdef CHECK_MEMORY_LEAKS
#include <fstream.h>
#include <typeinfo.h>
#endif

//
// DMReference
//
class DMReference: virtual public Void {
private:
  int referencesCount;
protected:
  DMReference();
  virtual void destroyObject() = 0;
public:
#ifdef CHECK_MEMORY_LEAKS
  static ofstream CHECK_LEAKS;
#endif
  DMReference* acquireReference() {
    referencesCount++;
#ifdef CHECK_MEMORY_LEAKS
    CHECK_LEAKS
      << "\n" << int(this)
      << "\t[+] " << referencesCount
      << "\t" << typeid(*this).name();
#endif
    return this;
  }
  bool releaseReference() {
    referencesCount--;
#ifdef CHECK_MEMORY_LEAKS
    CHECK_LEAKS
      << "\n" << int(this)
      << "\t[-] " << referencesCount
      << "\t" << typeid(*this).name();
#endif
    if(referencesCount == 0) {
      destroyObject();
      return true;
    }
    return false;
  }
};

//
// DMCache
//
class DMCache: public DMReference {
private:
  char* data;
  int size;
public:
  DMCache* acquireReference()
    {return dynamic_cast<DMCache*>(DMReference::acquireReference());}
protected:
  virtual void destroyObject();
  void resize(int siz, bool copy = false);
public:
  DMCache(int siz = 1024);
  void checkSize(int siz, bool copy = false) {if(size < siz) resize(siz,copy);}
  char* getDataPointer() {return data;}
};

#endif // DATAMANAGER_H
