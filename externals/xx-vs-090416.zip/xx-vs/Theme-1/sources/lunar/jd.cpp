#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "watdefs.h"
#include "date.h"

/* At one point,  I had the months shown by name,  not number.  This is
no longer true,  but I saw no need to chop out the month names for
those who might be interested: */

extern const char *islamic_month_names[12] = {
      "Muharram", "Safar", "Rabi'a I",
      "Rabi'a II", "Jumada I", "Jumada II",
      "Rajab", "Sha'ban", "Ramadan",
      "Shawwal", "Dhu al-Q'adah", "Dhu al-Hijjah" };

extern const char *hebrew_month_names[13] = {
      "Tishri", "Heshvan", "Kislev", "Tevet", "Shevat", "Adar",
      "Adar II", "Nisan", "Iyar", "Sivan", "Tammuz", "Av", "Elul" };

extern const char *french_month_names[12] = {
  "Vend�miaire",           "Germinal",
  "Brumaire",              "Flor�al",
  "Frimaire",              "Prairial",
  "Niv�se",                "Messidor",
  "Pluvi�se",              "Thermidor",
  "Vent�se",               "Fructidor" };

extern const char *french_extra_day_names[6] = {
        "Jour de la vertu (Virtue Day)",
        "Jour du genie (Genius Day)",
        "Jour du travail (Labour Day)",
        "Jour de l'opinion (Reason Day)",
        "Jour des recompenses (Rewards Day)",
        "Jour de la revolution (Revolution Day)" };

extern const char *day_names[7] = { "Sun", "Mon",  "Tue",  "Wed",
         "Thu",  "Fri",  "Sat" };

#define T0 1721060L

/* The Chinese calendar involves added complications for two reasons.
First,  instead of being computed algorithmically (as all the other
calendars are),  it's computed using a pre-compiled data table.  So you
have to load the file into memory,  as shown in the following code;  the
data is stored using the set_chinese_calendar_data( ) function.

   Second,  as will be seen in the main( ) code,  you have to watch out
for the intercalary months.  */

static int load_chinese_calendar_data( const char *filename)
{
   FILE *ifile = fopen( filename, "rb");
   size_t filesize;
   int rval = -1;
   static char *calendar_data = NULL;

   if( ifile)
      {
      fseek( ifile, 0L, SEEK_END);
      filesize = (size_t)ftell( ifile);
      calendar_data = (char *)malloc( filesize);
      if( calendar_data)
         {
         fseek( ifile, 0L, SEEK_SET);
         fread( calendar_data, filesize, 1, ifile);
         set_chinese_calendar_data( calendar_data);
         rval = 0;
         }
      fclose( ifile);
      }
   return( rval);
}

int main( int argc, char **argv)
{
   int hour, minute, calendar, err_code;
   int chinese_intercalary_month;
   double second;
   double jd = 0.;

   if( argc == 2)
      {
      double fraction;

      jd = atof( argv[1]) + .5;
/*    day_to_dmy( (long)jd, &day, &month, &year, 0);  */
      fraction = jd - floor( jd);
      hour = (int)( fraction * 24.);
      minute = (int)( fraction * 1440. - (double)hour * 60.);
      second = fraction * 86400. - (double)hour * 3600. - (double)minute * 60.;
      jd -= .5;
      }

   if( argc >= 4)
      {
      int day = atoi( argv[1]);
      int month = atoi( argv[2]);
      long year = atol( argv[3]);

      calendar = CALENDAR_JULIAN_GREGORIAN;
      jd = dmy_to_day( day, month, year, calendar) - .5;
      hour = 0;
      hour = minute = 0;
      second = 0.;
      }

   err_code = load_chinese_calendar_data( "chinese.dat");
   if( err_code)
      printf( "WARNING:  Chinese calendar data not loaded: %d\n", err_code);

   if( jd)
      for( calendar = 0; calendar < 9; calendar++)
         {
         int day, month;
         long year, ljd = (long)floor( jd + .5);
         long day_of_week = (ljd + 1L) % 7L;
         static const char *calendar_names[9] = {
                "Gregorian", "Julian", "Hebrew", "Islamic", "Revolutionary",
                "Persian (Jalali)", "Greg/Jul", "Chinese",  "Modern Persian" };
         char is_intercalary = ' ';

         day_to_dmy( ljd, &day, &month, &year, calendar);
         if( day_of_week < 0L)      /* this happens for negative JD */
            day_of_week += 7L;
         chinese_intercalary_month = get_chinese_intercalary_month( );
         if( calendar == CALENDAR_CHINESE && chinese_intercalary_month)
            {
            if( month == chinese_intercalary_month)
               is_intercalary = 'i';
            if( month >= chinese_intercalary_month)
               month--;
            }

         if( !calendar)
            printf( "%02d:%02d:%4.1lf %d %s %ld = JD %.5lf   %s\n",
                               hour, minute, second,
                               day, set_month_name( month, NULL), year, jd,
                               day_names[day_of_week]);
         else
            printf( "%-20s %3d%3d%c%4ld\n", calendar_names[calendar],
                        day, month, is_intercalary, year);
         }
   return( 0);
}
