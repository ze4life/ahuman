/*
  Copyright (C) 2001-2004 Leonardo Boselli

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the
    Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Please send remarks, questions and bug reports to
    boselli@uno.it
  or write to:
    Leonardo Boselli
    Via Diano Calderina, 7
    18100 Imperia
    ITALY
*/

#include "datasets.h"

//
// DSChainNode
//
DSChainNode::DSChainNode(): next(0) {
}

DSChainNode::~DSChainNode() {
}

//
// DSTwoWayChainNode
//
DSTwoWayChainNode::DSTwoWayChainNode(): prev(0), DSChainNode() {
}

//
// DSChain
//
DSChain::DSChain():
  length(0), first(0), last(0), pointer(0)
{}

DSChain::~DSChain() {
  deleteAll();
}

DSChainNode* DSChain::nextNode() {
  return pointer? pointer = pointer->getNextNode(): 0;
}

void DSChain::addNodeFirst(DSChainNode* node) {
  if(first) {
    node->setNextNode(first);
  } else {
    last = pointer = node;
  }
  first = node;
  length++;
}

void DSChain::addNodeLast(DSChainNode* node) {
  if(first) {
    last->setNextNode(node);
  } else {
    first = pointer = node;
  }
  last = node;
  length++;
}

void DSChain::insertNodeBehind(DSChainNode* node) {
  if(pointer) {
    DSChainNode* nextNode = pointer->getNextNode();
    pointer->setNextNode(node);
    node->setNextNode(nextNode);
  } else {
    node->setNextNode(first);
    first = node;
  }
  if(last == pointer) last = node;
  length++;
}

bool DSChain::deleteNode(DSChainNode* node) {
  DSChainNode* prevNode = 0;
  DSChainNode* thisNode = first;
  while(thisNode) {
    if(thisNode == node) {
      pointer = thisNode->getNextNode();
      if(!pointer) last = prevNode;
    	if(prevNode) {
      	prevNode->setNextNode(pointer);
      } else {
      	first = thisNode->getNextNode();
      }
      length--;
      delete node;
      return true;
    }
    prevNode = thisNode;
    thisNode = thisNode->getNextNode();
  }
  return false;
}

void DSChain::deleteAll() {
  while((pointer = first) != 0) {
    first = pointer->getNextNode();
    delete pointer;
  }
  last = 0;
  length = 0;
}

//
// DSTwoWayChain
//
DSTwoWayChainNode* DSTwoWayChain::prevNode() {
  if(pointer) {
    DSTwoWayChainNode* ptr = static_cast<DSTwoWayChainNode*>(pointer);
    pointer = ptr->getPrevNode();
    return( ptr->getPrevNode() );
  } else {
    return( 0 );
  }
}

void DSTwoWayChain::addNodeFirst(DSTwoWayChainNode* node) {
	DSTwoWayChainNode* next = static_cast<DSTwoWayChainNode*>( first );
	DSChain::addNodeFirst(node);
  static_cast<DSTwoWayChainNode*>(first)->setPrevNode(next);
}

void DSTwoWayChain::addNodeLast(DSTwoWayChainNode* node) {
	DSTwoWayChainNode* prev = static_cast<DSTwoWayChainNode*>(last);
	DSChain::addNodeLast(node);
  static_cast<DSTwoWayChainNode*>(last)->setPrevNode(prev);
}

void DSTwoWayChain::insertNodeBefore(DSTwoWayChainNode* node) {
	if(pointer) {
  	DSTwoWayChainNode* prevNode =
    	static_cast<DSTwoWayChainNode*>(pointer)->getPrevNode();
    if(prevNode) prevNode->setNextNode(node);
    node->setPrevNode(prevNode);
    node->setNextNode(pointer);
    static_cast<DSTwoWayChainNode*>(pointer)->setPrevNode(node);
  } else {
  	node->setPrevNode( static_cast<DSTwoWayChainNode*>(last));
    if(last) last->setNextNode(node);
    last = node;
  }
  if(first == pointer) first = node;
  length++;
}

void DSTwoWayChain::insertNodeBehind(DSTwoWayChainNode* node) {
	DSTwoWayChainNode* prev = static_cast<DSTwoWayChainNode*>(pointer);
	DSTwoWayChainNode* next =
  	static_cast<DSTwoWayChainNode*>(prev->getNextNode());
	DSChain::insertNodeBehind(node);
  node->setPrevNode(prev);
  if(next) next->setPrevNode(node);
}

bool DSTwoWayChain::deleteNode(DSTwoWayChainNode* node) {
	DSTwoWayChainNode* prev = node->getPrevNode();
	DSTwoWayChainNode* next = node->getNextNode();
	bool r = DSChain::deleteNode(node);
  if(r && next) next->setPrevNode(prev);
  return r;
}

