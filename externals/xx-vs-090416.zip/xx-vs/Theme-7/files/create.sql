use alpha
go

drop table teacher
go

create table teacher 
(
	id int PRIMARY KEY not null ,
	name varchar(30) not null
)
go

begin transaction
insert into teacher ( id , name ) values ( 1 , 'Ivanov' )
insert into teacher ( id , name ) values ( 2 , 'Petrov' )
commit transaction
go

drop table schoolclass
go

create table schoolclass
(
	code varchar(10) PRIMARY KEY not null,
	number int not null ,
	par char(1) null ,
	leading_teacher int null
)
go

begin transaction
insert into schoolclass ( code , number , par , leading_teacher ) values ( '10A' , 10 , 'A' , null )
insert into schoolclass ( code , number , par , leading_teacher ) values ( '10B' , 10 , 'B' , 1 )
commit transaction
go
	
drop table kid
go

create table kid
(
	id int primary key not null ,
	name varchar(30) not null ,
	schoolclass varchar(10) not null
)
go

begin transaction
insert into kid ( id , name , schoolclass ) values ( 1 , 'Petrov' , '10A' )
insert into kid ( id , name , schoolclass ) values ( 2 , 'Sidorov' , '10B' )
insert into kid ( id , name , schoolclass ) values ( 3 , 'Garin' , '10A' )
insert into kid ( id , name , schoolclass ) values ( 4 , 'Kireev' , '10B' )
commit transaction
go

drop table teacher_skill
go

create table teacher_skill
(
	teacher int not null ,
	skill char(2) not null ,
	inuse char(1) ,
	
	primary key ( teacher , skill )
)
go
