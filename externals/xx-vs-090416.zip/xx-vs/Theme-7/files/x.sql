use alpha
go

select * from kid 
left join schoolclass on kid.schoolclass = schoolclass.code
left outer join teacher on schoolclass.leading_teacher = teacher.id
go
