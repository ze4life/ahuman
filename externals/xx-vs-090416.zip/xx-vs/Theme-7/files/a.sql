use alpha
go

select * from x
go
