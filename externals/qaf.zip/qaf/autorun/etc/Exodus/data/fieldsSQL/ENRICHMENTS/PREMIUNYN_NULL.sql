select * from rms_owner.rtp_FXTWOBAROPTION where Premiumamount IS null AND Unwindpremiumamount is null AND ROWNUM<=1
