SELECT * FROM (SELECT systemid, version, Count(*) FROM rms_owner.commoditytwolegschedule GROUP BY systemid, version HAVING Count(*) = 2 ) WHERE ROWNUM <= 3
