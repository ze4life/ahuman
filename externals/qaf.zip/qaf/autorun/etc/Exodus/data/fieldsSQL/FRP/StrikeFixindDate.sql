SELECT * FROM  rms_owner.rtp_fxfuture  WHERE  STRIKEFIXINGDATE   iS NOT NULL AND tradetype = 'BMFDOLFuture' AND ROWNUM<=1
