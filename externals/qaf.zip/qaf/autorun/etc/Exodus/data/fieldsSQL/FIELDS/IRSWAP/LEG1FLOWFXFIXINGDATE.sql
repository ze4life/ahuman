select * from rms_owner.InterestRateSwapSchedule where LEG1FLOWFXFIXINGDATE is not null and rownum<=1
