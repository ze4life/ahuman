SELECT * FROM (SELECT systemid, version, Count(*) FROM rms_owner.commodityonelegschedule GROUP BY systemid, version HAVING Count(*) = 3 ) WHERE ROWNUM <= 3
