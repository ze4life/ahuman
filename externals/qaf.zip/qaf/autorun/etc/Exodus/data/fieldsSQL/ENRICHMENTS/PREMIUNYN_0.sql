select * from rms_owner.rtp_FXTWOBAROPTION where Premiumamount = 0 AND Unwindpremiumamount = 0 AND ROWNUM<=1
