select * from rms_owner.rtp_FXTWOBAROPTION where Premiumamount IS NOT NULL OR Unwindpremiumamount IS NOT NULL AND ROWNUM<=1
