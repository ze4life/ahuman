#!/bin/ksh
#
# $Id: deploy.sh,v 1.27 2008/06/04 08:41:35 kovyale Exp $
#

. ./common.sh
. ./env.sh

for script in $DEPLOY_SCRIPTS
do
    echo "Running $script" >&3
    ./$script >&3
    if [ $? -ne 0 ]; then
        Sendfile "$script FAILED" "log/$script.current.log"
        exit 1
    fi
done
echo $TAG > $HOME/.CURRENT_RELEASE
