#!/bin/sh

# env var
. ./env.sh

# remove old bouncers
rm monitor-*.sh
echo "Creating checkers..."
./wcd/createbatches.sh wcd/monitor.sh
echo "   done."
echo "Checking applications..."
./wcd/applybatches.sh monitor-*.sh
