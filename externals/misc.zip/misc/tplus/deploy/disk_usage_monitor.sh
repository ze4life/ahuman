#!/bin/sh
# $Id: disk_usage_monitor.sh,v 1.12 2008/10/21 11:32:50 kovyale Exp $
# 0,5,10,15,20,25,30,35,40,45,50,55 * * * * /path/to/disk_usage_monitor.sh

MAILTO="gm-e-commerce.support@db.com alexey.kovyrshin@db.com evgeny.vizgalov@db.com george.egorov@db.com nikolay.teryaev@db.com dima.scherbakov@db.com alexander.egorushkin@db.com maksud.kamarov@db.com Harald.Wendel@db.com Anton.Novikov@db.com  Viacheslav.Tsarev@db.com"

Sendmail () {
   subj=$1
   hostname=`hostname`
   shift
        (
         echo "Subject: $subj"
	 echo "From: Disk Monitor $hostname <$LOGNAME.$hostname.uk.db.com@discard.mail.db.com>"
         echo
         echo "$*"
        ) | /usr/lib/sendmail $MAILTO
}

# Linux 2.4
# df man:
#       -P, --portability
#                     use the POSIX output format
#
#df -Pk | tail +2 | grep "/export/apps/prod" | while read line

df -k | tail +2 | grep "/export/apps/prod" | while read line
do
    FILESYSTEM=`echo $line | awk {'print $6'}`
    CAPACITY=`echo $line | awk {'print $5'} | sed "s/%//"`
    AVAIL=`echo $line | awk {'print $4'}`

    if [ "$CAPACITY" -ge 90 ]; then
        Sendmail "CRITICAL: $FILESYSTEM is ${CAPACITY}% FULL!" "$line"
    elif [ "$CAPACITY" -ge 80 ]; then
        Sendmail "WARNING: $FILESYSTEM is ${CAPACITY}% FULL!" "$line"
    elif [ "$CAPACITY" -ge 50 ]; then
        Sendmail "ONE HALF: $FILESYSTEM is ${CAPACITY}% FULL!" "$line"
    fi
done

exit 0
