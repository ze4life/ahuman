# Environment specific settings
ENVIRONMENT=moscow-build6; export ENVIRONMENT
FROM="FX+ Moscow Build 6"; export FROM
WAR_PROFILES="dbag-lan"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag; export FXPLUS_LEVEL_1
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LAYERS=$TPLUS_LEVEL_1; export TPLUS_LAYERS
FXPLUS_DEBUG=on
