#!/bin/sh
# $Id: test-build-env.sh,v 1.18 2008/06/04 09:01:44 kovyale Exp $

. ./common.sh
. ./test-funcs.sh
. ./env.sh


#
# Evironments for building
#

checkVar BUILD_HOME

checkVar JAVA_HOME
checkDir $JAVA_HOME
checkFile $JAVA_HOME/bin/java

checkVar ANT_BIN
checkDir $ANT_BIN
checkFile $ANT_BIN/ant

checkVar INSTALL4J_LOCATION
checkDir $INSTALL4J_LOCATION

checkVar CVSROOT

checkVar ENVIRONMENT
