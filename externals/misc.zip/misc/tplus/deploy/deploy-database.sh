#!/bin/sh
#
# $Id: deploy-database.sh,v 1.2 2007/12/18 16:35:48 kovyale Exp $
#

. ./common.sh
. ./env.sh

# database patching
echo "Running database_noninteractive.sh" >&3
./database_noninteractive.sh
if [ "$?" -ne "0" ]; then
	 echo "FAILED TO CREATE DATABASE PATCHES, check log/database_noninteractive.sh.current.log" >&3
	 Sendfile "FAILED TO CREATE DATABASE PATCHES" "log/database_noninteractive.sh.current.log"
	 exit 1
fi

# do vpd first
# need to remove the error file from prev deploy
test -f "log/abfx-$ENVIRONMENT-vpd.ksh.error.log" && rm "log/abfx-$ENVIRONMENT-vpd.ksh.error.log"
echo "Running abfx-$ENVIRONMENT-vpd.ksh" >&3
./abfx-$ENVIRONMENT-vpd.ksh
if [ "$?" -ne "0" ]; then
	 echo "VPD PATCHING FAILED, check log/abfx-$ENVIRONMENT-vpd.ksh.current.log" >&3
	 Sendfile "VPD PATCHING FAILED" "log/abfx-$ENVIRONMENT-vpd.ksh.current.log"
	 exit 1
fi
if [ -s "log/abfx-$ENVIRONMENT-vpd.ksh.error.log" ]; then
	 Sendfile "VPD patching errors" "log/abfx-$ENVIRONMENT-vpd.ksh.error.log"
fi

# patch db
for script in abfx-$ENVIRONMENT-????.ksh; do
	# need to remove the error file from prev deploy
	rm log/$script.error.log
	echo "Running $script" >&3
	 ./$script 
	 if [ "$?" -ne "0" ]; then
		  echo "DATABASE PATCHING FAILED for $script, check log/$script.current.log" >&3
		  Sendfile "DATABASE PATCHING FAILED for $script" "log/$script.current.log"
		  exit 1
	 fi
	 if [ -s "log/$script.error.log" ]; then
		  Sendfile "Database patching errors for $script" "log/$script.error.log"
	 fi
done
