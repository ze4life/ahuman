# Environment specific settings
ENVIRONMENT=moscow-build4; export ENVIRONMENT
FROM="FX+ Moscow Build 4"; export FROM
WAR_PROFILES="dbag-lan dbag-sp1"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag; export FXPLUS_LEVEL_1
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LAYERS=$TPLUS_LEVEL_1; export TPLUS_LAYERS
FXPLUS_DEBUG=on
