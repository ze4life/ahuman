#!/bin/sh
#
# This script prepares thread dump of Nirvana server on appearance of some string in server logs.
#
# Run the script from Nirvana server installation directory as a current working directory.
#
#  $ nohup watchnirvana.sh &
#
# The script will exit as soon as pattern appears in the log and signal is sent
#

MSG="Failure,nEventDispatch : no event sent for"
LOGFILE="data/nirvana.log"
PIDFILE="nirvana.pid"


if [ ! -r "$LOGFILE" ] ; then
        echo "Logfile either doesn't exist or isn't readable "
        exit 1
fi

if [ -f "$PIDFILE" ] ; then
        PID=`cat $PIDFILE` || (echo "cannot read pid file" ; exit 1 )
        if ( kill -0 $PID ) ; then
                echo "$PID is killable"
        else
                echo "cannot send signal to $PID"
                exit 1
        fi
else
        echo "pidfile either doesn't exist or not readable"
        exit 1
fi

tail -1f $LOGFILE | while read a
do
        echo $a |grep "$MSG" > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
                kill -3 $PID
                echo "done"
                exit 0
        fi
done

