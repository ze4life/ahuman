#!/bin/ksh
#
# $Id: clear-prev-release-files.sh,v 1.1 2008/06/04 13:06:24 kovyale Exp $
#

. ./common.sh
. ./env.sh

if [ "$KEEP_BUILD_FILES" != "YES" ]; then
    ( cd $BUILD_HOME && rm -rf "$TAG" )
fi

# clean prev release dirs, for prod keep for 2 weeks, for daily builds and prod copy - just remove
if [ "$KEEP_PREV_RELEASE" = "YES" ]; then
    CURRENT_RELEASE=`cat $HOME/.CURRENT_RELEASE`
    if [ -z "$CURRENT_RELEASE" ]; then
        exit 0
    fi

    find $HOME \( \
    -name "fxplusoptions-*" -o \
    -name "fxplus-*" -o \
    -name "rmi-jmx-*" -o \
    -name "stp-*" -o \
    -name "tplus-*" \
    \) -type d 2> /dev/null | grep -v $CURRENT_RELEASE | xargs rm -rf
else
    (cd $HOME
    rm -rf \
    fxplusoptions-* \
    rmi-jmx-* \
    fxplus \
    stp_fpml \
    tplus-* \
    2>/dev/null )
fi
