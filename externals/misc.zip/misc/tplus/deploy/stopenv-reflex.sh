#!/bin/sh
#
# $Id: stopenv-reflex.sh,v 1.1 2008/06/09 13:16:49 kovyale Exp $
#

. ./common.sh
. ./env.sh

( cd $HOME/fxpricing/bin && ./run stopall )
if [ $? -ne 0 ]; then
    exit 1
fi
