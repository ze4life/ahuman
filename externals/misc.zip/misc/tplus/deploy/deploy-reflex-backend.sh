#!/bin/ksh
#
# $Id: deploy-reflex-backend.sh,v 1.10 2008/10/21 15:12:06 fxplusAutoBuild Exp $
#

. ./common.sh
. ./env.sh

if [ ! -f "fxpricing-redist-$TAG.tgz" ]; then
    exit 1
fi

# exit on error
set -e

FXPRICING_TMP=$HOME/deploy/tmp/fxpricing-$TAG
mkdir -p $FXPRICING_TMP
gzip -d -c fxpricing-redist-$TAG.tgz | ( cd $FXPRICING_TMP && tar xf - )
if [ $? -ne 0 ]; then
    exit 1
fi

if [ -z "$DEPLOY_HOME" ]; then
    DEPLOY_HOME=$HOME
fi

if [ ! -d "$DEPLOY_HOME" ]; then
    exit 1
fi

mkdir -p $HOME/pidfiles/java
mkdir -p $HOME/archive
mkdir -p $DEPLOY_HOME/fxpricing-$TAG \
         $DEPLOY_HOME/fxpricing-$TAG/bin \
         $DEPLOY_HOME/fxpricing-$TAG/conf \
         $DEPLOY_HOME/fxpricing-$TAG/lib/thirdparty \
         $DEPLOY_HOME/fxpricing-$TAG/logs

cp -rp $FXPRICING_TMP/server/*.jar $DEPLOY_HOME/fxpricing-$TAG/lib
cp -rp $FXPRICING_TMP/server/conf/* $DEPLOY_HOME/fxpricing-$TAG/conf
cp -rp $FXPRICING_TMP/server/lib/* $DEPLOY_HOME/fxpricing-$TAG/lib/thirdparty
cp -rp $FXPRICING_TMP/server/bin/* $DEPLOY_HOME/fxpricing-$TAG/bin

# some symlinked files may not exist
set +e
chmod a+x $DEPLOY_HOME/fxpricing-$TAG/bin/*
set -e

rm -rf $DEPLOY_HOME/fxpricing-$TAG/lib/lib
mkdir $DEPLOY_HOME/fxpricing-$TAG/lib/lib

test -h $DEPLOY_HOME/fxpricing-$TAG/bin/pidfiles && rm $DEPLOY_HOME/fxpricing-$TAG/bin/pidfiles
ln -s $HOME/pidfiles $DEPLOY_HOME/fxpricing-$TAG/bin/

test -h $DEPLOY_HOME/fxpricing-$TAG/bin/env.sh && rm $DEPLOY_HOME/fxpricing-$TAG/bin/env.sh
ln -s $DEPLOY_HOME/fxpricing-$TAG/bin/$ENVIRONMENT-env.sh $DEPLOY_HOME/fxpricing-$TAG/bin/env.sh

test -h $DEPLOY_HOME/fxpricing-$TAG/bin/startReflexServices.sh && rm $DEPLOY_HOME/fxpricing-$TAG/bin/startReflexServices.sh
ln -s $DEPLOY_HOME/fxpricing-$TAG/bin/startReflexServices-$ENVIRONMENT.sh $DEPLOY_HOME/fxpricing-$TAG/bin/startReflexServices.sh

test -h $HOME/fxpricing && rm $HOME/fxpricing
ln -s $DEPLOY_HOME/fxpricing-$TAG $HOME/fxpricing

# clear tmp
rm -rf $REFLEX2_TMP $FXPRICING_TMP
