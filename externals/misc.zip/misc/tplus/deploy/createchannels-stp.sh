#!/bin/sh

. ./common.sh
. ./env.sh

# create channels
for stp in $HOME/stp_fpml/level_1/* $HOME/stp_fpml/level_2/* ;do
	if [ -d "$stp" ]; then
		 # create channels
                 startScript "$stp/release/bin/channelmanager.sh"
	         if [ "$?" -ne "0" ]; then
	                  Sendmail "STP channelmanager $stp" "channelmanager.sh start returns not 0 for $stp"
	         fi
	fi
done

exit 0
