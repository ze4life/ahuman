#!/bin/sh
#
# $Id: StopProdUK.sh,v 1.10 2008/06/20 10:44:33 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# change directory to $HOME
cd $HOME

echo "=== Layer 1" >&3
# stop Layer1
SSH_USERHOST="$TPLUS_USERHOST"
stopScript "tplus/deploy/dbag/bin/chatserver.sh"
stopScript "tplus/deploy/dbag/bin/tserver.sh"
stopScript "tplus/deploy/dbag/bin/authserver.sh"
stopScript "fxplus/level_1/dbag/release/bin/dbmpProxy.sh"
stopScript "fxplus/level_1/dbag/release/bin/emailserver.sh"
stopScript "fxplus/level_1/dbag/release/bin/rmsbridge.sh"
stopScript "fxplus/level_1/dbag/release/bin/gtbserver.sh"
stopScript "fxplusoptions/bin/fxopserver.sh"
stopScript "stp_fpml/level_1/dbag/release/bin/stpserver.sh"

SSH_USERHOST="$FXPLUS_USERHOST"
stopScript "fxplus/level_1/dbag/release/bin/server.sh"
stopScript "fxplus/level_1/dbag/release/bin/ratefan.sh"
stopScript "fxplus/level_1/dbag/release/bin/dedicated_ratefan.sh"
stopScript "fxplus/level_1/dbag/release/bin/d2n.sh"
stopScript "fxplus/level_1/dbag/release/bin/fixserver.sh"
stopScript "fxplus/level_1/dbag/release/bin/currenexbridge.sh"
stopScript "fxplus/level_1/dbag/release/bin/fxallmdpibridge.sh"
stopScript "fxplus/level_1/dbag/release/bin/fxalltcpibridge.sh"
stopScript "fxplus/level_1/dbag/release/bin/cfetsbridge.sh"

SSH_USERHOST="$CFETS_SCS_USERHOST"
stopScript "fxplus/cfets-scs/scripts/cfets-scs.sh"

echo "=== Layer 2" >&3
# stop Layer2
SSH_USERHOST="$WLC_USERHOST"
for wlc in $FXPLUS_LEVEL_2; do
	 stopScript "tplus/deploy/$wlc/bin/tserver.sh"
	 stopScript "tplus/deploy/$wlc/bin/authserver.sh"
	 stopScript "fxplus/level_2/$wlc/release/bin/server.sh"
         if [ -d "stp_fpml/level_2/$wlc" ]; then
             # Some WLCs do not have stp
             stopScript "stp_fpml/level_2/$wlc/release/bin/stpserver.sh"
         fi
done
if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
