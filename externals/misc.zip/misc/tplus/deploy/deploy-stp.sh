#!/bin/sh

. ./common.sh
. ./env.sh

# check if we have the STP release jar for this environment
# the jar will not be built if compile.sh did not find the
# stp config for the environment
if [ ! -f "$HOME/deploy/stp-$TAG.jar" ]; then
    echo Could not find $HOME/deploy/stp-$TAG.jar >&3
    echo STP FpML will not be deployed >&3
    exit 0
fi

# Move everything to the FX+ directory
DEPLOY_DIR=$HOME/stp_fpml

echo " Deploying stp" >&3

mkdir -p $DEPLOY_DIR || exit 1

(
cd $DEPLOY_DIR || exit 1
# remove "release" symbolic link, directory... whatever...
rm -rf release
# remove the same tag release directory
test -d stp-$TAG && rm -rf stp-$TAG

jar xvf $DEPLOY_HOME/stp-$TAG.jar || exit 1
mv $TAG stp-$TAG || exit 1
ln -s stp-$TAG release
# ABFX-77: copy certs
if [ -r "$HOME/SECRETS/certs/stp" ]; then
        cp -rp $HOME/SECRETS/certs/stp/* $DEPLOY_DIR/release/keystore/
fi
# ABFX-77: support for secrets.properties for stp
SECRETS=""
if   [ -r "$HOME/SECRETS/stp/secrets.properties" ]; then
	SECRETS="-Dsecrets.properties=$HOME/SECRETS/stp/secrets.properties"
fi
$ANT_BIN/ant -Dsrc=stp-$TAG -f config.xml -Dxml_config_filename=config/stp_config_$ENVIRONMENT.xml $SECRETS
)
if [ "$?" -ne "0" ] ;then
	echo "FAILED" >&3
	exit 1
fi

if [ "$REMOVE_RELEASE_TARS" = "YES" ]; then
    # cleanup build files for non PROD-like envs.
    rm -f stp-*.jar
fi

