# Environment specific settings
ENVIRONMENT=moscow-build2; export ENVIRONMENT
FROM="FX+ Moscow Build 2"; export FROM
WAR_PROFILES="\
dbag-lan \
aibk-lan \
bcvg-lan \
jybm-lan \
okoh-lan \
sabx-lan \
shin-lan \
pbzg-lan \
nbcm-lan \
bjss-lan \
jpmp-lan \
efgz-lan \
lodh-lan \
ubpg-lan \
"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="aibk bcvg jybm okoh sabx shin pbzg nbcm"; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS
