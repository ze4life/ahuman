ENVIRONMENT="live-uk"
FROM="Reflex Live UK"; export FROM

REALMS_SPOT="
nsp://dnap1.uk.db.com:31102
nsp://dnap1.uk.db.com:31104
nsp://reflexp1.us.db.com:31102
nsp://reflexp1.us.db.com:31104
nsp://singmfxwbp1-lower.sg.db.com:31104
"
REALMS_CONFIG="
nsp://dnap1.uk.db.com:31101
nsp://dnap1.uk.db.com:31103
nsp://reflexp1.us.db.com:31103
nsp://singmfxwbp1-lower.sg.db.com:31103
"

PUB_USER='pub$pr0d'
SUB_USER='sub$pr0d'

DEPLOY_HOME=/export/log/reflexprod/deploy
TOMCAT_HOME=/export/log/reflexprod/tomcat

CVSROOT=":pserver:tsarvi@fxcvs.uk.db.com:/cvs/archive"; export CVSROOT
CVS_MODULES="LRP/Reflex fxpricing"

BUILD_SCRIPTS="checkout.sh compile-reflex.sh mk-reflex-redist-tar.sh"
DEPLOY_SCRIPTS="deploy-reflex-backend.sh lame_hotfix_for_reflex_delete_in_prod.sh deploy-reflex-web.sh createchannels-reflex.sh"
STOPENV_SCRIPTS="stopenv-reflex.sh"
STARTENV_SCRIPTS="startenv-reflex.sh"

START_AFTER_AUTODEPLOY=NO
CREATE_CHANNELS=NO
REMOVE_RELEASE_TARS=NO
KEEP_PREV_RELEASE=YES
KEEP_BUILD_FILES=NO
TAG=fxpricing-prod-8-2-13 ; export TAG
