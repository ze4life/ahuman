#!/bin/sh

. ./common.sh
. ./env.sh

if [ "$ENVIRONMENT" = "live-uk-bcp" ] || [ "$ENVIRONMENT" = "live-uk-fwd" ] || [ "$ENVIRONMENT" = "live-uk-fwd-bcp" ]; then
    cd $HOME/fxpricing/conf &&
    rm wrapper.fxconfigchanger.conf wrapper.fxsourceswitcher.Defaults.conf wrapper.fxsourceswitcher.EBS.conf wrapper.fxsourceswitcher.Reuters.conf wrapper.fxspotserver.conf wrapper.fxvaluedatecalculator.conf
fi
