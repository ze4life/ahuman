#!/bin/sh
# This script will generate tplus.tar using "ant distribution"
# in tplus directory. Originally extracted from multi-level-cab-sign.sh.
#
# $Id: mktplustar.sh,v 1.7 2008/04/07 11:08:14 kovyale Exp $

. ./common.sh
. ./env.sh

(
    cd "$BUILD_HOME/$TAG/tplus"
    echo ' Building tplus tar' >&3
    ${ANT_BIN}/ant distribution
)
if [ "$?" -ne "0" ] ;then
    echo "FAILED" >&3
    exit 1
fi

# Move the relese file to deploy dir
echo " Moving $BUILD_HOME/$TAG/tplus/tplus.tar to $HOME/deploy" >&3
mv $BUILD_HOME/$TAG/tplus/tplus.tar .
if [ "$?" -ne "0" ] ;then
    echo "FAILED" >&3
    exit 1
fi

exit 0
