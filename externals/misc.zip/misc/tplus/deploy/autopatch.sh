#!/bin/ksh
#
# $Id: autopatch.sh,v 1.67 2008/04/15 13:41:07 kovyale Exp $
#
# alexey.kovyrshin@db.com
#

. ./getopts.sh

# if $1 == nodeploy set the NODEPLOY flag
if [ "$1" = "NODEPLOY" ]; then
    NODEPLOY="YES"
fi

# need to get the profile, but it sets "-o vi" 
# that's why the script must be executed by ksh
. $HOME/.profile

# Need to get CVSROOT
. ./common.sh

# update the deploy module and restart.
if [ -z "$RESTARTED" ]; then
	# check for running instance
	for pid in autopatch autodeploy; do 
		if [ -f "$pid.pid" ]; then
			PID=`head -1 $pid.pid`
	                ISRUNNING=`ps -ef | grep $PID | grep $LOGNAME | grep -v grep | egrep "autodeploy\.sh|autopatch\.sh"`
			if [ -n "$ISRUNNING" ]; then
				echo "The instance of autopatch.sh or autodeploy.sh is already running." >&3
				echo "$ISRUNNING" >&3
				exit 1
			fi
		fi
	done
	echo $$ > "`basename $0 .sh`.pid"

	cvs -q -z3 up -Pd
	# set the RESTARTED flag
        RESTARTED=YES
	export RESTARTED
	# return the STDOUT
	exec 1>&3
	# re-run self with the same arguments
        exec $0 
else
	# ok environemnt var RESTARTED is set,
	# i am the restarted instance!
        echo Restarted $0 $TAG
fi

# guessing the environment
case $LOGNAME in
	'tplu5')
		ENVIRONMENT=prod-copy
		;;
	'tplu2')
		ENVIRONMENT=daily-build2
		;;
	'abfx8')
		ENVIRONMENT=moscow-build8
		;;
	*)
		echo "This script is designed to run on PROD-COPY/DAILYBUILD2/MOSCOW-BUILD8 only" >&3
		exit 1
esac
export ENVIRONMENT

# get the latest prod tag
if [ ! -f "$DEPLOY_HOME/patches/latest_prod_tag.txt" ]; then
	echo "Can not find the latest prod tag file: $DEPLOY_HOME/patches/latest_prod_tag.txt" >&3
	Sendmail "No prod tag given" "Can not find the latest prod tag file: $DEPLOY_HOME/patches/latest_prod_tag.txt"
	exit 1
fi

LATEST_PRODTAG=`cat $DEPLOY_HOME/patches/latest_prod_tag.txt`

# get tag bits
major=`echo $LATEST_PRODTAG | cut -d- -f2`
minor=`echo $LATEST_PRODTAG | cut -d- -f3`
patchversion=`echo $LATEST_PRODTAG | cut -d- -f4`

# increment patchversion
pachversion=`expr $patchversion + 1`

# new tag
PRODTAG="prod-$major-$minor-$pachversion"

# candidate
CANDIDATETAG="prod-candidate-$major-$minor-$pachversion"

Sendmail "About to start autopatch on the $ENVIRONMENT with tag $PRODTAG" "Going to autopatch the $ENVIRONMENT using the tag $PRODTAG"

# before cloning cvs and doing everything check if the
# $DEPLOY_HOME/patches/$PRODTAG exists and not empty
if [ ! -d "$DEPLOY_HOME/patches/$PRODTAG" ]; then
	echo "Could not find $DEPLOY_HOME/patches/$PRODTAG" >&3
	Sendmail "No patches directory found" "Could not find $DEPLOY_HOME/patches/$PRODTAG directory"
	exit 1
fi
if [ -z "`ls $DEPLOY_HOME/patches/$PRODTAG/ABFX-* $DEPLOY_HOME/patches/$PRODTAG/BUG-*`" ]; then
	echo "There are no patches in $DEPLOY_HOME/patches/$PRODTAG" >&3
	Sendmail "No patches found" "There are no patches in $DEPLOY_HOME/patches/$PRODTAG"
	exit 1
fi

# the list of patches used in autodeploy.sh 
# to report in email
LIST_OF_PATCHES=""
# check the patches first
echo "Checking the patches in the $DEPLOY_HOME/patches/$PRODTAG/ ..." >&3
for patch in $DEPLOY_HOME/patches/$PRODTAG/ABFX-* $DEPLOY_HOME/patches/$PRODTAG/BUG-*;do 
        # SKIP non existing files, for exmaple if there is no BUG-* the shell will use "BUG-*" value
        if [ ! -f "$patch" ]; then
            continue
        fi
	# validade the patch file
	junk=`( cat $patch; echo ) | sed -e 's/  */ /g' -e 's/^ *//' -e 's/ *$//' | grep -v "^$" | \
        egrep -v '^[&0-9a-zA-Z./_\-]+ [0-9]+\.[0-9]+$' | \
	egrep -v '^[&0-9a-zA-Z./_\-]+ [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | \
	egrep -v '^[&0-9a-zA-Z./_\-]+ delete$'  `
	if [ -n "$junk" ]; then
		echo $junk >&3
		echo "Junk detected in the $patch file, will not continue autopatching" >&3
		Sendmail "Junk detected in the $patch file, will not continue autopatching" "$junk"
		exit 1
	fi
	patchfilename=`basename $patch`
	LIST_OF_PATCHES="$LIST_OF_PATCHES $patchfilename"

	tmpdir="$DEPLOY_HOME/tmp"
	mkdir -p $tmpdir
	if [ ! -d "$tmpdir" ]; then
		Sendmail "Error creating temporary directory" "Could not create tmpdir=$tmpdir"
		exit 1
	fi

	# check the cvs revisions are exist ABFX-1297
	jira=`basename $patch`
	( cat $patch ; echo ) \
	| sed -e 's/  */ /g' -e 's/^ *//' -e 's/ *$//' | grep -v "^$" \
	| while read line; do
		cvsfile=`echo $line|cut -d" " -f1`
		cvsrev=`echo $line|cut -d" " -f2`
		if [ "$cvsrev" != "delete" ]; then
			( cd $tmpdir
			 cvs -z3 co -r$cvsrev $cvsfile
			 if [ "$?" -ne "0" ] || [ ! -f "$cvsfile" ] ; then
				Sendmail "$jira: Error checking revisions" \
					"The revision=$cvsrev does not exist for the file $cvsfile"
				echo "$jira: The revision=$cvsrev does not exist for the file $cvsfile" >&3
				exit 1
			 else
				rm -f $cvsfile
			 fi
			)
	                if [ "$?" -ne "0" ]; then
		                exit 1
	                fi
		fi
	done
	if [ "$?" -ne "0" ]; then
		exit 1
	fi
done

echo "All patches look ok: $LIST_OF_PATCHES" >&3
export LIST_OF_PATCHES

# remove previously created tag, see ABFX-1531
echo "Removing previously created $CANDIDATETAG ..." >&3
cvs -q -z3 rtag -d $CANDIDATETAG tplus richclient tplus-common-jars fxplusoptions fxplus coldfusion

# clone the tag
echo "Cloning $LATEST_PRODTAG into $CANDIDATETAG ..." >&3
cvs -q -z3 rtag -F -r$LATEST_PRODTAG $CANDIDATETAG tplus fxplus tplus-common-jars fxplusoptions richclient coldfusion
if [ "$?" -ne "0" ]; then
	echo "Could not clone $LATEST_PRODTAG to $CANDIDATETAG" >&3
	Sendmail "Error cloning the prod tag" "Could not clone $LATEST_PRODTAG to $CANDIDATETAG" 
	exit 1
fi
echo "Tag $CANDIDATETAG has been successfully created from the $LATEST_PRODTAG" >&3

# clear changes file
test -f log/changes.txt.$DATE && rm log/changes.txt.$DATE

# clear multiple revisions file
test -f log/multiple.revisions.txt.$DATE && rm log/multiple.revisions.txt.$DATE

# check for the same file in many requests with different revisions
# need to take the latest revision
# On the input: path/to/file.ext 1.2.3.4
# 2nd sed - to transform the input to path/to/file.ext#1#2#3#4:
#  1 change the fisrt white space to # symbol
#  2 change the dots in the ending mainline revision to # symbols
#  3 change the dots in the ending branch revision to # symbols
# 1st sort with field separator #:
#  -k 1,1 sort by file name lexically
#  -k 2,2nr sort by the first revision number numerically reversing the results and so on...
# 3d sed - to transform the first # to whitespace and the next #s to dots
for patch in $DEPLOY_HOME/patches/$PRODTAG/ABFX-* $DEPLOY_HOME/patches/$PRODTAG/BUG-*;do 
        # SKIP non existing files, for exmaple if there is no BUG-* the shell will use "BUG-*" value
        if [ ! -f "$patch" ]; then
            continue
        fi
	( cat $patch ; echo )
done \
| sed -e "s/^ *//" -e "s/ *$//" -e "s/  */ /g" \
| grep -v "^$" \
| sed -e "s/ /#/" \
      -e "s/\(.*\)#\([0-9]*\)\.\([0-9]*\)$/\1#\2#\3/g" \
      -e "s/\(.*\)#\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)$/\1#\2#\3#\4#\5/g" \
| sort -t "#" -k 1,1 -k 2,2nr -k 3,3nr -k 4,4nr -k 5,5nr \
| sed -e "s/#/ /" -e "s/#/./g" \
| while read line; do
	cvsfile=`echo $line|cut -d" " -f1`
	cvsrev=`echo $line|cut -d" " -f2`
	
	# so we sort by fileanme and then reverse sort by revision number
	# to get the latest revision only
	# and we skip older revisions
	if [ "$cvsfile" = "$lastcvsfile" ]; then
		echo "$cvsfile $cvsrev, using revision $lastcvsrev" >> log/multiple.revisions.txt.$DATE
		continue
	fi
	lastcvsfile=$cvsfile
	lastcvsrev=$cvsrev

	# save the list of Patches into text file to be able to compare later on
	echo $lastcvsfile $lastcvsrev >> log/changes.txt.$DATE
	
	# move tag
	if [ "$lastcvsrev" = "delete" ]; then
		echo cvs -z3 rtag -d $CANDIDATETAG $lastcvsfile >&3
		cvs -z3 rtag -d $CANDIDATETAG $lastcvsfile
		if [ "$?" -ne "0" ]; then
			echo "Could not do: cvs -z3 rtag -d $CANDIDATETAG $lastcvsfile" >&3
			Sendmail "CVS rtag error" "Could not do: cvs -z3 rtag -d $CANDIDATETAG $lastcvsfile"
			exit 1
		fi
	else
		echo cvs -z3 rtag -F -r$lastcvsrev $CANDIDATETAG $lastcvsfile >&3
		cvs -z3 rtag -F -r$lastcvsrev $CANDIDATETAG $lastcvsfile
		if [ "$?" -ne "0" ]; then
			echo "Could not do: cvs -z3 rtag -F -r$lastcvsrev $CANDIDATETAG $lastcvsfile" >&3
			Sendmail "CVS rtag error" "Could not do: cvs -z3 rtag -F -r$lastcvsrev $CANDIDATETAG $lastcvsfile"
			exit 1
		fi
	fi
done
if [ "$?" -ne "0" ]; then
	exit 1
fi

if [ -s "log/multiple.revisions.txt.$DATE" ]; then
    echo "Multiple revisions for same file(s) found, please check the $HOME/deploy/log/multiple.revisions.txt.$DATE"
    Sendfile "Multiple revisions for same file(s) found, see the list attached" "log/multiple.revisions.txt.$DATE"
fi

## The tag is created ok, let's clone it to the PRODTAG
## remove previously created tag
#echo "Removing previously created $PRODTAG ..." >&3
#cvs -q -z3 rtag -d $PRODTAG tplus richclient tplus-common-jars fxplusoptions fxplus coldfusion
## clone the tag
#echo "Cloning $CANDIDATETAG into $PRODTAG ..." >&3
#cvs -q -z3 rtag -F -r$CANDIDATETAG $PRODTAG tplus fxplus tplus-common-jars fxplusoptions richclient coldfusion
#if [ "$?" -ne "0" ]; then
#	echo "Could not clone $CANDIDATETAG to $PRODTAG" >&3
#	Sendmail "Error cloning the prod tag" "Could not clone $CANDIDATETAG to $PRODTAG" 
#	exit 1
#fi
#echo "Tag $PRODTAG has been successfully created from the $CANDIDATETAG" >&3

# send the differences, always overwrite the log/tagdiffs.$DATE
cvs -q -z3 rdiff -s -r $LATEST_PRODTAG -r $CANDIDATETAG \
    tplus fxplus tplus-common-jars fxplusoptions richclient coldfusion | \
    sed -e "s/ is new; .* revision//" \
    > log/tagdiffs.$DATE 
if [ "$?" -ne "0" ]; then
	echo "Could not run rdiff -s -r $LATEST_PRODTAG -r $CANDIDATETAG" >&3
	Sendmail "Error diffing the tags" "Could not run rdiff rdiff -s -r $LATEST_PRODTAG -r $CANDIDATETAG"
	exit 1
fi
Sendfile "Tag difference $LATEST_PRODTAG -> $CANDIDATETAG" "log/tagdiffs.$DATE"

# clear downgraded revisions file
test -f log/downgraded.revisions.txt.$DATE && rm log/downgraded.revisions.txt.$DATE

# check the tagdiffs file for any downgraded revisions
cat "log/tagdiffs.$DATE" | grep "changed from revision" | while read line
do
    FILE=`echo $line | cut -d" " -f 2`
    R1=`echo $line | cut -d" " -f 6`
    R2=`echo $line | cut -d" " -f 8`
    i=0
    for r in `echo $R1 | sed -e "s/\./ /g"`
    do
        i=`expr $i + 1`
        r2=`echo $R2 | cut -d. -f $i`
        if [ $r2 -lt $r ]; then
            echo "$FILE changed from $R1 to $R2" >> log/downgraded.revisions.txt.$DATE
        fi
    done
done

if [ -s "log/downgraded.revisions.txt.$DATE" ]; then
    echo "WARNING: Downgraded revisions found, please check the $HOME/deploy/log/downgraded.revisions.txt.$DATE"
    Sendfile "WARNING: Downgraded revisions found, see the list attached" "log/downgraded.revisions.txt.$DATE"
fi

# compare log/changes.txt.$DATE and log/tagdiffs.$DATE
cat log/tagdiffs.$DATE | sed -e "s/^File //" -e "s/changed from revision .* to //" \
-e "s/is new; current revision //" -e "s/is removed; not included in release tag.*/delete/" | sort > log/tmp.tagdiffs.$DATE
sort log/changes.txt.$DATE > log/tmp.changes.txt.$DATE
diff log/tmp.changes.txt.$DATE log/tmp.tagdiffs.$DATE > log/patches_prodtag_diff.$DATE
if [ "$?" -ne 0 ]; then
	 echo "Warning: the tag difference $CANDIDATETAG - $LATEST_PRODTAG and the patch instructions are differ! Check log/patches_prodtag_diff.$DATE" >&3
	 Sendfile "Warning: the tag difference $CANDIDATETAG - $LATEST_PRODTAG and the patch instructions are differ!" "log/patches_prodtag_diff.$DATE"
	 rm log/tmp.changes.txt.$DATE log/tmp.tagdiffs.$DATE
fi
rm log/tmp.changes.txt.$DATE log/tmp.tagdiffs.$DATE

if [ -n "$NODEPLOY" ]; then
    echo "The tag $CANDIDATETAG has been successfully created." >&3
    echo "The autodeployment is skipped due to NODEPLOY command line argument" >&3
    exit 0
fi
# run the autodeploy.sh now
echo "Starting autodeploy for the $ENVIRONMENT with Tag=$CANDIDATETAG ..." >&3
exec 1>&3
exec ./autodeploy.sh -r $CANDIDATETAG
