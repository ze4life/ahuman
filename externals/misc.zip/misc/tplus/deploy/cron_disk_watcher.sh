#!/bin/sh
#
# $Id: cron_disk_watcher.sh,v 1.32 2008/11/06 09:00:24 fxplusAutoBuild Exp $
#
# put it on the cron control to be run every hour
#0 * * * * ( cd $HOME/deploy ; ./cron_disk_watcher.sh ) > /dev/null 2>&1

if [ -r "env.sh" ]; then
    . ./env.sh
fi

MAILTO="`cat autodeploy.mailto`"

# NEVER stop the prod, demo, extuat !
#
# AS A RULE: NEVER SET THE STOP_SIZE for PROD, PROD DEMO, EXT UAT1
#
STOP_SIZE=""

# define the soft (MAX_SIZE) and hard (STOP_SIZE) limits in Kb
case $LOGNAME in
    tplu1|tplu3|abfx1|abfx2|abfx3|abfx4|abfx6|abfx8)
            MAX_SIZE=8388608
            STOP_SIZE=13631488
            ;;
    abfxu1)
            MAX_SIZE=15728640
            #STOP_SIZE=18874368
            STOP_SIZE=25000000
            ;;
    tplu9)
            MAX_SIZE=7340032
            ;;
    tplu2)
            MAX_SIZE=15728640
            STOP_SIZE=18874368
            ;;
    tplu5)
            MAX_SIZE=15728640
            STOP_SIZE=18874368
            ;;
    tplu4)
            MAX_SIZE=17825792
            ;;
    tplu7)
            MAX_SIZE=18874368
            ;;
    tplp1)
            MAX_SIZE=47185920
            ;;
    *)
            MAX_SIZE=2097152
            ;;
esac

# renice self
renice +19 $$

DU=`du -sk $HOME | tail -1 | awk '{print $1}'`
if [ -f "log/env.stopped.by.watcher" ]; then
    STOPPED=YES
fi

if [ "$DU" -ge "$MAX_SIZE" ]; then
    # find the list of files with size greater then 0.5G
    rm -f log/huge_files.txt
    find $HOME -type f -size +1048575 | \
    while read file
    do
        du -sh $file >> log/huge_files.txt
    done

    STOP=""
    if [ -n "$STOP_SIZE" ]; then
        if [ "$DU" -ge "$STOP_SIZE" ]; then
            STOP=YES
        fi
    fi

    USER=$LOGNAME
    if [ -n "$ENVIRONMENT" ]; then
        USER=$ENVIRONMENT
    fi

    if [ -n "$FROM" ]; then
        echo "From: $FROM <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    elif [ -n "$ENVIRONMENT" ]; then
        echo "From: $ENVIRONMENT <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    fi

    (
    if [ "$STOPPED" = "YES" ]; then
        echo "Subject: REMINDER: Please clear the disk space on ${USER}'s account ($LOGNAME)"
    elif [ "$STOP" = "YES" ]; then
        echo "Subject: CRITICAL: The ${USER}'s disk usage exceeded the hard limit and will be STOPPED NOW"
    else
        echo "Subject: Warning: The ${USER}'s disk usage exceeded the soft limit. Please have a look"
    fi

    echo "From: $USER disk watcher <$LOGNAME.`hostname`.uk.db.com@discard.mail.db.com>"
    echo


    if [ "$STOPPED" = "YES" ]; then
        echo "The ${USER} has been stopped by the disk space watcher, but the space has not been released yet."
        echo "Please clear the disk space."
    elif [ "$STOP" = "YES" ]; then
        echo "The $USER has taken `expr $DU / 1024 / 1024`G which exceeds the hard limit - `expr $STOP_SIZE / 1024 / 1024`G for the given environment."
        echo "The $USER will be stopped now."
    else
        echo "The $USER has taken `expr $DU / 1024 / 1024`G which exceeds the soft limit - `expr $MAX_SIZE / 1024 / 1024`G for the given environment."
    fi

    if [ -s "log/huge_files.txt" ]; then
        echo Please find the list of files with size more then 0.5G
        echo
        cat log/huge_files.txt
    else
        echo Unable to find the files with size more then 0.5G
    fi

    # send directory size report
    echo
    echo Please find the directory size in Kb sorted below
    du -sk $HOME/* $HOME 2>&1 | sort -nr

    ) | /usr/lib/sendmail $MAILTO 

    if [ "$STOPPED" != "YES" ]; then
        if [ "$STOP" = "YES" ]; then
            if [ "$LOGNAME" != "tplp1" ] && \
               [ "$LOGNAME" != "tplu4" ] && \
               [ "$LOGNAME" != "tplu7" ]
            then
                ./stopenv.sh
                touch "log/env.stopped.by.watcher"
            fi
        fi
    fi
else
    # the space is ok remove the stopped env flag
    rm "log/env.stopped.by.watcher"
fi
exit 0
