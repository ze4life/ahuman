#!/bin/sh
#
# $Id: checkout.sh,v 1.49 2008/07/23 12:00:55 schedmi Exp $
#

. ./common.sh
. ./env.sh

if ( echo $TAG | grep -v grep | grep "^date-" > /dev/null ) ; then
    # remove date- prefix
    CHECKOUT_DATE=`echo $TAG | sed -e "s/^date-//"`
    CHECKOUT_ARGS="-D $CHECKOUT_DATE"
else
    CHECKOUT_ARGS="-r $TAG"
fi

if [ -d "$HOME/build/$TAG" ]; then
    rm -rf $HOME/build/$TAG
fi
mkdir -p $HOME/build/$TAG

for module in $CVS_MODULES
do
    echo " Running: cvs -z6 co $CHECKOUT_ARGS $module" >&3
    ( cd $HOME/build/$TAG && cvs -z6 co $CHECKOUT_ARGS $module )
    if [ "$?" -ne "0" ]; then
        echo "  check out failed" >&3
        exit 1
    fi
    # Check for the checkedout module directory
    # When you tag say tplus, fxplus but forgot fxplusoptions,...
    # cvs co will not return error due to the tag exists in CVSROOT/val-tags file
    # So we need to check the diretory for existace.
    if [ ! -d "$HOME/build/$TAG/$module" ]; then
        echo "  check out failed, directory $HOME/build/$TAG/$module could not be found" >&3
        exit 1
    fi
done
