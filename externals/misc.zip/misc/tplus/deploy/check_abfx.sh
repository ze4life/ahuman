#!/bin/sh

# env var
. ./env.sh


echo
echo "   --- Checking backend ---"
echo
./StatsProdUK.sh
./StatsProdUS.sh

echo
echo "   --- Checking frontends ---"
echo
./check_frontends.sh
