#
# $Id: env-daily-build3.sh,v 1.24 2008/07/14 15:14:32 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="daily-build3"; export ENVIRONMENT
FROM="FX+ Daily Build 3"; export FROM
TPLUS_LAYERS="dbag jybm bcvg"; export TPLUS_LAYERS
WAR_PROFILES="dbag-lan jybm-lan bcvg-lan asia-lan"; export WAR_PROFILES
FXPLUS_LEVEL_1="dbag"
FXPLUS_LEVEL_2="jybm bcvg" ; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2
FXPLUS_DEBUG=on
MIS_USERHOST="tplu5@longmgccappb1.uk.db.com"
MIS_WEBROOT="/home/tplu5/jrun4/servers/cfusion/cfusion-ear/cfusion-war"
