#!/usr/bin/perl
#
# $Id: connectivity_test.pl,v 1.1 2006/07/27 08:25:18 kovyale Exp $
#
# Connectivity testing script. Listener.
# * read the ports from the file $portsFile
# * iterate through all ports and start listening process
# * the listening process will tell "Hello, PORTNUMBER" on connection.
# * the parent process sleep forever unless killed or interrupted by Control+C
# * when interrupted/killed send TERM singals to all listening processes
#
# Alexey.Kovyrshin@db.com
#
# $Log: connectivity_test.pl,v $
# Revision 1.1  2006/07/27 08:25:18  kovyale
# ABFX-151: renaming listen.pl to connectivity_test.pl
#
# Revision 1.1  2006/05/11 10:04:11  kovyale
# ABFX-0: Checking in the listener - connectivity testing tool
#
#

$portsFile=$ARGV[0];

unless ( -f $portsFile ) {
	 print "Usage: $0 <ports file>\n";
	 die "Can not read $portsFile";
}


open(P, $portsFile) or die "open";
while(<P>) {
	 s/[\r\n\s]//g;
	 my $port=$_;

	 my $pid = fork();
	 if ($pid == 0) {
		  listenOn( $port );
	 }
	 print "Listener on $port started\n";
	 push(@childs, $pid);
}
close(P);

sub catch_zap {
	 my $signame = shift;
	 print "Exiting on $signame signal...\n";
	 print "Stopping all listeners...\n";
	 kill 15, @childs;
	 kill 9, @childs;
	 print "Done\n";
	 exit;
}
$SIG{INT} = \&catch_zap;

print "--------\n";
print "All listenres have been started.\nPress Control+C to exit and shutdown listeners\n";
sleep;

sub listenOn {
	 my $port = shift;

		use Socket;
		
		# make the socket
		socket(Server, PF_INET, SOCK_STREAM, getprotobyname('tcp'));
		
		# so we can restart our server quickly
		setsockopt(Server, SOL_SOCKET, SO_REUSEADDR, 1);
		
		# build up my socket address
		$my_addr = sockaddr_in($port, INADDR_ANY);
		bind(Server, $my_addr)
		    or die "Couldn't bind to port $port: $!\n";
		
		# establish a queue for incoming connections
		listen(Server, SOMAXCONN)
		    or die "Couldn't listen on port $port: $!\n";
		
		# accept and process connections
		while (accept(Client, Server)) {
		    # do something with new Client connection
			 select(Client); 
			 $| = 1; 
			 print "Hello. $port\n";
		    close(Client);
		}
		
		close(Server);
}
