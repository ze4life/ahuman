# Environment file for ABFX PRODUCTION
#
# $Id: env-prod-uk.sh,v 1.10 2008/10/11 12:01:26 kovyale Exp $
#

# Environment specific settings
ENVIRONMENT="prod-uk"; export ENVIRONMENT
FROM="FX+ Prod UK"; export FROM
WAR_PROFILES="\
dbag-lan \
dbag-lan2 \
dbag-bak \
dbag-lon \
dbag-bcp \
dbag-vpn \
dbag-vdr \
dbag-usa \
dbag-sin \
dbag-cit \
dbag-sp1 \
dbag-sp2 \
aibk-lon \
aibk-vpn \
bcvg-lon \
bcvg-vpn \
jybm-lon \
jybm-vpn \
okoh-lon \
okoh-vpn \
pbzg-lon \
pbzg-vpn \
sabx-lon \
sabx-vpn \
shin-lon \
shin-vpn \
nbcm-lon \
nbcm-vpn \
bjss-lon \
jpmp-lon \
efgz-lon \
lodh-lon \
ubpg-lon \
"; export WAR_PROFILES
FXPLUS_LEVEL_1="dbag"; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="aibk bcvg jybm okoh sabx shin pbzg nbcm"; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS

START_AFTER_AUTODEPLOY=NO
CREATE_CHANNELS=NO
REMOVE_RELEASE_TARS=NO
KEEP_PREV_RELEASE=YES
KEEP_BUILD_FILES=NO
SIGN_RICHCLIENT_JARS=YES

# Define the user@host for the T+ FX+ FXO+ WLC STPFPML
# The transfer_files.sh will copy over ssh the give module to the target host
STOPENV_SCRIPTS="StopProdUK.sh StopProdUS.sh"
STARTENV_SCRIPTS="StartProdUK.sh StartProdUS.sh"
TPLUS_USERHOST=""
FXPLUS_USERHOST="abfxp1@abfxp1.uk.db.com"
FXPLUS_US_USERHOST="abfxp1@abfxp1.us.db.com"
FXOPLUS_USERHOST=""
WLC_USERHOST="abfxp3@abfxp3.uk.db.com"
STPFPML_USERHOST=""
CFETS_SCS_USERHOST="abfxp2@abfxp2.uk.db.com"
MIS_USERHOST="abfxp3@abfxb3.uk.db.com"
MIS_WEBROOT="/export/apps/prod/abfxp3/coldfusion/wwwroot"
