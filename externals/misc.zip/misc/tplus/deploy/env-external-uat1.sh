# Environment file for ABFX External UAT 1
#
# $Id: env-external-uat1.sh,v 1.52 2008/07/14 15:14:32 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="external-uat1"; export ENVIRONMENT
FROM="FX+ External UAT 1 UK"; export FROM
WAR_PROFILES="\
dbag-lon \
dbag-lan \
asia-lon \
jpmp-lon \
bjss-lon \
aibk-lon \
bcvg-lon \
jybm-lon \
okoh-lon \
prtr-lon \
sabx-lon \
shin-lon \
pbzg-lon \
nbcm-lon \
ubpg-lon \
"; export WAR_PROFILES
FXPLUS_LEVEL_1="dbag"; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="aibk bcvg jybm okoh sabx shin pbzg prtr nbcm"; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS

SIGN_RICHCLIENT_JARS=YES
START_AFTER_AUTODEPLOY=YES
STOPENV_SCRIPTS="$STOPENV_SCRIPTS StopUS.sh"
STARTENV_SCRIPTS="$STARTENV_SCRIPTS StartUS.sh"
CREATE_CHANNELS=YES
REMOVE_RELEASE_TARS=YES
KEEP_PREV_RELEASE=YES
KEEP_BUILD_FILES=NO
FXPLUS_US_USERHOST="abfxu1@abfxu1.us.db.com"
