#!/bin/sh
#
# $Id: logrotate.sh,v 1.28 2008/05/26 10:52:11 kovyale Exp $
#
# AK: bzip2 has much better compression but the timing is very bad
# AK: take a look on this example:
#   > ls -l
#   -rw-r--r--   1 tplu4    tplus_u  1073741988 Aug 31 09:05 a
#   -rw-r--r--   1 tplu4    tplus_u  1073741988 Aug 31 09:05 b
#   > time gzip -9 a ; time bzip2 -9 b
#   
#   real    1m0.41s
#   user    0m53.74s
#   sys     0m2.15s
#   
#   real    10m34.40s
#   user    9m47.83s
#   sys     0m2.48s
#   > ls -l
#   total 78640
#   -rw-r--r--   1 tplu4    tplus_u  23853652 Aug 31 09:05 a.gz
#   -rw-r--r--   1 tplu4    tplus_u  16392869 Aug 31 09:05 b.bz2

. ./common.sh
. ./env.sh

# the size of chunks in bytes
SPLITSIZE=1073741824

# split and gzip rolled logs
find $HOME/stp_fpml $HOME/fxplus $HOME/tplus-* $HOME/fxplusoptions-* -name "*.log.????-???-??" | \
while read file
do
	(
	 DIRNAME=`dirname $file`
	 FILENAME=`basename $file`
	 cd $DIRNAME
	 FILESIZE=`ls -go $FILENAME | awk '{print $3}'`
	 if [ $FILESIZE -gt $SPLITSIZE ]; then
		  nice -n 19 split -b $SPLITSIZE -a 1 $FILENAME $FILENAME.
		  rm $FILENAME
		  nice -n 19 gzip -9 -v $FILENAME.?
	 else
		  nice -n 19 gzip -9 -v $FILENAME
	 fi
	)
done

# gzip all logs in prev release
if [ -f "$HOME/.CURRENT_RELEASE" ]; then
    CURRENT_RELEASE=`cat $HOME/.CURRENT_RELEASE`
    if [ -z "$CURRENT_RELEASE" ]; then
        CURRENT_RELEASE=`ls -l $HOME/fxplus/release | cut -d">" -f 2 | sed -e "s/ fxplus-//"`
    fi
else
    CURRENT_RELEASE=`ls -l $HOME/fxplus/release | cut -d">" -f 2 | sed -e "s/ fxplus-//"`
fi
find $HOME/stp_fpml $HOME/tplus-* $HOME/fxplus $HOME/fxplusoptions-* \
\( -name "*.log*" \) -a \( \! -name "*.gz" \) -a \( \! -name "*.bz2" \) -type f | \
grep -v "$CURRENT_RELEASE" | \
xargs nice -n 19 gzip -9 -v 

exit 0
