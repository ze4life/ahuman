#!/bin/ksh
#
# $Id: deploy-iapi-fix-tunnel.sh,v 1.11 2008/07/22 14:50:10 schedmi Exp $

. ./common.sh
. ./env.sh

# remove old 
rm iapifix-*.sh

if [ "$ENVIRONMENT" = "prod-uk" ]; then
    ./wcd/createbatch.sh wcd/webenv-prod-uk-vpn-l1.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prod-uk-ip.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-prod-uk-tpint-longmeappp22.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prod-uk-ssl.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-prod-uk-vdr-l1.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prod-uk-ip-dr.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-prod-uk-tpint-longmeappp25.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prod-uk-ssl-dr.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-prod-uk-abfxint-hbrgmabfxp1.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prod-us-ssl.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
fi

if [ "$ENVIRONMENT" = "external-uat1" ]; then
    ./wcd/createbatch.sh wcd/webenv-external-uat1-lon-l1.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-fan-extuat-1.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-external-uat1-abfxint-nyggmabfxp3.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-extuat-1-us-ip.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
fi

if [ "$ENVIRONMENT" = "daily-build2" ]; then
    ./wcd/createbatch.sh wcd/webenv-daily-build2-abfxu2-abfxu1-fixip.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-db2-us-ip.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-daily-build2-abfxu2-abfxu1-fixssl.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-db2-us-ssl.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
fi

if [ "$ENVIRONMENT" = "prod-copy" ]; then
    ./wcd/createbatch.sh wcd/webenv-prod-copy-abfxu3-abfxu1-fixip.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prodcopy-us-ip.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
    ./wcd/createbatch.sh wcd/webenv-prod-copy-abfxu3-abfxu1-fixssl.sh wcd/iapifix.sh $HOME/fxplus/release/fixRelease/fix-tunnel-prodcopy-us-ssl.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
fi

# check if there is any iapifix-*.sh selfinstaller
if [ -n "`ls iapifix-*.sh`" ]; then
    ./wcd/applybatches.sh iapifix-*.sh
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not apply some iapifix self-installers" >&3
        Sendfile "Could not apply some iapifix self-installers" "log/applybatches.sh.current.log"
    else
        rm iapifix-*.sh
    fi
fi

# never interrupt the autodeploy.sh only warng with email
exit 0
