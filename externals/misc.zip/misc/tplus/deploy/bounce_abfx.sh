#!/bin/sh

# env var
. ./env.sh

echo "About to perform the full bounce for $ENVIRONMENT"
echo "Please confirm (y/n):"
read ans
if [ "$ans" != "y" ] && [ "$ans" != "Y" ]; then
    echo "Cancelled."
    exit
fi
BOUNCE_COFIRMED=YES
export BOUNCE_COFIRMED
./bounce_frontends.sh
echo "Stopping backend processes".
if [ "$ENVIRONMENT" = "prod-uk" ]; then
    ./StopProdUK.sh
    ./StopProdUS.sh
else
    ./stopenv.sh
fi
echo " Done."
echo "Starting backend processes".
if [ "$ENVIRONMENT" = "prod-uk" ]; then
    ./StartProdUK.sh
    ./StartProdUS.sh
else
    ./startenv.sh
fi
echo " Done."
