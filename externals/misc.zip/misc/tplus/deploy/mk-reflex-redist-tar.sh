#!/bin/sh
#
# $Id: mk-reflex-redist-tar.sh,v 1.5 2008/10/21 13:49:23 fxplusAutoBuild Exp $
#

. ./common.sh
. ./env.sh

( cd $HOME/build/$TAG/fxpricing/dist && tar cvf - . ) | gzip -c > fxpricing-redist-$TAG.tgz
if [ $? -ne 0 ]; then
    exit 1
fi

# unmatched placeholders
(
cd $HOME/build/$TAG/fxpricing
for i in dist/wrapper/*; do grep -l '{' $i/*; grep -l '}' $i/*; done | sort | uniq
for i in dist/web/*.jnlp; do grep -l '{' $i; grep -l '}' $i; done | sort | uniq
) > "log/unmatched.placeholders.log.$DATE"
if [ -s "log/unmatched.placeholders.log.$DATE" ]; then
    Sendfile "The list of unmatched placeholders (fxpricing)" "log/unmatched.placeholders.log.$DATE"
fi
