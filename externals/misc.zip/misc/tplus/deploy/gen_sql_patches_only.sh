#!/bin/sh
#
# $Id: gen_sql_patches_only.sh,v 1.3 2007/06/25 10:58:28 kovyale Exp $
#
# This script will make:
# * runtime verion of patches and finaly sql scripts.
# * check DATABASE_PATCHES table for alredy applied patches.
# * a set of korn shell scripts, which apply not yet applied patches to database (after removing safety catch)
# 

set -e

###
### Internal functions
### 
### NOTE: All UPPER cased variables used in functions
### NOTE: should be initialized before calling functions,
### NOTE: exept the $COMMENT variable
###

# set ABORT_TOOL to true
set_abort()
{
        ABORT_TOOL=1
}

# checks if ABORT_TOOL is true
check_abort()
{
        if [[ $ABORT_TOOL = 1 ]]; then
                echo "$0: ERROR OCURED, check logfile for more information" >&3
                exit 1
        fi
}

# check for the existance of all the properties files
validate_environment()
{
        # this func check existing of some property files, it's depends on 
        # DEPLOY_TPLUS, DEPLOY_FXPLUS, DEPLOY_FXPLUSOPTIONS variables from env.sh

        # this is mandatory profile
        local property_files="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"

        if [[ "$DEPLOY_TPLUS" = "Y" ]]; then
                property_files="$property_files $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
        fi

        if [[ "$DEPLOY_FXPLUS" = "Y" ]] || [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]]; then
                property_files="$property_files $FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
        fi

        # Note: only layer1 supported for fxplusoptions (layer1 means dbag).
        if [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]] && [[ "$LAYER" = "dbag" ]]; then
                property_files="$property_files $FXOP_HOME/sql/profile/${PROFILE}.options.properties"
        fi

        for property_file in $property_files; do
                if [[ ! -r $property_file ]] ; then
                        echo "FAILED: property file $property_file have not been found." 
                        set_abort;
                fi
        done
}

# checks patch filename against naming convention:
# * first 5 digits must be numeric
# * filename must not use underscores
# * name must have > 1 hypen in it
# * must be lower case only
# * must have the application name embedded in it
check_patch_filename()
{
        local filename=$1
        local basename=`basename $filename`
        local estr="ERROR: Patch file $filename breaks naming convention:"
        # * first 5 digits must be numeric
        if [[ -z `echo $basename | egrep "^[0-9][0-9][0-9][0-9][0-9]-"` ]]; then
                echo $estr "first 5 digits must be numeric."
                set_abort;
        fi
        # * filename must not use underscores
        if [[ -n `echo $basename | egrep "_"` ]]; then
                echo $estr "filename must not use underscores."
                set_abort;
        fi
        # * name must have > 1 hypen in it
        if [[ `echo $basename | sed -e "s/-/ /g" | wc -w | sed -e "s/^ *//"` -le 2 ]]; then
                echo $estr "name must have > 1 hypen in it."
                set_abort;
        fi
        # * must be lower case only
        if [[ -n `echo $basename | egrep "[A-Z]"` ]]; then
                echo $estr "must be lower case only."
                set_abort;
        fi
        # * must have the application name embedded in it
        # FIXME: need to discuss
}

### 
### Main start of script
###

# suck in environment variables
. ./env.sh

# set up project directories, where it was deployed
TPLUS_HOME=`cygpath -m /cygdrive/c/build/$GIMS/tplus/release`
FXPLUS_HOME=`cygpath -m /cygdrive/c/build/$GIMS/fxplus/release`
FXOP_HOME=`cygpath -m /cygdrive/c/build/$GIMS/fxplusoptions/release`

ABORT_TOOL=0

if [[ $DEPLOY_VPD = "Y" ]]; then
    # generate patches, finally, runtime ksh scripts
    ANT_ARGS="-Djustgen=true -Dvpd=true -Dvpdhome=$TPLUS_HOME/vpd -Dabfxenv=abfx-$ENVIRONMENT"
    ( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS patch )
    if [[ $? -ne 0 ]]; then
        echo "FAILED: could not make runtime patches for profile: $PROFILE" 
        echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
        echo `date` " $0 finished with errors" 
        set_abort;
    fi
    check_abort;
fi

# generate patches, finally, runtime ksh scripts
for LAYER in dbag
do
        PROFILE="abfx-$ENVIRONMENT/$LAYER"

        # check needed property files
        validate_environment;
        check_abort;

        # default ant args
        ANT_ARGS="-Djustgen=true -Dabfxenv=abfx-$ENVIRONMENT -Dvpdhome=$TPLUS_HOME/vpd"
        
        if [[ "$DEPLOY_TPLUS" = "Y" ]]; then
                ANT_ARGS="$ANT_ARGS -Dtplus=true -Dtplushome=$TPLUS_HOME/sql"
        fi

        if [[ "$DEPLOY_FXPLUS" = "Y" ]]; then
                ANT_ARGS="$ANT_ARGS -Dfxplus=true -Dfxplushome=$FXPLUS_HOME/sql"
        fi

        if [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]] && [[ "$LAYER" = "dbag" ]]; then
                ANT_ARGS="$ANT_ARGS -Doptions=true -Doptionshome=$FXOP_HOME/sql"
        fi

        ANT_ARGS="$ANT_ARGS -Dlayerids=${PROFILE}"
        echo "Running patch target with options: $ANT_ARGS"
        ( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS patch )
        if [[ $? -ne 0 ]]; then
                echo "FAILED: could not make runtime patches for profile: $PROFILE" 
                echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
                echo `date` " $0 finished with errors" 
                set_abort;
        fi
        check_abort;

done
# end
