#!/bin/sh
#
# $Id: richclientwar.sh,v 1.36 2008/06/20 10:31:41 kovyale Exp $
#

. ./common.sh
. ./env.sh

echo " Starting richclient build for $WAR_PROFILES" >&3
date

# Make a rich client WAR file for each profile, and stick them in tplus/release/lib
for PROFILE in ${WAR_PROFILES}; do
	node=`echo $PROFILE | cut -d- -f1`
	pop=`echo $PROFILE | cut -d- -f2`
	fxop=`grep options.wlc.webcontent \
		$BUILD_HOME/$TAG/tplus/profiles/abfx-${ENVIRONMENT}/${PROFILE}.properties | cut -d= -f2`

	 echo " Building richclient for $PROFILE" >&3

	 (
	 cd $BUILD_HOME/$TAG/richclient/abrc-masterbuild
	 # reset args
	 DEFAULT_ARGS=""

	 # build rich client WAR
	 SKIN=$node

	 # small hack for DBSW
	 if [ "$SKIN" = "dbsw" ]; then
		  SKIN=dbag
	 fi

	 # BUG12477
	 if [ "$SKIN" = "dbag" ]; then
		  DEFAULT_ARGS="${DEFAULT_ARGS} -Dfxpricerinstaller=true"
		  DEFAULT_ARGS="${DEFAULT_ARGS} -Dfxoptions=true"
	 elif [ "$fxop" = "true" ]; then
		  DEFAULT_ARGS="${DEFAULT_ARGS} -Dfxoptions=true"
	 fi

	 # small hack for FXSPP
	 if [ "$PROFILE" = "dbag-sp1" ] || [ "$PROFILE" = "dbag-sp2" ]; then
		  DEFAULT_ARGS="${DEFAULT_ARGS} -Dskin=fxspp"
	 else
		  DEFAULT_ARGS="${DEFAULT_ARGS} -Dskin=${SKIN}"
	 fi

         # BUG-2474 - do not sign jars for daily builds
         if [ "$SIGN_RICHCLIENT_JARS" != "YES" ]; then
             DEFAULT_ARGS="${DEFAULT_ARGS} -Dnosign=true"
         fi
	 # Now run richclient build-war
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dinstaller=true"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dfxplus=true"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dinstall.anywhere.location=${INSTALL_ANYWHERE_LOCATION}"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dinstall4j.location=${INSTALL4J_LOCATION}"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dtplus.profile.directory=${ENVIRONMENT}"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dtplus.profile.node=${PROFILE}"
     DEFAULT_ARGS="${DEFAULT_ARGS} -Dtplus.profile.config=../../tplus/profiles/abfx-${ENVIRONMENT}/${PROFILE}.properties"	 
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dtplus.webservers.config=../../tplus/profiles/abfx-${ENVIRONMENT}/webservers.properties"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dbuild.tag.fxplus=$TAG"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -Dbuild.environment.name=$TAG"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -DtplusJar.storepass=${TPLUS_DEFAULT_TPLUSJAR_STOREPASS}"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -DtplusJar.keystore=${TPLUS_DEFAULT_TPLUSJAR_KEYSTORE}"
	 DEFAULT_ARGS="${DEFAULT_ARGS} -DtplusJar.alias=${TPLUS_DEFAULT_TPLUSJAR_ALIAS}"

	 #system property picked up by the installer
	 IA_PATH_ABRC_RICHCLIENT_DIR=${BUILD_HOME}/$TAG/richclient; export IA_PATH_ABRC_RICHCLIENT_DIR

	 ${ANT_BIN}/ant build-war ${DEFAULT_ARGS}
	 )
	 if [ "$?" -ne "0" ]; then
		  echo "FAILED" >&3
		  exit 1
	 fi

 	mv ${BUILD_HOME}/$TAG/richclient/abrc-masterbuild/dist/richclient.war $BUILD_HOME/$TAG/tplus/release/war/lib/richclient-${PROFILE}.war

done

date
echo " Done" >&3
