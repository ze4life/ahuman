#!/bin/sh
#
# $Id: baxters_compress_logs.sh,v 1.1 2007/08/09 09:08:40 kovyale Exp $
#

LOGSDIR="$HOME/server_logs"
if [ ! -d "$LOGSDIR" ]; then
    echo "Could not find $LOGSDIR"
    exit 1
fi

renice -n 19 $$

cd $HOME/server_logs
monitor_log=`ls -l monitor.log | cut -d">" -f 2`
monitor_log=`basename $monitor_log`
server_log=`ls -l server.log | cut -d">" -f 2`
server_log=`basename $server_log`
find . -type f -name "*.log" | grep -v "$monitor_log" | grep -v "$server_log" | xargs gzip
