#!/bin/sh
#
# $Id: StartProdUK.sh,v 1.10 2008/06/20 10:44:33 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# change directory to $HOME
cd $HOME

echo "=== Layer 1" >&3
# Start Layer1
SSH_USERHOST="$TPLUS_USERHOST"
startScript "tplus/deploy/dbag/bin/chatserver.sh"
startScript "tplus/deploy/dbag/bin/tserver.sh"
startScript "tplus/deploy/dbag/bin/authserver.sh"
startScript "fxplus/level_1/dbag/release/bin/dbmpProxy.sh"
startScript "fxplus/level_1/dbag/release/bin/emailserver.sh"
startScript "fxplus/level_1/dbag/release/bin/rmsbridge.sh"
startScript "fxplus/level_1/dbag/release/bin/gtbserver.sh"
startScript "fxplusoptions/bin/fxopserver.sh"
startScript "stp_fpml/level_1/dbag/release/bin/stpserver.sh"

SSH_USERHOST="$FXPLUS_USERHOST"
startScript "fxplus/level_1/dbag/release/bin/d2n.sh"
    echo "[1mPause before starting Core server (15 seconds)...[m" >&3
    sleep 15
startScript "fxplus/level_1/dbag/release/bin/ratefan.sh"
startScript "fxplus/level_1/dbag/release/bin/dedicated_ratefan.sh"
startScript "fxplus/level_1/dbag/release/bin/server.sh"
    echo "[1mPause before starting portal bridges (120 seconds)...[m" >&3
    sleep 120
startScript "fxplus/level_1/dbag/release/bin/fixserver.sh"
startScript "fxplus/level_1/dbag/release/bin/currenexbridge.sh"
startScript "fxplus/level_1/dbag/release/bin/fxallmdpibridge.sh"
startScript "fxplus/level_1/dbag/release/bin/fxalltcpibridge.sh"
startScript "fxplus/level_1/dbag/release/bin/cfetsbridge.sh"

SSH_USERHOST="$CFETS_SCS_USERHOST"
startScript "fxplus/cfets-scs/scripts/cfets-scs.sh"

echo "=== Layer 2" >&3
# Start Layer2
SSH_USERHOST="$WLC_USERHOST"
for wlc in $FXPLUS_LEVEL_2; do
	 startScript "tplus/deploy/$wlc/bin/tserver.sh"
	 startScript "tplus/deploy/$wlc/bin/authserver.sh"
	 startScript "fxplus/level_2/$wlc/release/bin/server.sh"
         if [ -d "stp_fpml/level_2/$wlc" ]; then
             # Some WLCs do not have stp
             startScript "stp_fpml/level_2/$wlc/release/bin/stpserver.sh"
         fi
done
if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
