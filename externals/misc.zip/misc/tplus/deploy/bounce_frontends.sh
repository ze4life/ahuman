#!/bin/sh

# env var
. ./env.sh

echo "About to perform the full bounce for $ENVIRONMENT frontend applications"
if [ -z "$BOUNCE_COFIRMED" ]; then
    echo "Please confirm (y/n):"
    read ans
    if [ "$ans" != "y" ] && [ "$ans" != "Y" ]; then
        echo "Cancelled."
        exit
    fi
fi
# remove old bouncers
rm bounce-*.sh
echo "Creating bouncers..."
./wcd/createbatches.sh wcd/bouncer.sh
echo "   done."
echo "Bouncing frontend servers..."
./wcd/applybatches.sh bouncer-*.sh
echo "   done."
