#!/bin/sh

### tplp1@cst-fjp1.uk.db.com

POP=bak
WLCS="dbag"
DIR_dbag="$HOME/webservers/orders2.fxplus.cib.intranet.db.com/apache_1.3.33/htdocs/orders2.fxplus.cib.intranet.db.com30052"

APP_DIRS="$HOME/nirvana/prod.internal \
$HOME/nirvana/prod.l1 \
$HOME/nirvana/prod.spot_rates \
$HOME/webservers/orders2.fxplus.cib.intranet.db.com"
