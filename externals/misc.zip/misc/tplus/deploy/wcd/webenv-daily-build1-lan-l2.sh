#!/bin/sh

### tplu1@cst-fju1.uk.db.com

POP=lan
WLCS="jybm aibk asia"
DIR_jybm="$HOME/webservers/fxdev1_L2_cst-fju1.uk.db.com/apache_1.3.33/htdocs/fxdev1l2a.uk.db.com10135"
DIR_aibk="$HOME/webservers/fxdev1_L2_cst-fju1.uk.db.com/apache_1.3.33/htdocs/fxdev1l2b.uk.db.com10147"
DIR_asia="$HOME/webservers/L2_fxop/apache_1.3.33/htdocs/cst-fju1.uk.db.com22094"

APP_DIRS="$HOME/nirvana/daily_build1.l2.shared \
$HOME/nirvana/daily_build1.fxop.asia \
$HOME/webservers/fxdev1_L2_cst-fju1.uk.db.com \
$HOME/webservers/L2_fxop"
