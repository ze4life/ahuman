#!/bin/sh
#
# $Id: webcontentdeployer.sh,v 1.35 2008/06/23 12:48:40 kovyale Exp $
#
# The webcontent deployment script.
# Will untar the attached tar archive at the end of 
# the script into the temporary directory,
# And redeploy the webcontent of the apache webservers.
#
# Uses the CR shell variable that is being defined by createpatches.sh
# And the webenv-$ENVIRONMENT sheel script

# redirrect stderr to stdout
exec 2>&1

DATE=`date +"%Y%m%d"`

# exit code
E_CODE=0

# find out the dirname
WORKDIR=`dirname $0` && cd $WORKDIR
if [ "$?" -ne "0" ]; then
	echo "Error, cat not find out and change to $WORKDIR"
	exit 1
fi

# need to have absolute pathnames
WORKDIR=`pwd`

TMPDIR="$WORKDIR/$DATE-$CR"

mkdir -p $TMPDIR
if [ "$?" -ne "0" ]; then
	echo "Error creating temporary directory $TMPDIR"
	exit 1
fi

# find the jar
if [ -x "$HOME/java/bin/jar" ]; then
	JAR="$HOME/java/bin/jar"
elif [ -x "$HOME/bin/jar" ]; then
	JAR="$HOME/bin/jar"
else
	JAR=`which jar`
fi
if [ ! -x "$JAR" ]; then
	# no jar tool here
	echo "Error could not find the jar tool"
	exit 1
fi
# find the diff
if [ -x "/bin/diff" ]; then
	DIFF="/bin/diff"
elif [ -x "/usr/bin/diff" ]; then
	DIFF="/usr/bin/diff"
else
	DIFF=`which diff`
fi
if [ ! -x "$DIFF" ]; then
	echo "WARNING: Could not find the diff tool, will redeploy the webcontent completely"
fi

# unpack itself
cat $0 | tail +$SKIP | ( cd $TMPDIR && tar xf - )
if [ "$?" -ne "0" ]; then
	echo "Error unpacking the archive"
	exit 1
fi

# WLCS are being setup in the correcsponding webenv
# deploy the webcontent
for node in $WLCS
do
        eval DIR=\$DIR_$node
	(
	 cd $DIR/app && \
	 for subdir in tplus richclient; do
	  if [ -f "$TMPDIR/$subdir-$node-$POP.war" ]; then
		  rm -rf $subdir-new 
		  mkdir  $subdir-new || exit 1
		  ( cd $subdir-new; $JAR xf $TMPDIR/$subdir-$node-$POP.war ) || exit 1
		  if [ ! -f "$subdir-pre-$CR.war" ]; then
			rm -rf $subdir-pre-*
			( cd $subdir ; $JAR cMf ../$subdir-pre-$CR.war . )
		  fi
		  if [ ! -x "$DIFF" ]; then
		  	rm -rf $subdir 
			mv $subdir-new $subdir
		  else
			( cd $subdir-new ; find . -type f ) | while read file; do
				update=''
				basename=`basename "$file" .jar`
				if [ ! -f "$subdir/$file" ]; then
					# file does not exist in the old webcontent
					update=1
				elif [ "$basename.jar" = "`basename \"$file\"`" ] && [ "$SIGN_RICHCLIENT_JARS" = "YES" ]; then
					pwd=`pwd`
					( mkdir -p $TMPDIR/$$.old && cd $TMPDIR/$$.old && \
						$JAR xf "$pwd/$subdir/$file" META-INF/MANIFEST.MF )
					if [ "$?" -ne "0" ]; then
						echo Could not extract old jar $pwd/$subdir/$file
						exit 1
					fi
					( mkdir -p $TMPDIR/$$.new && cd $TMPDIR/$$.new && \
						$JAR xf "$pwd/$subdir-new/$file" META-INF/MANIFEST.MF )
					if [ "$?" -ne "0" ]; then
						echo Could not extract new jar $pwd/$subdir-new/$file
						exit 1
					fi
					$DIFF $TMPDIR/$$.old/META-INF/MANIFEST.MF $TMPDIR/$$.new/META-INF/MANIFEST.MF \
								> /dev/null
					if [ "$?" -ne "0" ]; then
						update=1
					fi
					rm -rf $TMPDIR/$$.old $TMPDIR/$$.new
				else
					$DIFF "$subdir/$file" "$subdir-new/$file" > /dev/null
					if [ "$?" -ne "0" ]; then
						update=1
					fi
				fi
				if [ "$update" = "1" ]; then
					echo Updating file=$file
					dirname=`dirname "$file"`
					mkdir -p "$subdir/$dirname"
					if [ "$?" -ne "0" ]; then
						echo "Could not mkdir $subdir/$dirname"
						exit 1
					fi
					cp -fp "$subdir-new/$file" "$subdir/$file"
					if [ "$?" -ne "0" ]; then
						echo "Could not copy $subdir-new/$file $subdir/$file"
						exit 1
					fi
				fi
			done
			if [ "$?" -ne "0" ]; then
				exit 1
			fi
			rm -rf $subdir-new
		  fi
	  fi
	 done
	)
	if [ "$?" -ne "0" ]; then
		echo "Error deploying webcontent for $node"
		# do not exit on particular NODE, just pass error higher
		E_CODE=1
	fi
done

# bounce the webserver
# this assumes that we have one apache instance for L1
# and one for all WLCs. And we have separated patches for L1 and L2
for node in $WLCS
do
        eval DIR=\$DIR_$node
	webserverdir=`cd $DIR/../../.. && pwd`
	if [ "$lastdir" != "$webserverdir" ]; then
		if [ -d "$webserverdir" ]; then
			( 
			 cd "$webserverdir" && ./stop
			 rm -rf jakarta-tomcat-*/work/Standalone
			 ./start
			)
			if [ "$?" -ne "0" ]; then
				echo "Warning bouncing webserver returns not zero"
				E_CODE=1
			fi
		fi
			lastdir="$webserverdir"
	fi
done

# remove TMPDIR
rm -rf $TMPDIR

# remove self
#rm -f $0

# create uninstaller
UNINSTALLER_SH="$WORKDIR/uninstall_`basename $0`"
cat > "$UNINSTALLER_SH" <<EOF
#!/bin/sh
CR=$CR
POP=$POP
WLCS="$WLCS"
echo 
echo "   !!! WARNING !!!   "
echo 
echo "This script is going to revert changes made by CR/TAG=$CR"
echo 
echo "Are you sure? (y/n)"
read sure
if [ "\$sure" != "y" ]; then
	echo "Not uninstalling CR/TAG=$CR"
	exit
fi
EOF
for node in $WLCS
do
        eval DIR=\$DIR_$node
	echo "DIR_$node=\"$DIR\"" >> "$UNINSTALLER_SH"
done
cat >> "$UNINSTALLER_SH" <<EOF
set -x
for node in \$WLCS
do
        eval DIR=\\\$DIR_\$node
	(
	 cd \$DIR/app && \\
	 for subdir in tplus richclient; do
		mkdir \$subdir-pre-\$CR && \\
		(cd \$subdir-pre-\$CR && $JAR xf ../\$subdir-pre-\$CR.war) && \\
		rm -rf \$subdir && \\
		mv \$subdir-pre-\$CR \$subdir
	 done
	)
	if [ "\$?" -ne "0" ]; then
		echo "Error uninstalling webcontent for \$node"
	fi
done
EOF
chmod +x "$UNINSTALLER_SH"

# leave
exit $E_CODE

#ATTACHED TAR ARCHIVE
