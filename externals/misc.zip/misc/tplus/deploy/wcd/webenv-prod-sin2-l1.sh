#!/bin/sh

### abfxint@singmfxwbp2.sg.db.com

POP=sin2
WLCS="dbag"

APP_DIRS="$HOME/mychannels/prod.l1 \
$HOME/mychannels/prod.l1.api"
