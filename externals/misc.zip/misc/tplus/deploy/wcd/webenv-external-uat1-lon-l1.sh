#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=lon
WLCS="dbag"
DIR_dbag="$HOME/webservers/extuat1.l1/apache_1.3.33/htdocs/uat1-autobahnfx.db.com31514"

APP_DIRS="$HOME/nirvana/extuat1.l1 \
$HOME/webservers/extuat1.l1"

STPFIXDIR="$HOME/fix/stp-fix"
IAPIFIXDIR="$HOME/fix/iapi-fix"
