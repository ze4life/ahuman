#!/bin/sh

### tpint@longmeappp22.uk.db.com

STPFIXDIR="$HOME/fix/stp-fix"
IAPIFIXDIR="$HOME/fix/iapi-fix"
