#!/bin/sh 

### tprad@longmeappp23.uk.db.com

POP=vpn
WLCS="shin bcvg pbzg jybm aibk okoh sabx nbcm"
DIR_shin="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/forex-vpn.shinseibank.com31374"
DIR_bcvg="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/fxvpn.bcv.ch31574"
DIR_pbzg="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/ifx.pbz.hr32104"
DIR_jybm="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/jyskefx.jyskebank.dk31424"
DIR_aibk="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/www.internal.aibmarkets.com31404"
DIR_okoh="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/www.internal.fxplus.op.fi31444"
DIR_sabx="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/www.sfcforex.sfcvpn.com31544"
DIR_nbcm="$HOME/webservers/prod.l2.shared/apache_1.3.33/htdocs/radianz.fx.bnc.ca32144"

APP_DIRS="$HOME/mychannels/prod.l2a \
$HOME/mychannels/prod.l2a \
$HOME/webservers/prod.l2.shared"
