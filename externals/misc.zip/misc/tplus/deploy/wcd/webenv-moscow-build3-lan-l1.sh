#!/bin/sh

### abfx3@goldtpus39.ru.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build3.l1/apache/htdocs/goldtpus39.ru.db.com20033"

APP_DIRS="$HOME/mychannels/moscow_build3.internal
          $HOME/mychannels/moscow_build3.l1
          $HOME/mychannels/moscow_build3.l2
          $HOME/mychannels/moscow_build3.fxop.asia
          $HOME/webservers/moscow_build3.l1"
