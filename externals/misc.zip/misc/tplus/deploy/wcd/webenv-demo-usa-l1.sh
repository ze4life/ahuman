#!/bin/sh

### abfxint@nyggmabfxp1-adm.us.db.com

POP=usa
WLCS="dbag"
DIR_dbag="$HOME/webservers/demo-autobahnfx.us.db.com/apache/htdocs/demo-autobahnfx.us.db.com30012"

APP_DIRS="$HOME/mychannels/demo.l1 \
$HOME/webservers/demo-autobahnfx.us.db.com"
