#!/bin/sh
POP=lan
WLCS="aibk bcvg jybm okoh pbzg sabx shin dbsw nbcm bjss jpmp efgz lodh ubpg"

DIR_jybm="$HOME/webservers/moscow_build2.l2.jybm/apache_1.3.33/htdocs/goldtpus39.ru.db.com10440"
DIR_aibk="$HOME/webservers/moscow_build2.l2.aibk/apache_1.3.33/htdocs/goldtpus39.ru.db.com10449"
DIR_sabx="$HOME/webservers/moscow_build2.l2.sabx/apache_1.3.33/htdocs/goldtpus39.ru.db.com10458"
DIR_bcvg="$HOME/webservers/moscow_build2.l2.bcvg/apache_1.3.33/htdocs/goldtpus39.ru.db.com10467"
DIR_okoh="$HOME/webservers/moscow_build2.l2.okoh/apache_1.3.33/htdocs/goldtpus39.ru.db.com10503"
DIR_shin="$HOME/webservers/moscow_build2.l2.shin/apache_1.3.33/htdocs/goldtpus39.ru.db.com10524"
DIR_pbzg="$HOME/webservers/moscow_build2.l2.pbzg/apache_1.3.33/htdocs/goldtpus39.ru.db.com10544"
DIR_dbsw="$HOME/webservers/moscow_build2.l2.dbsw/apache_1.3.33/htdocs/goldtpus39.ru.db.com15111"
DIR_nbcm="$HOME/webservers/moscow_build2.l2.nbcm/apache_1.3.33/htdocs/goldtpus39.ru.db.com10601"
DIR_jpmp="$HOME/webservers/moscow_build2.l2.jpmp/apache_1.3.33/htdocs/goldtpus39.ru.db.com22116"
DIR_bjss="$HOME/webservers/moscow_build2.l2.bjss/apache_1.3.33/htdocs/goldtpus39.ru.db.com22111"
DIR_efgz="$HOME/webservers/moscow_build2.l2.efgz/apache_1.3.33/htdocs/goldtpus39.ru.db.com10631"
DIR_lodh="$HOME/webservers/moscow_build2.l2.lodh/apache_1.3.33/htdocs/goldtpus39.ru.db.com10632"
DIR_ubpg="$HOME/webservers/moscow_build2.l2.ubpg/apache_1.3.33/htdocs/goldtpus39.ru.db.com10633"

APP_DIRS=" \
$HOME/nirvana/moscow_build2.l2.fxop \
$HOME/nirvana/moscow_build2.l2a \
$HOME/webservers/moscow_build2.l2.jybm \
$HOME/webservers/moscow_build2.l2.aibk \
$HOME/webservers/moscow_build2.l2.sabx \
$HOME/webservers/moscow_build2.l2.bcvg \
$HOME/webservers/moscow_build2.l2.okoh \
$HOME/webservers/moscow_build2.l2.shin \
$HOME/webservers/moscow_build2.l2.pbzg \
$HOME/webservers/moscow_build2.l2.dbsw \
$HOME/webservers/moscow_build2.l2.nbcm \
$HOME/webservers/moscow_build2.l2.jpmp \
$HOME/webservers/moscow_build2.l2.bjss \
$HOME/webservers/moscow_build2.l2.efgz \
$HOME/webservers/moscow_build2.l2.lodh \
$HOME/webservers/moscow_build2.l2.ubpg \
"
