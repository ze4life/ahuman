#!/bin/sh

### tplu7@cst-fju1.uk.db.com

POP=lan
WLCS="dbsw prtr"
DIR_prtr="$HOME/webservers/demo.l2.shared/apache_1.3.33/htdocs/cst-fju1.uk.db.com22012"
DIR_dbsw="$HOME/webservers/demo.l2.shared/apache_1.3.33/htdocs/demo.pwmabfx.gm.cib.intranet.db.com22082"

APP_DIRS="$HOME/nirvana/demo.l2 \
$HOME/webservers/demo.l2.shared"
