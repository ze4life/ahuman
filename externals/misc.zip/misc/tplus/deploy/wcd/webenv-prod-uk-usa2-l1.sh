#!/bin/sh

### tpint@nyggmabfxp2.uk.db.com

POP=usa2
WLCS="dbag"

APP_DIRS="$HOME/mychannels/prod.l1.api \
$HOME/mychannels/prod.l1b"
