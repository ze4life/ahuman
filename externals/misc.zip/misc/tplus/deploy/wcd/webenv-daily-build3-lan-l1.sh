#!/bin/sh

### tplu3@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/fxdev3L1.uk.db.com_10347/apache_1.3.33/htdocs/fxdev3l1.uk.db.com10347"

APP_DIRS="$HOME/nirvana/internal \
$HOME/nirvana/l1 \
$HOME/nirvana/l1b \
$HOME/webservers/fxdev3L1.uk.db.com_10347"
