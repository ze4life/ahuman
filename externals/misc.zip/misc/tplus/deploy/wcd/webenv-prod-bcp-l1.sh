#!/bin/sh

### tpint@longmeappp23.uk.db.com

POP=bcp
WLCS="dbag"
DIR_dbag="$HOME/webservers/prod.l1/apache_1.3.33/htdocs/www.autobahnfxdr.db.com30204"

APP_DIRS="$HOME/mychannels/prod.l1a \
$HOME/mychannels/prod.l1.api \
$HOME/mychannels/prod.l1b \
$HOME/mychannels/prod.l1c \
$HOME/mychannels/prod.stp.fpml \
$HOME/webservers/prod.l1"
