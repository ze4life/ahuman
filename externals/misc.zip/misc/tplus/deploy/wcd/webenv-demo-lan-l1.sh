#!/bin/sh

### tplu7@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/demo.l1/apache_1.3.33/htdocs/demo.autobahnfx.cib.intranet.db.com8181"

APP_DIRS="$HOME/nirvana/demo.internal \
$HOME/nirvana/demo.l1 \
$HOME/webservers/demo.l1"
