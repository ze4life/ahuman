#!/bin/sh
set -x
if [ -z "$SKIP" ]; then
    echo "Attached archive line offset SKIP is not defined"
    echo "Will not proceed"
    exit 1
fi
E_CODE=0
TMPDIR=`pwd`/tmp.$$
mkdir -p $TMPDIR
cat $0 | tail +$SKIP | ( cd $TMPDIR && tar xvf -)
if [ "$?" -ne "0" ]; then
    echo "Error unpacking the archive"
    exit 1
fi
for app in $APP_DIRS
do
    # protection for local internal realm
    if echo $app | grep -i internal ; then
        continue
    fi
    # skip stp realms
    if echo $app | grep -i stp ; then
        continue
    fi
    # skip chat realms
    if echo $app | grep -i chat ; then
        continue
    fi
    # skip prod.spot_rates realm local realm
    if echo $app | grep -i prod.spot_rates ; then
        continue
    fi
    if [ -d "$app/data/RealmSpecific/" ]; then
        ( cd $app
          ./stop
          cp -p $TMPDIR/* data/RealmSpecific/
        )
        if [ $? -ne 0 ]; then
            echo "Could not copy $TMPDIR/* for $app"
            E_CODE=1
        fi
        ( cd $app
          ./start
        )
        if [ $? -ne 0 ]; then
            echo "Could not start $app"
            E_CODE=1
        fi
    fi
done
rm -rf $TMPDIR
exit $E_CODE
#ATTACHED TAR ARCHIVE
