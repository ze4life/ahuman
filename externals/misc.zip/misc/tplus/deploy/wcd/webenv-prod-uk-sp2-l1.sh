#!/bin/sh

### tpintra@longmfxsappp2.uk.db.com

POP=sp2
WLCS="dbag"
DIR_dbag="$HOME/webservers/abfxsp.pwm.intranet.db.com/apache/htdocs/abfxsp.pwm.intranet.db.com21052"

APP_DIRS="$HOME/mychannels/prod.l1 \
$HOME/webservers/abfxsp.pwm.intranet.db.com"
