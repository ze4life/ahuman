#!/bin/sh

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/layer1/apache_1.3.33/htdocs/loninengd82.uk.db.com20007"

APP_DIRS="$HOME/mychannels/layer1 \
$HOME/mychannels/internal \
$HOME/webservers/layer1"
