#!/bin/sh

### tpintra@longmfxsappp2

POP=lan2
WLCS="dbag"
DIR_dbag="$HOME/webservers/bcp.orders.fxplus.cib.intranet.db.com/apache_1.3.33/htdocs/bcp.orders.fxplus.cib.intranet.db.com30052"

APP_DIRS="$HOME/mychannels/data2.orders.fxplus.cib.intranet.db.com \
$HOME/webservers/bcp.orders.fxplus.cib.intranet.db.com"
