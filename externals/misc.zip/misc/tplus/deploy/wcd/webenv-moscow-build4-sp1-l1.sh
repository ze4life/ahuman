#!/bin/sh

POP=sp1
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build4.l1.pwm/apache/htdocs/goldtpus39.ru.db.com20185"
APP_DIRS="$HOME/webservers/moscow_build4.l1.pwm"
