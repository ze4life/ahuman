#!/bin/sh

### abfx1@goldtpus39.ru.db.com

POP=lan
WLCS="jybm nbcm"
DIR_jybm="$HOME/webservers/moscow_build1.l2.jybm/apache/htdocs/goldtpus39.ru.db.com10135"
DIR_nbcm="$HOME/webservers/moscow_build1.l2.nbcm/apache/htdocs/goldtpus39.ru.db.com10147"

APP_DIRS="$HOME/mychannels/moscow_build1.l2 \
$HOME/webservers/moscow_build1.l2.jybm
$HOME/webservers/moscow_build1.l2.nbcm"
