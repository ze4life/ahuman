#!/bin/sh

### tpintra@longmfxsappp1

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/orders.fxplus.cib.intranet.db.com/apache/htdocs/orders.fxplus.cib.intranet.db.com30052"

APP_DIRS="$HOME/mychannels/data.orders.fxplus.cib.intranet.db.com \
$HOME/webservers/orders.fxplus.cib.intranet.db.com"
