#!/bin/sh

### abfxint@singmfxwbp2-o.sg.db.com

POP=sin
WLCS="dbag"
DIR_dbag="$HOME/webservers/demo.autobahnfx.ap.db.com/apache_1.3.33/htdocs/demo.autobahnfx.ap.db.com31324"

APP_DIRS="$HOME/mychannels/demo.l1 \
$HOME/webservers/demo.autobahnfx.ap.db.com"
