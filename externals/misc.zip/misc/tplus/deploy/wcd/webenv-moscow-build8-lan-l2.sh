#!/bin/sh

POP=lan
WLCS="jybm nbcm"
DIR_jybm="$HOME/webservers/moscow_build8.l2.jybm/apache/htdocs/goldtpus39.ru.db.com28135"
DIR_nbcm="$HOME/webservers/moscow_build8.l2.nbcm/apache/htdocs/goldtpus39.ru.db.com28147"

APP_DIRS="$HOME/mychannels/moscow_build8.l2
$HOME/webservers/moscow_build8.l2.jybm
$HOME/webservers/moscow_build8.l2.nbcm"
