#!/bin/sh

### tpintra@longmfxsappp2

POP=lan2
WLCS="dbsw"
DIR_dbsw="$HOME/webservers/bcp.pwmabfx.gm.cib.intranet.db.com/apache_1.3.33/htdocs/bcp.pwmabfx.gm.cib.intranet.db.com20429"

APP_DIRS="$HOME/mychannels/data2.pwmabfx.gm.cib.intranet.db.com \
$HOME/webservers/bcp.pwmabfx.gm.cib.intranet.db.com"
