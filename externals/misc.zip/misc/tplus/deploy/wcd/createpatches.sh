#!/bin/sh
#
# $Id: createpatches.sh,v 1.35 2008/06/23 12:46:05 kovyale Exp $
#
# The script will create the self-extracting patch file
#
# alexey,kovyrshin@db.com

CR=$1
if [ -z "$CR" ]; then
	echo "Use: $0 <CRXXXXX | TAG-NAME>"
	exit 1
fi

# need to include the environment file to get the WAR_PROFILES
. ./common.sh
. ./env.sh

# exit code, let's try to do as much as possible
E_CODE=0

# sort out webcontent file per pop
for profile in $WAR_PROFILES; do
	pop=`echo $profile | cut -d "-" -f 2`
	node=`echo $profile | cut -d "-" -f 1`

	if [ "$node" = "dbag" ] ; then
		layer=l1
	else
		layer=l2
	fi

	# skip dbag-cit
	if [ "$pop" = "cit" ]; then
		continue
	fi

	# create if not exists directory per pop
	test -d webcontent-$pop-$layer || mkdir -p webcontent-$pop-$layer

	# copy appropriative webcontent archive to pop dir
#	if [ -f "$BUILD_HOME/$TAG/tplus/release/war/lib/richclient-$node-$pop.war" ]; then
#		# this is not autodeploy but looks like the patch build
#		cp -p $BUILD_HOME/$TAG/tplus/release/war/lib/richclient-$node-$pop.war webcontent-$pop-$layer
#		if [ "$?" -ne "0" ]; then
#			echo "ERROR: Could not copy $BUILD_HOME/$TAG/tplus/release/war/lib/richclient-$node-$pop.war to webcontent-$pop-$layer" >&3
#			E_CODE=1
#			# in the patch build exit here with error
#			exit $E_CODE
#		fi
#	else
		# this is autodeploy
		cp -p $HOME/tplus/deploy/web-content/richclient-$node-$pop.war webcontent-$pop-$layer
		if [ "$?" -ne "0" ]; then
			echo "ERROR: Could not copy $HOME/tplus/deploy/web-content/richclient-$node-$pop.war to webcontent-$pop-$layer" >&3
			E_CODE=1
		fi
		cp -p $HOME/tplus/deploy/web-content/tplus-$node-$pop.war webcontent-$pop-$layer 
		if [ "$?" -ne "0" ]; then
			echo "ERROR: Could not copy $HOME/tplus/deploy/web-content/tplus-$node-$pop.war to webcontent-$pop-$layer" >&3
			E_CODE=1
		fi
		
#	fi
done

# roll the tar files
for dir in webcontent-*; do
	pop=`echo $dir | cut -d "-" -f2`
	layer=`echo $dir | cut -d "-" -f3`

	(
	cd $dir
        envu=`echo $ENVIRONMENT | tr "-" "_" `
	tar cf ../webpatch-$envu-$pop-$layer.tar .
	)
	if [ "$?" -ne "0" ]; then
		echo "ERROR: Could not create webcontent-$pop-$layer.tar using directory $dir" >&3
		E_CODE=1
	fi
	
	# remove the webcontent dir to save the disk space
	rm -rf $dir
done


# now create the patchers
for tar in webpatch-*.tar; do
	filename=`basename $tar .tar`
	pop=`echo $filename | cut -d "-" -f3`
	layer=`echo $filename | cut -d "-" -f4`

	# calculate SKIP
	SKIP=`( echo "set -x" ; echo SKIP=$SKIP ; echo CR=$CR ; SIGN_RICHCLIENT_JARS=$SIGN_RICHCLIENT_JARS ; cat wcd/webenv-$ENVIRONMENT-$pop-$layer.sh wcd/webcontentdeployer.sh ) | wc -l `
	SKIP=`expr $SKIP + 1`
	( echo "set -x" ; echo SKIP=$SKIP ; echo CR=$CR ; SIGN_RICHCLIENT_JARS=$SIGN_RICHCLIENT_JARS ; cat wcd/webenv-$ENVIRONMENT-$pop-$layer.sh wcd/webcontentdeployer.sh $tar ) > $filename.sh
	if [ "$?" -ne "0" ]; then
		echo "ERROR: Could not create $filename.sh" >&3
		rm $filename.sh
		E_CODE=1
	else
		chmod +x $filename.sh
	fi
	# remove the tar for space save
	rm $tar
done

# exit with status
if [ "$E_CODE" -ne "0" ]; then
	echo "Some errors have appeared, check $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
