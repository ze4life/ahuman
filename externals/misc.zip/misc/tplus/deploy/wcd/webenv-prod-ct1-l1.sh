#!/bin/sh
#
# clrtrust@longmeappp12.uk.db.com
#

APP_DIRS="$HOME/ctrust55"
