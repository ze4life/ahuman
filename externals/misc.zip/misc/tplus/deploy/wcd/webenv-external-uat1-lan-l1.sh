#!/bin/sh

### tplu4@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/extuat1.l1/apache_1.3.33/htdocs/cst-fju1.uk.db.com21012"

APP_DIRS="$HOME/mychannels/extuat1.internal \
$HOME/mychannels/extuat1.l1 \
$HOME/webservers/extuat1.l1"
