#!/bin/sh

### tprad@longmeappp22.uk.db.com

POP=vpn
WLCS="dbag"
DIR_dbag="$HOME/webservers/prod.l1/apache/htdocs/www.autobahnfx.dbvpn.com31464"

APP_DIRS="$HOME/mychannels/prod.l1a \
$HOME/mychannels/prod.stp.fpml \
/export/apps/tpint/mychannels/prod.chat \
$HOME/webservers/prod.l1"

STPFIXDIR="$HOME/fix/stp-fix"
IAPIFIXDIR="$HOME/fix/iapi-fix"
