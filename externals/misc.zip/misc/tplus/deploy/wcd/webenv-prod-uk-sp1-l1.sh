#!/bin/sh

### tpintra@longmfxsappp1.uk.db.com

POP=sp1
WLCS="dbag"
DIR_dbag="$HOME/webservers/abfxsp.pwm.intranet.db.com/apache/htdocs/abfxsp.pwm.intranet.db.com21052"

APP_DIRS="$HOME/mychannels/prod.l1 \
$HOME/webservers/abfxsp.pwm.intranet.db.com"
