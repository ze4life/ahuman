#!/bin/sh
E_CODE=0
for app in $APP_DIRS
do
    if [ -d "$app" ]; then
        # check the state if monitor script exist
        if [ -x "$app/monitor" ]; then
            (cd $app && ./monitor)
            if [ $? -ne 0 ]; then
                echo 
                echo "DOWN: Application $app is not running!"
                echo 
                E_CODE=1
            else
                echo "UP: $app"
            fi
        else
            echo 
            echo "   ERROR: Could not find monitor script for $app"
            echo 
            E_CODE=1
        fi
    else
        echo
        echo "   ERROR: Could not find $app directory"
        echo 
        E_CODE=1
    fi
done
if [ -n "$STPFIXDIR" ]; then
    if [ -d "$STPFIXDIR/bin" ]; then
        ( cd $STPFIXDIR/bin && ./stp-fix-tunnel.sh stats >/dev/null 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "DOWN: STPFIX tunnel at `hostname`:$STPFIXDIR is down"
            E_CODE=1
        else
            echo "UP: STPFIX tunnel at `hostname`:$STPFIXDIR is up"
        fi
    fi
fi
if [ -n "$IAPIFIXDIR" ]; then
    if [ -d "$IAPIFIXDIR/bin" ]; then
        ( cd $IAPIFIXDIR/bin && ./fixtunnel.sh stats >/dev/null 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "DOWN: IAPIFIX tunnel at `hostname`:$IAPIFIXDIR is down"
            E_CODE=1
        else
            echo "UP: IAPIFIX tunnel at `hostname`:$IAPIFIXDIR is up"
        fi
        ( cd $IAPIFIXDIR/bin && ./fixfan.sh stats >/dev/null 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "DOWN: IAPIFIX fan at `hostname`:$IAPIFIXDIR is down"
            E_CODE=1
        else
            echo "UP: IAPIFIX fan at `hostname`:$IAPIFIXDIR is up"
        fi
    fi
fi
exit $E_CODE
