#!/bin/sh
set -x
if [ -z "$SKIP" ]; then
    echo "Attached archive line offset SKIP is not defined"
    echo "Will not proceed"
    exit 1
fi
E_CODE=0
TMPDIR=`pwd`/tmp.$$
mkdir -p $TMPDIR
cat $0 | tail +$SKIP | ( cd $TMPDIR && tar xvf -)
if [ "$?" -ne "0" ]; then
    echo "Error unpacking the archive"
    exit 1
fi
for app in $APP_DIRS
do
    find $app -name fx-abrc.jar | while read f
do 
    ( cp -p $f $f.preABFX5268 && cp -p $TMPDIR/fx-abrc.jar $f )
        if [ $? -ne 0 ]; then
            E_CODE=1
        fi
    done
done
rm -rf $TMPDIR
exit $E_CODE
#ATTACHED TAR ARCHIVE
