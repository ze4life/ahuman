#!/bin/sh
#set -x
E_CODE=0
for app in $APP_DIRS
do
    if [ -d "$app" ]; then
        ( 
        cd $app 
        ./stop
        ./start
        ) 
        if [ $? -ne 0 ]; then
            echo 
            echo "ERROR: Could not start $app"
            echo 
            E_CODE=1
        fi
        # check the state if monitor script exist
        if [ -x "$app/monitor" ]; then
            (cd $app && ./monitor)
            if [ $? -ne 0 ]; then
                echo
                echo "ERROR: Application $app is not running!"
                echo
                E_CODE=1
            fi
        fi
    else
        echo
        echo "ERROR: Could not find $app directory"
        echo
        E_CODE=1
    fi
done
if [ -n "$STPFIXDIR" ]; then
    if [ -d "$STPFIXDIR/bin" ]; then
        ( cd $STPFIXDIR/bin && ./stp-fix-tunnel.sh stop )
        if [ $? -ne 0 ]; then
            echo ERROR: stp-fix-tunnel.sh stop returns not zero
            E_CODE=1
        fi
        ( cd $STPFIXDIR/bin && ./stp-fix-tunnel.sh start )
        if [ $? -ne 0 ]; then
            echo ERORR: Could not start stp-fix-tunnel.sh
            E_CODE=1
        fi
    fi
fi
if [ -n "$IAPIFIXDIR" ]; then
    if [ -d "$IAPIFIXDIR/bin" ]; then
        ( cd $IAPIFIXDIR/bin && ./fixtunnel.sh stop )
        if [ $? -ne 0 ]; then
            echo ERROR: fixtunnel.sh stop returns not zero
            E_CODE=1
        fi
        ( cd $IAPIFIXDIR/bin && ./fixfan.sh stop )
        if [ $? -ne 0 ]; then
            echo ERROR: fixfan.sh stop returns not zero
            E_CODE=1
        fi
        ( cd $IAPIFIXDIR/bin && ./fixtunnel.sh start )
        if [ $? -ne 0 ]; then
            echo ERORR: Could not start fixtunnel.sh
            E_CODE=1
        fi
        ( cd $IAPIFIXDIR/bin && ./fixfan.sh start )
        if [ $? -ne 0 ]; then
            echo ERORR: Could not start fixfan.sh
            E_CODE=1
        fi
    fi
fi
exit $E_CODE
