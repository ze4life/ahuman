#!/bin/sh

### tplu1@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/fxdev1_L1_cst-fju1.uk.db.com/apache_1.3.33/htdocs/fxdev1l1.uk.db.com10132"

APP_DIRS="$HOME/nirvana/daily_build1.l1 \
$HOME/nirvana/daily_build1.internal \
$HOME/webservers/fxdev1_L1_cst-fju1.uk.db.com"
