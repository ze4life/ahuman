#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=lon
WLCS="dbag"
DIR_dbag="$HOME/webservers/daily-build2.l1/apache_1.3.33/htdocs/euro2504c5049.autobahnfx.db.com31354"

APP_DIRS="$HOME/nirvana/daily-build2.l1 \
$HOME/webservers/daily-build2.l1"
