#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=lon
WLCS="dbag"
DIR_dbag="$HOME/webservers/demo.l1/apache/htdocs/demo.autobahnfx.db.com8443"

APP_DIRS="$HOME/nirvana/demo.l1 \
$HOME/nirvana/demo.stp \
$HOME/webservers/demo.l1"
