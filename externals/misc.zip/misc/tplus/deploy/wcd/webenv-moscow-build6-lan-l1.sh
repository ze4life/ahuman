#!/bin/sh

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build6.l1/apache/htdocs/goldtpus39.ru.db.com20607"

APP_DIRS="
$HOME/nirvana/moscow_build6.l1
$HOME/nirvana/moscow_build6.internal
$HOME/webservers/moscow_build6.l1
"
