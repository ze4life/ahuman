#!/bin/sh
POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build2.l1/apache_1.3.33/htdocs/goldtpus39.ru.db.com10431"

APP_DIRS="$HOME/nirvana/moscow_build2.internal \
$HOME/nirvana/moscow_build2.l1a \
$HOME/nirvana/moscow_build2.l1b \
$HOME/webservers/moscow_build2.l1"
