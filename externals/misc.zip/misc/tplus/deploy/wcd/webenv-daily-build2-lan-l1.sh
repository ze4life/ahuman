#!/bin/sh

### tplu2@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/L1_fxdev2L1.uk.db.com_10385/apache_1.3.33/htdocs/fxdev2l1.uk.db.com10385"

APP_DIRS="$HOME/nirvana3/internal_10380 \
$HOME/nirvana3/dbag_10382 \
$HOME/nirvana3/dbag_10579 \
$HOME/nirvana3/dbag_10582 \
$HOME/webservers/L1_fxdev2L1.uk.db.com_10385"
