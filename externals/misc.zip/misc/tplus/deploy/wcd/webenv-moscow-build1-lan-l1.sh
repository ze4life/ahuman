#!/bin/sh

### abfx1@goldtpus39.ru.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build1.l1/apache/htdocs/goldtpus39.ru.db.com10132"

APP_DIRS="$HOME/mychannels/moscow_build1.l1 \
$HOME/mychannels/moscow_build1.internal \
$HOME/webservers/moscow_build1.l1"
