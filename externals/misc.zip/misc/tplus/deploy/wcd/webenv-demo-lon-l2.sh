#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=lon
WLCS="aibk shin bcvg okoh jybm nbcm pbzg sabx prtr"
DIR_nbcm="$HOME/webservers/demo.l2.shared/apache/htdocs/demo.fx.bnc.ca30012"
DIR_shin="$HOME/webservers/demo.l2.shared/apache/htdocs/demo-forex.shinseibank.com8443"
DIR_aibk="$HOME/webservers/demo.l2.shared/apache/htdocs/demo.aibmarkets.com8443"
DIR_bcvg="$HOME/webservers/demo.l2.shared/apache/htdocs/fxdemo.bcv.ch8443"
DIR_jybm="$HOME/webservers/demo.l2.shared/apache/htdocs/demo.jyskefx.dk8443"
DIR_okoh="$HOME/webservers/demo.l2.shared/apache/htdocs/demo.fxtreasurynet.oko.fi8443"
DIR_prtr="$HOME/webservers/demo.l2.shared/apache/htdocs/www.fxwhitelabel.com8443"
DIR_sabx="$HOME/webservers/demo.l2.shared/apache/htdocs/www.demo.sfcforex.com8443"
DIR_pbzg="$HOME/webservers/demo.l2.shared/apache/htdocs/fxdemo.pbz.hr30002"

APP_DIRS="$HOME/nirvana/demo.l2 \
$HOME/nirvana/demo.l2.vpn \
$HOME/webservers/demo.l2.shared"
