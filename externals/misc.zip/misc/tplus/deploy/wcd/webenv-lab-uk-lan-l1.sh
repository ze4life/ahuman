#!/bin/sh
### abfxu1@abfxu1.uk.db.com
POP="lan"
WLCS="dbag"
DIR_dbag="$HOME/webservers/abfxu1.uk.db.com/apache_1.3.33/htdocs/abfxu1.uk.db.com20004"
APP_DIRS="$HOME/mychannels/internal $HOME/mychannels/external $HOME/webservers/abfxu1.uk.db.com"
