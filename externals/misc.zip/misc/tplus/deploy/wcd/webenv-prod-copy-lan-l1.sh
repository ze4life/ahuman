#!/bin/sh

### tplu5@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/prodcopy.l1/apache_1.3.31/htdocs/cst-fju1.uk.db.com10431"

APP_DIRS="$HOME/nirvana/prodcopy.internal \
$HOME/nirvana/prodcopy.l1a \
$HOME/nirvana/prodcopy.l1b \
$HOME/nirvana/prodcopy.stp.fpml \
$HOME/webservers/prodcopy.l1"
