#!/bin/sh
#
# $Id: applybatches.sh,v 1.23 2008/06/04 13:33:23 kovyale Exp $
#
# The script will upload and run the batch file on the frontend box.
#
# alexey,kovyrshin@db.com

# environment variables
. ./common.sh
. ./env.sh

# certificate based auth
DEPLOYKEY=wcd/deployer/deployer.key
DELPOYCERT=wcd/deployer/deployer.crt
CACERT=wcd/deployer/generic-ca.crt

# The list of the batch files
BATCH_FILES=$*
if [ -z "$BATCH_FILES" ]; then
    echo "No batch files provided" >&3
    echo "Please use: $0 FILE1 [FILE2]..." >&3
    exit 1
fi

# load the list of dmz hsots
. ./wcd/dmzhosts.sh
if [ "$?" -ne "0" ]; then
    echo "Error loading the DMZ hosts list file" >&3
    exit 1
fi

local_batch() {
    batch=$1

    sh $batch
    return $?
}
remote_batch() {
    batch=$1
    hostport=$2

    ./wcd/deployer/deployer.pl -f $batch -h $hostport -a $CACERT -c $DELPOYCERT -k $DEPLOYKEY
    return $?
}

# do as much as posible. just pass the error code to the end
E_CODE=0

# send batches to DMZ
for batch in $BATCH_FILES
do
    pop=`basename $batch .sh | cut -d "-" -f3`
    layer=`basename $batch .sh | cut -d "-" -f4`
    envu=`echo $ENVIRONMENT | tr "-" "_"`

    if [ -n "`echo $pop | grep \"^lan\"`" ] && [ "$ENVIRONMENT" != "prod-uk" ]; then 

        echo "Running local $batch" >&3
        local_batch $batch >&3
        if [ $? -ne 0 ]; then
            echo "ERROR running $batch" >&3
            E_CODE=1
        fi

    elif [ -n "`echo $pop | grep \"^bak\"`" ]; then 

        echo "Running local $batch" >&3
        local_batch $batch >&3
        if [ $? -ne 0 ]; then
            echo "ERROR running $batch" >&3
            E_CODE=1
        fi

    else

        eval hostport=\$${envu}_${pop}_${layer}
        if [ -n "$hostport" ]; then
            echo "Uploading $batch to $hostport" >&3
            remote_batch $batch $hostport >&3
            if [ $? -ne 0 ]; then
                echo "ERROR running $batch" >&3
                E_CODE=1
            fi

        else
            echo "No host and port defined for ${envu}_${pop}_${layer}" >&3
            echo "Possible missing the ${envu}_${pop}_${layer}= in the wcd/dmzhosts.sh" >&3
            echo "$batch is SKIPPED" >&3
            E_CODE=1
        fi

    fi
done

if [ "$E_CODE" -ne "0" ]; then
    echo "The error occured running some batch files, please check $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi

# exit with code
exit $E_CODE
