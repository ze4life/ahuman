#!/bin/sh

### abfxint@singmfxwbp1.sg.db.com

POP=sin
WLCS="dbag"
DIR_dbag="$HOME/webservers/www.autobahnfx.ap.db.com/apache_1.3.33/htdocs/www.autobahnfx.ap.db.com31294"

APP_DIRS="$HOME/mychannels/prod.l1 \
$HOME/webservers/www.autobahnfx.ap.db.com"
