#!/bin/sh

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build8.l1/apache/htdocs/goldtpus39.ru.db.com28132"

APP_DIRS="$HOME/mychannels/moscow_build8.l1 \
$HOME/mychannels/moscow_build8.internal \
$HOME/webservers/moscow_build8.l1"
