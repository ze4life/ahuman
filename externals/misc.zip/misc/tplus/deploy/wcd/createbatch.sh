#!/bin/sh
#
# $Id: createbatch.sh,v 1.4 2007/12/04 08:12:49 kovyale Exp $
#

# env vars
. ./common.sh
. ./env.sh

WEBENVFILE=$1
ACTION_SCRIPT=$2

if [ -z "$WEBENVFILE" ] || [ -z "$ACTION_SCRIPT" ]; then
    echo "This script is designed to create the self-extracting shell script for the particular webenv profile" >&3
    echo "Please use:" >&3
    echo "$0 <path/to/webenv_file> <path/to/action_script> [path/to/tar_file]" >&3
    exit 1
fi

if [ ! -f "$WEBENVFILE" ]; then
    echo "Could not find the webenv profile: $WEBENVFILE" >&3
    exit 1
fi

if [ ! -f "$ACTION_SCRIPT" ]; then
    echo "Could not find the action script: $ACTION_SCRIPT" >&3
    exit 1
fi

ACTION=`basename $ACTION_SCRIPT .sh`

# the second param is exists must be the name of tar archive
# the archive must be located in $HOME/deploy/wcd
TAR_ARCHIVE=$3
if [ -n "$TAR_ARCHIVE" ]; then
    if [ ! -f "$TAR_ARCHIVE" ]; then
        echo "Could not find $TAR_ARCHIVE" >&3
        exit 1
    else
        # redefine archive name icluding wcd diretory
        TAR_ARCHIVE="$TAR_ARCHIVE"
    fi
fi

# exit code, let's try to do as much as possible
E_CODE=0

envu=`echo $ENVIRONMENT | tr "-" "_"`
filename="$ACTION-`basename $WEBENVFILE .sh | sed -e s/webenv-$ENVIRONMENT/$envu/`"

# calculate SKIP
SKIP=`( echo "#!/bin/sh" ; echo SKIP=$SKIP ; cat $WEBENVFILE $ACTION_SCRIPT ) | wc -l`
SKIP=`expr $SKIP + 1`

( echo "#!/bin/sh" ; echo SKIP=$SKIP ; cat $WEBENVFILE $ACTION_SCRIPT $TAR_ARCHIVE ) > $filename.sh
if [ $? -ne 0 ]; then
    echo "ERROR: Could not create $filename.sh" >&3
    rm $filename.sh
    E_CODE=1
else
    chmod +x $filename.sh
fi
exit $E_CODE
