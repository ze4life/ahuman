#!/bin/sh

### abfxp2@abfxp2.uk.db.com

POP=bak
WLCS="dbag"
DIR_dbag="$HOME/webservers/abfxp2.uk.db.com_30052/apache_1.3.33/htdocs/abfxp2.uk.db.com30052"

APP_DIRS="$HOME/mychannels/prod.internal \
$HOME/mychannels/prod.l1 \
$HOME/webservers/abfxp2.uk.db.com_30052"
