#!/bin/sh

### tplu4@cst-fju1.uk.db.com

POP=lan
WLCS="dbsw"
DIR_dbsw="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/cst-fju1.uk.db.com21203"

APP_DIRS="$HOME/mychannels/extuat1.l2.shared \
$HOME/webservers/extuat1.l2.shared"
