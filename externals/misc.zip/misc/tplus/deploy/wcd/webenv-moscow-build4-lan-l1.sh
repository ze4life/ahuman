#!/bin/sh

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/moscow_build4.l1/apache/htdocs/goldtpus39.ru.db.com20107"

APP_DIRS="$HOME/nirvana/moscow_build4.l1 \
$HOME/nirvana/moscow_build4.internal \
$HOME/webservers/moscow_build4.l1"
