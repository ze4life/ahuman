#!/bin/sh
#
# $Id: createbatches.sh,v 1.11 2008/06/04 13:33:23 kovyale Exp $
#

# env vars
. ./common.sh
. ./env.sh

# exit code, let's try to do as much as possible
E_CODE=0

# apps-prod-lan-l1.sh
for WEBENVFILE in wcd/webenv-$ENVIRONMENT-*.sh
do
        ./wcd/createbatch.sh $WEBENVFILE $*
        if [ "$?" -ne "0" ]; then
            E_CODE=1
        fi

done

# exit with status
exit $E_CODE
