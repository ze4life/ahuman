#!/bin/sh
IAPIFIXDIR="$HOME/fix/api-fix/ssl"
