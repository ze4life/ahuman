#!/bin/sh
#
# clrtrust@longmeappp13.uk.db.com
#

APP_DIRS="$HOME/ctrust55"
