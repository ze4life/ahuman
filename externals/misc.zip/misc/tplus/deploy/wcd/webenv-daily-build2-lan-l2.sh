#!/bin/sh

### tplu2@cst-fju1.uk.db.com

POP=lan
WLCS="jybm bcvg asia"
DIR_jybm="$HOME/webservers/L2_fxdev2L2.shared/apache_1.3.33/htdocs/fxdev2l2a.uk.db.com10394"
DIR_bcvg="$HOME/webservers/L2_fxdev2L2.shared/apache_1.3.33/htdocs/fxdev2l2b.uk.db.com10403"
DIR_asia="$HOME/webservers/L2_asia/apache_1.3.33/htdocs/cst-fju1.uk.db.com22086"

APP_DIRS="$HOME/nirvana3/asia_22089 \
$HOME/nirvana3/bcvg_10400 \
$HOME/nirvana3/jybm_10391 \
$HOME/webservers/L2_fxdev2L2.shared \
$HOME/webservers/L2_asia"
