#!/bin/sh

### tpint@nyggmabfxp1.uk.db.com

POP=usa
WLCS="dbag"
DIR_dbag="$HOME/webservers/www.autobahnfx.us.db.com/apache/htdocs/www.autobahnfx.us.db.com30002"

APP_DIRS="$HOME/mychannels/prod.l1 \
$HOME/webservers/www.autobahnfx.us.db.com"
