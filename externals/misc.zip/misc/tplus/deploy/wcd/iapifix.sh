#!/bin/sh
set -x
if [ -z "$SKIP" ]; then
    echo "Attached archive line offset SKIP is not defined"
    echo "Will not proceed"
    exit 1
fi
E_CODE=0
TMPDIR=`pwd`/tmp.$$
mkdir -p $TMPDIR
cat $0 | tail +$SKIP | ( cd $TMPDIR && cat > fix-tunnel-fan.tar )
if [ "$?" -ne "0" ]; then
    echo "Error unpacking the archive"
    exit 1
fi
# DEPLOY STP-FIX TAR HERE
mkdir -p $IAPIFIXDIR

if [ -f "$IAPIFIXDIR/bin/fixtunnel.sh" ]; then
    ( cd $IAPIFIXDIR/bin && ./fixtunnel.sh stop ) 
fi
if [ -f "$IAPIFIXDIR/bin/fixfan.sh" ]; then
    ( cd $IAPIFIXDIR/bin && ./fixfan.sh stop ) 
fi

( cd $IAPIFIXDIR && rm -rf bin  etc  keystore  lib )

( cd $IAPIFIXDIR && tar xvf $TMPDIR/fix-tunnel-fan.tar )
if [ "$?" -ne "0" ]; then
    echo Could not deploy fix-tunnel-fan.tar
    exit 1
fi
( cd $IAPIFIXDIR/bin && chmod +x *.sh )
if [ "$?" -ne "0" ]; then
    echo "Could not chmod +x $IAPIFIXDIR/bin/*.sh"
    E_CODE=1
fi

rm -rf $TMPDIR
exit $E_CODE
#ATTACHED TAR ARCHIVE
