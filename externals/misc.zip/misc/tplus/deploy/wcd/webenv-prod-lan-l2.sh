#!/bin/sh

### tpintra@longmfxsappp1

POP=lan
WLCS="dbsw"
DIR_dbsw="$HOME/webservers/www.pwmabfx.gm.cib.intranet.db.com/apache_1.3.33/htdocs/www.pwmabfx.gm.cib.intranet.db.com20429"

APP_DIRS="$HOME/mychannels/data.pwmabfx.gm.cib.intranet.db.com \
$HOME/webservers/www.pwmabfx.gm.cib.intranet.db.com"
