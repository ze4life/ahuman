#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=lon
WLCS="nbcm shin aibk bcvg jybm okoh prtr pbzg sabx asia jpmp bjss ubpg"
DIR_nbcm="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/amer14f43444e.autobahnfx.db.com31734"
DIR_sbhk="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/asia15443494c.autobahnfx.db.com31614"
DIR_shin="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/asia154494a4f.autobahnfx.db.com31694"
DIR_aibk="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro1424a434c.autobahnfx.db.com31554"
DIR_bcvg="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro143445748.autobahnfx.db.com31594"
DIR_jybm="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro14b5a434e.autobahnfx.db.com31534"
DIR_okoh="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro1504c5049.autobahnfx.db.com31654"
DIR_prtr="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro151535553.autobahnfx.db.com31574"
DIR_pbzg="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro151435b48.autobahnfx.db.com31974"
DIR_sabx="$HOME/webservers/extuat1.l2.shared/apache_1.3.33/htdocs/euro154424359.autobahnfx.db.com31674"
DIR_asia="$HOME/webservers/extuat1.l2.aspacdcd/apache_1.3.33/htdocs/asia2484c4850.autobahnfx.db.com31434"
DIR_jpmp="$HOME/webservers/extuat1.l2.aspacdcd/apache_1.3.33/htdocs/euro249574759.autobahnfx.db.com31474"
DIR_bjss="$HOME/webservers/extuat1.l2.aspacdcd/apache_1.3.33/htdocs/euro251435b48.autobahnfx.db.com31494"
DIR_ubpg="$HOME/webservers/extuat1.l2.aspacdcd/apache_1.3.33/htdocs/euro24550514d.autobahnfx.db.com31914"

APP_DIRS="$HOME/nirvana/extuat1.l2.aspacdcd \
$HOME/nirvana/extuat1.l2.jpmp \
$HOME/nirvana/extuat1.l2.shared \
$HOME/webservers/extuat1.l2.shared \
$HOME/webservers/extuat1.l2.aspacdcd"
