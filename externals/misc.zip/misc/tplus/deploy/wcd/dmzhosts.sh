#!/bin/sh
#
# $Id: dmzhosts.sh,v 1.44 2008/10/15 11:28:06 kovyale Exp $
#
# the file contains only the list of dmz hosts
# to be used by the fileuploader
# the format is:
#  env_pop_layer=host:port
# example:
#  prod_sin_l1=10.171.73.59:31111

#
# PRODUCTION
#
# Singapore two nodes
prod_sin_l1=singmfxwbp1-lower.sg.db.com:31111
prod_sin2_l1=singmfxwbp2-lower.sg.db.com:31111
# New York
prod_usa_l1=nyggmabfxp1.us.db.com:30111
prod_usa2_l1=nyggmabfxp2.us.db.com:30111
prod_uk_abfxint_hbrgmabfxp1=hbrgmabfxp1.us.db.com:30111
# L1 London Internet and Radianz
prod_vpn_l1=longmeappp22-int-v1.uk.db.com:31111
prod_bcp_l1=longmeappp23-int-v1.uk.db.com:31111
prod_lon_l1=longmeappp24-out-v1.uk.db.com:31111
prod_vdr_l1=longmeappp25-out-v1.uk.db.com:31111
# L2 London Internet and Radianz
prod_vpn_l2=longmeappp23-int-v1.uk.db.com:32222
prod_lon_l2=longmeappp25-out-v1.uk.db.com:32222
# these for stp fix internet tunnels
prod_tpint_longmeappp22=longmeappp22-int-v1.uk.db.com:31112
prod_tpint_longmeappp25=$prod_lon_l2
# Intranet (LAN and FXSPP) L1 and L2
prod_sp1_l1=longmfxsappp1.uk.db.com:31111
prod_sp2_l1=longmfxsappp2.uk.db.com:31111
prod_lan_l1=$prod_sp1_l1
prod_lan_l2=$prod_sp1_l1
prod_lan2_l1=$prod_sp2_l1
prod_lan2_l2=$prod_sp2_l1
# Prod ClearTrust for the bounce
prod_ct1_l1=longmeappp12-int.uk.db.com:5621
prod_ct2_l1=longmeappp13-int.uk.db.com:5621
prod_ct3_l1=abfxp2.uk.db.com:20483
#
# PRODUCTION UK
#
# Singapore two nodes
prod_uk_sin_l1=singmfxwbp1-lower.sg.db.com:31111
prod_uk_sin2_l1=singmfxwbp2-lower.sg.db.com:31111
# New York
prod_uk_usa_l1=nyggmabfxp1.us.db.com:30111
prod_uk_usa2_l1=nyggmabfxp2.us.db.com:30111
prod_uk_abfxint_hbrgmabfxp1=hbrgmabfxp1.us.db.com:30111
# L1 London Internet and Radianz
prod_uk_vpn_l1=longmeappp22-int-v1.uk.db.com:31111
prod_uk_bcp_l1=longmeappp23-int-v1.uk.db.com:31111
prod_uk_lon_l1=longmeappp24-out-v1.uk.db.com:31111
prod_uk_vdr_l1=longmeappp25-out-v1.uk.db.com:31111
# L2 London Internet and Radianz
prod_uk_vpn_l2=longmeappp23-int-v1.uk.db.com:32222
prod_uk_lon_l2=longmeappp25-out-v1.uk.db.com:32222
# these for stp fix internet tunnels
prod_uk_tpint_longmeappp22=longmeappp22-int-v1.uk.db.com:31112
prod_uk_tpint_longmeappp25=$prod_lon_l2
# Intranet (LAN and FXSPP) L1 and L2
prod_uk_sp1_l1=longmfxsappp1.uk.db.com:31111
prod_uk_sp2_l1=longmfxsappp2.uk.db.com:31111
prod_uk_lan_l1=$prod_sp1_l1
prod_uk_lan_l2=$prod_sp1_l1
prod_uk_lan2_l1=$prod_sp2_l1
prod_uk_lan2_l2=$prod_sp2_l1
# Prod ClearTrust for the bounce
prod_uk_ct1_l1=longmeappp12-int.uk.db.com:5621
prod_uk_ct2_l1=longmeappp13-int.uk.db.com:5621
prod_uk_ct3_l1=abfxp2.uk.db.com:20483
#
# DEMO
#
demo_sin_l1=$prod_sin2_l1
demo_usa_l1=$prod_usa_l1
demo_lon_l1=longmeappu1a1-intv100.uk.db.com:31111
demo_vpn_l1=$demo_lon_l1
demo_lon_l2=$demo_lon_l1
demo_vpn_l2=$demo_lon_l1

#
# EXT UAT
#
external_uat1_lon_l1=$demo_lon_l1
external_uat1_lon_l2=$demo_lon_l1
external_uat1_abfxint_nyggmabfxp3=nyggmabfxp3.us.db.com:30111
external_uat1_abfxu1_abfxu1=abfxu1.us.db.com:31111

#
# PROD COPY
#
prod_copy_ct1_l1=cst-fju1.uk.db.com:31111
prod_copy_abfxu3_abfxu1=abfxu1.us.db.com:31113
prod_copy_abfxu3_abfxu1_fixip=$prod_copy_abfxu3_abfxu1
prod_copy_abfxu3_abfxu1_sslip=$prod_copy_abfxu3_abfxu1


#
# DAILY BUILDs
#
daily_build1_ct1_l1=$prod_copy_ct1_l1
daily_build2_ct1_l1=$prod_copy_ct1_l1
daily_build2_lon_l1=$demo_lon_l1
daily_build2_abfxu2_abfxu1=abfxu1.us.db.com:31112
daily_build2_abfxu2_abfxu1_fixip=$daily_build2_abfxu2_abfxu1
daily_build2_abfxu2_abfxu1_sslip=$daily_build2_abfxu2_abfxu1
daily_build3_lon_l1=$demo_lon_l1
daily_build3_ct1_l1=$prod_copy_ct1_l1

#
# MOSCOW BUILDs
#
moscow_build4_sp1_l1=goldtpus39.ru.db.com:31111
