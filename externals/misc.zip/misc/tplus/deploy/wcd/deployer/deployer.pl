#!/usr/bin/perl
# 
# $Id: deployer.pl,v 1.14 2007/07/02 09:37:16 fxplusAutoBuild Exp $
#
# The deployer script. To run:
# deployer.pl -d -h cst-fju1.uk.db.com:4433 -f deployer.sh -a generic-ca.crt -c deployer.crt -k deployer.key
#
# Using openssl as SSL tunnel wrapper. Quite ugly bu we do not have the access to install SSL perl modules
# on the DMZ hosts.
#
# alexey.kovyrshin@db.com

$buflen=8192; # must be in the SAME as on other size!
$timeout=30;

use IPC::Open3;
use Getopt::Std;
use File::Basename;

getopts("df:h:a:c:k:");

$debug=$opt_d;
$filename=$opt_f;
$hostport=$opt_h;
$CAcert=$opt_a;
$deploycert=$opt_c;
$deploykey=$opt_k;

unless ( $filename and $hostport and $CAcert and $deploycert and $deploykey ) {
	 print "Usage: $0 [-d] -f file -h host:port -a CAcert -c cert -k key\n";
	 print "   -d   debug mode\n";
	 print "   -f   file The archive file to send and execute\n";
	 print "   -h   host:port This specifies the host and port to connect to.\n";
	 print "   -a   the path to CA certificate file\n";
	 print "   -c   the path to deployer certificate file\n";
	 print "   -k   the path to deployer key  file\n";
	 exit 1;
} 

$filebasename=basename($filename);

unless ( -f $filename ) {
	 print "Could not find $filename: $!\n";
	 exit 1;
}

sub date {
	 my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	 $year+=1900;
	 return sprintf("%02d-%02d-%d %02d:%02d:%02d",$mday,$mon,$year,$hour,$min,$sec);
}

sub exitonsignal {
	 my $signame = shift;
	 print "Exiting on $signame signal...\n";
	 sleep 3;
	 kill 15, $OPENSSLPID;
	 exit 1;
}
$SIG{INT} = \&exitonsignal;
$SIG{PIPE} = \&exitonsignal;


# start the ssl tunnel
$OPENSSLPID = open3(\*W, \*R, \*E, "openssl s_client -connect $hostport -quiet -CAfile $CAcert -verify 0 -cert $deploycert -key $deploykey");
if ( $@ ) {
	 print $!, "\n";
}

eval {
	 local $SIG{ALRM} = sub { die "alarm\n" };
	 alarm $timeout;
	 $answer=<R>;
	 alarm 0;
};
if ($@ eq "alarm\n") {
	 print  "Timeout wating for the hello string.\n";
	 # well i know the goto is bad. but in this case it is good, belive me :)
	 goto EERR;
}

if ($answer=~/hello .*, ready for file upload/) {
	 # get the md5 checksum 
	 my $pid=open(MD5, "openssl md5 < $filename |");
	 unless ($pid) {
		  print "MD5 ERROR: $!\n";
		  goto EERR;
	 }
	 my $md5=<MD5>; chomp($md5);
	 close(MD5);

	 # get the size
	 my $size= -s $filename; 

	 # open it
	 my $rs=open(F, "$filename");
	 unless ($rs) {
		  print "Error opening $filename: $!\n";
		  goto EERR;
	 }

	 # request upload
	 print W "FILEUPLOAD NAME=$filebasename SIZE=$size MD5=$md5\n";
	 eval {
		  local $SIG{ALRM} = sub { die "alarm\n" };
		  alarm $timeout;
		  $answer=<R>;
		  alarm 0;
	 };
	 if ($@ eq "alarm\n") {
		  print  "Timeout wating for the FILEUPLOAD command reply.\n";
		  goto EERR;
	 }

	 unless ($answer eq "FILEUPLOAD NAME=$filebasename SIZE=$size MD5=$md5 OK\n") {
		  print "FILEUPLOAD command reply error: $answer\n";
		  close(F);
		  goto EERR;
	 }

	 
	 while(my $r=sysread(F, $buf, $buflen)) {
		  syswrite(W, $buf, $r);
	 }
	 close(F);

	 eval {
		  local $SIG{ALRM} = sub { die "alarm\n" };
		  alarm $timeout;
		  $answer=<R>;
		  alarm 0;
	 };
	 if ($@ eq "alarm\n") {
		  print  "Timeout wating for the file upload confirmation.\n";
		  goto EERR;
	 }
	 unless ($answer eq "FILEUPLOAD OK $md5\n") {
		  print "File upload failed: $answer\n";
		  goto EERR;
	 }

	 # ready to run file
	 print W "RUNFILE NAME=$filebasename\n";


	 # read line by line
	 while(1) {
		  eval {
				local $SIG{ALRM} = sub { die "alarm\n" };
				# here we need to wait for a long time while the script 
				# is working if we want to get the full output
				# so need some bigger timeout say like 5 mins
				alarm 300;
				$answer=<R>;
				alarm 0;
		  };
		  if ($@ eq "alarm\n") {
				print  "Timeout wating for the output of the shell script\n";
				goto EERR;
		  }

		  if ( $answer=~/^RUNFILE ERROR:/ ) {
				print "Error while running the scipt on remote side: $answer\n";
				goto EERR;
		  } elsif ( $answer=~/^RUNLOG: / ) {
				print "$answer";
		  } elsif ( $answer=~/^RUNFILE EXITSTATUS=(.*)$/ ) {
				my $exit_status=$1;
				if ( $exit_status == 0 ) {
					 print "$answer";
					 last;
				} else {
					 print "Patch sctipt exit status is not zero: $answer\n";
					 goto EERR;
				}
		  }
	 }
	 print W "BYE\n";
         #print "Alright\n";
} else {
	 print "WrongAnswer: $answer\n";
         goto EERR;
}

close W; close R; close E;
sleep 3;
kill 15, $OPENSSLPID;
sleep 3;
exit 0;

# exit with error
EERR:
print W "BYE\n";
close W; close R; close E;
sleep 3;
kill 15, $OPENSSLPID;
sleep 3;
exit 1;
