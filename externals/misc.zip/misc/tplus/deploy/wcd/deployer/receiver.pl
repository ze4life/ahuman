#!/usr/bin/perl
#
# $Id: receiver.pl,v 1.14 2006/07/29 10:45:41 kovyale Exp $
#
# The webpatches receiver and launcher
#
# Using openssl as SSL tunnel wrapper. Quite ugly bu we do not have the access to install SSL perl modules
# on the DMZ hosts.
#
# alexey.kovyrshin@db.com

# Defaults
$tmpdir="$ENV{HOME}/tmp";
$logfile="$ENV{HOME}/receiver.log";
$pidfile="$ENV{HOME}/receiver.pid";

# some techinal values
$timeout=30;
$buflen=8192;

use IPC::Open3;
use Getopt::Std;

getopts("t:p:l:da:b:c:k:i:");

$port=$opt_p;
$debug=$opt_d;
$skey=$opt_k;
$scert=$opt_c;
$CAcert=$opt_a;
if ( -e "$opt_b" ) { 
	# defined path to openssl binary
	$openssl=$opt_b;
} else {
	# default
	$openssl="openssl";
}

unless ( $port and $skey and $scert and $CAcert ) {
	print "Usage: $0 -p PORT -a CAcert -k key -c cert [-d] [-b path ] [-t tmpdir] [-l logfile] [-i pidfile]\n";
	print "\nIt is more stable to run it via honup $0 .... & command on linux\n\n";
	print "   -p   the portnumber to listen\n";
	print "   -b   full path to openssl binary\n";
	print "   -t   the path to the temporary directory, default is $tmpdir\n";
	print "   -l   the path to the logfile, default is $logfile\n";
	print "   -l   the path to the pidfile, default is $pidfile\n";
	print "   -d   debug mode, do not fork into background\n";
	print "   -a   the CA certificate file\n";
	print "   -k   the server key file\n";
	print "   -c   the sever certificate\n";
	exit;
}

if ( $opt_t ) {
	$tmpdir=$opt_t;
}

if ( $opt_l )  {
	$logfile=$opt_l;
}

if ( $opt_i )  {
	$pidfile=$opt_i;
}

sub date {
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	$year+=1900;
	return sprintf("%02d-%02d-%d %02d:%02d:%02d",$mday,$mon,$year,$hour,$min,$sec);
}

sub plog {
	my $msg=shift;
	   $msg=~s/[\r\n]//g; # strip off any CR or LF
	open  LOG, ">>$logfile" ;#or die "open: $logfile: $!";
	print LOG date(), " $msg\n";
	close LOG;
	if ($debug) { print "$msg\n"; }
}

sub exitonsignal {
	my $signame = shift;
	plog "Exiting on $signame signal...";
	if ($OPENSSLPID) {
		kill 15, $OPENSSLPID;
	}
	exit;
}
$SIG{INT} = \&exitonsignal;
$SIG{TERM} = \&exitonsignal;
$SIG{PIPE} = \&exitonsignal;

#save pid
open(PID, ">$pidfile");
print PID "$$";
close(PID);

plog "Receiver started: PID=$$, PORT=$port, TMPDIR=$tmpdir, LOGFILE=$logfile, PIDFILE=$pidfile";
plog "Using openssl=$openssl\n";

# accept and process connections
while ( 1 ) {
	if ( $OPENSSLPID ) {
		# close the old process descriptors
		close(W); close(R); close(E);
	}

	$OPENSSLPID=open3(\*W, \*R, \*E, "$openssl s_server -key $skey -cert $scert -accept $port -Verify 0 -CAfile $CAcert -quiet") ;

	$user='';
	$verify='';
	# this READ will hold untill found CN=
	while(<E>) {
		if ( /^depth=0 \/CN=([^\/]*)\//g ) {
			$user=$1;
			# read verify messages
			$verify=<E>;
			last;
		}
	}

	if ( $user ne "deployer" or $verify=~/^verify error/ ) {
		print W "Access denined\n";
		plog "Access denined\n";
		sleep 3;
		kill 15, $OPENSSLPID;
		next;
	}

	# be polite
	print W "hello $user, ready for file upload\n";

	# read command loop
	while(1) {
		# set alarm before the loop
		my $command='';
		eval {
			local $SIG{ALRM} = sub { die "alarm\n" }; 
			alarm $timeout;
			$command=<R>;
			alarm 0;
			chomp($command);
		};
		if ($@ eq "alarm\n") {
			# timed out
			plog "$user has timedout\n";
			goto ENDSESSION;
		}
			if ( $command=~/^FILEUPLOAD NAME=([^ ]*) SIZE=([^ ]*) MD5=([^ ]*)$/ ) {
				my $filename=$1; # proviede filename
				my $size=$2;	# the size
				my $md5=$3;	# checksum

				my $rs=open(FILE, ">$tmpdir/$filename");
				unless ($rs) {
					# any error with open for write return it the peer
					print W "FILEUPLOAD OPEN FOR WRITE ERROR: $!\n";
					next;
				}

				print W "FILEUPLOAD NAME=$filename SIZE=$size MD5=$md5 OK\n";

				my $chunks=int($size / $buflen);
				my $lastchunk=($size - ($chunks * $buflen));
				my $buf='';
				my $tr=0;
				do {
					my $r=sysread R,$buf,$buflen;
					syswrite(FILE,$buf,$buflen);
					$tr += $r;
				} while ($tr < $size);

				close(FILE);

				# get the md5 checksum and return it back
				my $pid=open(MD5, "$openssl md5 < $tmpdir/$filename |");
				unless ($pid) {
					print W "FILEUPLOAD MD5 ERROR: $!\n";
					goto ENDSESSION;
				}
				my $local_md5=<MD5>; chomp($local_md5);
				close(MD5);
				if ( $md5 ne $local_md5) {
					print W "FILEUPLOAD MD5 DOES NOT MATCH $local_md5\n";
					goto ENDSESSION;
				} else {
					print W "FILEUPLOAD OK $local_md5\n";
				}
			} elsif ( $command=~/^RUNFILE NAME=(.*)$/ ) {
				my $filename=$1;
				{
					local $SIG{PIPE} = 'IGNORE';
					$rs=open(RUN, "sh $tmpdir/$filename 2>&1 |");
					unless ($rs) {
						print W "RUNFILE ERROR: $!\n";
						next;
					}

					# read output, the stderr must be already redirected to stdout
					while(<RUN>) {
						print W "RUNLOG: $_";
					}

					# i want exit status in $?
					waitpid($rs, 0);
					print W "RUNFILE EXITSTATUS=$?\n";
					
					close(RUN);
				}
				next;
			} elsif ( $command eq "BYE" ) {
				# end of session
				goto ENDSESSION;
			} else {
				print W "Command $command not understood\n";
			}
	}

ENDSESSION:
	plog "endsession\n";
	sleep 3;
	kill 15, $OPENSSLPID;
	# read child status, no zombies
	waitpid($OPENSSLPID, 0);
}

