#!/bin/sh
set -x
E_CODE=0
for app in $APP_DIRS
do
    if [ -d "$app" ]; then
        if [ -f "$app/sec_file.txt" ]; then
            (cd $app
            echo abfxp2@abfxp2.uk.db.com >> sec_file.txt
            echo abfxp2@10.143.169.51 >> sec_file.txt
            ./start
            )
	fi
    else
        echo
        echo "ERROR: Could not find $app directory"
        echo
        E_CODE=1
    fi
done
exit $E_CODE
