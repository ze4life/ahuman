#!/bin/sh
IAPIFIXDIR="$HOME/fix/api-fix/ip"
