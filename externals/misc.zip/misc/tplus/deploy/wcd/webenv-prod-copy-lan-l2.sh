#!/bin/sh

### tplu5@cst-fju1.uk.db.com


POP=lan
WLCS="aibk bcvg jybm okoh pbzg sabx shin dbsw nbcm bjss jpmp efgz lodh ubpg"
DIR_jybm="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2a-jybm.uk.db.com10440"
DIR_aibk="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2b-aibk.uk.db.com10449"
DIR_sabx="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2c-sabx.uk.db.com10458"
DIR_bcvg="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2d-bcvg.uk.db.com10467"
DIR_okoh="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2f-okoh.uk.db.com10503"
DIR_shin="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2h-shin.uk.db.com10524"
DIR_pbzg="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2j-pbzg.uk.db.com10544"
DIR_dbsw="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/fxdev5l2p-dbsw.uk.db.com15111"
DIR_nbcm="$HOME/webservers/prodcopy.l2.shared/apache_1.3.31/htdocs/cst-fju1.uk.db.com10601"
DIR_jpmp="$HOME/webservers/prodcopy.l2.jpmp/apache_1.3.33/htdocs/cst-fju1.uk.db.com22116"
DIR_bjss="$HOME/webservers/prodcopy.l2.bjss/apache_1.3.33/htdocs/cst-fju1.uk.db.com22111"
DIR_efgz="$HOME/webservers/prodcopy.l2.efgz/apache_1.3.33/htdocs/cst-fju1.uk.db.com10631"
DIR_lodh="$HOME/webservers/prodcopy.l2.lodh/apache_1.3.33/htdocs/cst-fju1.uk.db.com10632"
DIR_ubpg="$HOME/webservers/prodcopy.l2.ubpg/apache_1.3.33/htdocs/cst-fju1.uk.db.com10633"

APP_DIRS="$HOME/nirvana/prodcopy.l2.fxop \
$HOME/nirvana/prodcopy.l2a \
$HOME/webservers/prodcopy.l2.shared \
$HOME/webservers/prodcopy.l2.jpmp \
$HOME/webservers/prodcopy.l2.bjss \
$HOME/webservers/prodcopy.l2.efgz \
$HOME/webservers/prodcopy.l2.lodh \
$HOME/webservers/prodcopy.l2.ubpg"
