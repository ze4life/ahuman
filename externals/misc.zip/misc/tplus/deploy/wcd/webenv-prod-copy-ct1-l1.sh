#!/bin/sh

### tpluct@cst-fju1.uk.db.com

APP_DIRS="$HOME/ctrust55"
