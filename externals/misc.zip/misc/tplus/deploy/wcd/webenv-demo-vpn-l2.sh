#!/bin/sh

### clrtrust@longmeappp18a1.uk.db.com

POP=vpn
WLCS="prtr"
DIR_prtr="$HOME/webservers/demo.l2.shared/apache/htdocs/www.fxwhitelabel.dbvpn.com8443"
