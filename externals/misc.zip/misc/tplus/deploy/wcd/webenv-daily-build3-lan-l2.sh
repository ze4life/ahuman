#!/bin/sh

### tplu3@cst-fju1.uk.db.com

POP=lan
WLCS="jybm bcvg asia"
DIR_jybm="$HOME/webservers/fxdev3L2_consolidated/apache_1.3.33/htdocs/fxdev3l2a.uk.db.com10356"
DIR_bcvg="$HOME/webservers/fxdev3L2_consolidated/apache_1.3.33/htdocs/fxdev3l2b.uk.db.com10365"
DIR_asia="$HOME/webservers/l2_fxop/apache_1.3.33/htdocs/cst-fju1.uk.db.com10652"

APP_DIRS="$HOME/nirvana/l2 \
$HOME/webservers/fxdev3L2_consolidated \
$HOME/webservers/l2_fxop"
