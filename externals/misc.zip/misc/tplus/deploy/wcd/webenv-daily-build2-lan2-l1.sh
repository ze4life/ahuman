#!/bin/sh

### tplu2@cst-fju1.uk.db.com

POP=lan2
WLCS="dbag"
DIR_dbag="$HOME/webservers/L1_fxdev2L1.uk.db.com_10385/apache_1.3.33/htdocs/fxdev2l1b.uk.db.com10585"
