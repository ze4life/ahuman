#!/bin/sh

### tpint@longmeappp25.uk.db.com

POP=lon
WLCS="shin bcvg pbzg okoh aibk jybm sabx nbcm bjss jpmp efgz lodh ubpg"
DIR_shin="$HOME/webservers/prod.l2.shared/apache/htdocs/forex.shinseibank.com30034"
DIR_bcvg="$HOME/webservers/prod.l2.shared/apache/htdocs/fx.bcv.ch30084"
DIR_pbzg="$HOME/webservers/prod.l2.shared/apache/htdocs/fx.pbz.hr30804"
DIR_okoh="$HOME/webservers/prod.l2.shared/apache/htdocs/fxtreasurynet.oko.fi30314"
DIR_aibk="$HOME/webservers/prod.l2.shared/apache/htdocs/www.aibmarkets.com30224-DISABLED"
DIR_jybm="$HOME/webservers/prod.l2.shared/apache/htdocs/www.jyskefx.com30244"
DIR_sabx="$HOME/webservers/prod.l2.shared/apache/htdocs/www.sfcforex.com30164"
DIR_nbcm="$HOME/webservers/prod.l2.shared/apache/htdocs/fx.bnc.ca30824"
DIR_bjss="$HOME/webservers/prod.l2.options/apache_1.3.33/htdocs/safra.autobahnfx.db.com30854"
DIR_jpmp="$HOME/webservers/prod.l2.options/apache_1.3.33/htdocs/jpmorgan.autobahnfx.db.com30864"
DIR_efgz="$HOME/webservers/prod.l2.options/apache_1.3.33/htdocs/efg.autobahnfx.db.com30064"
DIR_lodh="$HOME/webservers/prod.l2.options/apache_1.3.33/htdocs/lodh.autobahnfx.db.com30074"
DIR_ubpg="$HOME/webservers/prod.l2.options/apache_1.3.33/htdocs/ubpg.autobahnfx.db.com30874"

APP_DIRS="$HOME/mychannels/prod.l2a \
$HOME/mychannels/prod.l2b \
$HOME/mychannels/prod.chat \
$HOME/mychannels/prod.l2.options \
$HOME/webservers/prod.l2.shared \
$HOME/webservers/prod.l2.options"
