#!/bin/sh

### tplu9@cst-fju1.uk.db.com

POP=lan
WLCS="dbag"
DIR_dbag="$HOME/webservers/dbag_cst-fju1.uk.db.com_10067/apache_1.3.33/htdocs/cst-fju1.uk.db.com10067"

APP_DIRS="$HOME/nirvana/internal \
$HOME/nirvana/dbag.l1 \
$HOME/webservers/dbag_cst-fju1.uk.db.com_10067"
