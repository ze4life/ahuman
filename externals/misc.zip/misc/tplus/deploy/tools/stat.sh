#!/bin/sh
# $Id: stat.sh,v 1.3 2006/11/20 09:18:26 kovyale Exp $
# script to geather some stats for the box perfomance monitoring
#
#
#   Resource bottleneck threshold rules-of-thumb
#   
# This section attempts to establish rules-of-thumb to determine if important system resources are 
# on the verge of being a bottleneck and limiting server performance.
# 
# Disk bottlenecks
# 
# Disk bottlenecks are the most likely bottlenecks. Here are the thresholds you should look 
# for using the different monitoring tools.
# 
# Using iostat:
# 
#     * The significant bottleneck threshold is %b (percent time disk busy) > 20% AND (20 ms < svc_t (ServiceTime) < 30 ms)
#     * The critical bottleneck threshold is %b (percent time disk busy) > 20% AND ( svc_t (ServiceTime) > 30 ms)
# 
# Using vmstat:
# 
#     * A significant bottleneck threshold occurs if b (processes blocked for resources) approaches r (# in run queue)
#     * A critical bottleneck threshold occurs if b (processes blocked for resources) = or > r (# in run queue)
#   
#   Memory bottlenecks
#   
# Here are the memory bottleneck thresholds you should look for using the different monitoring tools.
# 
# According to the book, Sun performance and Tuning, Java and the Internet, 
# by Adrian Cockcroft and Richard Pettit, using vmstat:
# 
#     * A significant bottleneck threshold occurs if sr (free page scan rate) > 200 scans/second
#     * A critical bottleneck threshold occurs if sr (free page scan rate) > 300 scans/second
# 
# (Note that the last point could indicate thrashing because active and 
#  inactive pages will be stolen from the Process Working Set.)
# 
# You can also issue the command vmstat -s to show paging. The si and so columns are pages swapped in and out.
# 
#		Note however, that for Solaris 2.6 and 7 systems running Domino, we see very high scan rates, upwards of 4000 pages per second at the high end. Despite Cockcroft's guideline we think such rates are perfectly normal for an application that uses the file system heavily. Unfortunately, the high scanning rates caused by file system activity will completely mask any other scanning sources.
# The file system in Solaris 8 generates little or no page scanning. Any scanning that does occur must arise from somewhere else. A few bursts here and there are no cause for alarm, but sustained scanning probably means something's not right. Sustained scanning at low rates may mean that NSF_Buffer_Pool_Size should be reduced a little. Try reducing it in 50 MB steps. High rates may mean that more RAM is needed or that the system is very badly mistuned.
# 
# A low (relatively speaking) scan rate does not prove that you've got the optimal amount of RAM. Domino scales its own memory use to the RAM size and may avoid scanning and paging, but it might still benefit from larger caches and so on if more RAM were made available.
#   
#   CPU bottlenecks
#   
# Here are the CPU bottleneck thresholds you should look for using the different monitoring tools.
# 
# Using vmstat:
# 
#     * A significant bottleneck occurs if process r (run queue) is > 2 times the # of CPUs, and/or %CPU >75%
#     * A critical bottleneck occurs if "sy" (% CPU system time) is greater than .25 "us" (user/application % CPU time) and/or %CPU >85%
# 
# When you run "uptime" at the OS prompt, it gives the load average, which is the sum of the run queue length and number of jobs currently on the CPUs. It gives an average over 1 minute, 5 minute, and 15 minute periods. This can be used as an average run queue length to see if you need more CPU power.
#   
#   Network bottlenecks
#   
# Here are the network bottleneck thresholds you should look for using the different monitoring tools.
# 
# Using netstat, when collisions are greater than 5 percent of the packets sent, you are starting to experience network saturation. That is colls / packets >5%.
# 
# Remember that you will not have collisions if you have a switched network. In that case, you should determine if the byte rate is approaching saturation. If you are running Domino 6, you can use the Platform stat Platform.Network.#.PctUtilBandwidth. A value over 30 percent may indicate that the network is near saturation. If you are running R5, then you can compute the percent network utilization or obtain it from a network sniffer. The command netstat -i discussed previously, will give you output bytes and input bytes so that you can compute the percent utilization.
#

# iostat produces a lot of output
# to prevent possible disk space issue
# it is disabled by default
# set it to `true` to enable
iostat_enable=false

case $1 in
	 start)
		 for pid in vmstat iostat; do 
			  if [ -f "$pid.pid" ]; then
					PID=`head -1 $pid.pid`
					ME=`ps -ef | grep $PID | grep $LOGNAME | grep -v grep | grep $pid`
					if [ -n "$ME" ]; then
						 echo "$ME is running"
						 exit 0
					fi
			  fi
		 done
	 	nohup sh -c "while true ; do date +\"%d-%m-%Y %H:%M\" ; vmstat 5 12 ; done"  >> vmstat.log < /dev/null &
		echo $! > vmstat.pid

		if [ "$iostat_enable" = "true" ]; then
			case `uname -s` in 
				 Linux) 
				 	iostat_args="-x" 
				 	;; 
				 *) 
				 	iostat_args="-xtc" 
				 	;;
			esac
	
		 	nohup sh -c "while true ; do date +\"%d-%m-%Y %H:%M\" ; iostat $iostat_args 5 12 ; done"  >> iostat.log < /dev/null &
			echo $! > iostat.pid
		fi
	 ;;
	 stop)
		 for pid in vmstat iostat; do 
			  if [ -f "$pid.pid" ]; then
					PID=`head -1 $pid.pid`
					ME=`ps -ef | grep $PID | grep $LOGNAME | grep -v grep | grep $pid`
					if [ -n "$ME" ]; then
						 kill $PID
					fi
			  fi
		 done
		 ;;
	 *)
		 echo "Usage: $0 stop/start"
		 exit
		 ;;
esac
