#!/usr/bin/perl


use lib "/export/apps/tpint/perl/lib/perl5/site_perl/5.8.3/";
use File::Tail;
use Time::localtime;

#####
$|=1;
my $NirvanaDir=$ARGV[0];
die "Uzage: watchnirvana.pl <NirvanaDir>\n" unless $NirvanaDir;

my $logfile=$NirvanaDir."/data/nirvana.log";
my $pidfile=$NirvanaDir."/nirvana.pid";

$pid=`cat $pidfile `;
chomp $pid;

die "Invalid pid file $pidfile\n" unless ( $pid=~/^\d+$/);
die "$pidfile is out of date \n" unless ( kill 0 => $pid) ;

$counter = 0;
####

my $pattern1 = '^.*Security,UserManager: User (\S+) Logged In using.*$';
my $pattern2 = '^.*Security,Session established for (\S+) using.*$';

sub action {
        my $msg = shift;
        my $sent = shift;
        print "$msg\n";
        if(!$sent){
                kill 3 => $pid or die "Cannot send signal 3 to $pid\n";
        	die "Enough signals were sent\n" if ($counter++ > 10);
        }

}

my $ref = tie *FH, "File::Tail", (name => $logfile, maxinterval=>60, nowait => 1) or die "Cannot read $logfile\n";

my %users = ();
my $tm;

while (<FH>) {
        my $line = $_;
        if ($line =~s#$pattern1#$1#){
                chomp $line;
                $users{$line} = time();
                $tm = localtime($users{$line});
                printf("Logged in: %s Time: %04d-%02d-%02d %02d:%02d:%02d\n", $line,$tm->year+1900,$tm->mon+1, $tm->mday, $tm->hour, $tm->min, $tm->sec);
        } elsif ( $line=~s#$pattern2#$1#){
                chomp $line;
                $tm=localtime(time());
                printf("Session started: %s Time: %04d-%02d-%02d %02d:%02d:%02d\n", $line,$tm->year+1900,$tm->mon+1, $tm->mday, $tm->hour, $tm->min, $tm->sec);
                delete $users{$line};
        }

        my $sent = 0;
        for $i (keys %users){
                if ((time() - $users{$i}) > 60){
                        $tm=localtime($users{$i});
                        my $msg=sprintf('Timed out: %s, logged in: %04d-%02d-%02d %02d:%02d:%02d',$i, $tm->year+1900,$tm->mon+1, $tm->mday, $tm->hour, $tm->min, $tm->sec);
                        action $msg ;
                        $sent = 1;
                        delete $users{$i};
                }
        }

        if (!$line){
                sleep 5;
        }
}

