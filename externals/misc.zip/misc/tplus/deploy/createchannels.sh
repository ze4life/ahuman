#!/bin/sh
# $Id: createchannels.sh,v 1.25 2008/07/07 08:40:20 kovyale Exp $
#
# Create channels in one run
#

. ./common.sh
. ./env.sh

# create channels
if [ "$CREATE_CHANNELS" != "YES" ]; then
    exit 0
fi

# Look for the nirvana common directory
if [ -d "$HOME/nirvana" ]; then
    NIRVANA_DIR="$HOME/nirvana"
elif [ -d "$HOME/nirvana3" ]; then
    NIRVANA_DIR="$HOME/nirvana3"
elif [ -d "$HOME/mychannels" ]; then
    NIRVANA_DIR="$HOME/mychannels"
else
    Sendmail "Could not find \$HOME/nirvana or \$HOME/nirvana3 or \$HOME/mychannels" ""
    exit 0
fi

E_CODE=0

# Here we look for $NIRVANA_DIR/CreateChannelsRealm. 
# CreateChannelsRealm MUST BE a symbolic realm to local L1 realm
# Local L1 realm is the realm loacal POP and/or for L2 server to login to L1
DATA_DIR="$NIRVANA_DIR/CreateChannelsRealm/data/RealmSpecific"
if [ ! -d "$DATA_DIR" ]; then
    Sendmail "Could not find $DATA_DIR" ""
    exit 0
fi

FILES="channels.nst 
AuditSettings.cfg 
ClientTimeoutValues.cfg 
ClusterConfig.cfg 
EventStorage.cfg 
FanoutValues.cfg
GlobalValues.cfg
JVMManagement.cfg
JoinConfig.cfg
RecoveryDaemon.cfg
TransactionManager.cfg
"

# Backup old channels
( cd $NIRVANA_DIR/CreateChannelsRealm && ./stop )
( cd $NIRVANA_DIR/CreateChannelsRealm/data/RealmSpecific && \
  ls $FILES | cpio -Hustar -o > $HOME/deploy/nirvana_data_backup_$DATE.tar )
( cd $NIRVANA_DIR/CreateChannelsRealm && ./start )

# sleeping fucking 3 mins to let the fucking piece of mychannels shit to start.
echo Sleeping 180 seconds to let the $NIRVANA_DIR/CreateChannelsRealm to startup >&3
sleep 180

echo Starting creating external channels... >&3
echo In another terminal run: >&3
echo "   tail -f $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log" >&3
echo To see the channel manager progress >&3
(
cd $HOME/tplus/deploy/dbag/bin
# output in $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log
./createExternalChannels.sh 
)
RC=$?
if [ "$RC" -ne 0 ]; then
    echo "Error creating DBAG External channels" >&3
    case $RC in
        1)
        echo "unhandled exception (e.g. Can not connect to Nirvana)" >&3
        ;;
        2)
        echo "error setting ACL" >&3
        ;;
    esac
    echo "Check $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log" >&3
    E_CODE=1
else
    echo Successfully created external channels >&3
    ( cd $NIRVANA_DIR/CreateChannelsRealm && ./stop )
    ( cd $NIRVANA_DIR/CreateChannelsRealm/data/RealmSpecific && \
      ls $FILES | cpio -Hustar -o > $HOME/deploy/nirvana_data.tar )
    ( cd $NIRVANA_DIR/CreateChannelsRealm && ./start )

    # remove old self-installers for channels.nst
    rm patch_channels-*-l1.sh

    # create new self-installers for channels.nst
    ./wcd/createbatches.sh wcd/patch_channels.sh nirvana_data.tar
    if [ $? -ne 0 ]; then
        echo "Could not create batch files for patch_channels.sh nirvana_data.tar" >&3
        E_CODE=1
    fi

    # remove l2 patches
    rm patch_channels-*-l2.sh

    echo Uploading the channels files to all realms... >&3
    #  upload and run self-installers for channels.nst
    ./wcd/applybatches.sh patch_channels-*-l1.sh
    if [ $? -ne 0 ]; then
        echo "Could not upload nirvana channels and config files to all pops" >&3
        E_CODE=1
    fi
fi

echo Starting creating internal channels... >&3
echo In another terminal run: >&3
echo "   tail -f $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log" >&3
echo To see the channel manager progress >&3
(
cd $HOME/tplus/deploy/dbag/bin
# output in $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log
./createInternalChannels.sh 
)
RC=$?
if [ "$?" -ne 0 ]; then
    echo "Error creating DBAG Internal channels" >&3
    case $RC in
        1)
        echo "unhandled exception (e.g. Can not connect to Nirvana)" >&3
        ;;
        2)
        echo "error setting ACL" >&3
        ;;
    esac
    echo "Check $HOME/tplus/deploy/dbag/log/channelmanagerstdout.log" >&3
    E_CODE=1
else
    echo Successfully created internal channels >&3
fi

for node in $FXPLUS_LEVEL_2
do
    echo Starting creating channels for $node ... >&3
    (
    cd $HOME/tplus/deploy/$node/bin
    msg=`sh ./createChannels.sh all`
    )
    RC=$?
    if [ "$RC" -ne 0 ]; then
        echo "Error creating channels for $node" >&3
        case $RC in
            1)
            echo "unhandled exception (e.g. Can not connect to Nirvana)" >&3
            ;;
            2)
            echo "error setting ACL" >&3
            ;;
        esac
        echo "$msg" >&3
        E_CODE=1
    else
        echo Successfully created channels for $node >&3
    fi
done

if [ $E_CODE -ne 0 ]; then
    Sendfile "Error creating channels" "$HOME/deploy/log/$SCRIPT_SELF_NAME.current.log"
fi
# do not interrupt the autodeploy.sh
exit 0
