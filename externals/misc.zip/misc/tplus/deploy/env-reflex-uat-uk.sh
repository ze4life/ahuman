ENVIRONMENT="uat-uk"
DEPLOY_HOME="/export/log/fxpricing/uat/deploy"
FROM="Reflex UAT UK"; export FROM
ANT_BIN=/export/apps/javalibs/ant/1.7.0/bin
CVS_MODULES="fxpricing"
BUILD_SCRIPTS="checkout.sh compile-reflex.sh mk-reflex-redist-tar.sh"
DEPLOY_SCRIPTS="deploy-reflex-backend.sh deploy-reflex-web.sh createchannels-reflex.sh"
REALMS=""
STOPENV_SCRIPTS="stopenv-reflex.sh"
STARTENV_SCRIPTS="startenv-reflex.sh"
TOMCAT_HOME=$HOME/tomcat
CVSROOT=":pserver:bushser@fxcvs.uk.db.com:/cvs/archive"; export CVSROOT
JAVA_HOME=$HOME/java
JAVA14_HOME=/usr/jdk/j2sdk1.4.2_08
CREATE_CHANNELS="NO"

REALMS_SPOT="
nsp://dnau2.uk.db.com:21001
nsp://dnau2.uk.db.com:21002
"
REALMS_CONFIG="
nsp://dnau2.uk.db.com:21003
nsp://dnau2.uk.db.com:21004
"
PUB_USER='pubuatuk'
SUB_USER='subuatuk'
TAG=fxpricing-prod-8-3-rc5 ; export TAG
