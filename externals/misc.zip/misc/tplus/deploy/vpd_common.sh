#!/bin/ksh
#
# wlc creation script
#
# This script will build you a ksh script which calls all the sql scripts to build a vpd schema
# Evgeny Tanhilevich
# 25 Apr 2005
# 
#
# Health Warning : 001-drop-user.sql . This will drop a schema. If you are creating
# a new schema comment out this command. You dont want to drop the wrong exists schema !
#
# Usage : 
# check these env variables. eg.
# TPLUS_HOME=/export/home/guesho/Projects/mainline/tplus
# FXPLUS_HOME=/export/home/guesho/Projects/mainline/fxplus
# FXOP_HOME=$HOME/fxplusoptions-${BUILD_TAG_FXPLUSOPTIONS}
# they should be fine as is
#
# Check log dir



# set ABORT_TOOL to true
set_abort()
{
        ABORT_TOOL=1
}

# checks if ABORT_TOOL is true
check_abort()
{
        if [[ $ABORT_TOOL = 1 ]]; then
                echo "$0: ERROR OCURRED, check logfile for more information" >&3
                exit 1
        fi
}

# check for the existance of all the properties files
validate_environment()
{
        # this func check existing of some property files, it's depends on 
        # DEPLOY_TPLUS, DEPLOY_FXPLUS, DEPLOY_FXPLUSOPTIONS variables from env.sh

        # this is mandatory profile
        local property_files="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"

        if [[ "$DEPLOY_TPLUS" = "Y" ]]; then
                property_files="$property_files $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
        fi

        for property_file in $property_files; do
                if [[ ! -r $property_file ]] ; then
                        echo "FAILED: property file $property_file have not been found." 
                        set_abort;
                fi
        done
}

# get value of preference from property file
get_prop_val()
{
        local prop=$1
        local file=$2
        # using tr for converting windows line end (if any) to unix. "0x0D0x0A" -> "0x0A" 
        result=`grep "^${prop}=" "$file" | tr -d '\r' | awk -F= '{ print $2 }'`
        echo "$result"
}

# test the oracle connection is correct
test_oracle_connection()
{
        local conn="$1@$2"
        local result=`sqlplus $conn 2>&1 <<!
exit
!
`
        # BUG11006 fix, check if sqlplus has been running properly
        local retcode=$?
        if [[ $retcode != 0 ]]; then
                echo "FAILED: test_oracle_connection: error running sqlplus: $result"
                set_abort;
        else
                local successful=`echo ${result} | grep ORA `
                if [[ -n $successful ]] ; then
                        echo "FAILED: test_oracle_connection: unsucessful connection: \"sqlplus $conn\": $successful" 
                        set_abort;
                fi
        fi
}


### 
### Main start of script
###


# suck in environment variables
. ./common.sh
. ./env.sh

# set up project directories, where it was deployed
TPLUS_HOME=${HOME}/tplus-${BUILD_TAG_TPLUS}

ABORT_TOOL=0

# generate ddl for wlc layer 
        PROFILE="abfx-$ENVIRONMENT/dbag"

        # check needed property files
        validate_environment;
        check_abort;

        # default ant args
        ANT_ARGS="-Djustgen=true -Dvpd=true -Dvpdhome=$TPLUS_HOME/vpd -Dabfxenv=abfx-$ENVIRONMENT"
        
        echo "Running patch target with options: $ANT_ARGS"
        ( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS )
        if [[ $? -ne 0 ]]; then
                echo "FAILED: could not make runtime patches for profile: $PROFILE" 
                echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
                echo `date` " $0 finished with errors" 
                set_abort;
        fi
        check_abort;

        DATABASETNS=`get_prop_val database.tnsname "$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"`

        PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"
        DBAUSERID=`get_prop_val "database.dba.username" $PROPERTY_FILE`
        DBAUSPASSWORD=`get_prop_val "database.dba.password" $PROPERTY_FILE`
        VPD_PROPERTY_FILE="$TPLUS_HOME/vpd/profile/abfx-$ENVIRONMENT.properties"
        VPDUSERID=`get_prop_val "master.vpd.username" $VPD_PROPERTY_FILE`
        VPDUSPASSWORD=`get_prop_val "master.vpd.password" $VPD_PROPERTY_FILE`
        for CONNECTION in "${DBAUSERID}/${DBAUSPASSWORD}"
        do
            test_oracle_connection $CONNECTION ${DATABASETNS}
        done
        check_abort;

        # start script generation
        KSH_SCRIPT="`echo abfx-$ENVIRONMENT/vpd-common|sed -e "s/\//-/g"`.ksh"
        if [[ -r "${KSH_SCRIPT}" ]]; then
                mv "${KSH_SCRIPT}" "${KSH_SCRIPT}.old"
        fi
        touch "${KSH_SCRIPT}"
        if [[ "$?" -ne "0" ]]; then
                echo "FAILED: could not create ${KSH_SCRIPT}"
                echo `date` " $0 finished with errors"
                set_abort;
        fi
        check_abort;
        chmod 700 "${KSH_SCRIPT}"
        cat > "${KSH_SCRIPT}" <<EOF
#!/bin/ksh
LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.log.\`date +%Y%m%d%H%M\`"
ORA_CHECK_LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.oracheck.log"
check_for_errors()
{
        error=\`grep "ORA-" \$ORA_CHECK_LOG | wc -l | sed -e "s/^ *//"\`
        if [[ \$error != 0 ]] ;  then  
                echo 'ERROR : Oracle errors found in last script.'
                echo 'Do you want to continue or exit [^C to cancel ] [ RETURN to continue] '
                read x
        fi
}
# Safety catch. You can not run script until the exit is removed.
echo "Safety catch. You can not run script until the exit is removed."
exit
#

# Script to create a vpd account & schema
# Autogenerated by $TPLUS_HOME/deploy/$0
# Created : ${START_DATETIME}

# load up logging
. ./common.sh

(
EOF
        # database
        local list_of_sql=`ls $TPLUS_HOME/vpd/database/runtime/abfx-${ENVIRONMENT}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $TPLUS_HOME/vpd/database/runtime/abfx-${ENVIRONMENT}/*.sql.runtime scripts not found." 
        fi
        for sql_ddl in $list_of_sql
        do
                local basename=`basename $sql_ddl`
                cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus -s ${DBAUSERID}/${DBAUSPASSWORD}@$DATABASETNS @ ${sql_ddl} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
EOF
        done

        # ddl
        local list_of_sql=`ls $TPLUS_HOME/vpd/ddl/runtime/abfx-${ENVIRONMENT}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $TPLUS_HOME/vpd/ddl/runtime/abfx-${ENVIRONMENT}/*.sql.runtime scripts not found." 
        fi
        for sql_ddl in $list_of_sql
        do
                local basename=`basename $sql_ddl`
                cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus -s ${VPDUSERID}/${VPDUSPASSWORD}@$DATABASETNS @ ${sql_ddl} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
EOF
        done

        # staticdata
        local list_of_sql=`ls $TPLUS_HOME/vpd/staticdata/runtime/abfx-${ENVIRONMENT}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $TPLUS_HOME/vpd/staticdata/runtime/abfx-${ENVIRONMENT}/*.sql.runtime scripts not found." 
        fi
        for sql_ddl in $list_of_sql
        do
                local basename=`basename $sql_ddl`
                cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus -s ${VPDUSERID}/${VPDUSPASSWORD}@$DATABASETNS @ ${sql_ddl} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
EOF
        done

echo '' >> "${KSH_SCRIPT}"
echo ') >&3' >> "${KSH_SCRIPT}"

echo "Database patching script $KSH_SCRIPT created." >&3

# end
