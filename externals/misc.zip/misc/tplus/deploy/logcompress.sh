#!/bin/sh
#
# $Id: logcompress.sh,v 1.3 2008/10/15 10:27:00 kovyale Exp $
# 
# cron:
# 0 * * * * $HOME/bin/logcompress.sh > /dev/null 2>&1
#
# Simple log compressor
find $HOME -name "*.log.*" -type f | grep -v "gz$" | grep -v "bz2$" | xargs nice -n 19 gzip -9 -v -f
