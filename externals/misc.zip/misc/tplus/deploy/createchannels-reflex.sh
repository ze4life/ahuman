#!/bin/sh
#
# $Id: createchannels-reflex.sh,v 1.15 2008/10/30 17:42:49 buraili Exp $
#

. ./common.sh
. ./env.sh

# create channels
if [ "$CREATE_CHANNELS" != "YES" ]; then
    exit 0
fi

createChannel() {
    set +e
    echo removing "$1"
    $JAVA -DRNAME=$RNAME com.pcbsys.nirvana.apps.deleteChannel "$1"
    set -e

    echo creating "$1"
    $JAVA -DRNAME=$RNAME com.pcbsys.nirvana.apps.makeChannel "$1" 5000 0 S

    echo adding acls for $1 
    $JAVA -DRNAME=$RNAME com.pcbsys.nirvana.nAdminAPI.apps.nAddChanAclEntry "$1" "$PUB_USER" "*" full
    if [ "$1" = "/fxpricing/spot/remotecontrol" ]; then
        ACLS="last_eid read write"
    else
        ACLS="last_eid read"
    fi
    $JAVA -DRNAME=$RNAME com.pcbsys.nirvana.nAdminAPI.apps.nAddChanAclEntry "$1" "$SUB_USER" "*" $ACLS
}

CLASSPATH="nirvana/commandline/nCommandLine.jar:nirvana/lib/icons.jar:nirvana/commandline/nAdminAPI.jar:nirvana/commandline/nP2P.jar:nirvana/commandline/nClient.jar"
JAVA=$JAVA_HOME/bin/java
export CLASSPATH JAVA

if [ -z "$PUB_USER" ]; then
    PUB_USER=pub
fi

if [ -z "$SUB_USER" ]; then
    SUB_USER=sub
fi

if [ -n "$REALMS" ]; then
    # this case if we have one realm serving both spot and config
    REALMS_SPOT=$REALMS
    REALMS_CONFIG=$REALMS
fi

for RNAME in $REALMS_CONFIG
do
    (
    set -e
    createChannel /fxpricing/spot/armskew	>&3
    createChannel /fxpricing/spot/ccypairblendconfig	>&3
    createChannel /fxpricing/spot/ccypairconfig	>&3
    createChannel /fxpricing/spot/ccypairladderconfig	>&3
    createChannel /fxpricing/spot/ccypairladderconfigtemplate	>&3
    createChannel /fxpricing/spot/ccypairstaticconfig	>&3
    createChannel /fxpricing/spot/command	>&3
    createChannel /fxpricing/spot/config	>&3
    createChannel /fxpricing/spot/crosspercentagetable	>&3
    createChannel /fxpricing/spot/gradientskewtable	>&3
    createChannel /fxpricing/spot/interestccylimitsconfig	>&3
    createChannel /fxpricing/spot/interestccypairconfig	>&3
    createChannel /fxpricing/spot/ownershipheartbeat	>&3
    createChannel /fxpricing/spot/position	>&3
    createChannel /fxpricing/spot/priceskewtable	>&3
    createChannel /fxpricing/spot/remotecontrol	>&3
    createChannel /fxpricing/spot/skewsettings	>&3
    createChannel /fxpricing/spot/skewsettingstemplate	>&3
    createChannel /fxpricing/spot/spotrate	>&3
    createChannel /fxpricing/spot/triangulatedcrossconfig	>&3
    createChannel /fxpricing/spot/triangulatedcrossconfigtemplate	>&3
    createChannel /fxpricing/spot/us/inputspotrate	>&3
    createChannel /fxpricing/spot/virtualposition	>&3
	createChannel /fxpricing/spot/positionlimit	>&3
	createChannel /fxpricing/spot/sourceswitchingconfig	>&3
	createChannel /fxpricing/spot/spreadmaptemplate	>&3
	createChannel /fxpricing/spot/heartbeat	>&3
    )
    if [ $? -ne 0 ]; then
        Sendfile "Create channels failed for realm $RNAME" "$HOME/deploy/log/$SCRIPT_SELF_NAME.current.log"
    fi
done

for RNAME in $REALMS_SPOT
do
    (
    set -e
    createChannel /fxpricing/spot/spotrate      >&3
    createChannel /fxpricing/spot/virtualposition       >&3
	createChannel /fxpricing/spot/actualposition        >&3
    createChannel /fxpricing/spot/us/inputspotrate      >&3
    )
    if [ $? -ne 0 ]; then
        Sendfile "Create channels failed for realm $RNAME" "$HOME/deploy/log/$SCRIPT_SELF_NAME.current.log"
    fi
done

exit 0
