#!/bin/ksh
#
# $Id: deploy-web.sh,v 1.10 2008/06/04 13:06:25 kovyale Exp $
#
# Deploy the webcontent
#
# alexey.kovyrshin@db.com

. ./common.sh
. ./env.sh

# remove old webpatches
rm webpatch-*.sh

./wcd/createpatches.sh $TAG
if [ "$?" -ne "0" ]; then
    echo "Warning: Could not create some webcontent self-installers" >&3
    Sendfile "Could not create some webcontent self-installers" "log/createpatches.sh.current.log"
else
    # if success then remove wars in tplus*/deploy/web-content
    find $HOME/tplus-*/deploy/web-content -type f -name "*.war"  | xargs rm
fi

./wcd/applybatches.sh webpatch-*.sh
if [ "$?" -ne "0" ]; then
    echo "Warning: Could not apply some webcontent self-installers" >&3
    Sendfile "Could not apply some webcontent self-installers" "log/applybatches.sh.current.log"
else
    # if the webcontent has been deployed OK - remove webarchives
    rm webpatch-*.sh
fi

# the list of updated jars
grep "^Updating" "log/deploy-web.sh.current.log" | sort | uniq > "log/updated.jars.log.$DATE"
if [ -s "log/updated.jars.log.$DATE" ]; then
    Sendfile "The list of updated webcontents files" "log/updated.jars.log.$DATE"
fi

# never interrupt the autodeploy.sh only warng with email
exit 0
