#!/bin/ksh
#
# $Id: show_dbinfo.sh,v 1.5 2007/08/15 10:59:08 fxplusAutoBuild Exp $
#
# This script's purpose is to show the database connection details
# For example if you need to do some manual database patching
#

# get value of preference from property file
get_prop_val()
{
        local prop=$1
        local file=$2
	# using tr for converting windows line end (if any) to unix. "0x0D0x0A" -> "0x0A" 
        result=`grep "^${prop}=" "$file" | tr -d '\r' | awk -F= '{ print $2 }'`
        echo "$result"
}

# suck in environment variables
. ./env.sh
# set up project directories, where it was deployed
TPLUS_HOME=$HOME/tplus-${BUILD_TAG_TPLUS}
FXPLUS_HOME=$HOME/fxplus/fxplus-${BUILD_TAG_FXPLUS}


for LAYER in $TPLUS_LAYERS; do
        PROFILE="abfx-$ENVIRONMENT/$LAYER"

	echo "=== LAYER: $LAYER ==="
	DATABASETNS=`get_prop_val database.tnsname "$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"`
	echo "TNSNAME: $DATABASETNS"
	if [[ $DEPLOY_TPLUS = "Y" ]]; then
		PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"
		TPLUSUSERID=`get_prop_val tplus.owner.username $PROPERTY_FILE`
		TPLUSUSPASSWORD=`get_prop_val tplus.owner.password $PROPERTY_FILE`
		PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
		TPLUSUSERID_AP=`get_prop_val tplus.ap.username $PROPERTY_FILE`
		TPLUSUSPASSWORD_AP=`get_prop_val tplus.ap.password $PROPERTY_FILE`
		TPLUSUSERID_RO=`get_prop_val tplus.ro.username $PROPERTY_FILE`
		TPLUSUSPASSWORD_RO=`get_prop_val tplus.ro.password $PROPERTY_FILE`
		echo "T+ database setup:"
		echo "\tOwner: $TPLUSUSERID"
		echo "\tOwner pass: $TPLUSUSPASSWORD"
		echo "\tAP user: $TPLUSUSERID_AP"
		echo "\tAP pass: $TPLUSUSPASSWORD_AP"
		echo "\tRO user: $TPLUSUSERID_RO"
		echo "\tRO pass: $TPLUSUSPASSWORD_RO"
		echo
	fi

	if [[ "${DEPLOY_FXPLUS}" = "Y" ]] || [[ "${DEPLOY_FXPLUSOPTIONS}" = "Y" ]]; then
		PROPERTY_FILE="$FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
		FXPLUSUSERID=`get_prop_val fxplus.owner.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD=`get_prop_val fxplus.owner.password $PROPERTY_FILE`
		FXPLUSUSERID_AP=`get_prop_val fxplus.ap.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD_AP=`get_prop_val fxplus.ap.password $PROPERTY_FILE`
		FXPLUSUSERID_RO=`get_prop_val fxplus.ro.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD_RO=`get_prop_val fxplus.ro.password $PROPERTY_FILE`
                echo "FX+ database setup:"
                echo "\tOwner: $FXPLUSUSERID"
                echo "\tOwner pass: $FXPLUSUSPASSWORD"
                echo "\tAP user: $FXPLUSUSERID_AP"
                echo "\tAP pass: $FXPLUSUSPASSWORD_AP"
                echo "\tRO user: $FXPLUSUSERID_RO"
                echo "\tRO pass: $FXPLUSUSPASSWORD_RO"
                echo
	fi
done
