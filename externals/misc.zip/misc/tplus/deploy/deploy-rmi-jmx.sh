#!/bin/sh
#
# $Id: deploy-rmi-jmx.sh,v 1.36 2008/06/04 13:33:22 kovyale Exp $
#

. ./common.sh
. ./env.sh

if [ ! -f "$HOME/deploy/rmi-jmx.tar" ]; then
    echo Could not find $HOME/deploy/rmi-jmx.tar >&3
    echo RMI-JMX will not be deployed >&3
    exit 0
fi

if [ "$ENVIRONMENT" != "prod-uk" ] && [ "$ENVIRONMENT" != "demo" ] && \
   [ "$ENVIRONMENT" != "external-uat1" ]; then
        (
            echo " Deploying rmi-jmx" >&3
            DEPLOY_LINK=$HOME/rmi-jmx
            DEPLOY_DIR=$HOME/rmi-jmx-$TAG
            test -h $DEPLOY_LINK && rm -f $DEPLOY_LINK
            test -d $DEPLOY_DIR && rm -rf $DEPLOY_DIR
            mkdir $DEPLOY_DIR || exit 1
            cd $DEPLOY_DIR || exit 1
            tar xvf $DEPLOY_HOME/rmi-jmx.tar || exit 1
            rm $DEPLOY_HOME/rmi-jmx.tar || exit 1
            ln -s $DEPLOY_DIR $DEPLOY_LINK || exit 1
        )
        if [ "$?" -ne "0" ] ;then
            echo "FAILED" >&3
            exit 1
        fi
        echo " rmi-jmx deployed" >&3
    else
       echo " Skipping deploying of rmi-jmx jars" >&3
fi
