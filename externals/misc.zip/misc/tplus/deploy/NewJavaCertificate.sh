#!/bin/sh
#
# Simple template for creating Java certificates
#

keystore=$1
cn=$2
pass=$3
alias=$4
if [ -z "$keystore" ] || [ -z "$cn" ] || [ -z "$pass" ]; then
    echo "Use: $0 keystore CN password [alias]"
    exit 1
fi
if [ -z "$alias" ]; then
    alias=mykey
fi

#set -x
DNAME="CN=$cn, OU=CIB, O=Deutsche Bank AG, L=London, ST=England, C=GB"

capass=password
#caal=dummy2-ca
#ca=/export/home/utils/SSL_forge/Root_CA/dummy2-ca
#caal=dummy-ca
#ca=/export/home/utils/SSL_forge/Root_CA/dummy-ca
caal=generic-ca
ca=/export/home/utils/SSL_forge/Root_CA/generic-ca

# generate rsa key
keytool -keystore $keystore.jks -genkey -keyalg rsa -storepass $pass -keypass $pass -dname "$DNAME" -alias $alias
if [ $? -ne 0 ]; then
    echo Failed to create the $keystore.jks
    exit 1
fi

# generate the certificate request
keytool -keystore $keystore.jks -certreq -file $keystore.csr -storepass $pass -keypass $pass -alias $alias
if [ $? -ne 0 ]; then
    echo Failed to create the certificate request $keystore.csr
    exit 1
fi

# check if CA exists
if [ ! -r "$ca.crt" ]; then
    echo Could not read $ca.crt
    exit 1
fi
if [ ! -r "$ca.key" ]; then
    echo Could not read $ca.key
    exit 1
fi

# sign
openssl x509 -req -CA $ca.crt -CAkey $ca.key -passin pass:$capass -in $keystore.csr -out $keystore.crt -CAcreateserial -days 7300
if [ $? -ne 0 ]; then
    echo Failed to sign the $keystore.csr using $ca.crt, $ca.key
    exit 1
fi

# import the CA
keytool -import -noprompt -trustcacerts -keystore $keystore.jks -file $ca.crt -alias $caal -storepass $pass
if [ $? -ne 0 ]; then
    echo Failed to import CA $ca.crt into $keystore.jks
    exit 1
fi

# import the certificate
keytool -import -noprompt -keystore $keystore.jks -file $keystore.crt -storepass $pass -alias $alias
if [ $? -ne 0 ]; then
    echo Failed to import the $keystore.crt into $keystore.jks
    exit 1
fi

echo $keystore is created. the password is $pass
