#!/bin/sh
#
# $Id: richclientstandalone.sh,v 1.14 2007/08/06 06:39:04 egorale Exp $
#

SKIN=dbag
echo ==============================================================
echo You must re-build the normal RichClient with the SKIN you need
echo Then set SKIN and run this script. The current SKIN is:
echo    SKIN=$SKIN
echo ==============================================================

sleep 3
. ./common.sh
. ./env.sh

if [ ! -d "$BUILD_HOME/$TAG/richclient/abrc-masterbuild" ]; then
	echo "FATAL: Could not find directory $BUILD_HOME/$TAG/richclient/abrc-masterbuild" >&3
	exit 1
fi
cd $BUILD_HOME/$TAG/richclient/abrc-masterbuild

echo BUILDING STAND ALONE >&3

DEFAULT_ARGS=""
DEFAULT_ARGS="${DEFAULT_ARGS} -Dinstall4j.location=${INSTALL4J_LOCATION}"
DEFAULT_ARGS="${DEFAULT_ARGS} -Dskin=${SKIN}"

#system property picked up by the installer
IA_PATH_ABRC_RICHCLIENT_DIR=${BUILD_HOME}/$TAG/richclient; export IA_PATH_ABRC_RICHCLIENT_DIR


echo "[in abrc-masterbuild] ant buildStandaloneInstaller ${DEFAULT_ARGS}" >&3

${ANT_BIN}/ant buildStandaloneInstaller ${DEFAULT_ARGS}
if [ "$?" -ne "0" ]; then
	 echo "FAILED: could not run buildStandaloneInstaller, values: ${DEFAULT_ARGS}" >&3
	 exit 1
fi

echo Please find the installer binary here >&3
ls -la ${BUILD_HOME}/$TAG/richclient/abrc-masterbuild/war/richclientlogin/install/autobahnFXStandaloneInstaller.exe >&3

cd $CURRENT_DIR
echo `date` " $0 finished"
