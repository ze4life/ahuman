#!/bin/sh
#
# $Id: StatsProdUK.sh,v 1.8 2008/06/20 10:44:33 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# change directory to $HOME
cd $HOME

echo "=== Layer 1" >&3
# Start Layer1
SSH_USERHOST="$TPLUS_USERHOST"
statsScript "tplus/deploy/dbag/bin/chatserver.sh"
statsScript "tplus/deploy/dbag/bin/tserver.sh"
statsScript "tplus/deploy/dbag/bin/authserver.sh"
statsScript "fxplus/level_1/dbag/release/bin/dbmpProxy.sh"
statsScript "fxplus/level_1/dbag/release/bin/emailserver.sh"
statsScript "fxplus/level_1/dbag/release/bin/rmsbridge.sh"
statsScript "fxplus/level_1/dbag/release/bin/gtbserver.sh"
statsScript "fxplusoptions/bin/fxopserver.sh"
statsScript "stp_fpml/level_1/dbag/release/bin/stpserver.sh"

SSH_USERHOST="$FXPLUS_USERHOST"
statsScript "fxplus/level_1/dbag/release/bin/server.sh"
statsScript "fxplus/level_1/dbag/release/bin/ratefan.sh"
statsScript "fxplus/level_1/dbag/release/bin/dedicated_ratefan.sh"
statsScript "fxplus/level_1/dbag/release/bin/d2n.sh"
statsScript "fxplus/level_1/dbag/release/bin/fixserver.sh"
statsScript "fxplus/level_1/dbag/release/bin/currenexbridge.sh"
statsScript "fxplus/level_1/dbag/release/bin/fxallmdpibridge.sh"
statsScript "fxplus/level_1/dbag/release/bin/fxalltcpibridge.sh"
statsScript "fxplus/level_1/dbag/release/bin/cfetsbridge.sh"

echo "=== Layer 2" >&3
# Start Layer2
SSH_USERHOST="$WLC_USERHOST"
for wlc in $FXPLUS_LEVEL_2; do
	 statsScript "tplus/deploy/$wlc/bin/tserver.sh"
	 statsScript "tplus/deploy/$wlc/bin/authserver.sh"
	 statsScript "fxplus/level_2/$wlc/release/bin/server.sh"
         if [ -d "stp_fpml/level_2/$wlc" ]; then
             # Some WLCs do not have stp
             statsScript "stp_fpml/level_2/$wlc/release/bin/stpserver.sh"
         fi
done
if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
