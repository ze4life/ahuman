#!/bin/sh
#
# $Id: StatsProdUS.sh,v 1.2 2008/05/27 11:56:15 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# change directory to $HOME
cd $HOME

echo "=== Layer 1" >&3
# Start Layer1
SSH_USERHOST="$FXPLUS_US_USERHOST"
statsScript "fxplus-hub/release/bin/server-fxcm.sh"
statsScript "fxplus-hub/release/bin/dedicated_ratefan.sh"
statsScript "fxplus-hub/release/bin/fixserver.sh"

if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
