#!/bin/sh
#
# $Id: watcher.sh,v 1.5 2006/06/17 12:24:36 kovyale Exp $
#
# WATCHER script
# 
# Alexey.Kovyrshin@db.com

WATCHER_PID=${HOME}/watcher/watcher.pid
WATCHER_LOG=${HOME}/watcher/watcher.log
WATCHER_CFG=${HOME}/watcher/watcher.cfg

# external programms
PS=ps
IFCONFIG=/sbin/ifconfig

# signal handler, action is to exit with message
sig_h () {
	 DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
	 echo "$DATE [$$] Got signal $1, exiting"
	 rm -f $WATCHER_PID
	 exit
}


. $WATCHER_CFG

case $1 in 
	 start)
	 # check if $0 is already running
	 if [ -r "$WATCHER_PID" ]; then
		  PID=`head -1 $WATCHER_PID`
		  ME=`$PS -ef | grep $PID | grep -v grep | grep $0`
		  if [ -n "$ME" ]; then
				echo "$0 is already running $PID"
				echo $ME
				exit 1
		  fi
	 fi

	 # run in background
	 nohup $0 _daemon_ >> $WATCHER_LOG 2>&1 &

	 echo "WATCHER started, check $WATCHER_LOG file"
	 ;;

	 _daemon_)
	 # save pid
	 echo $$ > $WATCHER_PID

	 DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
	 echo "$DATE [$$] WATCHER started"

	 # trap signals
	 trap "sig_h 1" 1
	 trap "sig_h 2" 2
	 trap "sig_h 3" 3
	 trap "sig_h 15" 15

	 # big loop
	 while true; do 
		  # update DATE
		  DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`

		  # suck in config every time so make it very flexible
		  . $WATCHER_CFG

		  # check for VIP
		  # monitor APPS only if VIP is present
		  VIP_PRESENT=`$IFCONFIG -a | grep "inet addr:$VIP"`
		  if [ -n "$VIP_PRESENT" ]; then
				for APP in $APPS; do
					 # First try the new style.
					 if [ -x $APP/$MONITOR ]; then
					 	  if [ -n "$DEBUG" ]; then
						  	DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
						  	echo "$DATE [$$] DEBUG: Running $APP/$MONITOR"
					 	  fi
						  $APP/$MONITOR 
						  if [ $? -ne 0 ]; then
								echo "$DATE [$$] CRITICAL: $APP/$MONITOR returns not 0"
								$APP/$START
						  fi
					 elif [ -x "$APP/monitorProcess.sh" ]; then
						  # old style of app monitoring
						  # the old style monitor will also do start
					 	  if [ -n "$DEBUG" ]; then
						  	DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
						  	echo "$DATE [$$] DEBUG: Running $APP/monitorProcess.sh"
					 	  fi
						  "$APP/monitorProcess.sh"
					 fi

					 # do not flood OS with processes
					 sleep 1
				done
		  fi

		  # sleep for SLEEP_TIME
		  sleep $SLEEP_TIME
	 done
	 ;;
	 stop)
	 # stop alerter
	 if [ -r "$WATCHER_PID" ]; then
		  PID=`head -1 $WATCHER_PID`
		  ME=`$PS -ef | grep $PID | grep -v grep | grep $0`
		  if [ -n "$ME" ]; then
				echo "killing $PID"
				kill $PID
				echo "done. please wait for $SLEEP_TIME seconds to let the process exit before next start"
		  fi
	 fi
	 ;;
	 *)
	 echo "Use: $0 start|stop"
	 echo 
	 echo "start - start WATCHER"
	 echo "stop  - stop WATCHER"
	 exit 1
	 ;;
esac

