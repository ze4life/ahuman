#!/bin/sh

cd $HOME/monitor/  && \
(
./gcAppStopTime.pl server $HOME/fxplus/level_1/dbag/release/log/serverstdout.log 
./gcAppStopTime.pl ratefan $HOME/fxplus/level_1/dbag/release/log/ratefanstdout.log 
./gcAppStopTime.pl dedicated_ratefan $HOME/fxplus/level_1/dbag/release/log/dedicated_ratefanstdout.log 
)
