#!/bin/sh
#
# $Id: openfiles.sh,v 1.2 2007/04/17 08:49:14 kovyale Exp $
#
# openfiles/descriptors monitor script
#

# load global config
. $HOME/monitor/env.sh

for STR in $OPENFILES_PIDS; do
	 LOGFILE=`echo $STR | cut -d\| -f 1`
	 PIDFILE=`echo $STR | cut -d\| -f 2`
	 if [ -r "$PIDFILE" ]; then
		  PID=`head -1 $PIDFILE`
		  DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
                  if [ -d "/proc/$PID/fd" ]; then
                      cd /proc/$PID/fd
                      OF=`ls | wc -l`
                      echo $DATE $OF >> $LOGFILE
                  fi
	 fi
done

# count the total opened files
OF=`ls -la /proc|grep $LOGNAME|awk '{print $9}' \
| while read pid; do
    ( cd /proc/$pid/fd && ls ) 2>/dev/null
done | wc -l `
echo $DATE $OF >> $HOME/monitor/openfiles-total.log
