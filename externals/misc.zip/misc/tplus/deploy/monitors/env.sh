#!/bin/sh
#
# $Id: env.sh,v 1.6 2008/01/18 10:21:49 zakhdmi Exp $
#
# The global monitor config file

## safety catch block
echo Safety catch!
echo 1. Please copy $HOME/deploy/monitors/env.sh to $HOME/monitor/env.sh
echo 2, Set the correct DATABASE_DETAILS, MONITOR_PIDS .. in the $HOME/monitor/env.sh
echo 3. Remove this \"safety catch block\"
echo 4. Do not forget to \"chmod 400 $HOME/monitor/env.sh\"
exit 1
## end of safety catch block

# Perl location
PERL=/usr/bin/perl
export PERL

# process listing programm, normally it is in the default PATH
# otherwise set the correct path/to/ps
PS=ps
export PS

#
## The trades and sessions monitor settings
#
# Oracle home is same for UAT and PROD
ORACLE_HOME="/data/oracle/product/9.2.0.4"
export ORACLE_HOME
# database information
DATABASE_DETAILS="fxp1dbag_ro/tpldcopy@TPLDCOPY"
SQLPLUS="$ORACLE_HOME/bin/sqlplus"
# SET THIS !!!
TNS_ADMIN="$HOME/oracle/9.2.0.4/network/admin"
export TNS_ADMIN
# node
NODE=dbag
export NODE

#
## The openfiles/descriptor monitor settings
#
# PIDs to watch for
# Format: logfile-name|path/to/pidfile
OPENFILES_PIDS="
$HOME/monitor/openfiles-dbag-authserver.log|$HOME/tplus/deploy/dbag/log/authserver.pid \
$HOME/monitor/openfiles-aibk-authserver.log|$HOME/tplus/deploy/aibk/log/authserver.pid \
$HOME/monitor/openfiles-bcvg-authserver.log|$HOME/tplus/deploy/bcvg/log/authserver.pid \
$HOME/monitor/openfiles-dbsw-authserver.log|$HOME/tplus/deploy/dbsw/log/authserver.pid \
$HOME/monitor/openfiles-jybm-authserver.log|$HOME/tplus/deploy/jybm/log/authserver.pid \
$HOME/monitor/openfiles-nbcm-authserver.log|$HOME/tplus/deploy/nbcm/log/authserver.pid \
$HOME/monitor/openfiles-okoh-authserver.log|$HOME/tplus/deploy/okoh/log/authserver.pid \
$HOME/monitor/openfiles-pbzg-authserver.log|$HOME/tplus/deploy/pbzg/log/authserver.pid \
$HOME/monitor/openfiles-sabx-authserver.log|$HOME/tplus/deploy/sabx/log/authserver.pid \
$HOME/monitor/openfiles-sbhk-authserver.log|$HOME/tplus/deploy/sbhk/log/authserver.pid \
$HOME/monitor/openfiles-shin-authserver.log|$HOME/tplus/deploy/shin/log/authserver.pid \
$HOME/monitor/openfiles-dbag-chat.log|$HOME/tplus/deploy/dbag/log/chatserver.pid \
$HOME/monitor/openfiles-aibk-chat.log|$HOME/tplus/deploy/aibk/log/chatserver.pid \
$HOME/monitor/openfiles-bcvg-chat.log|$HOME/tplus/deploy/bcvg/log/chatserver.pid \
$HOME/monitor/openfiles-dbsw-chat.log|$HOME/tplus/deploy/dbsw/log/chatserver.pid \
$HOME/monitor/openfiles-jybm-chat.log|$HOME/tplus/deploy/jybm/log/chatserver.pid \
$HOME/monitor/openfiles-nbcm-chat.log|$HOME/tplus/deploy/nbcm/log/chatserver.pid \
$HOME/monitor/openfiles-okoh-chat.log|$HOME/tplus/deploy/okoh/log/chatserver.pid \
$HOME/monitor/openfiles-pbzg-chat.log|$HOME/tplus/deploy/pbzg/log/chatserver.pid \
$HOME/monitor/openfiles-sabx-chat.log|$HOME/tplus/deploy/sabx/log/chatserver.pid \
$HOME/monitor/openfiles-sbhk-chat.log|$HOME/tplus/deploy/sbhk/log/chatserver.pid \
$HOME/monitor/openfiles-shin-chat.log|$HOME/tplus/deploy/shin/log/chatserver.pid \
$HOME/monitor/openfiles-dbag-tplus.log|$HOME/tplus/deploy/dbag/log/server.pid \
$HOME/monitor/openfiles-aibk-tplus.log|$HOME/tplus/deploy/aibk/log/server.pid \
$HOME/monitor/openfiles-bcvg-tplus.log|$HOME/tplus/deploy/bcvg/log/server.pid \
$HOME/monitor/openfiles-dbsw-tplus.log|$HOME/tplus/deploy/dbsw/log/server.pid \
$HOME/monitor/openfiles-jybm-tplus.log|$HOME/tplus/deploy/jybm/log/server.pid \
$HOME/monitor/openfiles-nbcm-tplus.log|$HOME/tplus/deploy/nbcm/log/server.pid \
$HOME/monitor/openfiles-okoh-tplus.log|$HOME/tplus/deploy/okoh/log/server.pid \
$HOME/monitor/openfiles-pbzg-tplus.log|$HOME/tplus/deploy/pbzg/log/server.pid \
$HOME/monitor/openfiles-sabx-tplus.log|$HOME/tplus/deploy/sabx/log/server.pid \
$HOME/monitor/openfiles-sbhk-tplus.log|$HOME/tplus/deploy/sbhk/log/server.pid \
$HOME/monitor/openfiles-shin-tplus.log|$HOME/tplus/deploy/shin/log/server.pid \
$HOME/monitor/openfiles-dbag-fxplus.log|$HOME/fxplus/level_1/dbag/release/log/server.pid \
$HOME/monitor/openfiles-aibk-fxplus.log|$HOME/fxplus/level_2/aibk/release/log/server.pid \
$HOME/monitor/openfiles-bcvg-fxplus.log|$HOME/fxplus/level_2/bcvg/release/log/server.pid \
$HOME/monitor/openfiles-dbsw-fxplus.log|$HOME/fxplus/level_2/dbsw/release/log/server.pid \
$HOME/monitor/openfiles-jybm-fxplus.log|$HOME/fxplus/level_2/jybm/release/log/server.pid \
$HOME/monitor/openfiles-nbcm-fxplus.log|$HOME/fxplus/level_2/nbcm/release/log/server.pid \
$HOME/monitor/openfiles-okoh-fxplus.log|$HOME/fxplus/level_2/okoh/release/log/server.pid \
$HOME/monitor/openfiles-pbzg-fxplus.log|$HOME/fxplus/level_2/pbzg/release/log/server.pid \
$HOME/monitor/openfiles-sabx-fxplus.log|$HOME/fxplus/level_2/sabx/release/log/server.pid \
$HOME/monitor/openfiles-sbhk-fxplus.log|$HOME/fxplus/level_2/sbhk/release/log/server.pid \
$HOME/monitor/openfiles-shin-fxplus.log|$HOME/fxplus/level_2/shin/release/log/server.pid \
$HOME/monitor/openfiles-dbag-fxo.log|$HOME/fxplusoptions/log/fxo.pid \
$HOME/monitor/openfiles-dbag-d2n.log|$HOME/fxplus/level_1/dbag/release/log/d2n.pid \
$HOME/monitor/openfiles-dbag-ratefan.log|$HOME/fxplus/level_1/dbag/release/log/ratefan.pid \
$HOME/monitor/openfiles-dbag-fxalltcpibridge.log|$HOME/fxplus/level_1/dbag/release/log/fxalltcpibridge.pid \
$HOME/monitor/openfiles-dbag-fxallmdpibridge.log|$HOME/fxplus/level_1/dbag/release/log/fxallmdpibridge.pid \
$HOME/monitor/openfiles-dbag-currenexbridge.log|$HOME/fxplus/level_1/dbag/release/log/currenexbridge.pid \
$HOME/monitor/openfiles-pbzg-stp.log|$HOME/stp_fpml/level_2/pbzg/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-jybm-stp.log|$HOME/stp_fpml/level_2/jybm/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-sabx-stp.log|$HOME/stp_fpml/level_2/sabx/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-bcvg-stp.log|$HOME/stp_fpml/level_2/bcvg/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-shin-stp.log|$HOME/stp_fpml/level_2/shin/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-okoh-stp.log|$HOME/stp_fpml/level_2/okoh/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-nbcm-stp.log|$HOME/stp_fpml/level_2/nbcm/stp-prod-5-1-5/log/stpserver.pid \
$HOME/monitor/openfiles-dbag-stp.log|$HOME/stp_fpml/level_1/dbag/stp-prod-5-1-5/log/stpserver.pid \
"
#
## The cpu/mem monitor settings
#
# PIDs to watch for
# Format: logfile-name|path/to/pidfile
MONITOR_PIDS="
$HOME/monitor/tplus-dbag-authserver.log|$HOME/tplus/deploy/dbag/log/authserver.pid \
$HOME/monitor/tplus-aibk-authserver.log|$HOME/tplus/deploy/aibk/log/authserver.pid \
$HOME/monitor/tplus-bcvg-authserver.log|$HOME/tplus/deploy/bcvg/log/authserver.pid \
$HOME/monitor/tplus-dbsw-authserver.log|$HOME/tplus/deploy/dbsw/log/authserver.pid \
$HOME/monitor/tplus-jybm-authserver.log|$HOME/tplus/deploy/jybm/log/authserver.pid \
$HOME/monitor/tplus-nbcm-authserver.log|$HOME/tplus/deploy/nbcm/log/authserver.pid \
$HOME/monitor/tplus-okoh-authserver.log|$HOME/tplus/deploy/okoh/log/authserver.pid \
$HOME/monitor/tplus-pbzg-authserver.log|$HOME/tplus/deploy/pbzg/log/authserver.pid \
$HOME/monitor/tplus-sabx-authserver.log|$HOME/tplus/deploy/sabx/log/authserver.pid \
$HOME/monitor/tplus-sbhk-authserver.log|$HOME/tplus/deploy/sbhk/log/authserver.pid \
$HOME/monitor/tplus-shin-authserver.log|$HOME/tplus/deploy/shin/log/authserver.pid \
$HOME/monitor/tplus-dbag-server.log|$HOME/tplus/deploy/dbag/log/server.pid \
$HOME/monitor/tplus-aibk-server.log|$HOME/tplus/deploy/aibk/log/server.pid \
$HOME/monitor/tplus-bcvg-server.log|$HOME/tplus/deploy/bcvg/log/server.pid \
$HOME/monitor/tplus-dbsw-server.log|$HOME/tplus/deploy/dbsw/log/server.pid \
$HOME/monitor/tplus-jybm-server.log|$HOME/tplus/deploy/jybm/log/server.pid \
$HOME/monitor/tplus-nbcm-server.log|$HOME/tplus/deploy/nbcm/log/server.pid \
$HOME/monitor/tplus-okoh-server.log|$HOME/tplus/deploy/okoh/log/server.pid \
$HOME/monitor/tplus-pbzg-server.log|$HOME/tplus/deploy/pbzg/log/server.pid \
$HOME/monitor/tplus-sabx-server.log|$HOME/tplus/deploy/sabx/log/server.pid \
$HOME/monitor/tplus-sbhk-server.log|$HOME/tplus/deploy/sbhk/log/server.pid \
$HOME/monitor/tplus-shin-server.log|$HOME/tplus/deploy/shin/log/server.pid \
$HOME/monitor/fxplus-dbag-server.log|$HOME/fxplus/level_1/dbag/release/log/server.pid \
$HOME/monitor/fxplus-aibk-server.log|$HOME/fxplus/level_2/aibk/release/log/server.pid \
$HOME/monitor/fxplus-bcvg-server.log|$HOME/fxplus/level_2/bcvg/release/log/server.pid \
$HOME/monitor/fxplus-dbsw-server.log|$HOME/fxplus/level_2/dbsw/release/log/server.pid \
$HOME/monitor/fxplus-jybm-server.log|$HOME/fxplus/level_2/jybm/release/log/server.pid \
$HOME/monitor/fxplus-nbcm-server.log|$HOME/fxplus/level_2/nbcm/release/log/server.pid \
$HOME/monitor/fxplus-okoh-server.log|$HOME/fxplus/level_2/okoh/release/log/server.pid \
$HOME/monitor/fxplus-pbzg-server.log|$HOME/fxplus/level_2/pbzg/release/log/server.pid \
$HOME/monitor/fxplus-sabx-server.log|$HOME/fxplus/level_2/sabx/release/log/server.pid \
$HOME/monitor/fxplus-sbhk-server.log|$HOME/fxplus/level_2/sbhk/release/log/server.pid \
$HOME/monitor/fxplus-shin-server.log|$HOME/fxplus/level_2/shin/release/log/server.pid \
$HOME/monitor/fxplusoptions-dbag-server.log|$HOME/fxplusoptions/log/fxo.pid \
$HOME/monitor/nirvana.prod.internal.log|$HOME/nirvana/prod.internal/nirvana.pid \
$HOME/monitor/nirvana.prod.l1.log|$HOME/nirvana/prod.l1/nirvana.pid \
$HOME/monitor/nirvana.prod.l2.log|$HOME/nirvana/prod.l2/nirvana.pid \
"

#
## The timeoffset monitor settings
#
# NTP hosts
# 10.140.116.59 REFLEX PROD
# 10.143.130.49 ABFX PROD
#NTP_HOSTS="10.143.130.49 10.140.116.59"
NTP_HOSTS="10.140.116.59"
