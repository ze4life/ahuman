set feed off
set pages 0
set lines 250

select 'environment,system,id,last-login,rights,disabled,first-name,last-name,full-name,owner,owner-type,personal,priv,start-date,expiry,description,node,auth-contact,approver,group-name' from dual
union all
select value as col from table(fxp1dbag.persmission_pipeline)
/

EXIT;
