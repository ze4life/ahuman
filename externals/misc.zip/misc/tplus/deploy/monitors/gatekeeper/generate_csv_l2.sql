set feed off
set pages 0
set lines 250

select 'GATE,26953-1,' ||t.user_id || ',' || NVL(to_char(s.login_timestamp,'yyyy-mm-dd hh24:mm:ss'),'1970-01-01 00:00:00') || 'Z,ALL,' ||
       decode(t.enabled, 'Y', 'N', 'N', 'Y', NULL) || ',"' ||
       t.first_name || '","' || t.last_name || '",,' ||
       t.email_address  || ',mail,Y,N,,,,,,,'
  from tplus_users t, 
       (
          select user_id, max(login_timestamp) as login_timestamp
            from abfxprod_owner.sessions
           group by user_id
       ) s
 where t.user_id = s.user_id (+)
/

EXIT;
