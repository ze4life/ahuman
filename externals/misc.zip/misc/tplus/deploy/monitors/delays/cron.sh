#!/bin/sh
# The script must be executed after the log file rotated
#

(
cd $HOME/monitor
./tailDelays.pl spotrates.dedicated_ratefan $HOME/fxplus/level_1/dbag/release/log/spotrates.dedicated_ratefan.log
./tailDelays.pl spotrates.ratefan $HOME/fxplus/level_1/dbag/release/log/spotrates.ratefan.log
./tailDelays.pl spotrates $HOME/fxplus/level_1/dbag/release/log/spotrates.log
)
