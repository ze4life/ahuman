#!/usr/bin/perl
#
# $Id: tailDelays.pl,v 1.4 2008/11/06 09:52:37 kovyale Exp $
#
# Supported: Solaris, Linux
#

sub usage {
    print "Use: $0 <application_short_name> </path/to/serverlogfile>\n";
}

$debug=0;

$APP_NAME = $ARGV[0];
$SERVER_LOG_FILE = $ARGV[1];

if ( not -r "$SERVER_LOG_FILE" ) {
    print STDERR "Could not read SERVER_LOG_FILE=$SERVER_LOG_FILE\n";
    usage;
    exit 1;
}
if ( not defined $APP_NAME ) {
    usage;
    exit 1;
}


if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$HOME=$ENV{HOME};
$LOG="$HOME/monitor/${PROGRAM}_${APP_NAME}.log";
$PID="$HOME/monitor/${PROGRAM}_${APP_NAME}.pid";

# rotate log size 20Mb
$LOG_ROTATE_SIZE=20 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    $|=1;
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, '>>/dev/null' or die "Can't write to /dev/null: $!";
    open STDERR, '>>/dev/null' or die "Can't write to /dev/null: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# check if the programm is already running
&checkpid;

if (not $debug) {
    &daemonize;
    &reopenlog;
    &savepid;
}

# load libraries
use lib "./lib/5.6.1";
$uname = `uname -s`;
if ( $uname eq "SunOS" ) {
    push (@INC , "./lib/5.6.1/sun4-solaris-64int") ;
}
use Time::HiRes qw( gettimeofday );
use File::Tail;

# the log files to tail
my @logs = (
    "$SERVER_LOG_FILE"
);

# open files
my @fds;
for (@logs) {
    if ( -f "$_" ) {
        push( @fds, File::Tail->new(
                name => "$_",
                interval => 0,
                maxinterval => 1,
                ignore_nonexistant => 1,
                resetafter => 30,
                debug => $debug,
            )
        );
    }
}

my $timeout = 60;

while (1) {
    my ($nfound,$timeleft,@pending) = File::Tail::select(undef,undef,undef,$timeout,@fds);

    if ($nfound) {
        for (@pending) {

            my $line = $_->read;
            my ($sec, $mic) = gettimeofday;
            $mic = sprintf "%06d", $mic;

# 81901 [SPOT RATEFAN] 27 04:41:11,801 BST - [spot: EURCZK 1835972756 0.0/-0.1/bid 24.047/24.08 -/-/-/3/99 ReutersD2K OK] 85b
            if ( 
                $line =~ /^\d+ \[SPOT[^\]]*\] \d\d \d\d:\d\d:\d\d,\d+ \D\D\D - \[spot: [^ ]+ [^ ]+ [^ ]+ [^ ]+ ([\d-]+)\/([\d-]+)\/([\d-]+)\/([\d-]+)\/([\d-]+)/
            ) 
            {
                print join (' ', "$sec.$mic", $1,$2,$3,$4,$5), "\n";
            } 
        }
    } 

    # check self log file
    &checklog;
}
