#!/bin/sh
# The script must be executed after the log file rotated
#

# DECOMMISIONED

exit 0
