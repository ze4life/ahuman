#!/usr/bin/perl
#
# $Id: tail_vmstat.pl,v 1.3 2008/05/20 09:40:37 kovyale Exp $
#
# Perl daemon monitoring t+ fx+ fxo alerts.
#
# Supported: Solaris, Linux
#

$debug=0;

if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$LOG="$ENV{HOME}/monitor/vmstat/$PROGRAM.log";
$PID="$ENV{HOME}/monitor/vmstat/$PROGRAM.pid";

# rotate log size 50Mb
$LOG_ROTATE_SIZE=50 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    close STDOUT;
    close STDERR;
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# flush the buffer
$| = 1;

# check if the programm is already running
&checkpid;

if (not $debug) {
# daemonize the program
    &daemonize;

# save pid
    &savepid;
}

# load libraries
use lib "./lib/5.6.1";
$uname = `uname -s`;
chomp $uname;
if ( $uname eq "SunOS" ) {
    push (@INC , "./lib/5.6.1/sun4-solaris-64int") ;
}
use File::Tail;

# the log files to tail
my @logs = qw(
    monitor/vmstat/vmstat.log
);

# open files
my @fds;
for (@logs) {
    push( @fds, File::Tail->new(
            name => "$ENV{HOME}/$_",
            interval => 0,
            maxinterval => 1,
            ignore_nonexistant => 1,
            resetafter => 10,
            debug => $debug,
        )
    );
}

my $timeout = 60;

sub doLinux {
    # Linux vmstat 16 fields
    #  0  1      2      3      4      5    6    7     8     9   10    11 12 13 14 15
    #  r  b   swpd   free   buff  cache   si   so    bi    bo   in    cs us sy id wa
    #  0  0      0  22488  96420  65152    0    0     0    40  268    36  0  0 100  0
    #
    my (@l) = split(/\s+/, $_[0]);
    return "$l[0]:$l[1]:$l[12]:$l[13]:$l[14]";
}

sub doSunOS {
    # Solaris vmstat 22 fields
    #  0 1 2      3     4   5   6  7  8  9 10 11 12 13 14 15   16   17   18 19 20 21
    #  r b w   swap  free  re  mf pi po fr de sr s0 s1 s1 s3   in   sy   cs us sy id
    #  32 0 0 47368976 48500288 119 1606 0 0 0 0 0 0 0  0  0 50058 166691 315761 20 62 17
    #
    my (@l) = split(/\s+/, $_[0]);
    return "$l[0]:$l[1]:$l[19]:$l[20]:$l[21]";
}

while (1) {
    my ($nfound,$timeleft,@pending) = File::Tail::select(undef,undef,undef,$timeout,@fds);

    if ($nfound) {
        my $time = time;
        for (@pending) {
            my $line = $_->read;
            $line =~ s/^\s*//;
            if ( $line =~ /^\d+\s+\d+\s+\d/ ) {
                if ( $uname eq "Linux" ) {
                    print "$time:", doLinux($line), "\n";
                }
                elsif ( $uname eq "SunOS" ) {
                    print "$time:", doSunOS($line), "\n";
                }
                else {
                    print "$uname is unsupported\n";
                }
            }
        }
    } 

    # check self log file
    &checklog;
}
