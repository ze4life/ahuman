#!/bin/sh
# $Id: run_vmstat.sh,v 1.3 2008/05/20 09:40:37 kovyale Exp $
# AK

# bug squisher
set -e

SCRIPT=`basename $0`
LOG_DIR=$HOME/monitor/vmstat
LOG_FILE=$LOG_DIR/vmstat.log
PID_FILE=$LOG_DIR/$SCRIPT.pid
# 86400 seconds - 1 day
LOG_ROTATE_SECONDS=86400

checkpid () {
    if [ -f "$PID_FILE" ]; then
        PID=`cat $PID_FILE`
        RUNNING=`ps -o user,args -p $PID | grep $LOGNAME | grep -v grep`
        if ( echo $RUNNING | grep -v grep | grep $SCRIPT > /dev/null ) ; then
            return 0
        fi
    fi
    return 1
}

rotatelog () {
    mv $LOG_FILE $LOG_FILE.old
}

# blind mkdir
mkdir -p $LOG_DIR

case $1 in
    start)
        if ( checkpid ) ; then
            PID=`cat $PID_FILE`
            echo "The $SCRIPT is already running $PID"
            exit 1
        fi
        trap "" HUP
        ( 
        while true
        do
            vmstat 1 $LOG_ROTATE_SECONDS > $LOG_FILE
            rotatelog
        done
        ) > /dev/null 2>&1 &
        PID=$!
        echo $PID > $PID_FILE
        echo $PID
        ;;
    stop)
        if ( checkpid ) ; then 
            PID=`cat $PID_FILE`
            echo $PID
            kill -TERM $PID
            # find and save vmstat pid
            VMSTAT_PS=`ps -eo pid,user,args | grep -v grep | grep $LOGNAME | grep "vmstat 1 $LOG_ROTATE_SECONDS"`
            if [ -n "$VMSTAT_PS" ]; then
                VMSTAT_PID=`echo $VMSTAT_PS | awk '{print $1}'`
                echo $VMSTAT_PID
                kill -TERM $VMSTAT_PID 
            fi
        else
            echo "The $SCRIPT is not running"
        fi
        ;;
    stats)
        if ( checkpid ) ; then
            PID=`cat $PID_FILE`
            echo "The $SCRIPT is running: $PID"
        fi
        ;;
    *)
        echo "Use: $0 start|stop|stats"
        ;;
esac

