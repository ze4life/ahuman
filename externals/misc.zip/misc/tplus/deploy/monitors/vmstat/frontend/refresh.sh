#!/bin/sh
#
# $Id: refresh.sh,v 1.2 2008/05/20 12:26:52 kovyale Exp $
#

renice 19 $$

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

sleep 5

./populate.sh
