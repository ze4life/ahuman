***About***

This directory contains various monitoring tools. Which are shell/perl based.
The graphical representation is made by RRDTool. 

Please see the 'RRDTool Installtion' section howto install RRDTool.

The most monitors consist of two parts:
1 - the script collecting data and saving it in the $HOME/monitor/$LOGFILE file
2 - the script the parse the give $LOGFILE and draw graphs.

1st one is running on the backend.
2nd one is running on the frontend. must be located in the webaccessible directory.

2nd script get data via SSH using key based auth.

There are two monitors wich does not have the 1st part. That's are ratedelays monitors, which
are collecting data right from the fxplus logfiles.

***RRDTool Installation***

Since the monitor uses the rrdtool(http://oss.oetiker.ch/rrdtool/) you need to install the tool.

***Building Libraries***

* I STRONGLY RECOMMEND TO READ THE http://oss.oetiker.ch/rrdtool/doc/rrdbuild.en.html *

Depending on the shell you are using, you can do either (bash,zsh):

BUILD_DIR=/tmp/rrdbuild
INSTALL_DIR=/usr/local/rrdtool-1.2.15

Or if you run tcsh:

set BUILD_DIR=/tmp/rrdbuild
set INSTALL_DIR=/usr/local/rrdtool-1.2.15

Now make sure the BUILD_DIR exists and go there:

mkdir -p $BUILD_DIR
cd $BUILD_DIR

cd $BUILD_DIR
wget http://oss.oetiker.ch/rrdtool/pub/libs/zlib-1.2.3.tar.gz
tar  zxf zlib-1.2.3.tar.gz
cd zlib-1.2.3
env CFLAGS="-O3 -fPIC" ./configure --prefix=$BUILD_DIR/lb
make
make install

cd $BUILD_DIR
wget http://oss.oetiker.ch/rrdtool/pub/libs/libpng-1.2.10.tar.gz
tar zxvf libpng-1.2.10.tar.gz
cd libpng-1.2.10
env CPPFLAGS="-I$BUILD_DIR/lb/include" LDFLAGS="-L$BUILD_DIR/lb/lib" CFLAGS="-O3 -fPIC" \
    ./configure --disable-shared --prefix=$BUILD_DIR/lb
make
make install

cd $BUILD_DIR
wget http://oss.oetiker.ch/rrdtool/pub/libs/freetype-2.1.10.tar.bz2
tar jxvf freetype-2.1.10.tar.bz2
cd freetype-2.1.10
env CPPFLAGS="-I$BUILD_DIR/lb/include" LDFLAGS="-L$BUILD_DIR/lb/lib" CFLAGS="-O3 -fPIC" \
    ./configure --disable-shared --prefix=$BUILD_DIR/lb
make
make install

If you run into problems building freetype on Solaris, you may want to try to add the following at the end of the configure line:

GNUMAKE=gmake EGREP=egrep

cd $BUILD_DIR
wget http://oss.oetiker.ch/rrdtool/pub/libs/libart_lgpl-2.3.17.tar.gz
tar zxvf libart_lgpl-2.3.17.tar.gz
cd libart_lgpl-2.3.17
env CFLAGS="-O3 -fPIC" ./configure --disable-shared --prefix=$BUILD_DIR/lb
make
make install

Especially BSD systems like Mac OS X may require this, Linux and Solaris will do just fine without since their ar command does ranlibs job as well.

 ranlib $BUILD_DIR/lb/lib/*.a


This time you tell configure where it should be looking for libraries and include files. This is done via environment variables. Depending on the shell you are running, the syntax for setting environment variables is different. Under csh/tcsh you use:

set IR=-I$BUILD_DIR/lb/include
setenv CPPFLAGS "$IR $IR/libart-2.0 $IR/freetype2 $IR/libpng"
setenv LDFLAGS  -L$BUILD_DIR/lb/lib
setenv CFLAGS -O3

If you are running bash/sh/ash/ksh/zsh use this:

IR=-I$BUILD_DIR/lb/include
CPPFLAGS="$IR $IR/libart-2.0 $IR/freetype2 $IR/libpng"
LDFLAGS="-L$BUILD_DIR/lb/lib"
CFLAGS=-O3
export CPPFLAGS LDFLAGS CFLAGS

And finally try building again. We disable the python and tcl bindings because it seems that a fair number of people have ill configured python and tcl setups that would prevent rrdtool from building if they are included in their current state.

wget http://oss.oetiker.ch/rrdtool/pub/rrdtool-1.2.15.tar.gz
tar zxf rrdtool-1.2.15.tar.gz
cd $BUILD_DIR/rrdtool-1.2.15
./configure --prefix=$INSTALL_DIR --disable-python --disable-tcl
make clean
make
make install


alexey.kovyrshin@db.com
