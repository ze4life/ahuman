#!/bin/sh
#
# $Id: cpu_mem.sh,v 1.2 2007/03/13 11:23:22 kovyale Exp $
#
# CPU, Memory Monitor script
#

# load global config
. $HOME/monitor/env.sh

# Output format
# it has been agreed that we need: PID CPU MEM VSZ RSS TIME
# also the graphs are set up to use this format
PS_OUTPUT_FMT="pid,pcpu,pmem,vsz,rss,time"

for STR in $MONITOR_PIDS; do
	 LOGFILE=`echo $STR | cut -d\| -f 1`
	 PIDFILE=`echo $STR | cut -d\| -f 2`
	 if [ -r "$PIDFILE" ]; then
		  PID=`head -1 $PIDFILE`
		  DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
		  if [ -n "$DEBUG" ]; then
				echo "$DATE [$$] Got pid $PID from $PIDFILE"
				echo "$DATE [$$] Will log results into $LOGFILE"
				echo "$DATE [$$] Running: $PS -o $OUTPUT_FMT -p $PID"
		  fi
		  PSINFO=`$PS -o $PS_OUTPUT_FMT -p $PID | tail -1`
		  echo $DATE $PSINFO >> $LOGFILE
	 fi
done
