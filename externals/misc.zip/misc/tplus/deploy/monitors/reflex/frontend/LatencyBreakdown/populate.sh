#!/bin/sh
#
# $Id: populate.sh,v 1.1 2007/10/18 10:25:01 kovyale Exp $
#

. ./env.sh

ssh -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -10800 LatencyBreakdown.pl.log )" \
| ./parse_log.pl | /bin/sh -x

