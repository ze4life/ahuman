#!/bin/sh
#
# $Id: env.sh,v 1.1 2007/10/18 10:25:01 kovyale Exp $
#

PATH=$HOME/bin:$PATH
export PATH

LD_LIBRARY_PATH=$HOME/bin
export LD_LIBRARY_PATH

# SSH Connection details
SSH_USER=javalib
SSH_HOST=dnau2
APPLICATION_USER=javalib

# Scale for delays graph
# PROD -u 50
# UAT  -u 100
DELAYS_GRAPH_SCALE="-l 0 -u 300 -r"

# End date for graphs
NOW=now

# time zone variable to be used in graphs
# should not be TZ since TZ variable will affect
# the log files contain the timestamp in localtime
# so will use mktime's isdst -1 
TZONE=`date +"%Z"`
