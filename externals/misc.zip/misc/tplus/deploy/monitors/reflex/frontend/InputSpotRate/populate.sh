#!/bin/sh
#
# $Id: populate.sh,v 1.2 2007/06/05 11:25:06 kovyale Exp $
#

. ./env.sh

ssh -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -1000 InputSpotRate.log )" \
| ./do.pl
