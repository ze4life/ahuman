#!/bin/sh

#2006-08-10 11:43:44
. ./env.sh

geometry="-w 900 -h 150 -i"
now="$NOW"
scale="$DELAYS_GRAPH_SCALE"

color="--color GRID#C0C0C0"
color1="#7648EC"
color2="#1598C3"
color3="#54EC48"
color4="#ECD748"


rrdtool graph LatencyBreakdown.png \
	$scale \
	-v "ms" -t "Reflex Latency breakdown. 5 seconds peaks for the last 30 minutes ($TZONE)." \
	$geometry $color \
	--end $now \
	--start end-30m \
	DEF:d1=LatencyBreakdown.rrd:d1:MAX  \
	DEF:d2=LatencyBreakdown.rrd:d2:MAX  \
	DEF:d3=LatencyBreakdown.rrd:d3:MAX  \
        AREA:d1$color1:"InputSpotRate" \
        AREA:d2$color4:"SpotServer":STACK \
        AREA:d3$color2:"OutputSpotRate":STACK 

rrdtool graph LatencyBreakdownDay.png \
	$scale \
	-v "ms" -t "Reflex Latency breakdown. 5 seconds peaks for the last day ($TZONE)." \
	$geometry $color \
	--end $now \
	--start end-1d \
	DEF:d1=LatencyBreakdown.rrd:d1:MAX  \
	DEF:d2=LatencyBreakdown.rrd:d2:MAX  \
	DEF:d3=LatencyBreakdown.rrd:d3:MAX  \
        AREA:d1$color1:"InputSpotRate" \
        AREA:d2$color4:"SpotServer":STACK \
        AREA:d3$color2:"OutputSpotRate":STACK 

rrdtool graph LatencyBreakdownWeek.png \
	$scale \
	-v "ms" -t "Reflex Latency breakdown. 5 seconds peaks for the last week ($TZONE)." \
	$geometry $color \
	--end $now \
	--start end-1w \
	DEF:d1=LatencyBreakdown.rrd:d1:MAX  \
	DEF:d2=LatencyBreakdown.rrd:d2:MAX  \
	DEF:d3=LatencyBreakdown.rrd:d3:MAX  \
        AREA:d1$color1:"InputSpotRate" \
        AREA:d2$color4:"SpotServer":STACK \
        AREA:d3$color2:"OutputSpotRate":STACK 

rrdtool graph LatencyBreakdownMonth.png \
	$scale \
	-v "ms" -t "Reflex Latency breakdown. 5 seconds peaks for the last month ($TZONE)." \
	$geometry $color \
	--end $now \
	--start end-1m \
	DEF:d1=LatencyBreakdown.rrd:d1:MAX  \
	DEF:d2=LatencyBreakdown.rrd:d2:MAX  \
	DEF:d3=LatencyBreakdown.rrd:d3:MAX  \
        AREA:d1$color1:"InputSpotRate" \
        AREA:d2$color4:"SpotServer":STACK \
        AREA:d3$color2:"OutputSpotRate":STACK 
