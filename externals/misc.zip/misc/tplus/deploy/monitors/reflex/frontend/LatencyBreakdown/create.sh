#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ./env.sh

    rrdtool create LatencyBreakdown.rrd \
    --start 20061101 \
    --step 1 \
    DS:d1:GAUGE:60:0:U     \
    DS:d2:GAUGE:60:0:U     \
    DS:d3:GAUGE:60:0:U     \
    RRA:MAX:0.5:5:6307200   \
    RRA:AVERAGE:0.5:5:6307200
