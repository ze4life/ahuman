#!/bin/sh

#2006-08-10 11:43:44
. ./env.sh

# globals
geometry="-w 1024 -h 300 --interlaced"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

Ri=0
Gi=175
Bi=255

for rrd in *.rrd
do
    name=`basename "$rrd" .rrd`

Ri=`expr $Ri + 40`;  if [ $Ri -gt 255 ]; then Ri=`expr $Ri - 255`; fi ; R=`printf "%02x" $Ri`
Gi=`expr $Gi + 60`;  if [ $Gi -gt 255 ]; then Gi=`expr $Gi - 255`; fi ; G=`printf "%02x" $Gi`
Bi=`expr $Bi - 20`;  if [ $Bi -lt 0 ]; then Bi=`expr 0 - $Bi `; fi ; B=`printf "%02x" $Bi`

    color="$R$G$B"

    GRAPH_HOURS="$GRAPH_HOURS DEF:$name=$rrd:mes:AVERAGE:step=60 CDEF:m$name=$name,60,* AREA:m$name#$color:$name:STACK"
    GRAPH_DAYS="$GRAPH_DAYS DEF:$name=$rrd:mes:AVERAGE:step=600 CDEF:m$name=$name,600,* AREA:m$name#$color:$name:STACK"
    GRAPH_WEEKS="$GRAPH_WEEKS DEF:$name=$rrd:mes:AVERAGE:step=3600 CDEF:m$name=$name,3600,* AREA:m$name#$color:$name:STACK"
    GRAPH_MONTHS="$GRAPH_MONTHS DEF:$name=$rrd:mes:AVERAGE:step=10800 CDEF:m$name=$name,10800,* AREA:m$name#$color:$name:STACK"

done

#hour 
rrdtool graph hours.png \
$geometry  \
--title "step 60 seconds. last 3 hours" \
--vertical-label "messages" \
--end $now \
--start end-3h \
$GRAPH_HOURS

#day 
rrdtool graph days.png \
$geometry  \
--title "step 10 minutes. last day" \
--vertical-label "messages" \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
$GRAPH_DAYS

#week
rrdtool graph weeks.png \
$geometry  \
--title "step 1 hour. last week" \
--vertical-label "messages" \
--end $now \
--start end-1w \
$GRAPH_WEEKS

#months
rrdtool graph months.png \
$geometry  \
--title "step 3 hours. last month" \
--vertical-label "messages" \
--end $now \
--start end-1m \
$GRAPH_MONTHS
