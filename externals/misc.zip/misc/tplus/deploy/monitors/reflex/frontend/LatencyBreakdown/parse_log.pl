#!/usr/bin/perl

my $rrdfile="LatencyBreakdown.rrd";
my $lastupdate = `rrdtool info $rrdfile | grep last_update | cut -d= -f 2`;
$lastupdate =~ s/ //g;
chomp $lastupdate;

my $nargs=0;
my $maxargs=40;
my $args='';

while (<STDIN>) {
    if ( /^(\d+):(\d+):(\d+):(\d+)$/ ) {
        if ( $1 > $lastupdate ) {
            $args .= " $1:$2:$3:$4";
            if ( $nargs == $maxargs ) {
                print "rrdupdate $rrdfile $args\n";
                $nargs=0;
                $args='';
            } else {
                $nargs++;
            }

        }
    }
}
if ($args) {
    print "rrdupdate $rrdfile $args\n";
}

