# The Ccy hash conatins the key - is the source name and the list of dirrectories where to find the log for it

package Cfg;

%Ccy = (

"Cbot" => [ "Cbot", "CbotApr7", "CbotAug7", "CbotJul7", "CbotJun7", "CbotMay7", "CbotOct7", "CbotSep7" ],
"Currenex" => [ "Currenex" ],
"EBS Live" => [ "EBS Live" ],
"EBSATIDeal" => [ "EBSATIDeal" ],
"EBSLiveUS" => [ "EBSLiveUS" ],
"Excel" => [ "Excel" ],
"FXCM" => [ "FXCM" ],
"Lava" => [ "Lava" ],
"Nymex" => [ "Nymex", "NymexApr7", "NymexAug7", "NymexCme", "NymexCmeAug7", "NymexCmeJul7", "NymexCmeJun7", "NymexCmeMay7", "NymexJul7", "NymexJun7", "NymexMay7", "NymexOct7", "NymexSep7" ],
"Reuters" => [ "Reuters",  "ReutersD2K", "ReutersEBS", "ReutersPBZG" ],
"ReutersAQ" => [ "ReutersAQ", "ReutersAQS" ],
"CMEIMM1" => [ "CMEIMM1" ],
"CMEIMM2" => [ "CMEIMM2" ],

);


#for $k (keys %Ccy) {
#    print "Name: $k\n\tDirectories: ";
#    for my $d (@{$Ccy{$k}}) {
#        print "$d ";
#    }
#    print "\n";
#}

1;
