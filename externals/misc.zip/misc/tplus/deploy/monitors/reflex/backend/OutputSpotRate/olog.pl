#!/usr/bin/perl -w

use strict;
use warnings;
use diagnostics;

system("renice", "19", $$);

#my $LogDir="$ENV{HOME}/logs/MessageLog.OutputSpotRate/OutputSpotRate";
my $LogDir="/export/home/reflexuat/logs/MessageLog.OutputSpotRate/OutputSpotRate";
my $MonitorLogDir="$ENV{HOME}/monitor";

sub logIt {
    my ( $name, $lines ) = @_;
    open LOG, ">>$MonitorLogDir/OutputSpotRate.log" or die;
    print LOG "$name:", time , ":$lines\n";
    close LOG;
}

if ( ! -d $MonitorLogDir ) {
    system("mkdir", "-p", $MonitorLogDir);
}

if ( -f "$MonitorLogDir/olog.cfg.pl" ) { 
    require "$MonitorLogDir/olog.cfg.pl";
}

if (not defined scalar %Cfg::Source) {
    print STDERR "Empty config file\n";
    exit 1;
}

my %Results;

open OLOG, "$LogDir/OutputSpotRate-statistics.log" or die;
while(my $line=<OLOG>) {
    my (@tokens) = split(/,/, $line);
    my $source = $tokens[3];
    $source =~ s/^ //;
    my $name = '';
    if ($Cfg::Source{$source}) {
        $name = $Cfg::Source{$source};
    } else {
        $name = $source;
        # strip off whitespaces
        $name =~ s/ //g;
    }
    if ( $Results{$name} ) {
        $Results{$name}++;
    } else {
        $Results{$name} = 1;
    }
}
close OLOG;

for my $k (sort keys %Results) {
    logIt ($k, $Results{$k});
}
