# The Ccy hash conatins the key - is the source name and the list of dirrectories where to find the log for it

package Cfg;

%Source = (

"Blend" => "Blend", 
"Blend EBSLive/Nymex" => "Blend",
"Blend EBSLive/Nymex/Cbot" => "Blend",
"BlendTest" => "Blend",
"EBS Live" => "EBSLive", 
"Excel" => "Excel",
"Reuters" => "Reuters", 
"ReutersD2K" => "Reuters",
"ReutersEBS" => "Reuters",
"ReutersPBZG" => "Reuters",
"ReutersAQ" => "ReutersAQ",
"ReutersAQS" => "ReutersAQ",

);


#for $k (keys %Ccy) {
#    print "Name: $k\n\tDirectories: ";
#    for my $d (@{$Ccy{$k}}) {
#        print "$d ";
#    }
#    print "\n";
#}

1;
