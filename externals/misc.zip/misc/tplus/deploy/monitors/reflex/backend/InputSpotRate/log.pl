#!/usr/bin/perl -w

use strict;
use warnings;
use diagnostics;

system("renice", "19", $$);

my $LogDir="$ENV{HOME}/logs/MessageLog.InputSpotRate.all/InputSpotRate";
my $MonitorLogDir="$ENV{HOME}/monitor";

sub logIt {
    my ( $name, $lines ) = @_;
    open LOG, ">>$MonitorLogDir/InputSpotRate.log" or die;
    print LOG "$name:", time , ":$lines\n";
    close LOG;
}

if ( ! -d $MonitorLogDir ) {
    system("mkdir", "-p", $MonitorLogDir);
}

if ( -f "$MonitorLogDir/log.cfg.pl" ) { 
    require "$MonitorLogDir/log.cfg.pl";
}

if (not defined scalar %Cfg::Ccy) {
    print STDERR "Empty config file\n";
    exit 1;
}

chdir $LogDir;

foreach my $key ( keys %Cfg::Ccy ) {
    my $lines = 0;
    for my $dir ( @{$Cfg::Ccy{$key}} ) {
        if ( -f "$dir/InputSpotRate-$dir.log" ) {
            my $l = `wc -l "$dir/InputSpotRate-$dir.log" 2>/dev/null`;
                chomp $l; 
                $l =~ s/^\s*//; 
                $l =~ s/^(\d+)\s.*$/$1/;
            $lines += $l if ( $l =~ /^\d+$/ );
        }
    }
    logIt ( $key, $lines );
}
