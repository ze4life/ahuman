#!/usr/bin/perl
#
# $Id: LatencyBreakdown.pl,v 1.2 2008/11/06 09:38:02 kovyale Exp $
#
# Supported: Solaris, Linux
#

$debug=0;

if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$LOG="/export/log/monitor/$PROGRAM.log";
$PID="/export/log/monitor/$PROGRAM.pid";

# rotate log size 50Mb
$LOG_ROTATE_SIZE=50 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    close STDOUT;
    close STDERR;
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# flush the buffer
$| = 1;

# check if the programm is already running
&checkpid;

if (not $debug) {
# daemonize the program
    &daemonize;

# save pid
    &savepid;
}

# load libraries
use lib "./lib/5.6.1";
$uname = `uname -s`;
if ( $uname eq "SunOS" ) {
    push (@INC , "./lib/5.6.1/sun4-solaris-64int") ;
}
use File::Tail;

# the log files to tail
my @logs = qw(
   /export/home/reflexuat/logs/MessageLog.OutputSpotRate/OutputSpotRate/OutputSpotRate-statistics.log
   /export/home/reflexprod/logs/MessageLog.OutputSpotRate/OutputSpotRate/OutputSpotRate-statistics.log
);

# open files
my @fds;
for (@logs) {
    if ( -f "$_" ) {
        push( @fds, File::Tail->new(
                name => "$_",
                interval => 0,
                maxinterval => 1,
                ignore_nonexistant => 1,
                resetafter => 30,
                debug => $debug,
            )
        );
    }
}

my $timeout = 60;
my $lasttime = undef;
my $InputSpotRate = undef;
my $SpotServer = undef;
my $OutputSpotRate = undef;

while (1) {
    my ($nfound,$timeleft,@pending) = File::Tail::select(undef,undef,undef,$timeout,@fds);

    if ($nfound) {
        for (@pending) {
            my $line = $_->read;
            # skip Blend
            next if (/Blend/);

            my %hash;
            for ( split(/, /, $line) ) {
                if (/=/) {
                    my ($k, $v) = split(/=/);
                    $hash{$k} = $v;
                }
            }

            next if ( 
                not defined $hash{Start} or 
                not defined $hash{Feed} or 
                not defined $hash{End} or 
                not defined $hash{Now} 
            );

            my $time = int ( $hash{Now} / 1000 );

            my $i = $hash{Start} - $hash{Feed};
            my $s = $hash{End} - $hash{Start};
            my $o = $hash{Now} - $hash{End};

            if ( $time > $lasttime ) {
                print "$lasttime:$InputSpotRate:$SpotServer:$OutputSpotRate\n";
                $InputSpotRate = 0;
                $SpotServer = 0;
                $OutputSpotRate = 0;
                $lasttime = $time;
            } else { 
                $InputSpotRate = $i if ( $i > $InputSpotRate );
                $SpotServer = $s if ( $s > $SpotServer );
                $OutputSpotRate = $o if ( $o > $OutputSpotRate );
            }
        }
    } 

    # check self log file
    &checklog;
}
