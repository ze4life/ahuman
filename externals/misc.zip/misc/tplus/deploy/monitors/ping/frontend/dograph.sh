#!/bin/sh

#2006-08-10 11:43:44
. ./env.sh

# globals
geometry="-w 900 -h 150 --interlaced"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

Ri=255
Gi=0
Bi=0

for rrd in *.rrd
do
    name=`basename "$rrd" .rrd`

R=`printf "%02x" $Ri`
G=`printf "%02x" $Gi`
B=`printf "%02x" $Bi`

    color="$R$G$B"
    #color="FF0000"

    GRAPH_HOUR="$GRAPH_HOUR DEF:$name=$rrd:d:MAX LINE1:$name#$color:$name"
    GRAPH_DAY="$GRAPH_DAY DEF:$name=$rrd:d:AVERAGE:step=300 LINE1:$name#$color:$name"

Ri=`expr $Ri + 60`;  if [ $Ri -gt 255 ]; then Ri=`expr $Ri - 255`; fi 
Gi=`expr $Gi + 90`;  if [ $Gi -gt 255 ]; then Gi=`expr $Gi - 255`; fi 
Bi=`expr $Bi + 120`;  if [ $Bi -gt 255 ]; then Bi=`expr $Bi - 255`; fi

done

#hour 
rrdtool graph HOUR.png \
$geometry  \
--title "Max ping delays. step 3 seconds. last 30 mins." \
--vertical-label "ms" \
--end $now \
--start end-30m \
$GRAPH_HOUR

#day 
rrdtool graph DAY.png \
$geometry  \
--title "Avg ping delays. step 10 minutes. last day." \
--vertical-label "ms" \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
$GRAPH_DAY
