#!/usr/bin/perl


$RRDtool="rrdtool";

sub createRRD {
    my $name = shift;
    my $rc = system($RRDtool, "create", "$name.rrd", "--start", 
        "20061101", "--step", "1", "DS:d:GAUGE:15:U:U",
        "RRA:AVERAGE:0.5:3:3153600", "RRA:MAX:0.5:3:3153600" );
    return $rc;
}

my %failedToCreate;
my %lastUpdate;

while (<STDIN>) {
    chomp;

    next if (! /^[\w\s]+:\d+:\d+$/);

    my ($name,$time,$value) = split (/:/, $_, 3);

    $name =~ s/ /_/g;

    if ( ! -f "$name.rrd" && ! $failedToCreate{$name} ) {
        # create the RRD for the new name, and skip it if could
        if ( createRRD($name) != 0) {
            print STDERR "Could not create RRD for $name\n";
            $failedToCreate{$name} = 1;
            next;
        }
    }

    if ( ! $lastUpdate{$name} ) {
        my $l = `rrdtool info "$name.rrd" | grep last_update | cut -d= -f 2`;
        $l =~ s/ //g; chomp $l;
        $lastUpdate{$name} = $l;
    }

    if ( $time > $lastUpdate{$name} ) {
        if ( system($RRDtool, "update", "$name.rrd", "$time:$value") != 0 ) {
            print STDERR "Could not update $name.rrd\n";
        } else { 
            $lastUpdate{$name} = $time;
        }
    }
}
