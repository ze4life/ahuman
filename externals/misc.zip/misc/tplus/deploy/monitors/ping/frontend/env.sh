#!/bin/sh
#
# $Id: env.sh,v 1.1 2007/09/05 12:13:37 kovyale Exp $
#

PATH=$HOME/rrdtool-1.2.15/bin:$PATH
export PATH

LD_LIBRARY_PATH=$HOME/rrdtool-1.2.15/lib
export LD_LIBRARY_PATH

# SSH Connection details
SSH_USER=tplu2
SSH_HOST=cst-fju1
APPLICATION_USER=tplu2

# Scale for delays graph
# PROD -u 50
# UAT  -u 100
DELAYS_GRAPH_SCALE="-l 0 -u 100 -r"

# End date for graphs
NOW=now

# time zone variable to be used in graphs
# should not be TZ since TZ variable will affect
# the log files contain the timestamp in localtime
# so will use mktime's isdst -1 
TZONE=`date +"%Z"`
