#!/bin/sh
#
# $Id: ping.sh,v 1.5 2007/09/05 13:49:44 kovyale Exp $
#

# default values, can be overrided by $HOME/monitor/env.sh
PING_HOSTS="dnau1"
PING_LOG=$HOME/monitor/ping.log
PING_SLEEP=1

if [ -f "$HOME/monitor/env.sh" ]; then
    . $HOME/monitor/env.sh
fi

while true
do
    if [ -f "$HOME/monitor/env.sh" ]; then
        . $HOME/monitor/env.sh
    fi
    for host in $PING_HOSTS
    do
        time=`perl -e "print time"`
        delay=`ping -s $host 1472 1 | grep "bytes from" | awk '{print $7}' | cut -d= -f2 | sed "s/\.//"`
        echo "$host:$time:$delay" >> $PING_LOG
    done
    sleep $PING_SLEEP
done
