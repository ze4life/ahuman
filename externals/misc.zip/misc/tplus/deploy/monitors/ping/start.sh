#!/bin/sh

PID=`ps -ef | grep $LOGNAME | grep -v grep | grep ping.sh | awk '{print $2}'`
if [ -n "$PID" ]; then
    echo ping,sh already running, pid:$PID
    exit 1
fi

nohup ./ping.sh &
