#!/usr/bin/perl
#
# $Id: netstat.pl,v 1.5 2008/10/10 07:56:20 kovyale Exp $
# Linux framework to get the network bytes
#

$debug=0;

my $ifname = $ARGV[0];
if ( not $ifname ) {
    print "\n";
    print "\tUse: $0 InterfaceName [SleepTime]\n";
    print "\n";
    print "\tPrint network statistic. Linux and Solaris are supported.\n";
    print "\tDefault SleepTime is 5 seconds\n";
    print "\tOnly suuply phisycal interface. Does not work with logincal ones\n";
    print "\n";
    print "\tExample: $0 eth0\n";
    print "\n";
    exit(1);
}
my $sleeptime = $ARGV[1];
if ( not $sleeptime ) {
    # default
    $sleeptime = 5;
}


my $uname = `uname -s`;
chomp($uname);


if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$LOG="$ENV{HOME}/monitor/netstat/$PROGRAM.log";
$PID="$ENV{HOME}/monitor/netstat/$PROGRAM.pid";

# rotate log size 50Mb
$LOG_ROTATE_SIZE=50 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    close STDOUT;
    close STDERR;
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# flush the buffer
$| = 1;

# check if the programm is already running
&checkpid;

if (not $debug) {
# daemonize the program
    &daemonize;

# save pid
    &savepid;
}

sub doNetstatLinux {
    my $ifname = $_[0];
    my $time = time;
    my $stats_file = "/proc/net/dev";

    if ( not -f $stats_file ) {
        print "Bah! The $stats_file does not exist!\n";
        exit(1);
    }
# Inter-|   Receive                                                |  Transmit
#  face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
#   eth0: 3235873   33218    0    0    0     0          0         0  4368405   26867    0    0    0     0       0          0
#     lo:       0       0    0    0    0     0          0         0        0       0    0    0    0     0       0          0
    #
    my $i_bytes = 0;
    my $o_bytes = 0;

    open DEV, $stats_file or die;
    while(<DEV>) {
        chomp;
        if (/:/) {
            s/^\s*//;
            s/:/ /;
            my (@ifstat) = split(/\s+/);
            if ( $ifname ) {
                if ( "$ifstat[0]" eq "$ifname" ) {
                    $i_bytes = $ifstat[1];
                    $o_bytes = $ifstat[9];
                    last;
                }
            } else {

                $i_bytes += $ifstat[1];
                $o_bytes += $ifstat[9];
            }
        }
    }
    close DEV;
    return "$time:$i_bytes:$o_bytes";
}

sub doNetstatSunOS {
    my $ifname = $_[0];
    my $time = time;
    my $kstat = "/usr/bin/kstat";

    if ( not -f $kstat ) {
        print "Bah! The $kstat does not exist!\n";
        exit(1);
    }

#    fjgi:0:fjgi0:obytes     1167066539
#    fjgi:0:fjgi0:obytes64   151490921899
#    fjgi:0:fjgi0:rbytes     3579541677
#    fjgi:0:fjgi0:rbytes64   407306467501

    my $tmp = `kstat -p '*:*:$ifname:rbytes64'`;
    chomp($tmp);
    my ($t, $i_bytes) = split(/\s+/, $tmp, 2);

    my $tmp = `kstat -p '*:*:$ifname:obytes64'`;
    chomp($tmp);
    my ($t, $o_bytes) = split(/\s+/, $tmp, 2);

    return "$time:$i_bytes:$o_bytes";
}

while(1) {
    if ( $uname eq "Linux" ) {
        print doNetstatLinux($ifname), "\n";
    }
    elsif ( $uname eq "SunOS" ) {
        print doNetstatSunOS($ifname), "\n";
    }
    else {
        print "$uname is unsupported\n";
        exit(1);
    }
    sleep($sleeptime);

    # check self log file
    &checklog;

}
