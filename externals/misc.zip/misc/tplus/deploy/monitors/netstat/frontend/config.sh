#!/bin/sh

# the list of servers
SERVERS="abfxp1@abfxp1.uk.db.com \
abfxp2@abfxp2.uk.db.com \
abfxp3@abfxp3.uk.db.com \
abfxp1@abfxp1.us.db.com \
abfxu1@abfxu1.uk.db.com \
tpint@longmeappp22-int-v1.uk.db.com:31122 \
tpint@longmeappp23-int-v1.uk.db.com:31122 \
tpint@longmeappp24-out-v1.uk.db.com:31122 \
tpint@longmeappp25-out-v1.uk.db.com:31122 \
abfxint@singmfxwbp1-lower.sg.db.com:31122 \
abfxint@singmfxwbp2-lower.sg.db.com:31122 \
tpintra@longmfxsappp1.uk.db.com \
tpintra@longmfxsappp2.uk.db.com \
abfxint@longmeappp27-out-v1.uk.db.com:31122 \
abfxint@longmeappp26-int.uk.db.com:31122 \
"
