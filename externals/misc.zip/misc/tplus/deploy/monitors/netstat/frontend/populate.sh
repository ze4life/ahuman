#!/bin/sh
#
# $Id: populate.sh,v 1.2 2008/05/25 09:22:10 kovyale Exp $
#

. ../../env.sh

# SERVERS are defined here
. ./config.sh

SSH_CMD="ssh -oPasswordAuthentication=no -oUserKnownHostsFile=/dev/null \
-oStrictHostKeyChecking=no -oCompression=yes -oCompressionLevel=6"

for USER_HOST in $SERVERS
do

    USER=`echo $USER_HOST | cut -d@ -f1`
    HOST=`echo $USER_HOST | cut -d@ -f2`
    PORT=22

    if [ -n "`echo $HOST | grep \":\"`" ]; then
        # the ssh port defined
        PORT=`echo $HOST | cut -d: -f2`
        HOST=`echo $HOST | cut -d: -f1`
    fi

    $SSH_CMD -p$PORT $USER@$HOST "( cd monitor/netstat && nice -n 19 tail -36 netstat.pl.log )" \
    | ./do.pl $HOST | /bin/sh -x

done
