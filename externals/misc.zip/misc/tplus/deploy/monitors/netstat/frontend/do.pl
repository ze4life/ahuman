#!/usr/bin/perl

$RRDtool="rrdtool";

$hostname = $ARGV[0];
if ( not defined $hostname ) {
    print "Use: cat LOG | $0 hostname\n";
    exit 1;
}

sub createRRD {
    my $name = shift;
    my $rc = system($RRDtool, "create", "$name.rrd", "--start", 
        "20061101", "--step", "5", 

        "DS:i:DERIVE:10:0:U",
        "DS:o:DERIVE:10:0:U",

        "RRA:AVERAGE:0.5:2:3153600",

    );
    return $rc;
}

if ( ! -f "$hostname.rrd" ) {
    # create the RRD for the new user, and skip it if could
    if ( createRRD($hostname) != 0) {
        print STDERR "Could not create RRD for $hostname\n";
        exit 1;
    }
}

my $lastupdate=0;
my $maxargs=40;
my $args = '';
my $nargs = 0;

if ( ! $lastupdate ) {
    my $l = `rrdtool info $hostname.rrd | grep last_update | cut -d= -f 2`;
    $l =~ s/ //g; chomp $l;
    $lastupdate = $l;
}

while (<STDIN>) {
    chomp;

    next if (! /^\d+:\d+:\d+$/ );

    my ($time,$i,$o) = split (/:/, $_, 3);


    if ( $time >= $lastupdate + 1) {
        $args .= " $time:$i:$o";
        $lastupdate=$time;

        if ( $nargs >= $maxargs ) {
            print "rrdupdate $hostname.rrd $args\n";
            $nargs=0;
            $args='';
        } else {
            $nargs++;
        }
    }
}
if ($args) {
    print "rrdupdate $hostname.rrd $args\n";
}
