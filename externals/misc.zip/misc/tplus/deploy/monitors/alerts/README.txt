INSTALL
^^^^^^^
Unzip and untar the lib.tar.gz into the alerts_tail.pl instalation directory.
