#!/usr/bin/perl
#
# $Id: alerts_tail.pl,v 1.8 2008/11/06 09:38:02 kovyale Exp $
#
# Perl daemon monitoring t+ fx+ fxo alerts.
#
# Supported: Solaris, Linux
#

$debug=0;

if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$LOG="$ENV{HOME}/monitor/$PROGRAM.log";
$PID="$ENV{HOME}/monitor/$PROGRAM.pid";

# rotate log size 50Mb
$LOG_ROTATE_SIZE=50 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    close STDOUT;
    close STDERR;
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# flush the buffer
$| = 1;

# check if the programm is already running
&checkpid;

if (not $debug) {
# daemonize the program
    &daemonize;

# save pid
    &savepid;
}

# load libraries
use lib "./lib/5.6.1";
$uname = `uname -s`;
if ( $uname eq "SunOS" ) {
    push (@INC , "./lib/5.6.1/sun4-solaris-64int") ;
}
use File::Tail;

# the log files to tail
my @logs = qw(
    tplus/deploy/dbag/log/server.log
    tplus/deploy/dbag/log/authserver.log
    fxplus/level_1/dbag/release/log/cfetsbridge.log
    fxplus/level_1/dbag/release/log/currenexbridge.log
    fxplus/level_1/dbag/release/log/dedicated_ratefan.log
    fxplus/level_1/dbag/release/log/email.log
    fxplus/level_1/dbag/release/log/fxallmdpibridge.log
    fxplus/level_1/dbag/release/log/ratefan.log
    fxplus/level_1/dbag/release/log/server.log
    fxplusoptions/log/fxo.log
);

# open files
my @fds;
for (@logs) {
    push( @fds, File::Tail->new(
            name => "$ENV{HOME}/$_",
            interval => 0,
            maxinterval => 1,
            ignore_nonexistant => 1,
            resetafter => 30,
            debug => $debug,
        )
    );
}

my $timeout = 60;

while (1) {
    my ($nfound,$timeleft,@pending) = File::Tail::select(undef,undef,undef,$timeout,@fds);

    if ($nfound) {
        my $time = time;
        for (@pending) {
            my $line = $_->read;
            #my $file = $_->{"input"};
            if ( $line =~ /\[audittrail\./ ) {
                print "$time $line";
            }
        }
    } 
    #else {
    #    # timeout
    #}

    # check self log file
    &checklog;
}
