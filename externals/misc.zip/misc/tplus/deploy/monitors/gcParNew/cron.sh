#!/bin/sh

cd $HOME/monitor/  && \
(
./gcParNew.pl server $HOME/fxplus/level_1/dbag/release/log/serverstdout.log 
)
