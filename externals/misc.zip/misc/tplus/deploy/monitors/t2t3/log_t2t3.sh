#!/bin/sh

renice -n 19 $$

SERVER_LOG=$HOME/fxplus/level_1/dbag/release/log/server.log
TMPFILE=$HOME/monitor/log_t2t3.tmp.$$

T2T3_LOG="$HOME/monitor/t2t3.log"

if [ -f $SERVER_LOG ]; then
    DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
    grep "completed processing in seconds" $SERVER_LOG > $TMPFILE
    MS=`grep "= 0.[1-9]" $TMPFILE | wc -l `
    SEC=`grep "= [1-9].[0-9]" $TMPFILE | wc -l`
    echo $DATE $MS $SEC >> $T2T3_LOG
    rm $TMPFILE
fi
