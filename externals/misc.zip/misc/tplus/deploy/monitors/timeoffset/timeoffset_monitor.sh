#!/bin/sh
#
# $Id: timeoffset_monitor.sh,v 1.3 2007/03/24 12:58:56 fxplusAutoBuild Exp $
#
# timeoffset_monitor script

# load global config
. $HOME/monitor/env.sh

SCRIPT_LOG=$HOME/monitor/timeoffset_monitor.log

# update DATE
DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`

for ntphost in $NTP_HOSTS; do
	 offset=`/usr/sbin/ntpdate -q $ntphost | head -1 | sed -e "s/\(offset .*\),/\1 sec,/"`
	 echo $DATE "[$$]" $offset >> $SCRIPT_LOG
done
