#!/bin/sh
#
# $Id: log_rejects.sh,v 1.2 2007/04/13 08:17:19 kovyale Exp $
#
# 1. get the number of rows in the TRADES table.
# 2. log them

# must be same as in graphic making script
LOGFILE=$HOME/monitor/traderejects.log

# load common environment script
. $HOME/monitor/env.sh

DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
REJECTS=`$SQLPLUS -s $DATABASE_DETAILS @$HOME/deploy/monitors/trades/get-rejects.sql`

echo $DATE $REJECTS >> $LOGFILE
