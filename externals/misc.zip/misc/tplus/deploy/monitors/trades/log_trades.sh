#!/bin/sh
#
# $Id: log_trades.sh,v 1.4 2007/04/09 08:11:44 kovyale Exp $
#
# 1. get the number of rows in the TRADES table.
# 2. log them

# must be same as in graphic making script
LOGFILE=$HOME/monitor/trades.log

# load common environment script
. $HOME/monitor/env.sh

DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
TRADES=`$SQLPLUS -s $DATABASE_DETAILS @$HOME/deploy/monitors/trades/get-trades.sql`

echo $DATE $TRADES >> $LOGFILE
