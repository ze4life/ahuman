#!/bin/sh
#
# $Id: log_speed.sh,v 1.3 2007/04/24 12:27:47 kovyale Exp $
#

# must be same as in graphic making script
LOGFILE=$HOME/monitor/tradespeed.log

# load common environment script
. $HOME/monitor/env.sh

TZONE=`date +"%Z"`
$SQLPLUS -s $DATABASE_DETAILS @$HOME/deploy/monitors/trades/get-speed.sql \
| grep -v "^$" | tr '\t' ' ' | sed -e "s/  */ /g" -e "s/ \([0-9]*\)$/ $TZONE \1/" \
>> $LOGFILE
