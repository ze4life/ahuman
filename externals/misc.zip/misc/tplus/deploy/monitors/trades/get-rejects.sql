SET HEAD OFF FEED OFF LINES 80
COL AA FORMAT A100 NEWLINE
select count(*) from mis_trade_requests t where TRADED = 'N';
EXIT;
