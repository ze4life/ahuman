SET HEAD OFF FEED OFF LINES 100
COL AA FORMAT A100 NEWLINE
SELECT SubStr(second,1, 18) || '0' ten_seconds, Max(trade_count) trade_max
FROM (
        SELECT To_char(trade_input_time+substr(tz_offset('Europe/London'),1,3)/24, 'YYYY-MM-DD HH24:MI:SS') second, Count(*) trade_count FROM trades
        WHERE
        trade_input_time BETWEEN SYSDATE-1/24/6-substr(tz_offset('Europe/London'),1,3)/24 AND SYSDATE-substr(tz_offset('Europe/London'),1,3)/24
        AND source='C'
        GROUP BY To_char(trade_input_time+substr(tz_offset('Europe/London'),1,3)/24, 'YYYY-MM-DD HH24:MI:SS')
     ) GROUP BY SubStr(second,1, 18) || '0'
/
EXIT;
