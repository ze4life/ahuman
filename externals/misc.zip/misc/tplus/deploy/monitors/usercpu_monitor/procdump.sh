#!/bin/sh
#
# This script monitors CPU usage, dumping proc table to file and mailing top 10 CPU consumers
#
# How to use it: edit MAILTO below, insert crontab jobs and change their paths and threshold
#
# 40 * * * * test -r /CHANGE_PATH/procdump.sh && sh /CHANGE_PATH/procdump.sh /CHANGE_PATH/procdump.log 20
# 0 0 * * * cat /var/tmp/procdump.pid | xargs kill -USR1 >/dev/null 2>/dev/null

# mail recipients separated by space
# you can comment out MAILTO and mail notification will be off
MAILTO="dima.scherbakov@db.com alexey.kovyrshin@db.com mark.wimpory@db.com viacheslav.tsarev@db.com"
# mail only once per MAILWINDOW minutes
MAILWINDOW=90
# dump process information at least every DUMPEVERY minutes
DUMPEVERY=5
# maximum log file size in KB
LOGMAX=131072
LOG=$1
IDLEWARN=$2
PIDFILE=/var/tmp/procdump.pid
# need /usr/lib/sendmail on Solaris
PATH=$PATH:/usr/lib

[ -f "env.sh" ] && . ./env.sh


if [ -x /usr/ucb/ps ]; then
    PS=/usr/ucb/ps
else
    PS=ps
fi

# remove temporary files on signals
trap cleanup 1 2 3 6 15
cleanup() {
    if [ "$TERM" ] && [ "$TERM" != dumb ]; then
        echo "Caught Signal ... cleaning up."
    fi
    rm -f ps.$$ /var/tmp/procdump.pid
    exit 0
}

# rotate logs on SIGUSR
trap rotatenow 10 12 16 17
rotatenow() {
    ROTATENOW=1
}

# rotate logs
rotatelogs() {
    if [ -r $LOG ]; then
        mv $LOG $LOG.latest
        renice +10 $$ > /dev/null
        rm -f $LOG.99.bz2
        i=98
        while [ "$i" -ge 0 ]; do
            if [ -r "$LOG.$i.bz2" ]; then
                mv $LOG.$i.bz2 $LOG.`expr $i + 1`.bz2
            fi
            i=`expr $i - 1`
        done
        mv $LOG.latest $LOG.0
        bzip2 -9 $LOG.0
    fi
}

# chech if process is not already running
if [ -r $PIDFILE ]; then
    PID=`cat $PIDFILE`
    if ps -o args -p "$PID" | tail -1 | grep procdump > /dev/null; then
        if [ "$TERM" ] && [ "$TERM" != dumb ]; then
            echo "ERROR: procdump.sh is already running. PID: $PID"
            exit 1
        else
            exit 0
        fi
    fi
fi
# save PID
echo $$ > $PIDFILE

# count arguments
if [ -z "$2" ]; then
    echo "Need two arguments: $0 LOGFILE IDLEWARN"
    exit 1
fi

# rotate logs before start
rotatelogs

# main loop
NEXTMAIL=1
NEXTLOG=1
while true; do
    if [ "$ROTATENOW" = 1 ]; then
        rotatelogs
        ROTATENOW=0
    fi
    # get unix time from perl
    UTIME=`perl -e "print time"`
    SAR=`sar -u 10 | tail -1`
    IDLE=`echo $SAR | sed -e 's/.* //' | sed -e 's/\..*//'`
    # check for logfile overflow
    if [ -r $LOG ] && [ "`du -k $LOG | cut -f1`" -gt $LOGMAX ]; then
        if tail 1 $LOG | grep "LOGGING DISABLED" > /dev/null; then
            sleep 3
            continue
        else
            if [ "$MAILTO" ]; then
                (
                if [ -n "$FROM" ]; then
                    echo "From: $FROM <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
                elif [ -n "$ENVIRONMENT" ]; then
                    echo "From: $ENVIRONMENT <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
                fi
                echo Subject: MONITORING: disabling monitoring on `hostname`.`domainname`
                echo
                echo "Log file is flooded. Monitoring of box `hostname`.`domainname` is disabled until next log rotation."
                ) | sendmail $MAILTO
            fi
            (
            echo
            echo "ERROR: LOG FILE IS FLOODED. LOGGING DISABLED"
            ) >> $LOG
            sleep 3
            continue
        fi
    fi
    # dump process table to file on high CPU load or on $DUMPEVERY interval
    if [ "$IDLE" -lt "$IDLEWARN" ] || [ "$UTIME" -ge "$NEXTLOG" ]; then
        # recalculate next surveillance process dump
        NEXTLOG=`expr $UTIME + $DUMPEVERY \* 60`
        $PS auxww | grep -v "^USER" | sort -nrk 3 > ps.$$
        DATE=`date`
       (
            echo ""
            echo DATE: $DATE
            echo SAR: $SAR
            sed -e 's/  */ /g' < ps.$$
        ) | sed -e "s/^/$UTIME: /" >> $LOG 2>/dev/null
        # mailing to $MAILTO
        if [ "$MAILTO" ] && [ "$IDLE" -lt "$IDLEWARN" ] && [ "$UTIME" -ge "$NEXTMAIL" ]; then
            # recalculate next mailing date
            if [ "$UTIME" -ge "$NEXTMAIL" ]; then
                NEXTMAIL=`expr $UTIME + $MAILWINDOW \* 60`
            fi
            (
                USAGE=`expr 100 - $IDLE`
                if [ -n "$FROM" ]; then
                    echo "From: $FROM <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
                elif [ -n "$ENVIRONMENT" ]; then
                    echo "From: $ENVIRONMENT <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
                fi
                echo "Subject: MONITORING: high CPU usage ($USAGE%) on `hostname`.`domainname`"
                echo ""
                echo "High CPU usage has been identified on `hostname`.`domainname`"
                echo "CPU utilization was $USAGE%"
                echo "Mail notifications are suppressed for next $MAILWINDOW minutes"
                echo
                echo "Date: `date`"
                echo "SAR: $SAR"
                echo "Top 10 processes"
                $PS u | head -1
                head ps.$$
            ) | sendmail $MAILTO
        fi
    fi
    sleep 1
done
