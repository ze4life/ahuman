#!/usr/bin/perl
#
# $Id: usercpu_monitor.pl,v 1.9 2008/05/27 08:01:23 kovyale Exp $
#
# Perl daemon monitoring user CPU usage.
# Uses ps -e to get the output and group by user
#
# Supported: Solaris, Linux
#

if ( $0 =~ /\// ) {
    $PROGRAM=substr($0, rindex($0, "/") + 1);
} else {
    $PROGRAM=$0;
}
$USER=$ENV{LOGNAME};
$LOG="$ENV{HOME}/monitor/$PROGRAM.log";
#$LOG="/export/log/monitor/$PROGRAM.log";
$PID="$ENV{HOME}/monitor/$PROGRAM.pid";

# rotate log size 20Mb
$LOG_ROTATE_SIZE=20 * 1024 * 1024;

use POSIX qw(setsid);

sub checklog {
    if ( -f "$LOG" ) {
        my $size = -s $LOG;
        if ( $size >= $LOG_ROTATE_SIZE ) {
            my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
            $year += 1900;
            $mon++;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d-%d%d%d", $mon, $mday, $hour, $min, $sec;
            #rename $LOG, sprintf "$LOG.$year-%02d-%02d", $mon, $mday;
            rename $LOG, "$LOG.old";
            &reopenlog;
        }
    } else {
        &reopenlog;
    }
}

sub reopenlog {
    close STDOUT;
    close STDERR;
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
}

sub checkpid {
    if ( -f "$PID" ) {
        open PID, "$PID" or die "Can't read $PID: $!";
        my $pid = <PID>;
        close PID;
        chomp $pid;
        my $running = `ps -o user,args -p $pid | grep $USER | grep -v grep`;
        if ( $running =~ /$PROGRAM/ ) {
            print STDERR "Seems like the $PROGRAM is already running\n$pid\n";
            exit 1;
        }
    }
}

sub savepid {
    open PID, ">$PID" or die "Can't write $PID: $!";
    print PID "$$\n";
    close PID;
}

sub daemonize {
    chdir '/'                 or die "Can't chdir to /: $!";
    open STDIN, '/dev/null'   or die "Can't read /dev/null: $!";
    open STDOUT, ">>$LOG" or die "Can't write to $LOG: $!";
    open STDERR, ">>$LOG" or die "Can't write to $LOG: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

# flush the buffer
$| = 1;

# check if the programm is already running
&checkpid;

# daemonize the program
&daemonize;

# save pid
&savepid;

while (1) {

    my @ps = split(/\n/, `ps -eo user,rss,vsz,pcpu,time`);

    my %stat;

    for (@ps) {

        # on solaris there is leading spaces
        s/^\s*//;

        next if ( /^USER\s+RSS\s+VSZ\s+\%CPU\s+TIME/ ) ;

        my ($user, $rss, $vsz, $pcpu, $time) = split (/\s+/);

        # convert time into seconds
        if ( $time =~ /^(\d+):(\d+)$/ ) {
            $time = $1 * 60 + $2;
        }
        elsif ( $time =~ /^(\d+):(\d+):(\d+)$/ ) {
            $time = $1 * 60 * 60 + $2 * 60 + $3;
        }
        elsif ( $time =~ /^(\d+)-(\d+):(\d+):(\d+)$/ ) {
            $time = $1 * 24 * 60 * 60 + $2 * 60 * 60 + $3 * 60 + $4;
        }

        if ( not defined $stat{$user}{pcpu} ) {
            $stat{$user}{pcpu} = $pcpu;
        } else {
            $stat{$user}{pcpu} += $pcpu;
        }

        if ( not defined $stat{$user}{rss} ) {
            $stat{$user}{rss} = $rss;
        } else {
            $stat{$user}{rss} += $rss;
        }

        if ( not defined $stat{$user}{vsz} ) {
            $stat{$user}{vsz} = $vsz;
        } else {
            $stat{$user}{vsz} += $vsz;
        }

        if ( not defined $stat{$user}{time} ) {
            $stat{$user}{time} = $time;
        } else {
            $stat{$user}{time} += $time;
        }

    }

    for my $user (keys %stat) {
        my $time = time;
        print "$time:$user:$stat{$user}{pcpu}:$stat{$user}{time}:$stat{$user}{rss}:$stat{$user}{vsz}\n";
    }

    sleep(10);

    &checklog;
}
