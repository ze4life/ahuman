#!/bin/sh

RRD=$1
RRDNAME=`basename $RRD`
DIRNAME=`dirname $RRD`

rrdtool dump $RRD $DIRNAME/$RRDNAME.xml
if [ $? -ne 0 ]; then
    echo Failed: rrdtool dump $RRD $DIRNAME/$RRDNAME.xml
    exit 1
fi

perl add2xml.pl < $DIRNAME/$RRDNAME.xml > $DIRNAME/$RRDNAME.tmp.xml
if [ $? -ne 0 ]; then
    echo "Failed: perl add2xml.pl < $DIRNAME/$RRDNAME.xml > $DIRNAME/$RRDNAME.tmp.xml"
    exit 1
fi

rrdtool restore $DIRNAME/$RRDNAME.tmp.xml $DIRNAME/$RRDNAME.tmp.rrd
if [ $? -ne 0 ]; then
    echo Failed: rrdtool restore $DIRNAME/$RRDNAME.tmp.xml $DIRNAME/$RRDNAME.tmp.rrd
    exit 1
fi


mv $RRD $RRD.bak
mv $DIRNAME/$RRDNAME.tmp.rrd $RRD
