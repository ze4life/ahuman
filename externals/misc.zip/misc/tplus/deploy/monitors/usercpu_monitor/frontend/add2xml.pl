#!/usr/bin/perl
#
$ds = "vsz";
$dstype = "GAUGE";
$heartbeat = 120 ;
$action = 'add';

# Create a marker hash ref to store temporary state
my $marker = {
    currentDSIndex => 0,
    deleteDSIndex => undef,
    addedNewDS => 0,
    parse => 0,
    version => 1,
};

# Parse the input XML file
while (local $_ = <STDIN>) {
    chomp;

    # Find out what index number the existing DS definition is in
    if ($action eq 'del' && /<name>\s*(\S+)\s*<\/name>/) {
        $marker->{deleteIndex} = $marker->{currentDSIndex} if $1 eq $ds;
        $marker->{currentDSIndex}++;
    }

    # Add the DS definition
    if ($action eq 'add' && !$marker->{addedNewDS} && /<rra>/) {
        print STDOUT <<EndDS;
        <ds>
                <name> $ds </name>
                <type> $dstype </type>
                <minimal_heartbeat> $heartbeat </minimal_heartbeat>
                <min> 0.0000000000e+00 </min>
                <max> NaN </max>

                <!-- PDP Status -->
                <last_ds> UNKN </last_ds>
                <value> 0.0000000000e+00 </value>
                <unknown_sec> 0 </unknown_sec>
        </ds>

EndDS
        $marker->{addedNewDS} = 1;
    }

    # Insert DS under CDP_PREP entity
    if ($action eq 'add' && /<\/cdp_prep>/) {
        # Version 0003 RRD from rrdtool 1.2x
        if ($marker->{version} >= 3) {
            print STDOUT "			<ds>\n";
            print STDOUT "			<primary_value> 0.0000000000e+00 </primary_value>\n";
            print STDOUT "			<secondary_value> 0.0000000000e+00 </secondary_value>\n";
            print STDOUT "			<value> NaN </value>\n";
            print STDOUT "			<unknown_datapoints> 0 </unknown_datapoints>\n";
            print STDOUT "			</ds>\n";

            # Version 0001 RRD from rrdtool 1.0x
        } else { 
            print STDOUT "			<ds><value> NaN </value>  <unknown_datapoints> 0 </unknown_datapoints></ds>\n";
        }
    }

    # Look for the end of an RRA
    if (/<\/database>/) {
        $marker->{parse} = 0;

        # Find the dumped RRD version (must take from the XML, not the RRD)
    } elsif (/<version>\s*([0-9\.]+)\s*<\/version>/) {
        $marker->{version} = ($1 + 1 - 1);
    }

    # Add the extra "<v> NaN </v>" under the RRAs. Just print normal lines
    if ($marker->{parse} == 1) {
        if ($_ =~ /^(.+ <row>.+)(<\/row>.*)/) {
            print STDOUT $1;
            print STDOUT "<v> NaN </v>" if $action eq 'add';
            print STDOUT $2;
            print STDOUT "\n";
        }
    } else {
        print STDOUT "$_\n";
    }

    # Look for the start of an RRA
    if (/<database>/) {
        $marker->{parse} = 1;
    }
}

