#!/bin/sh
#
# $Id: run.sh,v 1.6 2007/11/12 08:13:02 kovyale Exp $
#

PATH=$HOME/bin:/usr/bin:/usr/local/bin:$PATH
export PATH

LD_LIBRARY_PATH=$HOME/bin
export LD_LIBRARY_PATH

script=$1

renice 19 $$

MYDIR=`dirname $0`

test -d $MYDIR || exit 1

cd $MYDIR

if [ ! -r "$script" ]; then
    echo could not find $script
    exit 1
fi

# check if the script is alrady running
running=`ps -ef | grep $LOGNAME | grep -v grep | grep $script | grep -v run.sh`
if [ -n "$running" ]; then
    echo $script is still running
    echo $running
    exit 1
fi

exec 1> run_$script.log 2>&1

perl $script
