#!/usr/bin/perl
#
#

require "./config.pl";

use POSIX ":sys_wait_h";

$max_running_childs = 2;
$running_childs = 0;

open IDX, "> hosts/index.html.new" or die;
open IDXT, "> hosts/time.html.new" or die;

print IDX <<EOF
<head>
         <TITLE>User CPU</TITLE>
         <meta http-equiv="refresh" content="30">
         <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
<a href="http://confluence.gslb.db.com/display/ABFX/CPUAlerts">CPU alerts notification</a>
<br />
EOF
;
print IDXT <<EOF
<head>
         <TITLE>User CPU</TITLE>
         <meta http-equiv="refresh" content="30">
         <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
EOF
;

for my $host (sort keys %CFG) {

    # skip disabled hosts
    next if ( $CFG{$host}{disabled} =~ /yes/i );

    while ($running_childs == $max_running_childs) {
        print "waitpid...($running_childs) \n";
        my $kid = waitpid(-1, 0);
        print "Got kid $kid\n";
        $running_childs--;
    }

    my $pid = fork;

    die "fork" if (not defined $pid);

    if ($pid == 0) {
        #child
        if ( -d "hosts/$host" ) {
            `cp index.html hosts/$host/`;
            `perl ./draw.pl host=$host cpu_num=$CFG{$host}{cpu_num} os=$CFG{$host}{os} > hosts/$host/drawstdout.log 2>&1`;
        }
        exit;
    } else {
        #father
        print "Child $pid started\n";
        $running_childs++;
        if ( -d "hosts/$host" ) {
            print IDX "<a href=\"$host/\"><img src=\"$host/scpu_hour.png\"></a>";
            print IDXT "<a href=\"$host/\"><img src=\"$host/stime_hour.png\"></a>";
        }
    }
}

close IDX;
close IDXT;

while ($running_childs > 0) {
    print "wating for $running_childs kids \n";
    my $kid = waitpid(-1, 0);
    print "got kid $kid\n";
    $running_childs--;
}
print "all kids gone, exiting...\n";

rename "hosts/index.html.new", "hosts/index.html";
rename "hosts/time.html.new", "hosts/time.html";
