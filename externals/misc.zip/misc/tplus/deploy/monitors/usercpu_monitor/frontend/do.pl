#!/usr/bin/perl


#use Data::Dumper;

$RRDtool="rrdtool";

sub createRRD {
    my $name = shift;
    my $rc = system($RRDtool, "create", "$name.rrd", "--start", 
        "20061101", "--step", "10", 
        "DS:pcpu:GAUGE:120:0:U",
        "DS:time:DERIVE:120:0:U",
        "DS:rss:GAUGE:120:0:U",
        "DS:vsz:GAUGE:120:0:U",
        "RRA:MAX:0.5:1:1080",
        "RRA:MAX:0.5:6:43829",
        "RRA:MAX:0.5:60:13148",
        "RRA:MAX:0.5:360:26295",
        "RRA:AVERAGE:0.5:1:1080",
        "RRA:AVERAGE:0.5:6:43829",
        "RRA:AVERAGE:0.5:60:13148",
        "RRA:AVERAGE:0.5:360:26295",
    );
    return $rc;
}

my %User;
my $rrd_max_args = 40;

while (<STDIN>) {
    chomp;
    # skip non 1190194185:user:0:0:28320
    #1194757717:tplu4:0.3:13362:10182576
    #1194757717:tplu5:1.8:129817:16191584
    next if (! /^\d+:[^:]+:[^:]+:\d+:\d+$/ and ! /^\d+:[^:]+:[^:]+:\d+:\d+:\d+$/);
    my ( $timestamp,$user,$pcpu,$time,$rss,$vsz ) = split (/:/);
    $User{$user}{$timestamp}{pcpu} = $pcpu;
    $User{$user}{$timestamp}{time} = $time;
    $User{$user}{$timestamp}{rss} = $rss;
    if ($vsz) {
        $User{$user}{$timestamp}{vsz} = $vsz;
    } else { 
        $User{$user}{$timestamp}{vsz} = 'U';
    }
}

for my $user (keys %User) {

    if ( ! -f "$user.rrd" ) {
        # create the RRD for the new user, and skip it if could
        if ( createRRD($user) != 0) {
            print STDERR "Could not create RRD for $user\n";
            next;
        }
    }

    my $lastupdate = `rrdtool info "$user.rrd" | grep last_update | cut -d= -f 2`;
    $lastupdate =~ s/ //g; chomp $l;

    my @update_line;
    my $rrd_args = 0;

    for my $timestamp (sort {$a <=> $b} keys %{$User{$user}}) {

        if ( $timestamp > $lastupdate ) {
            if ( $rrd_args < $rrd_max_args ) {
                push(
                    @update_line,
                    "$timestamp:$User{$user}{$timestamp}{pcpu}:$User{$user}{$timestamp}{time}:$User{$user}{$timestamp}{rss}:$User{$user}{$timestamp}{vsz}"
                );
                $rrd_args++;
            } else {
                if ( 
                    system($RRDtool, "update", "$user.rrd", "-t", "pcpu:time:rss:vsz", @update_line) != 0 
                ) {
                    print STDERR "Could not update $user.rrd with array \@update_line\n";
                    for (@update_line) {
                        print "value|$_|\n";
                    }
                } 
                $rrd_args = 0;
                splice @update_line;
            }
        }
    } 
    if ( $rrd_args > 0 ) {
        if ( 
            system($RRDtool, "update", "$user.rrd", "-t", "pcpu:time:rss:vsz", @update_line) != 0 
        ) {
            print STDERR "Could not update $user.rrd with array \@update_line\n";
            for (@update_line) {
                print "value|$_|\n";
            }
        }
    }
}
