#!/usr/bin/perl
#
#

our %CFG = (
    'abfxp1.uk.db.com' => {
        'ssh_user' => 'abfxp1',
        'cpu_num' => 32,
    },
    'abfxp2.uk.db.com' => {
        'ssh_user' => 'abfxp2',
        'cpu_num' => 32,
    },
    'abfxp3.uk.db.com' => {
        'ssh_user' => 'abfxp3',
        'cpu_num' => 16,
    },
    'abfxu1.uk.db.com' => {
        'ssh_user' => 'abfxu1',
        'cpu_num' => 32,
    },
    'abfxb2.uk.db.com' => {
        'ssh_user' => 'abfxb2',
        'cpu_num' => 32,
    },
    'abfxb3.uk.db.com' => {
        'ssh_user' => 'abfxdem1',
        'cpu_num' => 16,
    },
    'abfxp1.us.db.com' => {
        'ssh_user' => 'abfxp1',
        'cpu_num' => 16,
    },
    'abfxu1.us.db.com' => {
        'ssh_user' => 'abfxu1',
        'cpu_num' => 16,
    },
    'reflexp1.us.db.com' => {
        'ssh_user' => 'reflexp1',
        'cpu_num' => 8,
    },
    'reflexp2.us.db.com' => {
        'ssh_user' => 'reflexp2',
        'cpu_num' => 8,
    },
    'longmfxf02p1b1.uk.db.com' => {
        'ssh_user' => 'tplp1',
        'cpu_num' => 32,
    },
    'longmfxf01p1a1.uk.db.com' => {
        'ssh_user' => 'tplp1',
        'cpu_num' => 32,
    },
    'cst-fjp1.uk.db.com' => {
        'ssh_user' => 'tplp1',
        'cpu_num' => 32,
    },
    'cst-fju1.uk.db.com' => {
        'ssh_user' => 'tplu5',
        'cpu_num' => 16,
	#'disabled' => 'yes',
    },
    'dnau1.uk.db.com' => {
        'ssh_user' => 'javalib',
        'cpu_num' => 8,
    },
    'dnau2.uk.db.com' => {
        'ssh_user' => 'javalib',
        'cpu_num' => 8,
    },
    'dnap1.uk.db.com' => {
        'ssh_user' => 'javalib',
        'cpu_num' => 16,
    },
    'dnap2.uk.db.com' => {
        'ssh_user' => 'javalib',
        'cpu_num' => 16,
    },
    'longmfxapp10.uk.db.com' => {
        'ssh_user' => 'reflexmon',
        'os' => 'linux',
        'cpu_num' => 4,
    },
    'longmfxapp14.uk.db.com' => {
        'ssh_user' => 'reflexmon',
        'os' => 'linux',
        'cpu_num' => 4,
    },
    'longmfxappp2.uk.db.com' => {
        'ssh_user' => 'wlsadmin',
        'os' => 'linux',
        'cpu_num' => 4,
    },
    'longmfxappb2.uk.db.com' => {
        'ssh_user' => 'wlsadmin',
        'os' => 'linux',
        'cpu_num' => 4,
    },
    'nyggmrvfxap1.us.db.com' => {
        'ssh_user' => 'dnaprod',
        'os' => 'linux',
        'cpu_num' => 8,
    },
    'hbrgmrvfxab1.us.db.com' => {
        'ssh_user' => 'dnaprod',
        'os' => 'linux',
        'cpu_num' => 8,
    },
    'longmeappd1.uk.db.com' => {
        'ssh_user' => 'maven01',
        'cpu_num' => 2,
        'os' => 'linux',
    },
    'singmfxwbp1-lower.sg.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 31122,
        'cpu_num' => 8,
    },
    'singmfxwbp2-lower.sg.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 31122,
        'cpu_num' => 2,
    },
    'longmeappp22-int-v1.uk.db.com' => {
        'ssh_user' => 'tpint',
        'ssh_port' => 31122,
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'longmeappp23-int-v1.uk.db.com' => {
        'ssh_user' => 'tpint',
        'ssh_port' => 31122,
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'longmeappp26-int.uk.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 31122,
        'cpu_num' => 8,
        'os' => 'linux',
    },
    'longmeappp24-out-v1.uk.db.com' => {
        'ssh_user' => 'tpint',
        'ssh_port' => 31122,
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'longmeappp25-out-v1.uk.db.com' => {
        'ssh_user' => 'tpint',
        'ssh_port' => 31122,
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'longmeappp27-out-v1.uk.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 31122,
        'cpu_num' => 8,
        'os' => 'linux',
    },
    'longmfxsappp1.uk.db.com' => {
        'ssh_user' => 'tpintra',
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'longmfxsappp2.uk.db.com' => {
        'ssh_user' => 'tpintra',
        'cpu_num' => 4,
        'os' => 'linux',
    },
    'nyggmabfxp1.us.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 30023,
        'cpu_num' => 8,
        'os' => 'linux',
        #'proxy_command' => 'ssh tplu5@cst-fju1.uk.db.com',
        'proxy_command' => 'ssh -o \'PasswordAuthentication no\' -o \'UserKnownHostsFile /dev/null\' -o \'StrictHostKeyChecking no\' tplp1@cst-fjp1.uk.db.com',
	#'disabled' => 'yes',
    },
    'nyggmabfxp2.us.db.com' => {
        'ssh_user' => 'abfxint',
        'ssh_port' => 30022,
        'cpu_num' => 8,
        'os' => 'linux',
        #'proxy_command' => 'ssh tplu5@cst-fju1.uk.db.com',
        'proxy_command' => 'ssh -o \'PasswordAuthentication no\' -o \'UserKnownHostsFile /dev/null\' -o \'StrictHostKeyChecking no\' tplp1@cst-fjp1.uk.db.com',
	#'disabled' => 'yes',
    },
    'goldtpus39.mos.eur.deuba.com' => {
        'ssh_user' => 'abfx1',
        'cpu_num' => 8,
        'os' => 'linux',
    },
    'loninengd82.uk.db.com' => {
        'ssh_user' => 'abfx',
	'disabled' => 'yes',
    },
    'longmeappu1a1-intv100.uk.db.com' => {
        'ssh_user' => 'clrtrust',
        'ssh_port' => 31122,
        'cpu_num' => 4,
        'os' => 'linux',
    },
);
1;
