#!/usr/bin/perl
#
#

require "./config.pl";

use POSIX ":sys_wait_h";

$max_running_childs = 10;
$running_childs = 0;

for my $host (sort keys %CFG) {

    # skip disabled hosts
    next if ( $CFG{$host}{disabled} =~ /yes/i );

    if ( ! -d "hosts/$host" ) {
        `mkdir -p hosts/$host`;
    }

    my $ssh_user = $CFG{$host}{ssh_user};
    my $ssh_port = 22;

    if ( defined $CFG{$host}{ssh_port} ) {
        $ssh_port = $CFG{$host}{ssh_port};
    }


    while ($running_childs == $max_running_childs) {
        print "waitpid...($running_childs) \n";
        my $kid = waitpid(-1, 0);
        print "Got kid $kid\n";
        $running_childs--;
    }

    my $pid = fork;

    die "fork" if (not defined $pid);

    if ($pid == 0) {
        #child
        eval {
            local $SIG{ALRM} = sub { die "alarm\n" }; # NB: \n required
            alarm 40;

            if ( defined $CFG{$host}{proxy_command} ) {
                `cd hosts/$host && \\
                $CFG{$host}{proxy_command} "\\
                ssh -o 'PasswordAuthentication no' -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' \\
                -p $ssh_port $ssh_user\@$host \\
                \\\"( cd monitor && nice -n 19 tail -1000 usercpu_monitor.pl.log )\\\"" | ../../do.pl`;
            } else {
                `cd hosts/$host && \\
                ssh -o 'PasswordAuthentication no' \\
                -o 'UserKnownHostsFile /dev/null' \\
                -o 'StrictHostKeyChecking no' \\
                -p $ssh_port $ssh_user\@$host \\
                "( cd \\\$HOME/monitor && nice -n 19 tail -1000 usercpu_monitor.pl.log )" | ../../do.pl`;
            }
            alarm 0;
        };
        if ($@) {
            print "timeout connecting to $host:$ssh_port\n";
        }
        exit;
    } else {
        #father
        print "Child $pid started\n";
        $running_childs++;
    }
}
while ($running_childs > 0) {
    print "wating for $running_childs kids \n";
    my $kid = waitpid(-1, 0);
    print "got kid $kid\n";
    $running_childs--;
}
print "all kids gone, exiting...\n";

