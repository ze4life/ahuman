#!/usr/bin/perl
#
#

# must be in $PATH ($ENV{PATH}), check the path in refresh.sh
$RRDtool = "rrdtool";

# geometry
@geometry = ( "-w", "512", "-h",  "150",  "--interlaced" , "-z" );

# periods
@periods = ("hour", "day", "week", "month", "3months", "year");

# step
%step = ( 
    "hour" => 10, 
    "day" => 60,
    "week" => 600,
    "month" => 3600,
    "3months" => 86400,
    "year" => 3 * 86400,
);

%start = ( 
    "hour" => 'end-2h', 
    "day" => 'end-1d',
    "week" => 'end-1w',
    "month" => 'end-30d',
    "3months" => 'end-90d',
    "year" => 'end-1y',
);

%arg;
# parse ARGS
for (@ARGV) {
    my ($var, $val) = split(/=/);
    $arg{$var} = $val;
}
# host name
$host = $arg{host};
$host || die;

$cpu_num = $arg{cpu_num};
$os = $arg{os};

# red colot for max cpu time
$red_color="#CE0005";

# defined peruser colors
%user_colors = (
    'root' => '000000',
    'armp' => 'ff0000',
    'armu1' => 'ff0000',
    'armuat' => 'ff0000',
    'tplp1' => '7cfc00',
    'abfxp1' => '7cfc00',
    'abfxp2' => '7cfc00',
    'abfxp3' => '7cfc00',
    'abfxu1' => '7cfc00',
    'tpint' => 'ffd700',
    'tpintra' => 'adff2f',
    'abfxint' => 'adff2f',
    'tprad' => '00ff7f',
    'oracle' => '1e90ff',
    'dbmpprod' => 'ff80ff',
    'dbmpuat' => 'ff80ff',
    'dbmpdev' => 'ff80ff',
    'reflexprod' => '8f00ff',
    'reflexuat' => '8f00ff',
    'rfxp' => '5f9ea0',
    'dnaprod' => 'ff00ff',
    'dnauat' => 'ff00ff',
    'tplu1' => '8ee5ee',
    'tplu2' => '00ee00',
    'tplu3' => '9b30ff',
    'tplu4' => 'eec900',
    'tplu5' => 'ff6a6a',
    'tplu7' => 'eeb4b4',
    'wlsadmin' => '9aff9a',
    'cvsuser' => '7fff00',
);

# load colors from the __DATA__
@colors;
while(<DATA>) {
    chomp;
    push(@colors, $_);
}
$colors_n = @colors;

# load the list of rrd files
opendir(DIR, "hosts/$host") || die;
@rrdfiles = sort grep { /\.rrd$/ && -f "hosts/$host/$_" } readdir(DIR);
closedir DIR;

# construct draw command
%draw_args;
$i=0;
for my $rrd (@rrdfiles) { 
    my $user = $rrd; 
    $user =~ s/\.rrd$//;

    # reset color counter
    $i = 0 if ( $i >= $colors_n );

    # color for the user
    my $color;
    if ( defined $user_colors{$user} ) {
        $color = $user_colors{$user};
    } else {
        $color = $colors[$i];
        $i++;
    }

    for my $p (@periods) {
        push(@{$draw_args{pcpu}{$p}}, 
            "DEF:u$user=hosts/$host/$rrd:pcpu:AVERAGE:step=$step{$p}",
            "AREA:u$user#$color:$user:STACK"
        );
        push(@{$draw_args{pcpumax}{$p}}, 
            "DEF:u$user=hosts/$host/$rrd:pcpu:MAX:step=$step{$p}",
            "AREA:u$user#$color:$user:STACK"
        );
        if ( $user ne "oracle" ) {
            push(@{$draw_args{rss}{$p}}, 
                "DEF:u$user=hosts/$host/$rrd:rss:AVERAGE:step=$step{$p}",
                #convert to bytes
                "CDEF:x$user=u$user,1024,*",
                "AREA:x$user#$color:$user:STACK"
            );
            push(@{$draw_args{vsz}{$p}}, 
                "DEF:u$user=hosts/$host/$rrd:vsz:AVERAGE:step=$step{$p}",
                #convert to bytes
                "CDEF:x$user=u$user,1024,*",
                "AREA:x$user#$color:$user:STACK"
            );
        } 
        push(@{$draw_args{orarss}{$p}}, 
            "DEF:u$user=hosts/$host/$rrd:rss:AVERAGE:step=$step{$p}",
            #convert to bytes
            "CDEF:x$user=u$user,1024,*",
            "AREA:x$user#$color:$user:STACK"
        );
        # to calculate CDEF it must be always AVERAGE
        push(@{$draw_args{time}{$p}}, 
            "DEF:u$user=hosts/$host/$rrd:time:AVERAGE:step=$step{$p}",
            "CDEF:x$user=u$user,$step{$p},*",
            #"LINE2:x$user#$colors[$i]:$user"
            "AREA:x$user#$color:$user:STACK"
        );
    }
}

$cpu_upper_limit = 100;
%cpu_time_upper_limit;

if ($cpu_num > 0) {
    for my $p (@periods) {

        my $max_cpu_time = $cpu_num * $step{$p};

        push(@{$cpu_time_upper_limit{$p}}, "-u", "$max_cpu_time");

        push(@{$draw_args{time}{$p}}, 
            "LINE3:$max_cpu_time$red_color",
        );
    }
    if ($os eq 'linux') {
        $cpu_upper_limit = $cpu_num * 100;
    }
}

# draw graphs

for my $p (@periods) {

    $rc = system ( $RRDtool , "graph" , "hosts/$host/cpu_$p.png" , @geometry,
        "--title", "$host CPU average last $p",
        "-l", "0", "-u", "$cpu_upper_limit", "-r",
        "--vertical-label", "%",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{pcpu}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "hosts/$host/maxcpu_$p.png" , @geometry,
        "--title", "$host CPU max last $p",
        "-l", "0", "-r",
        "--vertical-label", "%",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{pcpumax}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "hosts/$host/rss_$p.png" , @geometry,
        "--title", "$host resident memory last $p",
        "-l", "0", "-r", 
        "-b", "1024",
        "--vertical-label", "Bytes",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{rss}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "hosts/$host/vsz_$p.png" , @geometry,
        "--title", "$host virtual memory last $p",
        "-l", "0", "-r", 
        "-b", "1024",
        "--vertical-label", "Bytes",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{vsz}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "hosts/$host/orarss_$p.png" , @geometry,
        "--title", "$host resident memory last $p including oracle",
        "-l", "0", "-r", 
        "-b", "1024",
        "--vertical-label", "Bytes",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{orarss}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "hosts/$host/time_$p.png" , @geometry,
        "--title", "$host CPU time last $p",
        "-l", "0", @{$cpu_time_upper_limit{$p}}, "-r",
        "--vertical-label", "seconds",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{time}{$p}},
    );
}

# draw small graph for frontend
$rc = system ( $RRDtool , "graph" , "hosts/$host/scpu_hour.png" ,
    ( "-w", "140", "-h",  "60",  "--interlaced" ), 
        "-l", "0", "-u", "$cpu_upper_limit", "-r", "-g",
    "--title", "$host",
    "--vertical-label", "%",
    "--end", "now",
    "--start", $start{'hour'}, 
    @{$draw_args{pcpu}{'hour'}},
);
$rc = system ( $RRDtool , "graph" , "hosts/$host/stime_hour.png", 
    ( "-w", "140", "-h",  "60",  "--interlaced" ), 
    "--title", "$host", "-g",
    "-l", "0", @{$cpu_time_upper_limit{'hour'}}, "-r",
    "--vertical-label", "seconds",
    "--end", "now",
    "--start", $start{hour}, 
    @{$draw_args{time}{hour}},
);


__DATA__
ffff00
00ff00
0000ff
ff00ff
4876ff
ffc125
00f5ff
c71585
