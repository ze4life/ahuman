#!/bin/sh
#
# $Id: log_pnl.sh,v 1.1 2008/01/15 13:25:41 kovyale Exp $
#

# must be same as in graphic making script
LOGFILE=$HOME/monitor/pnl.log

# load common environment script
. $HOME/monitor/env.sh

if [ -z "$FXQUANT_DATABASE" ]; then
    exit 1
fi

test -z "$PERL" && PERL=perl
test -z "$SQLPLUS" && SQLPLUS=sqlplus

TIME=`$PERL -e 'print time'`
SQLOUT=`$SQLPLUS -s $FXQUANT_DATABASE  @get-pnl.sql`
PNL=`echo $SQLOUT | awk '{print $4":"$5}'`
echo "$TIME:$PNL" >> $LOGFILE
