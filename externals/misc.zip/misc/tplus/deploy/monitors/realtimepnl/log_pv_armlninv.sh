#!/bin/sh
#
# $Id: log_pv_armlninv.sh,v 1.1 2008/10/14 13:15:16 kovyale Exp $
#

# must be same as in graphic making script
LOGFILE=$HOME/monitor/pv_armlninv.log

# load common environment script
. $HOME/monitor/env.sh

if [ -z "$FXQUANT_DATABASE" ]; then
    exit 1
fi

test -z "$PERL" && PERL=perl
test -z "$SQLPLUS" && SQLPLUS=sqlplus

TIME=`$PERL -e 'print time'`
SQLOUT=`$SQLPLUS -s $FXQUANT_DATABASE  @get-pv-armlninv.sql`
PV=`echo $SQLOUT | awk '{print $4":"$5}'`
echo "$TIME:$PV" >> $LOGFILE
