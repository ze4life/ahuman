#!/bin/sh
#
# $Id: log_pv.sh,v 1.1 2008/07/18 10:40:07 kovyale Exp $
#

# must be same as in graphic making script
LOGFILE=$HOME/monitor/pv.log

# load common environment script
. $HOME/monitor/env.sh

if [ -z "$FXQUANT_DATABASE" ]; then
    exit 1
fi

test -z "$PERL" && PERL=perl
test -z "$SQLPLUS" && SQLPLUS=sqlplus

TIME=`$PERL -e 'print time'`
SQLOUT=`$SQLPLUS -s $FXQUANT_DATABASE  @get-pv.sql`
PV=`echo $SQLOUT | awk '{print $4":"$5}'`
echo "$TIME:$PV" >> $LOGFILE
