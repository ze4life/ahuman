#!/bin/sh
#
# $Id: log_sessions.sh,v 1.2 2007/03/05 13:52:31 kovyale Exp $
#
# 1. Get the list of users with null LAST_LOGOUT_TIME , print the realmname
# 2. call log_sessions.pl that will process the output

# must be same as in graphic making script
LOGFILE=$HOME/monitor/sessions.log
TMPFILE=$HOME/monitor/log_sessions.tmp.$$
export LOGFILE TMPFILE

# load common environment script
. $HOME/monitor/env.sh

DATE=`date +"%Y-%m-%d %H:%M:%S %Z"`
export DATE

$SQLPLUS -s $DATABASE_DETAILS @$HOME/deploy/monitors/sessions/get-sessions.sql | grep -v "^$" | sort | uniq -c > $TMPFILE

status=`$PERL log_sessions.pl`
echo $DATE "$status" >> $LOGFILE

rm $TMPFILE
