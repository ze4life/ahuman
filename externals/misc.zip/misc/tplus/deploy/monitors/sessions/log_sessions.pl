#!/usr/bin/perl
#
# $Id: log_sessions.pl,v 1.4 2007/10/31 15:15:57 fxplusAutoBuild Exp $
#

use Data::Dumper;

$LOGFILE=$ENV{LOGFILE};
$TMPFILE=$ENV{TMPFILE};
$DATE=$ENV{DATE};

$TPLUS_REGISTRY="$ENV{HOME}/tplus/deploy/$ENV{NODE}/conf/registry.xml";

# load the pop hash
%popname;
$r=open REG, $TPLUS_REGISTRY;
if (not defined $r) {
	 print "Could not open $TPLUS_REGISTRY\n";
	 exit 2;
}
while(<REG>) {
	 if (/<realm pop=\"(\w\w\w)\" internalInterface=\"(nsp[^:]*:\/\/[^\"]*)\"/) {
		  my $realm = $2;
		  my $pop = $1;

		  # skip CIT virtual pop
		  next if ( $pop eq "CIT" );

		  # include VDR into VPN (Radianz)
		  $pop = "VPN" if ( $pop eq "VDR" );

                  # BAK is LAN
		  $pop = "LAN" if ( $pop eq "BAK" );

		  # unite fxspp pops
                  #$pop = "FXS" if ( $pop=~/SP[1-2]/ );
		  $pop = "LAN" if ( $pop=~/SP[1-2]/ );

		  $popname{$realm} = $pop;
	 }
}
close REG;

# process tmp file
%popstat;
$r=open TMP, $TMPFILE; 
if (not defined $r) {
	 print "Could not open $TMPFILE\n";
	 exit 3;
}
while(<TMP>) {
	if (/(\d+)\s(nsp.*)$/){
		my $n=$1;
		my $realm=$2;
		if ( $popname{$realm} ) {
			if ( $popstat{$popname{$realm}} ) {
				$popstat{$popname{$realm}} += $n;
			} else { 
				$popstat{$popname{$realm}} = $n;
			}
		}
		# skip nonexistent realm
	}
}
close TMP;

# count total sessions
$total=0;
$s='';
for my $k (sort keys %popstat) {
	$total += $popstat{$k};
	$s .= "$k=$popstat{$k} ";
}

# print log
print "ALL=$total $s\n";

exit 0;
