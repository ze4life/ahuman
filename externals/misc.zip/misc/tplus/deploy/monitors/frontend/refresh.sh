#!/bin/sh

renice 19 $$

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

for dir in Monitoring/BtoC Monitoring/BtoCui Monitoring/BtoI Monitoring/Sessions \
    Monitoring/Trades Support Monitoring/T2T3 Monitoring/TSpeed
do
	 if [ -x "$dir/refresh.sh" ]; then
		  (
		  cd $dir
		  test -x ./refresh.sh && ./refresh.sh
		  )
	 fi
done

# clean pics older the 10 mins (the refresh time)
find Monitoring/tmp -type f -name "*.png" -mmin +10 -exec rm {} \;
