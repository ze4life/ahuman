#!/bin/sh

#2006-08-10 11:43:44
. ../env.sh

# globals
geometry="-w 512 -h 130 -i -z"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

# draw funcs
draw_mem() {
	 local app=$1
	 local y_scale=$2
	 local y_label=$3
	 local h_rule=$4

	 rrdtool graph ${app}_day.png \
	 $y_scale -v "$y_label" \
	  -t "$app memory usage for the last day. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1d \
	 DEF:linea=$app.rrd:rss:MAX:step=600 AREA:linea$green_color:"Resident Memory Size\n" \
	 HRULE:$h_rule$red_color:"Maximum memory allocated to the process"

	 rrdtool graph ${app}_week.png \
	 $y_scale -v "$y_label" \
	  -t "$app memory usage for the last week. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1w \
	 DEF:linea=$app.rrd:rss:MAX:step=3600 AREA:linea$green_color:"Resident Memory Size\n" \
	 HRULE:$h_rule$red_color:"Maximum memory allocated to the process"

	 rrdtool graph ${app}_month.png \
	  -t "$app memory usage for the last month. ($TZONE Time)." \
	 $y_scale -v "$y_label" \
	 $geometry $color \
	 --end $now \
	 --start end-1m \
	 --x-grid DAY:1:WEEK:1:WEEK:1:0:%b-%d \
	 DEF:linea=$app.rrd:rss:MAX:step=10800 AREA:linea$green_color:"Resident Memory Size\n" \
	 HRULE:$h_rule$red_color:"Maximum memory allocated to the process"

	 rrdtool graph ${app}_quarter.png \
	  -t "$app memory usage for the last quarter. ($TZONE Time)." \
	 $y_scale -v "$y_label" \
	 $geometry $color \
	 --end $now \
	 --start end-3m \
	 --x-grid DAY:1:WEEK:1:WEEK:2:0:%b-%d \
	 DEF:linea=$app.rrd:rss:MAX:step=43200 AREA:linea$green_color:"Resident Memory Size\n" \
	 HRULE:$h_rule$red_color:"Maximum memory allocated to the process"

	 rrdtool graph ${app}_year.png \
	  -t "$app memory usage for the last year. ($TZONE Time)." \
	 $y_scale -v "$y_label" \
	 $geometry $color \
	 --end $now \
	 --start end-1y \
	 DEF:linea=$app.rrd:rss:MAX:step=86400 AREA:linea$green_color:"Resident Memory Size\n" \
	 HRULE:$h_rule$red_color:"Maximum memory allocated to the process"
}

draw_cpu() {
	 local app=$1
	 local y_scale=$2
	 local y_label=$3

	 rrdtool graph ${app}_cpu_day.png \
	 $y_scale -v "$y_label" \
	  -t "$app cpu usage for the last day. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1d \
	 DEF:lineb=$app.rrd:cpu:MAX:step=600 AREA:lineb$red_color:"Cpu peaks\n" \
	 DEF:linea=$app.rrd:cpu:AVERAGE:step=600 AREA:linea$green_color:"Cpu average usage\n"

	 rrdtool graph ${app}_cpu_week.png \
	 $y_scale -v "$y_label" \
	  -t "$app cpu usage for the last week. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1w \
	 DEF:lineb=$app.rrd:cpu:MAX:step=3600 AREA:lineb$red_color:"Cpu peaks\n" \
	 DEF:linea=$app.rrd:cpu:AVERAGE:step=3600 AREA:linea$green_color:"Cpu average usage\n"

	 rrdtool graph ${app}_cpu_month.png \
	 $y_scale -v "$y_label" \
	  -t "$app cpu usage for the last month. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1m \
	 --x-grid DAY:1:WEEK:1:WEEK:1:0:%b-%d \
	 DEF:lineb=$app.rrd:cpu:MAX:step=10800 AREA:lineb$red_color:"Cpu peaks\n" \
	 DEF:linea=$app.rrd:cpu:AVERAGE:step=10800 AREA:linea$green_color:"Cpu average usage\n"

	 rrdtool graph ${app}_cpu_quarter.png \
	 $y_scale -v "$y_label" \
	  -t "$app cpu usage for the last quarter. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-3m \
	 --x-grid DAY:1:WEEK:1:WEEK:2:0:%b-%d \
	 DEF:lineb=$app.rrd:cpu:MAX:step=43200 AREA:lineb$red_color:"Cpu peaks\n" \
	 DEF:linea=$app.rrd:cpu:AVERAGE:step=43200 AREA:linea$green_color:"Cpu average usage\n"

	 rrdtool graph ${app}_cpu_year.png \
	 $y_scale -v "$y_label" \
	  -t "$app cpu usage for the last year. ($TZONE Time)." \
	 $geometry $color \
	 --end $now \
	 --start end-1y \
	 DEF:lineb=$app.rrd:cpu:MAX:step=86400 AREA:lineb$red_color:"Cpu peaks\n" \
	 DEF:linea=$app.rrd:cpu:AVERAGE:step=86400 AREA:linea$green_color:"Cpu average usage\n"
}

# fxplus
draw_mem fxplus "-M -l 0 -u 1500000" "Kb" 1300000
draw_cpu fxplus "-M -l 0 -u 10" "%"
# tplus
draw_mem tplus "-M -l 0 -u 1000000" "Kb" 1000000
draw_cpu tplus "-M -l 0 -u 10" "%"
# fxplusoptions 
draw_mem fxplusoptions "-M -l 0 -u 1500000" "Kb" 1300000
draw_cpu fxplusoptions "-M -l 0 -u 10" "%"
# auth
draw_mem auth "-M -l 0 -u 1500000" "Kb" 1300000
draw_cpu auth "-M -l 0 -u 10" "%"

exit 0
