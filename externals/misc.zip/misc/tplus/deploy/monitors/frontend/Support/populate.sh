#!/bin/sh

. ../env.sh

for app in tplus fxplus fxplusoptions;do 
	 ssh -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' $SSH_USER@$SSH_HOST \
	 "( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -2160  $app-dbag-server.log )" \
	 | ./parse_log.pl $app | /bin/sh -x
done
	 ssh -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' $SSH_USER@$SSH_HOST \
	 "( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -2160  tplus-dbag-authserver.log )" \
	 | ./parse_log.pl auth | /bin/sh -x
