#!/usr/bin/perl

use POSIX;

use strict;
use warnings;

my $app = $ARGV[0];

my $lasttime = `rrdtool info $app.rrd | grep last_update | cut -d= -f 2`;
$lasttime =~ s/ //g;
chomp $lasttime;

my $lastdelay=0;
my $nargs=0;
my $maxargs=40;
my $args='';
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

while ( <STDIN> ) {

	#2006-08-10 11:52:16 BST 26092 2.8 0.6 1155536 943272 1-19:22:44

	next if (not /^200\d-\d\d-\d\d \d\d:\d\d:\d\d \D\D\D \d+ \d+\.\d+ \d+\.\d+ \d+ \d+/);

	my (@toks) = split(/ +/);
	my ($hour, $min, $sec) = split(/:/, $toks[1]);
	my ($year, $mon, $day) = split(/-/, $toks[0]);
	my $wday = 0;
	my $yday = 0;
	my $tz = $toks[2];
	my $vsz = $toks[6];
	my $rss = $toks[7];
	my $cpu = $toks[4];

	$year -= 1900;
	$mon -= 1;

	my $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

	if ( $lasttime == 0 ) {
		 $lasttime = $unixtime;
	}

	if ( $unixtime > $lasttime ) {
		 $args .= " $unixtime:$rss:$vsz:$cpu";
		 if ( $nargs == $maxargs ) {
			  print "rrdupdate $app.rrd $args\n";
			  $nargs=0; 
			  $args='';
		 } else { 
			  $nargs++; 
		 }
		 $lasttime = $unixtime;
	}
}

# print the latest line
if ($args) {
	 print "rrdupdate $app.rrd $args\n";
}
