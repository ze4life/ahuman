#!/bin/sh

echo Safety catch to no overwrite the database.
echo To create the database comment out next line after this message.
exit 1

# Data source:
# DS:rss:GAUGE:180:0:10485760  <--- store resident memory size, min:0 max:10485760 (10Gb)
# DS:vsz:GAUGE:180:0:10485760  <--- store virtual memory size, min:0 max:10485760 (10Gb)
# DS:cpu:GAUGE:180:0:100       <--- store the cpu usage, min:0% max:100%

# Round Robin archives:
# RRA:AVERAGE:0.5:5:157680     <--- min, max, average values is being counted 
# RRA:MAX:0.5:5:157680         <--- for the period of 10mins (120s * 5) and keep 157680 such
# RRA:MIN:0.5:5:157680         <--- values: 120s * 5 * 157680 = 3 years

. ../env.sh

for app in auth tplus fxplus fxplusoptions; do
	 rrdtool create $app.rrd \
	 --start 20060101 \
	 --step 120 \
	 DS:rss:GAUGE:180:0:10485760 	\
	 DS:vsz:GAUGE:180:0:10485760 	\
	 DS:cpu:GAUGE:180:0:100 	\
	 RRA:AVERAGE:0.5:5:157680 \
	 RRA:MAX:0.5:5:157680 \
	 RRA:MIN:0.5:5:157680 
done
