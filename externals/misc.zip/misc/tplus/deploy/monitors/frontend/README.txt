1.	In the apache httpd.conf add
	AllowOverride All
	for directory with web root

2. Edit .htaccess file define proper path to rrdtool lib directory

3. Edit Monitoring/index.cgi set the correct path to rrdtool binary here:
# do not use RRDs modules since it is outdated on frontends
$RRDtool="/export/home/tpintra/rrdtool-1.2.15/bin/rrdtool";

4. Update crontab.txt and cut&paste the line into editor when you do crontab -e
