#!/bin/sh
#
# $Id: populate.sh,v 1.5 2008/11/06 09:38:02 kovyale Exp $
#

. ../../env.sh

for i in spotrates.dedicated_ratefan spotrates.ratefan spotrates
do

$SSH_CMD $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -2000 tailDelays.pl_$i.log )" \
| ./parse_log.pl $i.rrd | /bin/sh -x


done
