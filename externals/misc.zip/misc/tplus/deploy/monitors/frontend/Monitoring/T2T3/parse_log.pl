#!/usr/bin/perl
#
# $Id: parse_log.pl,v 1.1 2007/04/23 08:34:50 kovyale Exp $
#
# Parse the trades log and update rrd
#
# This script does calculation of delta itself.

use POSIX;

use strict;
use warnings;

sub read_file {
	 my $f = shift;
	 my $l = undef;

	 if ( -f "$f") {
		  open L, "$f";
		  $l = <L>;
		  close L;
		  chomp $l;
	 }
	 $l=0 if (not $l);
	 $l;
}

sub write_file {
	 my $f = shift;
	 my $l = shift;
	 open L, ">$f";
	 print L "$l\n";
	 close L;
}

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

my $lastupdate = read_file ( "T2T3.lastupdatetime" );
my $lastvalues = read_file ( "T2T3.lastvalues" );
my ($lms, $lss) = split (/ +/, $lastvalues);
my $unixtime = undef;

while ( <STDIN> ) {

	 chomp;

	 #2007-01-31 11:02:59 GMT 942072
	 next if (not /^200\d-\d\d-\d\d \d\d:\d\d:\d\d \D\D\D \d+ \d+$/);

	 my (@toks) = split(/ +/);
	 my ($hour, $min, $sec) = split(/:/, $toks[1]);
	 my ($year, $mon, $day) = split(/-/, $toks[0]);
	 my $wday = 0;
	 my $yday = 0;
	 my $tz = $toks[2];
	 my $ms = $toks[3];
	 my $ss = $toks[4];

	 $year -= 1900;
	 $mon -= 1;
	 $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

	 # sometimes there was delays
	 # round the time to 600 seconds
	 $unixtime =~ s/\d\d$/00/;


	 next if ($lastupdate >= $unixtime);

	 if ( not $lms or $lms > $ms ) {
		  # the old server.log is rolled, the trades are being counted again
	 	  $lms = $ms;
	 	  $lss = $ss;
		  next;
	 }

	 my $dm = $ms - $lms;
	 my $ds = $ss - $lss;
	 print "rrdupdate T2T3.rrd $unixtime:$dm:$ds\n";
	 $lms = $ms;
	 $lss = $ss;
}

write_file("T2T3.lastupdatetime", $unixtime);
write_file("T2T3.lastvalues", "$lms $lss");
