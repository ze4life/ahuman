#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

geometry="-w 1024 -h 200 -i"
sgeometry="-w 1024 -h 130"
now="$NOW"
scale="$DELAYS_GRAPH_SCALE"

max_color="#FF0000"
min_color="#0000FF"
avg_color="#00FF00"
color="--color GRID#C0C0C0"

rrdtool graph EURUSD.png \
	$scale \
	-v "ms" -t "EBS to ABFX Trade Acceptance latency (B to I). EURUSD last hour. Max min avg for every 1 minute ($TZONE)." \
	$geometry $color \
	--end $now \
	--start end-1h \
	DEF:linec=EURUSD.rrd:day:MIN:step=60 LINE1:linec$min_color:"Min" \
	DEF:linea=EURUSD.rrd:day:AVERAGE:step=60 LINE1:linea$avg_color:"Avg" \
	DEF:lineb=EURUSD.rrd:day:MAX:step=60 LINE1:lineb$max_color:"Max" 

rrdtool graph BtoI_BtoC.png \
        -M -l 0 \
	-v "ms" -t "(BtoI) vs (BtoC). EURUSD last day." \
	-w 310 -h 65 --interlaced \
	$color \
	--color BACK#ADFAD3 \
	--end $now \
	--start end-1d \
	DEF:linea=EURUSD.rrd:day:MAX:step=600 LINE1:linea$min_color:"MAX B2I" \
	DEF:lineb=../BtoC/EURUSD.rrd:day:MAX:step=600 LINE1:lineb$max_color:"MAX B2C" \


rrdtool graph EURUSD_sday.png \
	$scale \
	-v "ms" -t "EBS to ABFX Trade Acceptance latency (B to I). EURUSD last day. Average for every 10 minutes ($TZONE)." \
	$sgeometry $color \
	--color BACK#ADFAD3 \
	--end $now \
	--start end-1d \
	--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:%H:%M \
	DEF:linec=EURUSD.rrd:day:MIN:step=600 LINE1:linec$min_color:"Min" \
	DEF:linea=EURUSD.rrd:day:AVERAGE:step=600 LINE1:linea$avg_color:"Avg" \
	DEF:lineb=EURUSD.rrd:day:MAX:step=600 LINE1:lineb$max_color:"Max" 

rrdtool graph EURUSD_day.png \
	$scale \
	-v "ms" -t "EBS to ABFX Trade Acceptance latency (B to I). EURUSD last day. Average for every 10 minutes ($TZONE)." \
	$geometry $color \
	--color BACK#ADFAD3 \
	--end $now \
	--start end-1d \
	--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:%H:%M \
	DEF:linec=EURUSD.rrd:day:MIN:step=600 LINE1:linec$min_color:"Min" \
	DEF:linea=EURUSD.rrd:day:AVERAGE:step=600 LINE1:linea$avg_color:"Avg" \
	DEF:lineb=EURUSD.rrd:day:MAX:step=600 LINE1:lineb$max_color:"Max" 

rrdtool graph EURUSD_week.png \
	$scale \
	-v "ms" -t "EBS to ABFX Trade Acceptance latency (B to I). EURUSD last week. Average for every 1 hour ($TZONE)." \
	$geometry $color \
	--color BACK#9DCFF9 \
	--end $now \
	--start end-1w \
	--x-grid HOUR:2:DAY:1:DAY:1:0:%d \
	DEF:linec=EURUSD.rrd:day:MIN:step=3600 LINE1:linec$min_color:"Min" \
	DEF:linea=EURUSD.rrd:day:AVERAGE:step=3600 LINE1:linea$avg_color:"Avg" \
	DEF:lineb=EURUSD.rrd:day:MAX:step=3600 LINE1:lineb$max_color:"Max" 

rrdtool graph EURUSD_month.png \
	$scale -v "ms" -t "EBS to ABFX Trade Acceptance latency (B to I). EURUSD last month. Average for every 3 hours ($TZONE)." \
	$geometry $color \
	--color BACK#E4E4E4 \
	--end $now \
	--start end-1m \
	--x-grid HOUR:6:DAY:1:DAY:1:0:%d \
	DEF:linec=EURUSD.rrd:day:MIN:step=10800 LINE1:linec$min_color:"Min" \
	DEF:linea=EURUSD.rrd:day:AVERAGE:step=10800 LINE1:linea$avg_color:"Avg" \
	DEF:lineb=EURUSD.rrd:day:MAX:step=10800 LINE1:lineb$max_color:"Max" 
