#!/usr/bin/perl


$rrdfile = $ARGV[0];
if ( not defined $rrdfile ) {
    print "Use: cat LOG | $0 <rrd_filename>\n";
    exit 1;
}

$RRDtool="rrdtool";

my $lastupdate;
my $maxargs=40;
my $args = '';
my $nargs = 0;

if ( ! $lastupdate ) {
    my $l = `rrdtool info "$rrdfile" | grep last_update | cut -d= -f 2`;
    $l =~ s/ //g; chomp $l;
    $lastupdate = $l;
}

while (<STDIN>) {
    chomp;

    next if (! /^\d+\.\d+:\d+:\d+:\d+$/ && ! /^\d+:\d+:\d+:\d+$/);

    my ($time,$gc1,$gc2,$gc3) = split (/:/, $_, 4);

    if ( $time >= $lastupdate + 1) {
        $args .= " $time:$gc1:$gc2:$gc3";
        $lastupdate=$time;

        if ( $nargs >= $maxargs ) {
            print "rrdupdate $rrdfile $args\n";
            $nargs=0;
            $args='';
        } else {
            $nargs++;
        }
    }
}
if ($args) {
    print "rrdupdate $rrdfile $args\n";
}
