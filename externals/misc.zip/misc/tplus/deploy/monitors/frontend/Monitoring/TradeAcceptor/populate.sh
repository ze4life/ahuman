#!/bin/sh
#
# $Id: populate.sh,v 1.4 2008/11/06 09:52:37 kovyale Exp $
#

. ../../env.sh

for i in server fixserver
do

    $SSH_CMD $SSH_USER@$SSH_HOST \
    "( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -2000 tradeAcceptedMonitor.pl_${i}.log )" \
    | ./parse_log.pl Accepted_${i}.rrd | /bin/sh -x
    $SSH_CMD $SSH_USER@$SSH_HOST \
    "( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -2000 tradeRejectedMonitor.pl_${i}.log )" \
    | ./parse_log.pl Rejected_${i}.rrd | /bin/sh -x

done
