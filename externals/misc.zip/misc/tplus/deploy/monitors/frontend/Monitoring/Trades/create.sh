#!/bin/sh
#
# $Id: create.sh,v 1.4 2007/04/13 07:17:12 kovyale Exp $
#

echo Safety catch to no overwrite the database.
echo To create the database comment out next line after this message.
exit 1

. ../../env.sh

# create trades database
rrdtool create TRADES.rrd \
--start 20060101 \
--step 600 \
DS:ses:GAUGE:1200:0:U 	\
RRA:AVERAGE:0.5:1:157680 \
RRA:MIN:0.5:1:157680 \
RRA:MAX:0.5:1:157680
