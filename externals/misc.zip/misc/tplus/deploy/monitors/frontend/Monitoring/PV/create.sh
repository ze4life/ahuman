#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ../../env.sh

rrdtool create PV.rrd \
--start 20061101 \
--step 60 \
DS:tra_pv:GAUGE:120:U:U     \
DS:tot_pv:GAUGE:120:U:U     \
RRA:AVERAGE:0.5:1:1577847
