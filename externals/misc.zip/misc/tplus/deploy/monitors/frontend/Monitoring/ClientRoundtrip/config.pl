#!/usr/bin/perl
#
#
%Client = (
'EU0279753' => { 'name' => 'Forex Capital Markets Retail' , 'pop' => '' },
'EU0266926' => { 'name' => 'GMO Short - Term Market Opportunites Fund' , 'pop' => '' },
'EU0290034' => { 'name' => 'Currenex: OCBC Securities - OPSL' , 'pop' => '' },
'TS4206470' => { 'name' => 'Tokyo Financial Exchange Inc.' , 'pop' => '' },
'EU0327510' => { 'name' => 'Bank of China Hong Kong' , 'pop' => '' },
'EU0311161' => { 'name' => 'Macquarie Bank Limited Sydney Spot' , 'pop' => '' },
'EU0650030' => { 'name' => 'Saxo Options Gentofte' , 'pop' => '' },
'EU0268689' => { 'name' => 'Olsen Ltd' , 'pop' => '' },
'EU0271383' => { 'name' => 'PANTA RHEI SECURITIES CO LTD ' , 'pop' => '' },
);

1;
