#!/usr/bin/perl

use POSIX;

use strict;
use warnings;

my $lasttime=0;
# read the last update time
if ( -f "lastupdate") {
	 open(L, "lastupdate");
	 $lasttime = <L>;
	 close(L);
	 chomp $lasttime;
}

my $nargs=0;
my $maxargs=40;
my $args='';
my $second_max = 0;
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

while ( <STDIN> ) {
#64319420 [SPOT] 11 00:00:00,631 GMT - USDJPY  {1165795200650 - 1165795200650 / 0}  7ms EBS Live(longmfxf02p1b1) 116.24/116.25 [10f6ead5fca:-5fec]
#82887 [SPOT] 08 07:45:15,654 GMT - EURUSD 1.3007/1.3008 [42: 5, 0, 37, 0] EBS Live (dnau2.uk.db.com)  [110a01d60d2:-687]
	 my (@toks) = split(/ +/);
	 my ($hour, $min, $y) = split(/:/, $toks[3]);
	 my ($sec, $x) = split(/,/, $y);
	 my $day  = $toks[2];
	 my $wday = 0;
	 my $yday = 0;
	 my $tz = $toks[4];

	 my $delay = undef;

	 if ( $toks[8] eq "-" ) {
		  #old logs format
		  $delay = $toks[12];

	 }
	 if ( $toks[8]=~/^\[/) {
		  # new log format
		  $delay = $toks[8];
	 }

	 $delay=~s/ms$//;
	 $delay=~s/\[//;
	 $delay=~s/://;

	 next if ( not $delay );

	 next if ( $delay eq "N/A" );

    # No need to this check. reflex fixed the rate when switching source
    # next if ( $delay > 500 );

	 my $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

	 if ( $unixtime == $lasttime ) {
		  # updates during same second
		  if ( $delay > $second_max ) {
				$second_max = $delay;
		  }
	 }

	 if ( $unixtime > $lasttime ) {

		  $args .= " $lasttime:$second_max";

		  if ( $nargs == $maxargs ) {
				print "rrdupdate EURUSD.rrd $args\n";
				$nargs=0;
				$args='';
		  } else {
				$nargs++;
		  }

		  $lasttime = $unixtime;
		  $second_max = $delay;
	 }
}

if ($args) {
	 print "rrdupdate EURUSD.rrd $args\n";
}


# save the last time to skip times
open(L, ">lastupdate");
print L "$lasttime\n";
close(L);
