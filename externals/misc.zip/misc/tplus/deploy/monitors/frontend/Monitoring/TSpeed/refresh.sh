#!/bin/sh
#
# $Id: refresh.sh,v 1.1 2007/04/23 12:59:13 kovyale Exp $
#

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

./populate.sh 

./dograph.sh
