#!/usr/bin/perl

my $rrdfile=$ARGV[0];
my $lastupdate = `rrdtool info $rrdfile | grep last_update | cut -d= -f 2`;
$lastupdate =~ s/ //g;
chomp $lastupdate;

my $nargs=0;
my $maxargs=40;
my $args='';

while (<STDIN>) {
    chomp;
    if ( /^\d+\.\d+ [\d-]+ [\d-]+ [\d-]+ [\d-]+ [\d-]+$/ ) {
        my (@val) = split(/ /, $_);

        for (@val) {
            if ( $_ eq "-" ) {
                $_ = "U";
            }
        }

        if ( $val[0] >= $lastupdate + 1 ) {

            my $rrd_arg = join( ':', @val );
            my ( $s, $m ) = split( /\./, $val[0] );

            $lastupdate = $s;
            $args .= " $rrd_arg";

            if ( $nargs == $maxargs ) {
                print "rrdupdate $rrdfile $args\n";
                $nargs=0;
                $args='';
            } else {
                $nargs++;
            }
        }
    }
}
if ($args) {
    print "rrdupdate $rrdfile $args\n";
}

