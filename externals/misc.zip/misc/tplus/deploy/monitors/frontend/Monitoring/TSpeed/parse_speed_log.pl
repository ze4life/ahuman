#!/usr/bin/perl
#
# $Id: parse_speed_log.pl,v 1.5 2007/04/24 06:45:26 kovyale Exp $
#
# Parse the trades log and update rrd
#
# This script does calculation of delta itself.

use POSIX;

use strict;
use warnings;

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

my $lastupdate = `rrdtool info TSPEED.rrd | grep last_update | cut -d= -f 2`;
$lastupdate =~ s/ //g;
chomp $lastupdate;

my $unixtime = undef;
my $nargs=0;
my $maxargs=40;
my $args='';

while ( <STDIN> ) {

    chomp;

    #2007-01-31 11:02:59 GMT 942072
    next if (not /^200\d-\d\d-\d\d \d\d:\d\d:\d\d \D\D\D \d+$/);

    my (@toks) = split(/ +/);
    my ($hour, $min, $sec) = split(/:/, $toks[1]);
    my ($year, $mon, $day) = split(/-/, $toks[0]);
    my $wday = 0;
    my $yday = 0;
    my $tz = $toks[2];
    my $trades = $toks[3];

    $year -= 1900;
    $mon -= 1;
    $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

    # sometimes there was delays
    # round the time to 10 seconds
    $unixtime =~ s/\d$/0/;

    next if ($lastupdate >= $unixtime);

    $args .= " $unixtime:$trades";
    if ( $nargs == $maxargs ) {
        print "rrdupdate TSPEED.rrd $args\n";
        $nargs=0;
        $args='';
    } else {
        $nargs++;
    }
}
if ($args) {
    print "rrdupdate TSPEED.rrd $args\n";
}
