#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced -l 0"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

# hour number only
cat <<EOF > current.html
<head>
    <title>Current PV</title>
	 <meta http-equiv="refresh" content="60">
	 <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
EOF
echo "<font style=\"font-family: Verdana; font-size: 156pt; font-weight: bold;\">" >> current.html
echo "<center>&euro;" >> current.html
rrdtool graph pv_num.png \
--end $now \
--start end-1h \
DEF:tra=PV.rrd:tra_pv:AVERAGE \
PRINT:tra:LAST:"%.0lf" | sed -e "s/0x0//" >> current.html
echo "</center></font>" >> current.html

#hour
rrdtool graph pv_hour.png \
$geometry $color \
--title "PV sampled every minute. Last hour." \
--vertical-label "PV" \
--end $now \
--start end-1h \
DEF:tra=PV.rrd:tra_pv:AVERAGE \
LINE1:tra$red_color:"trading pv"

#LINE1:tot$red_color:"total pv"

#day
rrdtool graph pv_day.png \
$geometry $color \
--title "PV sampled every minute. Last day." \
--vertical-label "PV" \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
DEF:tra=PV.rrd:tra_pv:AVERAGE:step=60 \
LINE1:tra$red_color:"trading pv" \

#week
rrdtool graph pv_week.png \
$geometry $color \
--title "PV sampled every ten minutes. Last week." \
--vertical-label "PV" \
--end $now \
--start end-1w \
DEF:tra=PV.rrd:tra_pv:AVERAGE:step=600 \
LINE1:tra$red_color:"trading pv" \

#month
rrdtool graph pv_month.png \
$geometry $color \
--title "PV sampled every hour. Last month." \
--vertical-label "PV" \
--end $now \
--start end-1m \
--x-grid HOUR:6:DAY:1:DAY:1:0:%d \
DEF:tra=PV.rrd:tra_pv:AVERAGE:step=3600 \
LINE1:tra$red_color:"trading pv" \

#year
rrdtool graph pv_year.png \
$geometry $color \
--title "PV sampled every day. Last year." \
--vertical-label "PV" \
--end $now \
--start end-1y \
DEF:tra=PV.rrd:tra_pv:AVERAGE \
LINE1:tra$red_color:"trading pv" \
