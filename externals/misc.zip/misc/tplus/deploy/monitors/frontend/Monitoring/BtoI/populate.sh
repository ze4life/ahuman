#!/bin/sh

. ../../env.sh

	 $SSH_CMD $SSH_USER@$SSH_HOST \
	 "( cd ~$APPLICATION_USER/fxplus/level_1/dbag/; \
	  nice -n 19 grep EURUSD release/log/spotrates.log ; \
	  ) | \
	  nice -n 19 grep -v price-config | nice -n 19 grep Live
	 " | ./parse_spotrates_log.pl | /bin/sh
