#!/usr/bin/perl
#
# $Id: parse_traderejects_log.pl,v 1.1 2007/04/05 14:27:53 kovyale Exp $
#
# Parse the traderejects log and update rrd
#
# This script does calculation of delta itself.

use POSIX;

use strict;
use warnings;

sub read_file {
	 my $f = shift;
	 my $l = undef;

	 if ( -f "$f") {
		  open L, "$f";
		  $l = <L>;
		  close L;
		  chomp $l;
	 }
	 $l=0 if (not $l);
	 $l;
}

sub write_file {
	 my $f = shift;
	 my $l = shift;
	 open L, ">$f";
	 print L "$l\n";
	 close L;
}

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

my $lastupdate = read_file ( "REJECTS.lastupdatetime" );
my $lastvalue = read_file ( "REJECTS.lastrejects" );
my $unixtime = undef;

while ( <STDIN> ) {

	 chomp;

	 #2007-01-31 11:02:59 GMT 942072
	 next if (not /^200\d-\d\d-\d\d \d\d:\d\d:\d\d \D\D\D \d+$/);

	 my (@toks) = split(/ +/);
	 my ($hour, $min, $sec) = split(/:/, $toks[1]);
	 my ($year, $mon, $day) = split(/-/, $toks[0]);
	 my $wday = 0;
	 my $yday = 0;
	 my $tz = $toks[2];
	 my $trades = $toks[3];

	 $year -= 1900;
	 $mon -= 1;
	 $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

	 # sometimes there was delays
	 # round the time to 600 seconds
	 $unixtime =~ s/\d\d$/00/;


	 next if ($lastupdate >= $unixtime);

	 if ( not $lastvalue or $lastvalue > $trades ) {
		  # we have just started to fill the database or trades table purge happened.
	 	  $lastvalue = $trades;
		  next;
	 }

	 my $delta = $trades - $lastvalue;
	 print "rrdupdate REJECTS.rrd $unixtime:$delta\n";
	 $lastvalue = $trades;
}

write_file("REJECTS.lastupdatetime", $unixtime);
write_file("REJECTS.lastrejects", $lastvalue);
