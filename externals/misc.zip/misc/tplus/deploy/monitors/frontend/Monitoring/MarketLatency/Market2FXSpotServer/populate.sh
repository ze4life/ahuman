#!/bin/sh
#
# $Id: populate.sh,v 1.1 2008/10/31 10:21:38 kovyale Exp $
#

. ../../../env.sh

for f in EBS_Live ReutersAQ ReutersD2K ReutersEBS Nymex Cbot
do
    for i in SpotServer
    do

        $SSH_CMD $SSH_USER@$SSH_HOST \
        "( cd monitor ; nice -n 19 tail -3000 Market2FXSpotServer.pl_${i}_${f}.log )" \
        | ./parse_log.pl ${i}_${f}.rrd | /bin/sh -x


    done
done
