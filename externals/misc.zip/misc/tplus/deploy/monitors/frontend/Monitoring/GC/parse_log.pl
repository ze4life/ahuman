#!/usr/bin/perl

my $rrdfile=$ARGV[0];
my $lastupdate = `rrdtool info $rrdfile | grep last_update | cut -d= -f 2`;
$lastupdate =~ s/ //g;
chomp $lastupdate;

my $nargs=0;
my $maxargs=40;
my $args='';

while (<STDIN>) {
    if ( /^(\d+\.\d+) (\d+\.\d+)$/ ) {
        if ( $1 >= $lastupdate + 1 ) {
            $args .= " $1:$2";
            $lastupdate=$1;
            if ( $nargs == $maxargs ) {
                print "rrdupdate $rrdfile $args\n";
                $nargs=0;
                $args='';
            } else {
                $nargs++;
            }

        }
    }
}
if ($args) {
    print "rrdupdate $rrdfile $args\n";
}

