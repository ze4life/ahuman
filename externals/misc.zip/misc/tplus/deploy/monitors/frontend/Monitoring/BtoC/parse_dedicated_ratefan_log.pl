#!/usr/bin/perl

use POSIX;

use strict;
use warnings;

my $lasttime=0;
# read the last update time
if ( -f "lastupdate") {
	 open(L, "lastupdate");
	 $lasttime = <L>;
	 close(L);
	 chomp $lasttime;
}

my $nargs=0;
my $maxargs=40;
my $args='';
my $second_max = 0;
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

while ( <STDIN> ) {
# old dedicatied ratefan
#64320646 [SPOT DEDICATED RATEFAN] 11 00:00:00,631 GMT - USDJPY 0ms  {1165795200650 - 1165795200650 / 0}  7ms EBS Live(longmfxf 02p1b1) 116.24/116.25 [10f6ead5fca:-5fec]

# old ratefan
#64320646 [SPOT RATEFAN] 11 00:00:00,631 GMT - USDJPY 0ms  {1165795200650 - 1165795200650 / 0}  7ms EBS Live(longmfxf 02p1b1) 116.24/116.25 [10f6ead5fca:-5fec]

# new dedicated ratefan
#   60479 [SPOT DEDICATED RATEFAN] 08 09:25:05,617 GMT - EURUSD 1.2983/1.2984 [13: 3, 0, 9, 1] EBS Live (dnau2.uk.db.com)  [110a0a14924:-684e]

# new ratefan
#   60479 [SPOT RATEFAN] 08 09:25:05,617 GMT - EURUSD 1.2983/1.2984 [13: 3, 0, 9, 1] EBS Live (dnau2.uk.db.com)  [110a0a14924:-684e]


	 my $shift = 0;
	 if (/SPOT DEDICATED RATEFAN/) {
		  # once more token in the line
		  $shift = 1;
	 }

	 my (@toks) = split(/ +/);
	 my ($hour, $min, $y) = split(/:/, $toks[4 + $shift]);
	 my ($sec, $x) = split(/,/, $y);
	 my $day  = $toks[3 + $shift];
	 my $wday = 0;
	 #my $mon = 11 - 1;
	 my $yday = 0;
	 my $tz = $toks[5 + $shift];

	 my $delay = undef;

	 if ( $toks[10 + $shift] eq "-" ) {
		  #old logs format
		  $delay = $toks[14 + $shift];

	 }
	 if ( $toks[9 + $shift]=~/^\[/) {
		  # new log format
		  $delay = $toks[9 + $shift];
	 }

	 $delay=~s/ms$//;
	 $delay=~s/\[//;
	 $delay=~s/://;

	 next if ( not $delay );

	 next if ( $delay eq "N/A" );

	 # No need to this check. reflex fixed the rate when switching source
	 #next if ( $delay > 500 );

	 my $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

	 if ( $unixtime == $lasttime ) {
		  # updates during same second
		  if ( $delay > $second_max ) {
				$second_max = $delay;
		  }
	 }

	 if ( $unixtime > $lasttime ) {

		  $args .= " $lasttime:$second_max";

		  if ( $nargs == $maxargs ) {
				print "rrdupdate EURUSD.rrd $args\n";
				$nargs=0;
				$args='';
		  } else {
				$nargs++;
		  }

		  $lasttime = $unixtime;
		  $second_max = $delay;
	 }
}

if ($args) {
	 print "rrdupdate EURUSD.rrd $args\n";
}

# save the last time to skip times
open(L, ">lastupdate");
print L "$lasttime\n";
close(L);
