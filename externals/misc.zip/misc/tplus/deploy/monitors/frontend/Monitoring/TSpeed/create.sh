#!/bin/sh
#
# $Id: create.sh,v 1.18 2007/04/29 11:14:55 kovyale Exp $
#

echo Safety catch to no overwrite the database.
echo To create the database comment out next line after this message.
exit 1

. ../../env.sh

# create trades database
rrdtool create TSPEED.rrd \
--start 20060101 \
--step 10 \
DS:tps:GAUGE:1200:0:U 	\
RRA:MAX:0.5:6:1576800 \
