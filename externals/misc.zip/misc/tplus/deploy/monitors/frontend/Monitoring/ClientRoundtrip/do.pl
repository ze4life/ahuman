#!/usr/bin/perl


#use Data::Dumper;

$RRDtool="rrdtool";

sub createRRD {
    my $name = shift;
    my $rc = system($RRDtool, "create", "$name.rrd", "--start", 
        "20061101", "--step", "1", 
        "DS:r:GAUGE:86400:0:U",
        "RRA:MAX:0.5:1:3600",
        "RRA:MAX:0.5:60:1440",
        "RRA:MAX:0.5:600:1008",
        "RRA:MAX:0.5:10800:244",
        "RRA:MAX:0.5:86400:366",
        "RRA:AVERAGE:0.5:1:3600",
        "RRA:AVERAGE:0.5:60:1440",
        "RRA:AVERAGE:0.5:600:1008",
        "RRA:AVERAGE:0.5:10800:244",
        "RRA:AVERAGE:0.5:86400:366",
    );
    return $rc;
}

#my %Client; # <--- this is being defined in config.pl
my $rrd_max_args = 40;

# load the list of the clients to show.
require './config.pl';

while (<STDIN>) {
    chomp;
    next if (! /^\d+:[^:]+:/);
    my ( $timestamp,$client,$r,$realm_protocol,$realm_host,$realm_port,$user_id ) = split (/:/);
    my $realm_url = "$realm_protocol:$realm_host:$realm_port";

    next if ( not defined $Client{$client} );

    if ( defined $Client{$client}{$timestamp} ) {
        $Client{$client}{$timestamp} = $r if ( $r > $Client{$client}{$timestamp} );
    } else {
        $Client{$client}{$timestamp} = $r;
    }
}

for my $client (keys %Client) {

    if ( ! -f "$client.rrd" ) {
        # create the RRD for the new client, and skip it if could
        if ( createRRD($client) != 0) {
            print STDERR "Could not create RRD for $client\n";
            next;
        }
    }

    my $lastupdate = `rrdtool info "$client.rrd" | grep last_update | cut -d= -f 2`;
    $lastupdate =~ s/ //g; chomp $l;

    my @update_line;
    my $rrd_args = 0;

    for my $timestamp (sort {$a <=> $b} keys %{$Client{$client}}) {

        if ( $timestamp > $lastupdate ) {
            if ( $rrd_args < $rrd_max_args ) {
                push(
                    @update_line,
                    "$timestamp:$Client{$client}{$timestamp}"
                );
                $rrd_args++;
            } else {
                if ( 
                    system($RRDtool, "update", "$client.rrd", @update_line) != 0 
                ) {
                    print STDERR "Could not update $client.rrd with array \@update_line\n";
                    for (@update_line) {
                        print "value|$_|\n";
                    }
                } 
                $rrd_args = 0;
                splice @update_line;
            }
        }
    } 
    if ( $rrd_args > 0 ) {
        if ( 
            system($RRDtool, "update", "$client.rrd", @update_line) != 0 
        ) {
            print STDERR "Could not update $client.rrd with array \@update_line\n";
            for (@update_line) {
                print "value|$_|\n";
            }
        }
    }
}
