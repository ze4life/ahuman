#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ../../env.sh

rrdtool create PNL.rrd \
--start 20061101 \
--step 60 \
DS:tra_pnl:GAUGE:120:U:U     \
DS:tot_pnl:GAUGE:120:U:U     \
RRA:AVERAGE:0.5:1:1577847
