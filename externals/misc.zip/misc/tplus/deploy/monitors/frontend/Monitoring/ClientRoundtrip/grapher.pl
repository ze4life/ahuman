#!/usr/bin/perl
#
#

# must be in $PATH ($ENV{PATH}), check the path in refresh.sh
$RRDtool = "rrdtool";

require "./config.pl";

open IDX, ">index.html.new" or die;

print IDX <<EOF
<head>
         <meta http-equiv="refresh" content="60">
         <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
EOF
;

my @periods = ("hour", "day", "week", "month", "year");
my @geometry = ( "-w", "1024", "-h",  "512",  "-i" , "-z" , "-E" , "-r", "-l", "0" );
my @sgeometry = ( "-w", "512", "-h",  "200",  "-i" , "-z" , "-E" , "-r", "-l", "0" );
my $maxcolor = '#FF4444';
my $avgcolor = '#00AA00';


for my $client (sort keys %Client) {
    if ( -f "$client.rrd" ) {
        open HTML, "> $client.html" or die;
        print HTML <<EOF
<head>
         <meta http-equiv="refresh" content="60">
         <title>The roundtrips for the $Client{$client}{name}</title>
         <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
EOF
        ;
        for my $p (@periods) {
            my $l = substr($p, 0, 1);
            my $rc = system ( $RRDtool , "graph" , "${client}_$p.png", 
                @geometry,
                #"--title", "$Client{$client}{name} last $p ($Client{$client}{pop})",
                "--title", "$Client{$client}{name} last $p",
                "--vertical-label", "ms",
                "--end", "now",
                "--start", "end-1$l",
                "DEF:m=$client.rrd:r:MAX", 
                "DEF:a=$client.rrd:r:AVERAGE", 
                "AREA:m$maxcolor:Max",
                "AREA:a$avgcolor:Average",
            );
            print HTML "<img src=\"${client}_$p.png\"><br>\n";
        }
        my $rc = system ( $RRDtool , "graph" , "${client}_s.png", 
            @sgeometry,
            "--title", "$Client{$client}{name}",
            "--vertical-label", "ms",
            "--end", "now",
            "--start", "end-1h",
            "DEF:m=$client.rrd:r:MAX", 
            "DEF:a=$client.rrd:r:AVERAGE", 
            "AREA:m$maxcolor:Max",
            "AREA:a$avgcolor:Average",
        );
        print IDX "<a href=\"$client.html\"><img src=\"${client}_s.png\"></a>";
        close HTML;
    }
}

close IDX;

rename "index.html.new", "index.html";
