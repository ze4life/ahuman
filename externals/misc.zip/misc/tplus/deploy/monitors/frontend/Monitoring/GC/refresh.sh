#!/bin/sh
#
# $Id: refresh.sh,v 1.4 2008/11/06 12:44:33 kovyale Exp $
#

renice 19 $$

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

./populate.sh
