#!/bin/sh
#
# $Id: refresh.sh,v 1.1 2007/10/24 14:03:38 kovyale Exp $
#

renice 19 $$

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

. ../../env.sh

./populate.sh

./grapher.pl
