#!/bin/sh
#
# $Id: populate.sh,v 1.4 2008/05/23 13:44:36 kovyale Exp $
#

. ../../env.sh

$SSH_CMD $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -432 sessions.log )" \
| ./parse_sessions_log.pl | /bin/sh -x
