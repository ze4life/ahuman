#!/bin/sh
#
# $Id: populate.sh,v 1.2 2008/05/23 13:44:35 kovyale Exp $
#

. ../../env.sh

$SSH_CMD $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -300 ClientRoundtrip.pl.log )" \
| ./do.pl 
