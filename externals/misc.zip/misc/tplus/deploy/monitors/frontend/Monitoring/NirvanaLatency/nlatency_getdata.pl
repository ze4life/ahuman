#!/usr/bin/perl
#
#

require "./config.pl";

use POSIX ":sys_wait_h";

$max_running_childs = 10;
$running_childs = 0;

for my $realm (sort keys %CFG) {

    # skip disabled realms
    next if ( $CFG{$realm}{disabled} =~ /yes/i );

    if ( ! -d "realms/$realm" ) {
        `mkdir -p realms/$realm`;
    }

    my $ssh_user = $CFG{$realm}{ssh_user};
    my $ssh_host = $CFG{$realm}{ssh_host};
    my $ssh_port = 22;

    if ( defined $CFG{$realm}{ssh_port} ) {
        $ssh_port = $CFG{$realm}{ssh_port};
    }


    while ($running_childs == $max_running_childs) {
        print "waitpid...($running_childs) \n";
        my $kid = waitpid(-1, 0);
        print "Got kid $kid\n";
        $running_childs--;
    }

    my $pid = fork;

    die "fork" if (not defined $pid);

    if ($pid == 0) {
        #child
        eval {
            local $SIG{ALRM} = sub { die "alarm\n" }; # NB: \n required
            alarm 120;

            if ( defined $CFG{$realm}{proxy_command} ) {
                `cd realms/$realm && \\
                $CFG{$realm}{proxy_command} "\\
                ssh -o 'PasswordAuthentication no' -o 'UserKnownHostsFile /dev/null' -o 'StrictHostKeyChecking no' \\
                -p $ssh_port $ssh_user\@$ssh_host \\
                \\\"( cd $CFG{$realm}{path}/latency && nice -n 19 tail -3000 latency.log )\\\"" | perl ../../do.pl > do.pl.debug.out 2>&1`;
            } else {
                `cd realms/$realm && \\
                ssh -o 'PasswordAuthentication no' \\
                -o 'UserKnownHostsFile /dev/null' \\
                -o 'StrictHostKeyChecking no' \\
                -p $ssh_port $ssh_user\@$ssh_host \\
                "( cd $CFG{$realm}{path}/latency && nice -n 19 tail -3000 latency.log )" | perl ../../do.pl > do.pl.debug.out 2>&1`;
            }
            alarm 0;
        };
        if ($@) {
            print "timeout connecting to $realm:$ssh_port\n";
        }
        exit;
    } else {
        #father
        print "Child $pid started\n";
        $running_childs++;
    }
}

while ($running_childs > 0) {
    print "wating for $running_childs kids \n";
    my $kid = waitpid(-1, 0);
    print "got kid $kid\n";
    $running_childs--;
}
print "all kids gone, exiting...\n";
