#!/usr/bin/perl
#
#

require "./config.pl";

use POSIX ":sys_wait_h";

$max_running_childs = 2;
$running_childs = 0;

open IDX, "> realms/index.html.new" or die;

print IDX <<EOF
<head>
         <TITLE>Nirvana Latencies</TITLE>
         <meta http-equiv="refresh" content="30">
         <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
<br />
EOF
;

for my $realm ( sort { $CFG{$a}{pop} cmp $CFG{$b}{pop} } keys %CFG ) {

    # skip disabled hosts
    next if ( $CFG{$realm}{disabled} =~ /yes/i );

    while ($running_childs == $max_running_childs) {
        print "waitpid...($running_childs) \n";
        my $kid = waitpid(-1, 0);
        print "Got kid $kid\n";
        $running_childs--;
    }

    my $pid = fork;

    die "fork" if (not defined $pid);

    if ($pid == 0) {
        #child
        if ( -d "realms/$realm" ) {
            `cp index.html realms/$realm/`;
            `perl ./draw.pl realm=$realm pop=$CFG{$realm}{pop} scale=$CFG{$realm}{scale} > realms/$realm/draw.pl.debug.out 2>&1`;
        }
        exit;
    } else {
        #father
        print "Child $pid started\n";
        $running_childs++;
        if ( -d "realms/$realm" ) {
            print IDX "<a href=\"$realm/\"><img src=\"$realm/small_hour.png\"></a>";
        }
    }
}
close IDX;

while ($running_childs > 0) {
    print "wating for $running_childs kids \n";
    my $kid = waitpid(-1, 0);
    print "got kid $kid\n";
    $running_childs--;
}
print "all kids gone, exiting...\n";

rename "realms/index.html.new", "realms/index.html";
