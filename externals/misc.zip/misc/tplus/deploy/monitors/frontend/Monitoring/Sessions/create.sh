#!/bin/sh
#
# $Id: create.sh,v 1.1 2007/02/09 12:07:18 kovyale Exp $
#

echo Safety catch to no overwrite the database.
echo To create the database comment out next line after this message.
exit 1

. ../../env.sh

# POP names are:
# ALL - stands for total users
# LAN - LAN 
# LON - LONDON including bcp
# SIN - SINGAPORE
# USA - NEW YORK
# VPN - RADIANZ
# VDR - RADIANZ DR included in VPD
# FXS - fx spp realm sp1 and sp2

# create sessions databases
rrdtool create SESSIONS.rrd \
--start 20060101 \
--step 600 \
DS:ALL:GAUGE:1200:0:U 	\
DS:LAN:GAUGE:1200:0:U 	\
DS:LON:GAUGE:1200:0:U 	\
DS:SIN:GAUGE:1200:0:U 	\
DS:USA:GAUGE:1200:0:U 	\
DS:VPN:GAUGE:1200:0:U 	\
DS:FXS:GAUGE:1200:0:U 	\
RRA:AVERAGE:0.5:1:157680 \
RRA:MIN:0.5:1:157680 \
RRA:MAX:0.5:1:157680
