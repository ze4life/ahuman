#!/usr/bin/perl

#use Data::Dumper;

$RRDtool="rrdtool";
#$RRDtool="echo";

sub createRRD {
    my $name = shift;
    my $rc = system($RRDtool, "create", "$name.rrd", "--start", 
        "20061101", "--step", "1", 
        "DS:l:GAUGE:5:0:U",
        "RRA:MAX:0.5:1:3600",
        "RRA:MAX:0.5:60:1440",
        "RRA:MAX:0.5:600:1008",
        "RRA:MAX:0.5:10800:244",
        "RRA:MAX:0.5:86400:366",
        "RRA:AVERAGE:0.5:1:3600",
        "RRA:AVERAGE:0.5:60:1440",
        "RRA:AVERAGE:0.5:600:1008",
        "RRA:AVERAGE:0.5:10800:244",
        "RRA:AVERAGE:0.5:86400:366",
    );
    return $rc;
}

my $rrd_max_args = 40;

sub cachedUpdateRRD {
    my $timestamp = shift;
    my $latency = shift;

    if ( defined $timestamp && defined $latency ) {

        if ( scalar @update_line < $rrd_max_args ) {
            push( @update_line, "$timestamp:$latency");
        } else {
            if ( system($RRDtool, "update", "latency.rrd", @update_line) != 0 ) {
                print STDERR "Could not update latency.rrd with array \@update_line\n";
                for (@update_line) { print STDERR "value|$_|\n"; }
                die;
            } 
            splice @update_line;

        }
    }
}

if ( ! -f "latency.rrd" ) {
    # create the RRD for the new user, and skip it if could
    if ( createRRD("latency") != 0) {
        print STDERR "Could not create latency.rrd\n";
        die;
    }
}

my $prev_timestamp = `rrdtool info "latency.rrd" | grep last_update | cut -d= -f 2`;
$prev_timestamp =~ s/ //g; 
chomp $prev_timestamp;

my $prev_latency;
my @update_line;

while (<STDIN>) {
    chomp;
    #1196284599.518 USDJPY 2 0 5
    next if (! /^\d+\.\d+\s[^\s]+\s\d+$/);

    my ($timestamp, $ccy, $latency) = split(/\s/);

    next until ( $timestamp > $prev_timestamp + 1);

    if (not defined $prev_latency) {
        $prev_latency = $latency;
        $prev_timestamp = $timestamp;
        next;
    }

    if ( $timestamp > $prev_timestamp ) {
        cachedUpdateRRD ( $prev_timestamp, $prev_latency );
        $prev_timestamp = $timestamp;
        $prev_latency = $latency;
    } else {
        # if timestamp == prev_timestamp
        $prev_latency = $latency if ( $latency > $prev_latency );
    }
}

# do not miss latest values
cachedUpdateRRD ( $prev_timestamp, $prev_latency );

# check for the prev data
if ( scalar @update_line  > 0 ) {
    if ( system($RRDtool, "update", "latency.rrd", @update_line) != 0 ) {
        print STDERR "Could not update latency.rrd with array \@update_line\n";
        for (@update_line) { print STDERR "value|$_|\n"; }
        die;
    }
}
