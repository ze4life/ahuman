#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced"
all_color="#CC3118"
lan_color="#7648EC"
vpn_color="#1598C3"
sin_color="#54EC48"
usa_color="#ECD748"
lon_color="#EC9D48"
fxs_color="#FF0000"


# now time
now="$NOW"

# POP names are:
# ALL - stands for total users
# LAN - LAN 
# LON - LONDON including bcp
# SIN - SINGAPORE
# USA - NEW YORK
# VPN - RADIANZ
# VDR - RADIANZ DR included in VDR
# FXS - fx spp realm sp1 and sp2

start=""
step=""
stext=""
xgrid=""

set_start() {
	 local per=$1

	 case $per in
		  day) start="end-1d"
		  step=600
		  stext="ten minutes"
		  xgrid="--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:%H:%M"
		  ;;
		  week) start="end-1w"
		  step=3600
		  stext="hour"
		  xgrid=""
		  ;;
		  month) start="end-1m"
		  step=86400
		  stext="day"
		  xgrid=""
		  ;;
		  quarter) start="end-3m"
		  step=86400
		  stext="day"
                  xgrid="--x-grid DAY:1:WEEK:1:MONTH:1:0:%b-%d"
		  ;;
		  year) start="end-1y"
		  step=86400
		  stext="day"
                  xgrid="--x-grid WEEK:1:MONTH:1:MONTH:1:2592000:%b"
		  ;;
		  *)
		  echo "Period must be: day, week, month, quarter or year"
		  exit 1
		  ;;
	 esac
}

draw_all() {
	 local per=$1
	 local back_color=$2

	 if [ -n "$back_color" ]; then
		  back_color="--color BACK$back_color"
	 fi

	 set_start $per

	 rrdtool graph all_sessions_${per}.png \
	 $geometry $back_color \
	 --title "Total user sessions for the last $per. Re-measured every $stext." \
	 --vertical-label "sessions" \
         -M -l 0 \
	 --end $now \
	 --start $start \
	 $xgrid \
	 DEF:ALL=SESSIONS.rrd:ALL:MAX:step=$step LINE2:ALL$all_color:"Total number of users connected." GPRINT:ALL:LAST:"Last\:%.0lf" GPRINT:ALL:MAX:"Max\:%.0lf"
}

draw_pops() {
	 local per=$1
	 local back_color=$2
	 local start=""

	 if [ -n "$back_color" ]; then
		  back_color="--color BACK$back_color"
	 fi

	 set_start $per

	 rrdtool graph sessions_${per}.png \
	 $geometry $back_color \
	 --title "User sessions per location for the last $per. Re-measured every $stext." \
         -M -l 0 \
	 --vertical-label "sessions" \
	 --end $now \
	 --start $start \
	 $xgrid \
	 COMMENT:"Location\:last/max\n" \
	 DEF:LAN=SESSIONS.rrd:LAN:MAX:step=$step LINE2:LAN$lan_color:"Intranet\:\g" GPRINT:LAN:LAST:"%.0lf\g" GPRINT:LAN:MAX:"/%.0lf%s" \
	 DEF:VPN=SESSIONS.rrd:VPN:MAX:step=$step LINE2:VPN$vpn_color:"Radianz\:\g" GPRINT:VPN:LAST:"%.0lf\g" GPRINT:VPN:MAX:"/%.0lf%s" \
	 DEF:SIN=SESSIONS.rrd:SIN:MAX:step=$step LINE2:SIN$sin_color:"Singapore\:\g" GPRINT:SIN:LAST:"%.0lf\g" GPRINT:SIN:MAX:"/%.0lf%s" \
	 DEF:USA=SESSIONS.rrd:USA:MAX:step=$step LINE2:USA$usa_color:"New York\:\g" GPRINT:USA:LAST:"%.0lf\g" GPRINT:USA:MAX:"/%.0lf%s" \
	 DEF:LON=SESSIONS.rrd:LON:MAX:step=$step LINE2:LON$lon_color:"London\:\g" GPRINT:LON:LAST:"%.0lf\g" GPRINT:LON:MAX:"/%.0lf%s" \
	 DEF:ALL=SESSIONS.rrd:ALL:MAX:step=$step GPRINT:ALL:LAST:"Total\: %.0lf" \

}

draw_pops_stack() {
	 local per=$1
	 local back_color=$2
	 local start=""

	 if [ -n "$back_color" ]; then
		  back_color="--color BACK$back_color"
	 fi

	 set_start $per

	 rrdtool graph sessions_${per}_stacked.png \
	 $geometry $back_color \
	 --title "User sessions per location for the last $per. Re-measured every $stext." \
	 --vertical-label "sessions" \
         -M -l 0 \
	 --end $now \
	 --start $start \
	 $xgrid \
	 DEF:LAN=SESSIONS.rrd:LAN:MAX:step=$step AREA:LAN$lan_color:"Intranet\:\g":STACK GPRINT:LAN:LAST:"%.0lf" \
	 DEF:VPN=SESSIONS.rrd:VPN:MAX:step=$step AREA:VPN$vpn_color:"Radianz\:\g":STACK GPRINT:VPN:LAST:"%.0lf" \
	 DEF:SIN=SESSIONS.rrd:SIN:MAX:step=$step AREA:SIN$sin_color:"Singapore\:\g":STACK GPRINT:SIN:LAST:"%.0lf" \
	 DEF:USA=SESSIONS.rrd:USA:MAX:step=$step AREA:USA$usa_color:"New York\:\g":STACK GPRINT:USA:LAST:"%.0lf" \
	 DEF:LON=SESSIONS.rrd:LON:MAX:step=$step AREA:LON$lon_color:"London\:\g":STACK GPRINT:LON:LAST:"%.0lf" \
	 DEF:ALL=SESSIONS.rrd:ALL:MAX:step=$step GPRINT:ALL:LAST:"Total\: %.0lf" \

}
draw_pops_stack_small() {
	 local per=$1
	 local back_color=$2
	 local start=""

	 if [ -n "$back_color" ]; then
		  back_color="--color BACK$back_color"
	 fi

	 set_start $per

	 rrdtool graph sessions_${per}_stacked_small.png \
	 $back_color \
	 -w 310 -h 65 --interlaced \
	 --title "Sessions last $per." \
         -M -l 0 \
	 --vertical-label "sessions" \
	 --end $now \
	 --start $start \
	 DEF:LAN=SESSIONS.rrd:LAN:MAX:step=$step AREA:LAN$lan_color:"LAN\:\g":STACK GPRINT:LAN:LAST:"%.0lf" \
	 DEF:VPN=SESSIONS.rrd:VPN:MAX:step=$step AREA:VPN$vpn_color:"VPN\:\g":STACK GPRINT:VPN:LAST:"%.0lf" \
	 DEF:SIN=SESSIONS.rrd:SIN:MAX:step=$step AREA:SIN$sin_color:"SIN\:\g":STACK GPRINT:SIN:LAST:"%.0lf" \
	 DEF:USA=SESSIONS.rrd:USA:MAX:step=$step AREA:USA$usa_color:"USA\:\g":STACK GPRINT:USA:LAST:"%.0lf\n" \
	 DEF:LON=SESSIONS.rrd:LON:MAX:step=$step AREA:LON$lon_color:"LON\:\g":STACK GPRINT:LON:LAST:"%.0lf" \
	 DEF:ALL=SESSIONS.rrd:ALL:MAX:step=$step GPRINT:ALL:LAST:"Tot\: %.0lf" \

}


draw_pops day
draw_pops_stack day
draw_pops_stack_small day
draw_all day

draw_pops week 
draw_all week 

draw_pops month 
draw_all month 

draw_all quarter
draw_all year

exit 0
