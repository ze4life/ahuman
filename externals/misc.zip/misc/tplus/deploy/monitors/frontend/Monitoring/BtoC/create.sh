#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ../../env.sh

rrdtool create EURUSD.rrd \
--start 20061101 \
--step 1 \
DS:day:GAUGE:90:0:U 	\
RRA:AVERAGE:0.5:60:2678400 \
RRA:MAX:0.5:60:2678400 \
RRA:MIN:0.5:60:2678400 \


