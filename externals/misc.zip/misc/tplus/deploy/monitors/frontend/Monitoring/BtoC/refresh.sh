#!/bin/sh
#
# $Id: refresh.sh,v 1.1 2007/02/09 12:07:18 kovyale Exp $
#

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

./populate.sh

./dograph.sh
