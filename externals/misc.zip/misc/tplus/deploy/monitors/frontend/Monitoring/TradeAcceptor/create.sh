#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ../../env.sh


for i in server fixserver
do
    rrdtool create Accepted_${i}.rrd \
    --start 20061101 \
    --step 1 \
    DS:t1:ABSOLUTE:3600:U:U \
    DS:t2:GAUGE:60:U:U \
    DS:t3:GAUGE:60:U:U \
    DS:t4:GAUGE:60:U:U \
    DS:t5:GAUGE:60:U:U \
    DS:t6:GAUGE:60:U:U \
    DS:t7:GAUGE:60:U:U \
    DS:t8:GAUGE:60:U:U \
    DS:t9:GAUGE:60:U:U \
    DS:t10:GAUGE:60:U:U \
    DS:t11:GAUGE:60:U:U \
    RRA:MAX:0.5:10:120960 \
    RRA:AVERAGE:0.5:10:120960 \
    RRA:MAX:0.5:60:527040 \
    RRA:AVERAGE:0.5:60:527040

    rrdtool create Rejected_${i}.rrd \
    --start 20061101 \
    --step 1 \
    DS:t1:ABSOLUTE:3600:U:U \
    DS:t2:GAUGE:60:U:U \
    DS:t3:GAUGE:60:U:U \
    DS:t4:GAUGE:60:U:U \
    RRA:MAX:0.5:10:120960 \
    RRA:AVERAGE:0.5:10:120960 \
    RRA:MAX:0.5:60:527040 \
    RRA:AVERAGE:0.5:60:527040
done
