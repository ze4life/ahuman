#!/bin/sh
#
# $Id: populate.sh,v 1.1 2008/07/18 12:02:40 kovyale Exp $
#

. ../../env.sh

SSH_USER=abfxp2
SSH_HOST=abfxp2.uk.db.com
APPLICATION_USER=abfxp2

$SSH_CMD $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -30 pv.log )" \
| ./parse_log.pl PV.rrd | /bin/sh -x
