#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced -l 0"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

#small day
rrdtool graph trades_day_small.png \
$color \
-w 310 -h 70 --interlaced \
--title "Trades last day." \
--vertical-label "trades" \
--end $now \
--start end-1d \
DEF:tavg=TRADES.rrd:ses:AVERAGE \
AREA:tavg$green_color:"trades per ten minutes." \
GPRINT:tavg:LAST:"Last\:%.0lf" \
GPRINT:tavg:MAX:",Max\:%.0lf" \

#day
rrdtool graph trades_day.png \
$geometry $color \
--title "Number of trades per ten minutes. Last day." \
--vertical-label "trades" \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
DEF:tavg=TRADES.rrd:ses:AVERAGE \
LINE1:tavg$green_color:"Number of trades per ten minutes." \
GPRINT:tavg:LAST:"Last\:%.0lf" \
GPRINT:tavg:MAX:",Max\:%.0lf" \

# week
rrdtool graph trades_week.png \
$geometry $color \
--title "Number of trades per hour. Last week." \
--vertical-label "trades" \
--end $now \
--start end-1w \
DEF:tavg=TRADES.rrd:ses:AVERAGE:step=3600 \
CDEF:tot=tavg,6,* \
AREA:tot$green_color:"Number of trades per hour." \
GPRINT:tot:MAX:"Max\:%.0lf" \

# 3 months
rrdtool graph trades_month.png \
$geometry $color \
--title "Number of trades per day. Last three months." \
--vertical-label "trades" \
--end $now \
--start end-3m \
DEF:tavg=TRADES.rrd:ses:AVERAGE:step=86400 \
CDEF:tot=tavg,144,* \
AREA:tot$green_color:"Number of trades per day." \
GPRINT:tot:MAX:"Max\:%.0lf" \

# year
rrdtool graph trades_year.png \
$geometry $color \
--title "Number of trades per month. Last year." \
--vertical-label "trades" \
--end $now+1w \
--start end-1y \
DEF:tavg=TRADES.rrd:ses:AVERAGE:step=2629746 \
CDEF:tot=tavg,4382,* \
AREA:tot$green_color:"Number of trades per month." \
GPRINT:tot:MAX:"Max\:%.0lf" \
