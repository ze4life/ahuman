#!/usr/bin/perl

my $maxtablerows = 5;

my @rows;

my $now = time;
my @td_style = (
    '<td style="font-family: Verdana; font-size: 36pt; color: #000000; background: #a0ffa0">',
    '<td style="font-family: Verdana; font-size: 36pt; color: #000060; background: #ffff80">',
);
my $silk_td = '<td align="center" style="font-family: Verdana; font-size: 36pt; color: #000000; background: #a0ffa0">',
my $td_i = 0;

while(<ARGV>) {
    my $date;
    my $type;
    my $ts;
    my $app;
    my $title;
    my $message;

    if ( 
        /^(\d+)\s+\[([^\]]*)\]\s+\d\d-\D\D\D-\d\d\d\d\s+(\d\d:\d\d:\d\d,\d\d\d)\s+\D\D\D\s+(\w+)\s+-\s+(.+)$/ or
        /^(\d+)\s+\[([^\]]*)\]\s+\d\d\d\d-\D\D\D-\d\d\s+(\d\d:\d\d:\d\d,\d\d\d)\s+\D\D\D\s+(\w+)\s+-\s+(.+)$/ or
        /^(\d+)\s+\[([^\]]*)\]\s+(\d\d:\d\d:\d\d,\d\d\d)\s+\D\D\D\s+(\w+)\s+-\s+(.+)$/
    ) {
        $ts = $1;
        $app = $2;
        $date = $3;
        $type = $4;
        ( $title, $message ) = split (/:/, $5, 2);
    } else {
        print STDERR "Can not parse:\n";
        print STDERR "$_";
        next;
    }

    # only last 10 mins
    next if ( ( $now - $ts ) > 10 * 60 );

    # skip FXOP panic
    next if ($app =~ /FXOP/ && $title =~ /VSS ERROR/);
    next if ($app =~ /FXOP/ && $title =~ /FX RATES UNAVAILABLE/);
    next if ($app =~ /FXOP/ && $title =~ /EXERCISE STATUS DISCREPANCY/);
    next if ($app =~ /FXOP/ && $title =~ /COMMAND TIMEOUT/);
    next if ($app =~ /FXOP/ && $title =~ /VOLS STALE/);
    next if ($app =~ /FXOP/ && $title =~ /VSS FAILOVER/);
    next if ($app =~ /FXOP/ && $title =~ /TRADE AFFIRMATION ERROR/);
    next if ($app =~ /FXOP/ && $title =~ /PRICER ERROR/);
    next if ($app =~ /FXOP/ && $title =~ /PRICER FAILOVER/);
    next if ($app =~ /FXOP/ && $title =~ /ARCS FAILOVER/);
    next if ($app =~ /FXOP/ && $title =~ /VOLATILITY NOT TRADABLE/);
    # some FXPLUS too
    next if ($app =~ /FXPLUS/ && $title =~ /ARCS FAILOVER/);
    next if ($app =~ /FXPLUS/ && $title =~ /SYSTEM ERROR/ 
                && $message =~ /System error occured executing CheckRfsCreditCommand/ );
    next if ($app =~ /FXPLUS/ && $title =~ /SYSTEM ERROR/ 
                && $message =~ /System error occured executing: DefaultStandardRateRequester/ );

    # small hack to show all NIRVANA messages
    if ($title =~ /NIRVANA/) {
        $type = 'ERROR';
    }

    # add red color for errors
    if ( $type eq "ERROR" or $type eq "FATAL" or $type eq "WARN" ) {
        $title = "<font color=\"red\">$title</font>";
    } else {
        # skip non ERROR
        next;
    }

    # remove trail shit from message
    $message = substr($message, 0, index($message, " [] "));

    # truncate message to the first 120 chars
    $message = substr($message, 0, 120) . "...";

    push(@rows, "<tr>$td_style[$td_i++] $date [$app] <b>$title</b>: $message</td></tr>");
    $td_i = 0 if ( $td_i > $#td_style );
}

# rewrite index.html
open I, ">index.html" or die;
# header
print I <<EOF
<html>
<head>
<title>Autobahn FX Alerts</title>
<meta http-equiv="refresh" content="10">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
<body>
<br><br>
<table border="0" cellpadding="5" width="90%" align=center>
EOF
;
my $lastrow_n = $#rows;
if ( $lastrow_n > -1 ) {
    for (my $i = 0; $i < $maxtablerows and $i <= $lastrow_n; $i++) {
        print I $rows[$lastrow_n - $i];
    }
} else {
    print I "<tr>$silk_td <b>smooth as silk</b></td></tr>";
}

#footer
print I <<EOF
</table>
</body>
</html>
EOF
;
close I;
