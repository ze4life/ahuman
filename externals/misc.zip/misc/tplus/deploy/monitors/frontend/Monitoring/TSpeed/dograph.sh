#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"
scale="-l 0 -r"

# now time
now="$NOW"

#hour
rrdtool graph tspeed_hour.png \
$geometry $color \
--title "Maximum trading speed (trades / second) per ten seconds. Last hour." \
--vertical-label "trades/sec" \
$scale \
--end $now \
--start end-1h \
DEF:max=TSPEED.rrd:tps:MAX:step=10 \
LINE1:max$red_color:"max" \

#day
rrdtool graph tspeed_day.png \
$geometry $color \
--title "Maximum trading speed (trades / second) per ten minutes. Last day." \
--vertical-label "trades/sec" \
$scale \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
DEF:max=TSPEED.rrd:tps:MAX:step=600 \
LINE1:max$red_color:"max" \

# week
rrdtool graph tspeed_week.png \
$geometry $color \
--title "Maximum trading speed (trades / second) per one hour. Last week." \
--vertical-label "trades/sec" \
$scale \
--end $now \
--start end-1w \
DEF:max=TSPEED.rrd:tps:MAX:step=3600 \
LINE1:max$red_color:"max" \

# 3 months
rrdtool graph tspeed_month.png \
$geometry $color \
--title "Maximum trading speed (trades / second) per one day. Last three month." \
--vertical-label "trades/sec" \
$scale \
--end $now \
--start end-3m \
DEF:max=TSPEED.rrd:tps:MAX:step=86400 \
LINE1:max$red_color:"max" \

