#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced -l 0"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

# hour number only
cat <<EOF > current.html
<head>
    <title>Current PnL</title>
	 <meta http-equiv="refresh" content="60">
	 <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
EOF
echo "<font style=\"font-family: Verdana; font-size: 156pt; font-weight: bold;\">" >> current.html
echo "<center>&euro;" >> current.html
rrdtool graph pnl_num.png \
--end $now \
--start end-1h \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE \
PRINT:tra:LAST:"%.0lf" | sed -e "s/0x0//" >> current.html
echo "</center></font>" >> current.html

#hour
rrdtool graph pnl_hour.png \
$geometry $color \
--title "PnL sampled every minute. Last hour." \
--vertical-label "PnL" \
--end $now \
--start end-1h \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE \
LINE1:0$blue_color \
LINE1:tra$red_color:"trading pnl"

#LINE1:tot$red_color:"total pnl"

#day
rrdtool graph pnl_day.png \
$geometry $color \
--title "PnL sampled every minute. Last day." \
--vertical-label "PnL" \
-l -1000000 -u 2000000 -r \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE:step=60 \
LINE1:0$blue_color \
LINE1:tra$red_color:"trading pnl" \

#week
rrdtool graph pnl_week.png \
$geometry $color \
--title "PnL sampled every ten minutes. Last week." \
--vertical-label "PnL" \
-l -1000000 -u 2000000 -r \
--end $now \
--start end-1w \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE:step=600 \
LINE1:0$blue_color \
LINE1:tra$red_color:"trading pnl" \

#month
rrdtool graph pnl_month.png \
$geometry $color \
--title "PnL sampled every hour. Last month." \
--vertical-label "PnL" \
-l -1000000 -u 2000000 -r \
--end $now \
--start end-1m \
--x-grid HOUR:6:DAY:1:DAY:1:0:%d \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE:step=3600 \
LINE1:0$blue_color \
LINE1:tra$red_color:"trading pnl" \

#year
rrdtool graph pnl_year.png \
$geometry $color \
--title "PnL sampled every day. Last year." \
--vertical-label "PnL" \
-l -3000000 -u 3000000 -r \
--end $now \
--start end-1y \
DEF:tra=PNL.rrd:tra_pnl:AVERAGE \
LINE1:0$blue_color \
LINE1:tra$red_color:"trading pnl" \

