#!/bin/sh
#
# $Id: populate.sh,v 1.5 2008/09/22 10:40:39 kovyale Exp $
#

. ../../env.sh

PROCS="dedicated_ratefan ratefan server fixserver"

for i in $PROCS
do

$SSH_CMD $SSH_USER@$SSH_HOST \
"( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -1000 gcAppStopTime.pl_$i.log )" \
| ./parse_log.pl $i.rrd | /bin/sh -x


done
