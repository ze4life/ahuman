#!/bin/sh

echo Safety catch to no overwrite the database.
exit 1

. ../../../env.sh

for f in EBS_Live ReutersAQ ReutersD2K ReutersEBS Nymex Cbot
do
    for i in SpotServer
    do
        rrdtool create ${i}_${f}.rrd \
        --start 20061101 \
        --step 1 \
        DS:d1:GAUGE:60:0:U     \
        DS:d2:GAUGE:60:0:U     \
        DS:d3:GAUGE:60:0:U     \
        DS:d4:GAUGE:60:0:U     \
        DS:d5:GAUGE:60:0:U     \
        RRA:MAX:0.5:10:120960 \
        RRA:AVERAGE:0.5:10:120960 \
        RRA:MAX:0.5:60:527040 \
        RRA:AVERAGE:0.5:60:527040
    done
done
