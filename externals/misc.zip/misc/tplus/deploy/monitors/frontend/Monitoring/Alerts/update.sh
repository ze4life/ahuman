#!/bin/sh
#
# $Id: update.sh,v 1.9 2008/05/17 16:46:30 kovyale Exp $
#

. ../../env.sh

# The DAEMON variable is exported from start script
if [ "$DAEMON" = "YES" ]; then
    pidfile=update.sh.pid
    echo $$ > $pidfile
fi

while true; do

  (
    for CON in abfxp1@abfxp1.uk.db.com abfxp2@abfxp2.uk.db.com
    do
    ssh -o 'UserKnownHostsFile /dev/null' \
        -o 'StrictHostKeyChecking no' $CON \
        "( cd monitor && nice -n 19 tail -200 alerts_tail.pl.log )" 2>/dev/null
    done
  ) | sort -n | /usr/bin/perl alerts.pl

    [ "$DAEMON" != "YES" ] && exit 0

    sleep 10

done
