#!/bin/sh
#
# $Id: refresh.sh,v 1.2 2008/06/27 11:21:37 kovyale Exp $
#

renice 19 $$

BASEDIR=`dirname $0`

test -d $BASEDIR || exit 1

cd $BASEDIR

exec 1> refresh.log 2>&1

./populate.sh
