#!/bin/sh
#
# $Id: populate.sh,v 1.6 2008/11/06 12:48:23 kovyale Exp $
#

. ../../env.sh

PROCS="server fixserver"

for app in $PROCS
do
   $SSH_CMD $SSH_USER@$SSH_HOST \
   "( cd ~$APPLICATION_USER/monitor ; nice -n 19 tail -1000 gcParNew.pl_$app.log )" \
   | ./do.pl $app.rrd | /bin/sh -x
done
