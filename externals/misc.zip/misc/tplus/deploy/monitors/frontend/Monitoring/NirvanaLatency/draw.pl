#!/usr/bin/perl
#
#

# must be in $PATH ($ENV{PATH}), check the path in refresh.sh
$RRDtool = "rrdtool";

# geometry
@geometry = ( "-w", "1024", "-h",  "350",  "--interlaced" , "-z" , "-E");

# periods
@periods = ("hour", "day", "week", "month", "year");

# step
%step = ( 
    "hour" => 10, 
    "day" => 60,
    "week" => 600,
    "month" => 3600,
    "year" => 86400,
);

%start = ( 
    "hour" => 'end-1h', 
    "day" => 'end-1d',
    "week" => 'end-1w',
    "month" => 'end-30d',
    "year" => 'end-1y',
);

%arg;
# parse ARGS
for (@ARGV) {
    my ($var, $val) = split(/=/);
    $arg{$var} = $val;
}
# realm name
$realm = $arg{realm};
$realm || die;

$pop = $arg{pop};
$scale = $arg{scale};
$scale = 500 if ( not defined $scale );

my $maxcolor = '#FF4444';
my $avgcolor = '#00AA00';

%draw_args;

for my $p (@periods) {
    push(@{$draw_args{avg}{$p}}, 
        "DEF:la=realms/$realm/latency.rrd:l:AVERAGE",
        "AREA:la$avgcolor:Avg",
    );
    push(@{$draw_args{max}{$p}}, 
        "DEF:lm=realms/$realm/latency.rrd:l:MAX",
        "AREA:lm$maxcolor:Max",
    );
}

for my $p (@periods) {
    $rc = system ( $RRDtool , "graph" , "realms/$realm/latency_avg_$p.png" , @geometry,
        "--title", "$realm, $pop, latency last $p",
        "-l", "0", "-u", "$scale", "-r",
        "--vertical-label", "ms",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{avg}{$p}},
    );
    $rc = system ( $RRDtool , "graph" , "realms/$realm/latency_max_$p.png" , @geometry,
        "--title", "$realm, $pop, latency last $p",
        "-l", "0", 
        "--vertical-label", "ms",
        "--end", "now",
        "--start", $start{$p}, 
        @{$draw_args{max}{$p}},
    );
}

# draw small graph for frontend
$rc = system ( $RRDtool , "graph" , "realms/$realm/small_hour.png" ,
    ( "-w", "150", "-h", "60",  "--interlaced" ), 
    "-l", "0", "-u", "$scale", "-r", "-g",
    "--title", "$realm",
    "--vertical-label", "ms",
    "--end", "now",
    "--start", $start{'hour'}, 
    @{$draw_args{max}{'hour'}},
    @{$draw_args{avg}{'hour'}},
);
