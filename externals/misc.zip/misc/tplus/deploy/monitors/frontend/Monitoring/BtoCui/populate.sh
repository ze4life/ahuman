#!/bin/sh

. ../../env.sh

$SSH_CMD $SSH_USER@$SSH_HOST \
"( 
cd ~$APPLICATION_USER/fxplus/level_1/dbag/
if [ -f release/log/spotrates.ratefan.log ]; then
	nice -n 19 grep EURUSD release/log/spotrates.ratefan.log
fi
) | nice -n 19 grep -v price-config | nice -n 19 grep Live
" | ./parse_dedicated_ratefan_log.pl | /bin/sh
