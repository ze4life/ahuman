#!/bin/sh

#2006-08-10 11:43:44
. ../../env.sh

# globals
geometry="-w 1024 -h 130 --interlaced"
#color="--color GRID#C0C0C0"
red_color="#CE0005"
blue_color="#0000FF"
green_color="#00CA1A"

# now time
now="$NOW"

#day
rrdtool graph t2t3_day.png \
$geometry $color \
--title "Number of slow booking times (trade processing took longer than a second) per ten minutes. Last day." \
--vertical-label "trades" \
--end $now \
--start end-1d \
--x-grid MINUTE:10:MINUTE:30:HOUR:1:0:"%H:%M" \
DEF:sec=T2T3.rrd:sec:AVERAGE \
DEF:ms=T2T3.rrd:ms:AVERAGE \
LINE1:ms$green_color:"100ms - 999ms" \
LINE1:sec$red_color:"more then 1sec" \

# week
rrdtool graph t2t3_week.png \
$geometry $color \
--title "Number of slow booking times (trade processing took longer than a second) per hour. Last week." \
--vertical-label "trades" \
--end $now \
--start end-1w \
DEF:sec=T2T3.rrd:sec:AVERAGE:step=3600 \
DEF:ms=T2T3.rrd:ms:AVERAGE:step=3600 \
CDEF:tsec=sec,6,* \
CDEF:tms=ms,6,* \
LINE1:tms$green_color:"100ms - 999ms" \
LINE1:tsec$red_color:"more then 1sec" \

# 3 months
rrdtool graph t2t3_month.png \
$geometry $color \
--title "Number of slow booking times (trade processing took longer than a second) per day. Last three months." \
--vertical-label "trades" \
--end $now \
--start end-3m \
DEF:sec=T2T3.rrd:sec:AVERAGE:step=86400 \
DEF:ms=T2T3.rrd:ms:AVERAGE:step=86400 \
CDEF:tsec=sec,144,* \
CDEF:tms=ms,144,* \
LINE1:tms$green_color:"100ms - 999ms" \
LINE1:tsec$red_color:"more then 1sec" \
