#!/usr/bin/perl
#
# $Id: parse_sessions_log.pl,v 1.5 2007/03/27 08:05:48 kovyale Exp $
#
# Parse the sessions.log file
# Update the RRD.

use POSIX;

use strict;
use warnings;

sub read_file {
    my $f = shift;
    my $l = undef;

    if ( -f "$f") {
        open L, "$f";
        $l = <L>;
        close L;
        chomp $l;
    }
    $l=0 if (not $l);
    $l;
}

sub write_file {
    my $f = shift;
    my $l = shift;
    open L, ">$f";
    print L "$l\n";
    close L;
}


my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

my $lastupdate = read_file ( "SESSIONS.lastupdatetime" );
my $unixtime = undef;

while ( <STDIN> ) {

	 chomp;

	 #2007-01-31 08:13:21 GMT ALL=32 LAN=10 LON=22
	 next if (not /^200\d-\d\d-\d\d \d\d:\d\d:\d\d \D\D\D (ALL=\d+ .*)$/);

	 my (@toks) = split(/ +/);
	 my ($hour, $min, $sec) = split(/:/, $toks[1]);
	 my ($year, $mon, $day) = split(/-/, $toks[0]);
	 my $wday = 0;
	 my $yday = 0;
	 my $tz = $toks[2];

	 $year -= 1900;
	 $mon -= 1;

	 # POP names are:
	 # ALL - stands for total users
	 # LAN - LAN 
	 # LON - LONDON including bcp
	 # SIN - SINGAPORE
	 # USA - NEW YORK
	 # VPN - RADIANZ
	 # VDR - RADIANZ DR included in VPN
	 # FXS - fx spp realm sp1 and sp2

	 my (@poppairs)=split(/ +/, $1);

	 $unixtime = mktime ($sec, $min, $hour, $day, $mon, $year, $wday, $yday, -1);

    # sometimes there was delays
    # round the time to 600 seconds
    $unixtime =~ s/\d\d$/00/;

	 next if ($lastupdate >= $unixtime);

	 my $update_line="$unixtime:";
	 my $update_tmpl='';

	 for my $poppair (@poppairs) {
		  my ( $name, $ses ) = split (/=/, $poppair);

		  $ses=0 if (not $ses);

		  $update_tmpl .= "$name:";
		  $update_line .= "$ses:";
	 }
	 $update_tmpl=~s/:$//;
	 $update_line=~s/:$//;
	 print "rrdupdate SESSIONS.rrd --template $update_tmpl $update_line\n";
}

write_file( "SESSIONS.lastupdatetime" , $unixtime);
