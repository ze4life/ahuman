#!/bin/sh
# ASSUMPTIONS: This script assumes that names of the FX+ directories are the same as
# the TPlus skin names
# $Id: deploy-fxplus.sh,v 1.29 2008/06/04 13:06:25 kovyale Exp $

. ./common.sh
. ./env.sh

if [ ! -f "$HOME/deploy/release.jar" ]; then
    echo Could not find $HOME/deploy/release.jar >&3
    echo FX+ will not be deployed >&3
    exit 0
fi

# Move everything to the FX+ directory
DEPLOY_DIR=$HOME/fxplus/

mkdir -p $DEPLOY_DIR || exit 1

echo " Deploying fxplus" >&3
(
cd $DEPLOY_DIR || exit 1
# remove "release" symbolic link, directory... whatever...
rm -rf release
# remove the same tag release directory
test -d fxplus-$TAG && rm -rf fxplus-$TAG

jar xvf $DEPLOY_HOME/release.jar || exit 1

mv release fxplus-$TAG
# ABFX-77: support for secrets.properties for fxplus
SECRETS=""
if   [ -r "$HOME/SECRETS/fxplus/secrets.properties" ]; then
	SECRETS="-Dsecrets.properties=$HOME/SECRETS/fxplus/secrets.properties"
fi
$ANT_BIN/ant -f config.xml -Dxml_config_filename=config/$ENVIRONMENT.xml -Dsrc=fxplus-$TAG $SECRETS
)
if [ "$?" -ne "0" ] ;then
    echo "FAILED" >&3
    exit 1
fi

if [ "$REMOVE_RELEASE_TARS" = "YES" ]; then
    rm -f release.jar
fi

