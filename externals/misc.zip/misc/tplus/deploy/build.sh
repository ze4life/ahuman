#!/bin/ksh
#
# $Id: build.sh,v 1.35 2008/06/04 08:41:35 kovyale Exp $
#

# Get options. This will set up the TAG variable. See getopts.sh
. ./getopts.sh
. ./common.sh

# Overrride tag, if no use from the env.sh
if [ -n "$CHECKOUT_TAG" ]; then
    FORCE_TAG=$CHECKOUT_TAG
elif [ -n "$CHECKOUT_DATE" ]; then
    FORCE_TAG="date-$CHECKOUT_DATE"
fi

# removing stale TAGs from env.sh, saving latest one
if [ -n "$FORCE_TAG" ]; then
    grep -v "^TAG" < env.sh > env.sh.$$
    echo "TAG=$FORCE_TAG ; export TAG" >> env.sh.$$
    cat < env.sh.$$ > env.sh
    rm env.sh.$$
fi

. ./env.sh

Sendmail "$ENVIRONMENT. Starting build with the tag - $TAG" "$TAG"

for script in $BUILD_SCRIPTS
do
    echo "Running $script" >&3
    ./$script >&3
    if [ "$?" -ne "0" ]; then
        Sendfile "$script FAILED" "log/$script.current.log"
        exit 1
    fi
done
