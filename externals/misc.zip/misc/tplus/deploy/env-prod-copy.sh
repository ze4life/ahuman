# Environment file for ABFX Production Copy
#
# $Id: env-prod-copy.sh,v 1.47 2008/07/22 11:25:34 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="prod-copy"; export ENVIRONMENT
FROM="FX+ Prod Copy"; export FROM
WAR_PROFILES="\
dbag-lan \
aibk-lan \
bcvg-lan \
jybm-lan \
okoh-lan \
sabx-lan \
shin-lan \
pbzg-lan \
nbcm-lan \
bjss-lan \
jpmp-lan \
efgz-lan \
lodh-lan \
ubpg-lan \
"; export WAR_PROFILES
FXPLUS_LEVEL_1="dbag"; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="aibk bcvg jybm okoh sabx shin pbzg nbcm"; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS
CREATE_CHANNELS=NO
STOPENV_SCRIPTS="$STOPENV_SCRIPTS StopUS.sh"
STARTENV_SCRIPTS="$STARTENV_SCRIPTS StartUS.sh"
FXPLUS_US_USERHOST="abfxu3@abfxu1.us.db.com"
MIS_USERHOST="misuat1@longmgccappb1.uk.db.com"
MIS_WEBROOT="/home/misuat1/coldfusion/wwwroot"
