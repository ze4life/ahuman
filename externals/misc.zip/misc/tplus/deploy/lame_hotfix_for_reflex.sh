#!/bin/sh

. ./common.sh
. ./env.sh

if [ "$ENVIRONMENT" = "demo-uk" ]; then
    cd  $BUILD_HOME/$TAG/fxpricing &&
    cp -p ~/oracle-10-g-jars/*.jar ./thirdparty-jars/lib ||
    ( echo "ERROR: reflex libraries hot fixing failed" >&3; exit 1 )
fi
