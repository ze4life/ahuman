#!/bin/sh
#
# $Id: env.sh,v 1.7 2008/10/07 10:15:07 kovyale Exp $
#
# Nirvana environment
#
# alexey.kovyrshin@db.com

#
# ATTENTION: 
#    realm name has to be lowercase and should not contain dots ('.')
#    failing to meet this condition may cause issues 
#    with connectivity from realm manager tool
#
REALM=therealmname

ADAPTER_0=nsp://0.0.0.0:9000
#ADAPTER_1=nsps://0.0.0.0:
#ADAPTER_2=nhps://0.0.0.0:
#ADAPTER_3=nsps://0.0.0.0:

keyStore=keystore/cst-fju1.uk.db.com.jks
keyStorePassword=password

DATADIR=$APP_DIR/data
SECURITYFILE=$APP_DIR/sec_file.txt

JAVA_HOME=$HOME/java; export JAVA_HOME
JAVA=$JAVA_HOME/bin/java

PIDFILES="nirvana.pid"
START_SCRIPTS="nstart"
STOP_SCRIPTS="nstop"

#START_SCRIPTS="$START_SCRIPTS latency/start"
#STOP_SCRIPTS="$STOP_SCRIPTS latency/stop"
