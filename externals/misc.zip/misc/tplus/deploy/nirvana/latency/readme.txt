Get the jars - latencyMonitor.zip
 1 checkout the fxplus
 2 run "ant latencyMonitorCompile"

Get FXPhase2.jks
 copy from $HOME/tplus/dbag/certs

