#!/bin/sh
# $Id: common.sh,v 1.2 2006/06/23 12:57:52 kovyale Exp $
#
# Normaly you should not edit this file, edit env.sh one.
#
# Must be included in every scripts
# $Log: common.sh,v $
# Revision 1.2  2006/06/23 12:57:52  kovyale
# ABFX-716: imorted to deploy/nirvana
#

# The exit codes definition
EXIT_ERROR=101
EXIT_OK=0
## Exit code OK for veritas is 110
#EXIT_OK=110
EXIT_FAILED=100
EXIT_NOPID=109
EXIT_STOPPED=105

# Autoconfigure stuff
case `uname -s` in
   'SunOS')
      PS="/usr/ucb/ps"
      ;;
   'Linux')
      PS="/bin/ps"
      ;;
   *)
      exit ${EXIT_ERROR}
esac

USER=$LOGNAME
PROGNAME=`basename $0`

# Common functions
force_kill ()
{
	PID=$1 		# the PID of the process to kill
	PATTERN=$2	# the string in the process command line to ensure not killing wrong process

	out=`${PS} ww ${PID} | tail +2 | grep -v $0 | grep $PATTERN | grep -v grep`
	if [ -n "$out" ]; then
		kill $PID
	fi

	sleep 3 # give it a chance to exit itself

	out=`${PS} ww ${PID} | tail +2 | grep -v $0 | grep $PATTERN | grep -v grep`
	if [ -n "$out" ]; then
		# still here? go away...
		kill -9 $PID
	fi
}

rotate_logs ()
{
	LOG_DIR=$1
	test -d ${LOG_DIR}.9 && rm -rf ${LOG_DIR}.9
	for i in 8 7 6 5 4 3 2 1 0
	do
		if [ -d ${LOG_DIR}.$i ]; then
			 NEXT=`expr $i + 1`
			 mv ${LOG_DIR}.$i ${LOG_DIR}.$NEXT
		fi
	done
	mv $LOG_DIR ${LOG_DIR}.0
	mkdir $LOG_DIR
}

APP_DIR=`dirname $0`
# fixup APP_DIR
if [ "$APP_DIR" = "." ]; then
        APP_DIR=`pwd`
fi

# load process configuration file
. "$APP_DIR/env.sh" || exit ${EXIT_ERROR}

# check the do not run trigger
if [ -f "$APP_DIR/DO_NOT_RUN_PROCESS" ]; then
	if [ "$PROGNAME" != "stop" ]; then
		exit ${EXIT_STOPPED}
	else
		echo You are running $PROGNAME command while DO_NOT_RUN_PROCESS is found. The instance will not be automatically started !!!
	fi
fi
