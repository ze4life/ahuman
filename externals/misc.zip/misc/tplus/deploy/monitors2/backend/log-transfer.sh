#!/bin/sh

ENVFILE="./env.sh"

if [ -r "$ENVFILE" ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi

LOGS=`find $LOGDIR -name '*.log' -type f`

if [ -n "$LOGS" ]; then
    echo $LOGS | xargs cat | sort > $LOGDIR/transfering.$UTIME.$$
    echo $LOGS | xargs rm
    scp -C -q -o 'StrictHostKeyChecking no' $LOGDIR/transfering.$UTIME.$$ $SSH_USER@$SSH_HOST:$SSH_PATH/`hostname`.$UTIME.$$.log &&
    mv $LOGDIR/transfering.$UTIME.$$ $LOGDIR/transfered.$UTIME.$$
fi
