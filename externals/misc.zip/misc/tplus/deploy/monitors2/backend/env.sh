#!/bin/sh

APP=reflex
ENV=uat
HOST=`hostname`
PIDDIR=/export/home/reflexuat/bin/pidfiles/java

ID_TO_PID="$APP|$ENV|$HOST|BookSwitcher|$PIDDIR/BookSwitcher.pid
$APP|$ENV|$HOST|EBSLiveFeed|$PIDDIR/EBSLiveFeed.pid
$APP|$ENV|$HOST|ForwardsBridge-dBus2jms|$PIDDIR/ForwardsBridge.dBus2jms.pid
$APP|$ENV|$HOST|ForwardsBridge-jms2dBus|$PIDDIR/ForwardsBridge.jms2dBus.pid
$APP|$ENV|$HOST|ReutersBridge|$PIDDIR/ReutersBridge.pid
$APP|$ENV|$HOST|FwdConfigPub|$PIDDIR/FwdConfigPub.pid
$APP|$ENV|$HOST|ImpliedCurveCalc|$PIDDIR/ImpliedCurveCalc.pid
$APP|$ENV|$HOST|SourceSwitcher-EBS|$PIDDIR/SourceSwitcher.EBS.pid
$APP|$ENV|$HOST|LadderSwitcher|$PIDDIR/LadderSwitcher.pid
$APP|$ENV|$HOST|LogManager|$PIDDIR/LogManager.pid
$APP|$ENV|$HOST|MessageLog-ARMShade|$PIDDIR/MessageLog.ARMShade.pid
$APP|$ENV|$HOST|MessageLog-Conversation|$PIDDIR/MessageLog.Conversation.pid
$APP|$ENV|$HOST|MessageLog-ForwardConfig|$PIDDIR/MessageLog.ForwardConfig.pid
$APP|$ENV|$HOST|MessageLog-Heartbeat|$PIDDIR/MessageLog.Heartbeat.pid
$APP|$ENV|$HOST|MessageLog-InputForwardRate|$PIDDIR/MessageLog.InputForwardRate.pid
$APP|$ENV|$HOST|MessageLog-InputSpotRate-all|$PIDDIR/MessageLog.InputSpotRate.all.pid
$APP|$ENV|$HOST|MessageLog-OutputForwardRate|$PIDDIR/MessageLog.OutputForwardRate.pid
$APP|$ENV|$HOST|MessageLog-OutputSpotRate|$PIDDIR/MessageLog.OutputSpotRate.pid
$APP|$ENV|$HOST|MessageLog-RemoteControl|$PIDDIR/MessageLog.RemoteControl.pid
$APP|$ENV|$HOST|MessageLog-SpotAdminConfig|$PIDDIR/MessageLog.SpotAdminConfig.pid
$APP|$ENV|$HOST|MessageLog-Trade|$PIDDIR/MessageLog.Trade.pid
$APP|$ENV|$HOST|MessageLog-TraderCurves|$PIDDIR/MessageLog.TraderCurves.pid
$APP|$ENV|$HOST|MessageLog-UnifiedCurves|$PIDDIR/MessageLog.UnifiedCurves.pid
$APP|$ENV|$HOST|NirvSub-cme|$PIDDIR/NirvSub.cme.pid
$APP|$ENV|$HOST|NirvSub-fxplus|$PIDDIR/NirvSub.fxplus.pid
$APP|$ENV|$HOST|SourceSwitcher-Reuters|$PIDDIR/SourceSwitcher.Reuters.pid
$APP|$ENV|$HOST|PriceRequestServer|$PIDDIR/PriceRequestServer.pid
$APP|$ENV|$HOST|RatesMonitor-InputSpotRate|$PIDDIR/RatesMonitor.InputSpotRate.pid
$APP|$ENV|$HOST|RatesMonitor-OutputSpotRate|$PIDDIR/RatesMonitor.OutputSpotRate.pid
$APP|$ENV|$HOST|ReutersFwd|$PIDDIR/ReutersFwd.pid
$APP|$ENV|$HOST|SourceSwitcher-Defaults|$PIDDIR/SourceSwitcher.Defaults.pid
$APP|$ENV|$HOST|SpotAdminPublisher|$PIDDIR/SpotAdminPublisher.pid
$APP|$ENV|$HOST|SpotBridge-cme|$PIDDIR/SpotBridge.cme.pid
$APP|$ENV|$HOST|SpotBridge-$APP|$PIDDIR/SpotBridge.reflex.pid
$APP|$ENV|$HOST|SpotServer|$PIDDIR/SpotServer.pid
$APP|$ENV|$HOST|TradeBridge|$PIDDIR/TradeBridge.pid
$APP|$ENV|$HOST|TraderCurveBridge|$PIDDIR/TraderCurveBridge.pid
$APP|$ENV|$HOST|valuedate|$PIDDIR/valuedate.pid
$APP|$ENV|$HOST|JmsBridge-ARMShade-live|$PIDDIR/JmsBridge.ARMShade.live.pid"

LOGDIR=/export/home/javalib/monitor/LOG
PS=ps
UTIME=`perl -e "print time"`
LOGFILE=$LOGDIR/$TYPE.$UTIME.$$.log
HOSTNAME=`hostname`
COMPRESS=bzip2
YMD=`date +%Y%m%d`
HMS=`date +%H%M%S`
PERL=perl
SSH_USER=javalib
SSH_HOST=dnau1.uk.db.com
SSH_PATH=frontends-logs/

