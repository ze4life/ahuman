#!/bin/sh

ENVFILE=./env.sh

if [ -r "$ENVFILE" ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi

YESTERDAY=`$PERL -e '@x=localtime time-86400; printf"%4d%02d%02d.%02d%02d\n", $x[5]+1900, $x[4]+1, $x[3], $x[2], $x[1]'`
LOGS=`find $LOGDIR -type f -name 'transfered.*' -mtime +1 | sort`

if [ -n "$LOGS" ]; then
    tar -cf - $LOGS | $COMPRESS > $LOGDIR/transfered.$YESTERDAY.tar.bz2
    rm $LOGS
fi
