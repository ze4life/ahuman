#!/bin/sh

ENVFILE="./env.sh"

if [ -r "$ENVFILE" ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi

LOGS=`find $LOGDIR -name '*.log' -type f`

if [ -n "$LOGS" ]; then
    echo $LOGS | xargs cat | sort > $LOGDIR/transfering.$UTIME.$$
    echo $LOGS | xargs rm
    cat $LOGDIR/transfering.$UTIME.$$ &&
    mv $LOGDIR/transfering.$UTIME.$$ $LOGDIR/transfered.$UTIME.$$
fi
