#!/bin/sh

TYPE=$1
ENVFILE="./env.sh"

if [ -z "$TYPE"  ]; then
    echo "Usage: $0 process_property"
    echo "Example: $0 rss"
    exit 1
fi

if [ -r "$ENVFILE" ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi

for PR in $ID_TO_PID; do
    APP=`echo $PR | cut -d\| -f 1`
    ENV=`echo $PR | cut -d\| -f 2`
    HOST=`echo $PR | cut -d\| -f 3`
    PROC=`echo $PR | cut -d\| -f 4`
    PIDFILE=`echo $PR | cut -d\| -f 5`
    if [ -r "$PIDFILE" ]; then
        PID=`head -1 $PIDFILE`
        if [ -d /proc/$PID/ ]; then
            VALUE=`$PS -o $TYPE -p $PID | tail -1`
            if [ -n "$VALUE" ]; then
                echo $APP $ENV $HOST $PROC $TYPE $UTIME $VALUE >> $LOGFILE.gathering
            fi
        fi
    fi
done

if [ -r "$LOGFILE.gathering" ]; then
    mv $LOGFILE.gathering $LOGFILE
fi
