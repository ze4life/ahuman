#!/usr/bin/perl -wT

use strict;
use diagnostics;
use warnings;

our %CFG = (
  'seconds' => {
    'hour' => 3600,
    'day' => 86400,
    'week' => 604800,
    'month' => 2629746,
    'quarter' => 7889238,
    'year' => 31556952,
  },
  'timeframe' => {
    'hour' => 'start+1hour',
    'day' => 'start+1day',
    'week' => 'start+1week',
    'month' => 'start+1month',
    'quarter' => 'start+3month',
    'year' => 'start+1year',
  },
  'RrdDir' => '/export/apps/monitoring/RRD',
  'RrdTool' => '/export/home/javalib/bin/rrdtool',
  'Dot' => ' &middot; ',
  'Tab' => '&emsp;',
  'DrawScript' => 'draw.cgi',
  'Pattern' => '^[A-Za-z0-9_-]+$',
  'PageTitle' => 'Technical Support Monitoring Page',
  'EndOfHtml' => '</body></html>',
  'refresh' => {
    'several' => 60,
    'many' => 600,
  },
  'graph' => {
    'dateminw' => 800,
    'type' => {
      'several' => 'wide',
      'many' => 'narrow',
    },
    'wide' => {
      'width' => 1142,
      'widthall' => 1239,
      'height' => 194,
      'heightall' => 273,
      'step' => {
        'hour' => {
          'sec' => 60,
          'text' => '1 minute',
          'xgrid' => 'MINUTE:1:MINUTE:3:MINUTE:3:0:%H:%M',
        },
        'day' => {
          'sec' => 300,
          'text' => '5 minutes',
          'xgrid' => 'MINUTE:10:MINUTE:30:HOUR:1:0:%H:%M',
        },
        'week' => {
          'sec' => 1800,
          'text' => '30 minutes',
          'xgrid' => 'HOUR:1:HOUR:12:DAY:1:0:%d %b',
        },
        'month' => {
          'sec' => 7200,
          'text' => '2 hours',
          'xgrid' => 'HOUR:6:DAY:1:DAY:2:0:%d %b',
        },
        'quarter' => {
          'sec' => 21600,
          'text' => '6 hours',
          'xgrid' => 'DAY:1:WEEK:1:WEEK:1:0:%d %b',
        },
        'year' => {
          'sec' => 86400,
          'text' => '1 day',
          'xgrid' => 'WEEK:1:WEEK:3:WEEK:3:0:%d %b',
        },
      },
    },
    'narrow' => {
      'width' => 522,
      'widthall' => 619,
      'height' => 121,
      'heightall' => 214,
      'step' => {
        'hour' => {
          'sec' => 60,
          'text' => '1 minute',
          'xgrid' => 'MINUTE:1:MINUTE:5:MINUTE:5:0:%H:%M',
        },
        'day' => {
          'sec' => 600,
          'text' => '10 minutes',
          'xgrid' => 'MINUTE:30:HOUR:1:HOUR:3:0:%H:%M',
        },
        'week' => {
          'sec' => 3600,
          'text' => '1 hour',
          'xgrid' => 'HOUR:4:DAY:1:DAY:1:0:%d %b',
        },
        'month' => {
          'sec' => 14400,
          'text' => '4 hours',
          'xgrid' => 'DAY:1:DAY:3:DAY:3:0:%d %b',
        },
        'quarter' => {
          'sec' => 43200,
          'text' => '12 hours',
          'xgrid' => 'DAY:1:WEEK:1:WEEK:2:0:%d %b',
        },
        'year' => {
          'sec' => 172800,
          'text' => '2 days',
          'xgrid' => 'WEEK:1:MONTH:1:MONTH:1:0:%b',
        },
      },
    },
  },
  'type' => {
    'rss' => {
      'vlabel' => 'bytes',
      'base' => 1024,
      'DEF' => {
        1 => {
          'value' => 'rss',
          'ds-name' => 'rss',
          'cf' => 'AVERAGE',
        },
      },
      'CDEF' => {
        1 => {
          'value' => 'rssDraw',
          'rpnexpr' => 'rss,1024,*',
        },
      },
      'AREA' => {
        1 => {
          'value' => 'rssDraw',
          'color' => '44AA44AA',
          'legend' => 'Average Resident Set Size',
        },
      },
      'COMMENT' => {
        1 => {
          'text' => '\t\t\t\t\t\t\t',
        },
      },
      'descr' => 'memory usage',
      'minstep' => 600,
      'minsteptext' => '10 minutes',
    },
    'pcpu' => {
      'vlabel' => '%',
      'base' => 1000,
      'DEF' => {
        1 => {
          'value' => 'pcpu-max',
          'ds-name' => 'pcpu',
          'cf' => 'MAX',
        },
        2 => {
          'value' => 'pcpu-avg',
          'ds-name' => 'pcpu',
          'cf' => 'AVERAGE',
        },
      },
      'AREA' => {
        1 => {
          'value' => 'pcpu-max',
          'color' => 'FF4444FF',
          'legend' => 'Maximum Cputime/Realtime Percentage',
        },
        2 => {
          'value' => 'pcpu-avg',
          'color' => '00AA00',
          'legend' => 'Average Cputime/Realtime Percentage',
        },
      },
      'descr' => 'cpu usage',
      'minstep' => 60,
      'minsteptext' => '1 minute',
    },
  },
);
