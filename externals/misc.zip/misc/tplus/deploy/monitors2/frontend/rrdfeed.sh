#!/bin/sh

ENVFILE=./env.sh

if [ -f $ENVFILE ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi

# chech if process is not already running
if [ -r $PIDFILE ]; then
    PID=`cat $PIDFILE`
        if ps -o args -p "$PID" | tail -1 | grep rrdfeed > /dev/null; then
            if [ "$TERM" != dumb ] && [ "$TERM" ]; then
                echo "ERROR: procdump.sh is already running. PID: $PID"
            exit 1
        else
            exit 0
        fi
    fi
fi
# save PID
echo $$ > $PIDFILE

# get list of new logs
NEWLOGS=`find $LOGDIR -name '*.log' -type f | sort`

if [ ! -n "$NEWLOGS" ]; then
    # nothing to do
    exit 0
fi

# parse line-by-line of each log
for CURLOG in $NEWLOGS; do
    # rename file while processing it
    mv $CURLOG $CURLOG.inprogress$$
    if [ $? -ne 0 ]; then
        echo "WARNING: unable to rename log file $CURLOG. Skipping..."
        continue
    fi

    # parse line by line and put VALUE to appropriate RRD file
    cat $CURLOG.inprogress$$ | \
    while read LINE ; do
        # get variables from line
        LINE_LEN=`echo $LINE | wc -w`
        if [ "$LINE_LEN" -eq 8 ]; then
            APP=`echo $LINE | cut -d" " -f 1`
            ENV=`echo $LINE | cut -d" " -f 2`
            NODE=`echo $LINE | cut -d" " -f 3`
            HOST=`echo $LINE | cut -d" " -f 4`
            PROC=`echo $LINE | cut -d" " -f 5`
            TYPE=`echo $LINE | cut -d" " -f 6`
            TIME=`echo $LINE | cut -d" " -f 7`
            VALUE=`echo $LINE | cut -d" " -f 8`
        else
            APP=`echo $LINE | cut -d" " -f 1`
            ENV=`echo $LINE | cut -d" " -f 2`
            NODE=default
            HOST=`echo $LINE | cut -d" " -f 3`
            PROC=`echo $LINE | cut -d" " -f 4`
            TYPE=`echo $LINE | cut -d" " -f 5`
            TIME=`echo $LINE | cut -d" " -f 6`
            VALUE=`echo $LINE | cut -d" " -f 7`
        fi
        
        if [ -z "$VALUE" ]; then
            echo "WARNING: bogus line in $CURLOG: \"$LINE\". Skipping..."
            continue
        fi
        
        HOSTDIR=$RRDDIR/$APP/$ENV/$NODE/$HOST/
        RRDFILE=$RRDDIR/$APP/$ENV/$NODE/$HOST/$PROC-$TYPE.rrd
        HOSTDIRDEF=$RRDDIR/$APP/$ENV/default/$HOST/
        RRDFILEDEF=$RRDDIR/$APP/$ENV/default/$PROC-$TYPE.rrd
        
        # create RRD file if does not exist
        if [ ! -r "$RRDFILE"  ]; then
            if [ ! -r "$RRDFILEDEF" ]; then
                # create HOSTDIR if does not exist
                mkdir -p $HOSTDIR
                eval RRDOPT=\$RRDCREATE$TYPE
                if [ -n "$RRDOPT" ]; then
                    $RRDTOOL create $RRDFILE --start 20060101 $RRDOPT
                else
                    echo "WARNING: Data type \"$TYPE\" is unknow. Unable to create RRD file. Skipping..."
                    continue
                fi
            else
                mkdir -p $HOSTDIR
                mv $RRDFILEDEF $RRDFILE
            fi
        fi
        
        # put data to .rrd file
        $RRDUPDATE $RRDFILE $TIME:$VALUE
        done
    mv $CURLOG.inprogress$$ $CURLOG.`$CURDATE`.done
    if [ $? -ne 0 ]; then
        echo "WARNING: unable to rename log file $CURLOG.inprogress$$"
        continue
    fi
done

rm $PIDFILE
