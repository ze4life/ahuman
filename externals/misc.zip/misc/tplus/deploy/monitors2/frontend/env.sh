#!/bin/sh

PIDFILE=/var/tmp/rrdfeed.pid
LOGDIR=/export/apps/monitoring/LOG
UTIME=`perl -e "print time"`
LOGFILE=$LOGDIR/$TYPE.$UTIME.$$.log
RRDDIR=/export/apps/monitoring/RRD/
RRDCREATErss="--step 60 DS:rss:GAUGE:180:0:67108864 RRA:AVERAGE:0.5:10:157785"
RRDCREATEpcpu="--step 60 DS:pcpu:GAUGE:180:0:100 RRA:AVERAGE:0.5:1:1577848 RRA:MAX:0.5:1:1577848"
LD_LIBRARY_PATH=$HOME/bin
export LD_LIBRARY_PATH
RRDTOOL=/export/home/javalib/bin/rrdtool
RRDUPDATE=/export/home/javalib/bin/rrdupdate
CURDATE='date +%Y%m%d%H%M%S'

FETCH_HOSTS='clrtrust@longmeappu1a1-intv100.uk.db.com:31122'
