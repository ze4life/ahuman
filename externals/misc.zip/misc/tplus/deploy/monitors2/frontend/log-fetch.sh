#!/bin/sh

ENVFILE=./env.sh

if [ -r "$ENVFILE" ]; then
    . $ENVFILE
else
    echo "Unable to locate env file: $ENVFILE"
    exit 1
fi


for LINE in $FETCH_HOSTS; do
    USER=`echo $LINE | cut -d: -f 1 | cut -d@ -f 1`
    HOST=`echo $LINE | cut -d: -f 1 | cut -d@ -f 2`
    PORT=`echo $LINE | cut -d: -f 2`
    ssh -Cn -p $PORT -o 'StrictHostKeyChecking no' $USER@$HOST "cd monitor2/ && ./log-transfer-push.sh" > $HOME/frontends-logs/$HOST.$UTIME.$$.transfering
    if [ -r $HOME/frontends-logs/$HOST.$UTIME.$$.transfering ]; then
        mv $HOME/frontends-logs/$HOST.$UTIME.$$.transfering $HOME/frontends-logs/$HOST.$UTIME.$$.log
    fi
done
