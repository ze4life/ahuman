#!/bin/sh
#
# $Id: startenv.sh,v 1.25 2008/06/04 13:33:22 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# Start Layer1
startScript "$HOME/tplus/deploy/dbag/bin/chatserver.sh"
startScript "$HOME/fxplus/level_1/dbag/release/bin/dbmpProxy.sh"
if [ "$ENVIRONMENT" != "prod-uk" ] ; then
    startScript "$HOME/fxplus/level_1/dbag/release/bin/dbmpAckDistributor.sh"
fi
startScript "$HOME/tplus/deploy/dbag/bin/tserver.sh"
startScript "$HOME/tplus/deploy/dbag/bin/authserver.sh"
startScript "$HOME/fxplus/level_1/dbag/release/bin/fxplus.sh"
startScript "$HOME/fxplus/level_1/dbag/release/bin/gtbserver.sh"
startScript "$HOME/stp_fpml/level_1/dbag/release/bin/stpserver.sh"
startScript "$HOME/fxplusoptions/bin/fxopserver.sh"
# Start Layer2
for wlc in $FXPLUS_LEVEL_2; do
	 startScript "$HOME/tplus/deploy/$wlc/bin/tserver.sh"
	 startScript "$HOME/tplus/deploy/$wlc/bin/authserver.sh"
	 startScript "$HOME/fxplus/level_2/$wlc/release/bin/server.sh"
         startScript "$HOME/stp_fpml/level_2/$wlc/release/bin/stpserver.sh"
done
if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the log/startenv.sh.log.$DATE" >&3
fi
exit $E_CODE
