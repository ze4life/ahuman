#!/bin/sh
#
# $Id: transfer_files.sh,v 1.35 2008/10/13 10:50:56 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

#######################################################################################################
# Layer1 TPLUS DBAG
#######################################################################################################
if [ -n "$TPLUS_USERHOST" ]; then
    # transfer
    echo " Transferring tplus.tar to $TPLUS_USERHOST ..." >&3
    ( cd $HOME && tar cf - tplus-$TAG ) | $SSH_CMD $TPLUS_USERHOST "cat > tplus.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer tplus.tar to $TPLUS_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L1 tplus on the $TPLUS_USERHOST ..." >&3
        $SSH_CMD $TPLUS_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "tplus-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf tplus.tar
        rm tplus.tar
        test -h tplus && rm tplus
        ln -s tplus-$TAG tplus

        #remove L2s
        ( cd tplus/deploy && ls | grep -v dbag | xargs rm -rf )

        # enable scripts
        ( cd tplus/deploy/dbag/bin && chmod +x *.sh )

        # link directories
        for dir in $TPLUS_LEVEL_1
        do
           ( 
            cd tplus/deploy/\$dir
            rm -rf certs lib patches lib-nirvana
            ln -s ../../server/certs
            ln -s ../../server/lib
            ln -s ../../server/lib-nirvana
            ln -s ../../patches
           )
        done

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L1 tplus.tar to $TPLUS_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable l1 tplus
            ( cd $HOME/tplus/deploy/dbag/bin && chmod -x *.sh )
        fi
    fi
fi

#######################################################################################################
# Layer1 FXPLUS DBAG
#######################################################################################################
if [ -n "$FXPLUS_USERHOST" ]; then
    # transfer
    echo " Transferring fxplus.tar to $FXPLUS_USERHOST ..." >&3
    ( cd $HOME && tar cf - fxplus ) | $SSH_CMD $FXPLUS_USERHOST "cat > fxplus.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer fxplus.tar to $FXPLUS_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L1 fxplus on the $FXPLUS_USERHOST ..." >&3
        $SSH_CMD $FXPLUS_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "fxplus-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf fxplus.tar
        rm fxplus.tar

        # remove l2s
        rm -rf fxplus/level_2

        # link directories
        for dir in $FXPLUS_LEVEL_1
        do
           ( 
            cd fxplus/level_1/\$dir/release
            rm -rf doc lib patches lib-nirvana
            ln -s ../../../release/doc
            ln -s ../../../release/lib
            ln -s ../../../release/lib-nirvana
            ln -s ../../../release/patches
           )
        done

        # disable not required fxplus scripts
        ( cd fxplus/level_1/dbag/release/bin && chmod -x *.sh )

        # enable required fxplus scripts
        ( cd fxplus/level_1/dbag/release/bin && chmod +x server.sh ratefan.sh dedicated_ratefan.sh d2n.sh fixserver.sh currenexbridge.sh fxallmdpibridge.sh fxalltcpibridge.sh cfetsbridge.sh )

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L1 fxplus.tar to $FXPLUS_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable not required fxplus scripts
            ( cd $HOME/fxplus/level_1/dbag/release/bin && chmod -x *.sh )
            # enable require scripts
            ( cd $HOME/fxplus/level_1/dbag/release/bin && chmod +x dbmpProxy.sh emailserver.sh rmsbridge.sh gtbserver.sh )

            # fix the VT_ALIAS_NAME for abfxp2
            # on the abfxp1 abfxp3 the correct hostname is set by the fxplus/config/prod-uk.xml
            ( echo "VT_HOST_ALIAS=abfxp2.uk.db.com" > $HOME/fxplus/level_1/dbag/release/etc/dbusenv.cfg )
            if [ $? -ne 0 ]; then
                Sendmail "ERROR: Could not set VT_HOST_ALIAS" "Command failed: echo VT_HOST_ALIAS=abfxp2.uk.db.com > $HOME/fxplus/level_1/dbag/release/etc/dbusenv.cfg"
            fi
        fi
    fi
fi

#######################################################################################################
# Layer 1 STP FPML DBAG
#######################################################################################################
if [ -n "$STPFPML_USERHOST" ]; then
    # transfer
    echo " Transferring stp_fpml.tar to $STPFPML_USERHOST ..." >&3
    ( cd $HOME && tar cf - stp_fpml ) | $SSH_CMD $STPFPML_USERHOST "cat > stp_fpml.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer stp_fpml.tar to $STPFPML_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L1 stp_fpml on the $STPFPML_USERHOST ..." >&3
        $SSH_CMD $STPFPML_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "stp-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf stp_fpml.tar
        rm stp_fpml.tar

        # remove l2s
        rm -rf stp_fpml/level_2

        # link directories
        for dir in $FXPLUS_LEVEL_1
        do
           ( 
            cd stp_fpml/level_1/\$dir/release
            rm -rf keystore lib xml patches lib-nirvana
            ln -s ../../../release/keystore
            ln -s ../../../release/lib
            ln -s ../../../release/lib-nirvana
            ln -s ../../../release/xml
            ln -s ../../../release/patches
           )
        done

        # enable scripts
        ( cd stp_fpml/level_1/dbag/release/bin/ && chmod +x *.sh )

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L1 stp_fpml.tar to $STPFPML_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            ( cd $HOME/stp_fpml/level_1/dbag/release/bin/ && chmod -x *.sh )
        fi
    fi
fi


#######################################################################################################
# FXPLUSOPTIONS
#######################################################################################################
if [ -n "$FXOPLUS_USERHOST" ]; then
    # transfer
    echo " Transferring fxplusoptions.tar to $FXOPLUS_USERHOST ..." >&3
    ( cd $HOME && tar cf - fxplusoptions-$TAG ) | $SSH_CMD $FXOPLUS_USERHOST "cat > fxplusoptions.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer fxplusoptions.tar to $FXOPLUS_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying fxplusoptions on the $FXOPLUS_USERHOST ..." >&3
        $SSH_CMD $FXOPLUS_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "fxplusoptions-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf fxplusoptions.tar
        rm fxplusoptions.tar

        test -h fxplusoptions && rm fxplusoptions
        ln -s fxplusoptions-$TAG fxplusoptions

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy fxplusoptions.tar to $FXOPLUS_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            ( cd $HOME/fxplusoptions/bin/ && chmod -x *.sh )
        fi
    fi
fi

#######################################################################################################
# Layer 2 TPLUS, FXPLUS, STP_FPML
#######################################################################################################
if [ -n "$WLC_USERHOST" ]; then
    # transfer
    echo " Transferring tplus.tar to $WLC_USERHOST ..." >&3
    ( cd $HOME && tar cf - tplus-$TAG ) | $SSH_CMD $WLC_USERHOST "cat > tplus.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer tplus.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L2 tplus on the $WLC_USERHOST ..." >&3
        $SSH_CMD $WLC_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "tplus-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf tplus.tar
        rm tplus.tar
        test -h tplus && rm tplus
        ln -s tplus-$TAG tplus

        #remove L1
        ( cd tplus/deploy && rm -rf dbag )

        # enable scripts
        ( cd tplus/deploy && find . -type f -name "*.sh" | xargs chmod +x )

        # link directories
        for dir in $TPLUS_LEVEL_2
        do
           ( 
            cd tplus/deploy/\$dir
            rm -rf certs lib patches lib-nirvana
            ln -s ../../server/certs
            ln -s ../../server/lib
            ln -s ../../server/lib-nirvana
            ln -s ../../patches
           )
        done

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L2 tplus.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable l2s tplus
            ( cd $HOME/tplus/deploy && find . -type f -name "*.sh" |  grep -v "/dbag/" | xargs chmod -x )
        fi
    fi

    # transfer
    echo " Transferring fxplus.tar to $WLC_USERHOST ..." >&3
    ( cd $HOME && tar cf - fxplus ) | $SSH_CMD $WLC_USERHOST "cat > fxplus.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer fxplus.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L2 fxplus on the $WLC_USERHOST ..." >&3
        $SSH_CMD $WLC_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "fxplus-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf fxplus.tar
        rm fxplus.tar

        # remove l1
        rm -rf fxplus/level_1
        rm -rf fxplus/cfets-scs

        # link directories
        for dir in $FXPLUS_LEVEL_2
        do
           ( 
            cd fxplus/level_2/\$dir/release
            rm -rf doc lib patches lib-nirvana
            ln -s ../../../release/doc
            ln -s ../../../release/lib
            ln -s ../../../release/lib-nirvana
            ln -s ../../../release/patches
           )
        done

        # enable scripts
        ( cd fxplus/level_2/ && find . -type f -name "*.sh" | xargs chmod +x )

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L2 fxplus.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable l2s
            ( cd $HOME/fxplus/level_2/ && find . -type f -name "*.sh" | xargs chmod -x )
        fi
    fi

    # transfer
    echo " Transferring stp_fpml.tar to $WLC_USERHOST ..." >&3
    ( cd $HOME && tar cf - stp_fpml ) | $SSH_CMD $WLC_USERHOST "cat > stp_fpml.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer stp_fpml.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying L2 stp_fpml on the $WLC_USERHOST ..." >&3
        $SSH_CMD $WLC_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME -name "stp-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf stp_fpml.tar
        rm stp_fpml.tar

        # remove l1
        rm -rf stp_fpml/level_1

        # link directories
        for dir in $FXPLUS_LEVEL_2
        do
            if [ -d "stp_fpml/level_2/\$dir/release" ]; then
               ( 
                cd stp_fpml/level_2/\$dir/release
                rm -rf keystore lib xml patches lib-nirvana
                ln -s ../../../release/keystore
                ln -s ../../../release/lib
                ln -s ../../../release/lib-nirvana
                ln -s ../../../release/xml
                ln -s ../../../release/patches
               )
            fi
        done

        # enable scripts
        ( cd stp_fpml/level_2/ && find . -type f -name "*.sh" | xargs chmod +x )

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L2 stp_fpml.tar to $WLC_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable l2
            ( cd $HOME/stp_fpml/level_2/ && find . -type f -name "*.sh" | xargs chmod -x )
        fi
    fi
fi

#######################################################################################################
# Layer1 FXPLUS HUB US
#######################################################################################################
if [ -n "$FXPLUS_US_USERHOST" ]; then
    # transfer
    echo " Transferring fxplus-ushub.tar to $FXPLUS_US_USERHOST ..." >&3
    ( cd $HOME/fxplus-hub && tar chf - fxplus-hub/fxplus-$TAG ) | $SSH_CMD $FXPLUS_US_USERHOST "cat > fxplus-ushub.tar"
    if [ $? -ne 0 ]; then
        Sendfile "Failed to transfer fxplus-ushub.tar to $FXPLUS_US_USERHOST" "log/transfer_files.sh.current.log"
        E_CODE=1
    else
        # deploy
        echo " Deploying fxplus USHUB on the $FXPLUS_US_USERHOST ..." >&3
        $SSH_CMD $FXPLUS_US_USERHOST "/bin/sh -ex" <<EOF
        # this is to keep the prev release
        CURRENT_RELEASE=\`cat .CURRENT_RELEASE\`
        if [ -n "\$CURRENT_RELEASE" ]; then
            set +e
            find \$HOME/fxplus-hub/ -name "fxplus-*" -type d 2> /dev/null | grep -v \$CURRENT_RELEASE | xargs rm -rf 
            set -e
        fi

        # deploy 
        tar xf fxplus-ushub.tar
        rm fxplus-ushub.tar

        # create "release" symbolic link
        test -h fxplus-hub/release && rm fxplus-hub/release
        ln -s fxplus-$TAG fxplus-hub/release

        # fix VT_HOST_ALIAS in dbusenv.cfg
        ( echo VT_HOST_ALIAS=abfxp1.us.db.com > fxplus-hub/release/etc/dbusenv.cfg )

        # save the current tag
        echo $TAG > .CURRENT_RELEASE
EOF
        if [ $? -ne 0 ]; then
            Sendfile "Failed to deploy L1 fxplus-ushub.tar to $FXPLUS_US_USERHOST" "log/transfer_files.sh.current.log"
            E_CODE=1
        else
            # disable not required fxplus scripts
            ( cd $HOME/fxplus-hub/fxplus-hub/release/bin && chmod -x *.sh )
        fi
    fi
fi

exit $E_CODE
