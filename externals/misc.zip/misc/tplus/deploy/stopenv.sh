#!/bin/sh
#
# $Id: stopenv.sh,v 1.21 2008/05/09 11:36:30 kovyale Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# Stop Layer2
for wlc in $FXPLUS_LEVEL_2; do
	 stopScript "$HOME/tplus/deploy/$wlc/bin/tserver.sh"
	 stopScript "$HOME/tplus/deploy/$wlc/bin/authserver.sh"
	 stopScript "$HOME/fxplus/level_2/$wlc/release/bin/server.sh"
         stopScript "$HOME/stp_fpml/level_2/$wlc/release/bin/stpserver.sh"
done
# Stop Layer1
stopScript "$HOME/fxplusoptions/bin/fxopserver.sh"
stopScript "$HOME/stp_fpml/level_1/dbag/release/bin/stpserver.sh"
stopScript "$HOME/fxplus/level_1/dbag/release/bin/fxplus.sh"
stopScript "$HOME/fxplus/level_1/dbag/release/bin/gtbserver.sh"
stopScript "$HOME/tplus/deploy/dbag/bin/tserver.sh"
stopScript "$HOME/tplus/deploy/dbag/bin/authserver.sh"
stopScript "$HOME/fxplus/level_1/dbag/release/bin/dbmpAckDistributor.sh"
stopScript "$HOME/fxplus/level_1/dbag/release/bin/dbmpProxy.sh"
stopScript "$HOME/tplus/deploy/dbag/bin/chatserver.sh"
if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the log/stopenv.sh.log.$DATE" >&3
fi
exit $E_CODE
