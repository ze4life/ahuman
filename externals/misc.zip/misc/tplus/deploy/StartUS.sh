#!/bin/sh
#
# $Id: StartUS.sh,v 1.1 2008/07/02 13:14:06 schedmi Exp $
#

. ./common.sh
. ./env.sh

E_CODE=0

# change directory to $HOME
cd $HOME

echo "=== Layer 1" >&3
# Start Layer1
SSH_USERHOST="$FXPLUS_US_USERHOST"
startScript "fxplus-hub/release/bin/server-fxcm.sh"
startScript "fxplus-hub/release/bin/dedicated_ratefan.sh"
startScript "fxplus-hub/release/bin/fixserver.sh"

if [ "$E_CODE" -ne "0" ]; then
        echo "Some errors occured, please check the $HOME/deploy/log/$SCRIPT_SELF_NAME.current.log" >&3
fi
exit $E_CODE
