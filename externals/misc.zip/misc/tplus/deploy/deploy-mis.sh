#!/bin/sh
#
# $Id: deploy-mis.sh,v 1.8 2008/05/26 09:03:09 kovyale Exp $
#

. ./common.sh
. ./env.sh

if [ -z "$MIS_USERHOST" ] || [ -z "$MIS_WEBROOT" ]; then
    echo "MIS_USERHOST or MIS_WEBROOT is not defined" >&3
    echo "MIS will not be deployed" >&3
    exit 0
fi

MISTAR="coldfusion.tar"

(
if [ -n "$MIS_USERHOST" ]; then
    if [ ! -f "$MISTAR" ]; then
        echo "Error: Can not find $MISTAR" >&3
        Sendmail "MIS deploy failed" "Can not find $MISTAR"
        exit 1
    fi

    TEMPDIR=temp.`date +%Y%m%d`.$$
    $SSH_CMD $MIS_USERHOST "mkdir -p deploy/$TEMPDIR"
    if [ $? -ne 0 ]; then
        echo "Error: Remote command failed: mkdir -p deploy/$TEMPDIR" >&3
        Sendmail "MIS deploy failed" "Remote command failed: mkdir -p deploy/$TEMPDIR"
        exit 1
    fi

    cat $MISTAR | $SSH_CMD $MIS_USERHOST "cd deploy/$TEMPDIR && tar xf -"
    if [ $? -ne 0 ]; then
        echo "Error: Could not transfer $MISTAR" >&3
        Sendmail "MIS deploy failed" "Could not transfer $MISTAR"
        exit 1
    fi

    $SSH_CMD $MIS_USERHOST "/bin/sh -x" <<EOF
    if [ ! -d "$MIS_WEBROOT/mis-pre-$TAG" ]; then
        mv $MIS_WEBROOT/mis $MIS_WEBROOT/mis-pre-$TAG
    else
        rm -rf $MIS_WEBROOT/mis
    fi

    mv deploy/$TEMPDIR/mis $MIS_WEBROOT/mis || exit 1

    ( find $MIS_WEBROOT -type d -name "mis-pre-*" -mtime +14 | xargs rm -rf ) || exit 1

    ( cd $MIS_WEBROOT/mis && ln -s b2b B2B && ln -s fxmt FXMT ) || exit 1

    if [ "$ENVIRONMENT" != "prod-uk" ]; then
        (
	        cd $MIS_WEBROOT/mis
	        cp  mis_centre_main_prod_copy.cfm mis_centre_main.cfm
	        cp -p DatabaseList.cfm DatabaseListprod.cfm
        ) || exit 1
    fi

    rm -rf deploy/$TEMPDIR
EOF
    if [ $? -ne 0 ]; then
        echo "Error: MIS deployment script failed" >&3
        Sendfile "MIS deploy failed" "$CURRENT_LOG_LINK"
        exit 1
    fi
fi
)

# deploy-mis.sh must never interrupt the autodeploy.sh
# must always exit OK
exit 0
