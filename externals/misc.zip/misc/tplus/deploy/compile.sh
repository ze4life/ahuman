#!/bin/sh
#
# $Id: compile.sh,v 1.59 2008/03/26 12:59:15 gunddmi Exp $
#

. ./common.sh
. ./env.sh

(
    cd $BUILD_HOME/$TAG/tplus
    echo ' Building tplus' >&3
    date
    ${ANT_BIN}/ant -Drelease_ver=$TAG
)
    if [ "$?" -ne "0" ] ;then
        echo " FAILED" >&3
        exit 1
    fi

(
    cd $BUILD_HOME/$TAG/richclient/abrc-masterbuild
    echo ' Building richclient' >&3
    date
    ${ANT_BIN}/ant build-components -Drelease_ver=$TAG
)
    if [ "$?" -ne "0" ] ;then
        echo "FAILED" >&3
        exit 1
    fi

(
    cd $BUILD_HOME/$TAG/fxplusoptions
    echo ' Building fxplusoptions' >&3
    date
    ${ANT_BIN}/ant -Drelease_ver=$TAG -Ddeploy_ver=$TAG distribution
)
    if [ "$?" -ne "0" ] ;then
        echo "FAILED" >&3
        exit 1
    fi

    echo " Moving $BUILD_HOME/$TAG/fxplusoptions/fxo.tar to $HOME/deploy/fxo.tar" >&3
    # Move the release file to deploy dir
    mv $BUILD_HOME/$TAG/fxplusoptions/fxo.tar .
    if [ "$?" -ne "0" ] ;then
	echo "FAILED" >&3
        exit 1
    fi

    # BUG12477
    #  Building the Option Pricing Tool Installer
(
    cd $BUILD_HOME/$TAG/fxplusoptions
    echo ' Building activexInstaller' >&3
    date
    ${ANT_BIN}/ant -Dinstall.anywhere.location=${INSTALL_ANYWHERE_LOCATION} -Dinstall4j.location=${INSTALL4J_LOCATION} activexInstaller
)
    if [ "$?" -ne "0" ] ;then
        echo "FAILED" >&3
        exit 1
    fi

(
    cd $BUILD_HOME/$TAG/fxplus
    echo ' Building fxplus' >&3
    date
    ${ANT_BIN}/ant -Drelease_ver=$TAG -Ddebug=$FXPLUS_DEBUG
)
    if [ "$?" -ne "0" ] ;then
        echo "FAILED" >&3
        exit 1
    fi

    echo " Moving $BUILD_HOME/$TAG/fxplus/release.jar to $HOME/deploy/release.jar" >&3
    # Move the release file to deploy dir
    mv $BUILD_HOME/$TAG/fxplus/release.jar .
    if [ "$?" -ne "0" ] ;then
	echo "FAILED" >&3
        exit 1
    fi

	# stp compile
    if [ -f "$BUILD_HOME/$TAG/fxplus/stp/config/stp_config_$ENVIRONMENT.xml" ]; then
	    (
	     cd $BUILD_HOME/$TAG/fxplus/stp
	     echo ' Building STP ' >&3
             date
	     ${ANT_BIN}/ant -Drelease=$TAG -Drelease_ver=$TAG -Dinstall4j.location=${INSTALL4J_LOCATION}
	    )
	    if [ "$?" -ne "0" ] ;then
	    	echo "FAILED" >&3
	    	exit 1
	    fi
	# Move the release file to deploy dir
        echo " Moving $BUILD_HOME/$TAG/fxplus/stp/$TAG.jar to $HOME/deploy/stp-$TAG.jar" >&3
	    mv $BUILD_HOME/$TAG/fxplus/stp/$TAG.jar stp-$TAG.jar
	    if [ "$?" -ne "0" ] ;then
	    	echo "FAILED" >&3
	    	exit 1
	    fi
    fi
date
echo " Done. `date`" >&3
