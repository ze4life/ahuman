#!/bin/ksh
#
# $Id: deploy-stp-fix-tunnel.sh,v 1.15 2008/05/26 06:43:52 kovyale Exp $

. ./common.sh
. ./env.sh

# remove old 
rm stpfix-*.sh

if [ "$ENVIRONMENT" = "external-uat1" ]; then

    ./wcd/createbatch.sh \
        wcd/webenv-external-uat1-lon-l1.sh \
        wcd/stpfix.sh \
        $HOME/stp_fpml/level_1/dbag/tunnels/internet.tar

    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create stpfix self-installer for wcd/webenv-external-uat1-lon-l1.sh" >&3
        Sendfile "Could not create stpfix self-installer for wcd/webenv-external-uat1-lon-l1.sh" "log/createpatch.sh.current.log"
    fi

fi

if [ "$ENVIRONMENT" = "prod-uk" ]; then

    ./wcd/createbatch.sh wcd/webenv-prod-uk-vpn-l1.sh wcd/stpfix.sh $HOME/stp_fpml/level_1/dbag/tunnels/vpn.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi

    ./wcd/createbatch.sh wcd/webenv-prod-uk-tpint-longmeappp22.sh wcd/stpfix.sh $HOME/stp_fpml/level_1/dbag/tunnels/internet.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi

    ./wcd/createbatch.sh wcd/webenv-prod-uk-vdr-l1.sh wcd/stpfix.sh $HOME/stp_fpml/level_1/dbag/tunnels/vpn-dr.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi

    ./wcd/createbatch.sh wcd/webenv-prod-uk-tpint-longmeappp25.sh wcd/stpfix.sh $HOME/stp_fpml/level_1/dbag/tunnels/internet-dr.tar
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not create self-installer" >&3
        Sendfile "Could not create self-installer" "log/createbatch.sh.current.log"
    fi
fi

# check if there is any stpfix-*.sh selfinstaller
if [ -n "`ls stpfix-*.sh`" ]; then
    ./wcd/applybatches.sh stpfix-*.sh
    if [ "$?" -ne "0" ]; then
        echo "Warning: Could not apply some stpfix self-installers" >&3
        Sendfile "Could not apply some stpfix self-installers" "log/applybatches.sh.current.log"
    else
        rm stpfix-*.sh
    fi
fi

# never interrupt the autodeploy.sh only warng with email
exit 0
