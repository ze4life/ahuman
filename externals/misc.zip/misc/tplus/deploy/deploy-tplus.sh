#!/bin/sh
# $Id: deploy-tplus.sh,v 1.43 2008/06/04 13:06:25 kovyale Exp $

. ./common.sh
. ./env.sh

if [ ! -f "$HOME/deploy/tplus.tar" ]; then
    echo Could not find $HOME/deploy/tplus.tar >&3
    echo T+ will not be deployed >&3
    exit 0
fi

DEPLOY_DIR=$HOME/tplus-$TAG

rm -rf "$DEPLOY_DIR"
mkdir -p $DEPLOY_DIR || exit 1

(
cd $DEPLOY_DIR || exit 1

tar xvf $DEPLOY_HOME/tplus.tar || exit 1

# ABFX-77: copy certs
if [ -r "$HOME/SECRETS/certs/tplus" ]; then
	 cp -rp $HOME/SECRETS/certs/tplus/* $DEPLOY_DIR/server/certs/
fi
for NODE in $TPLUS_LAYERS
do

	 # ABFX-77: support for secrets.properties for tplus
	 SECRETS=""
	 if   [ -r "$HOME/SECRETS/tplus/$NODE.secrets.properties" ]; then
		  SECRETS="-Dsecrets.properties=$HOME/SECRETS/tplus/$NODE.secrets.properties"
	 fi

	 # we use hardcoded -Dserver_build=true, we do not need to build wars here!
	 cmd="$ANT_BIN/ant -Dprofile=abfx-$ENVIRONMENT/$NODE -Dskin=$NODE -Dserver_build=true $SECRETS generic"
         echo " Deploying tplus for $NODE" >&3
	 $cmd
	 if [ "$?" -ne "0" ] ;then
		  echo "FAILED" >&3
		  exit 1
	 fi
done

#
# we build ONLY wars here
#
for PROFILE in $WAR_PROFILES
do
	 # here is how we determine the skin name from PROFILE variable which looks like dbag-lan, bcvg-lon, jybm-vpn, etc...
	 SKIN=`echo $PROFILE | cut -d- -f 1`

	 # small hack for DBSW
	 if [ "$SKIN" = "dbsw" ]; then
		  SKIN=dbag
	 fi

	 # -Dprofile        - the file name of profile located in tplus/profiles directory
	 # -Dprofile.config - the same as above btu from tplus/directory (don't bite me i did not write config.xml :-)
	 # -Dskin           - skin name in tplus/war/skin
	 # -Dnode           - node name, the name will be used for tplus-$node.war, also for directory tplus/web-content/$node
	 #                    as temporary directory for war building, should be somethign like dbag-lan, dbag-lon, etc...
	 # FIXME: this should be fixed in the future, it looks crappy.

	 cmd="$ANT_BIN/ant -Dprofile=abfx-$ENVIRONMENT/$PROFILE -Dprofile.config=profiles/abfx-$ENVIRONMENT/$PROFILE.properties -Dskin=$SKIN -Dnode=$PROFILE war-config"
         echo " Creating tplus-$PROFILE.war" >&3
	 $cmd
	 if [ "$?" -ne "0" ] ;then
		  echo "FAILED" >&3
		  exit 1
	 fi
done

# move richclient war from ~/tplus/war/lib/richclient-dbag-lan.war
# ~/tplus/deploy/web-content/richclient-dbag.war
# safety check of web_content directory
webcont_dir="deploy/web-content"
test -d $webcont_dir || mkdir -p $webcont_dir

# Loop through all web profiles and move richclient
# to deploy/web_content directory
for PROFILE in $WAR_PROFILES
do
	 SKIN=`echo $PROFILE | cut -d- -f 1`
	 mv war/lib/richclient-$PROFILE.war $webcont_dir/
done

# Remove and recreate the symbolic link
rm -f $HOME/tplus
ln -s $HOME/tplus-$TAG $HOME/tplus
if [ $? -ne 0 ]
then
	 echo " Error creating link from $HOME/tplus -> $HOME/$TPLUS_DEPLOY_DIR" >&3
	 exit 1
fi

)

if [ "$REMOVE_RELEASE_TARS" = "YES" ]; then
    rm -f tplus.tar 
fi
