#!/bin/sh
# $Id: deploy-fxplus-ushub.sh,v 1.4 2008/10/01 10:05:44 kusuale Exp $
# ASSUMPTIONS: This script assumes that names of the FX+ directories are the same as
# the TPlus skin names

. ./common.sh
. ./env.sh

if  [ "$ENVIRONMENT" != "prod-uk" ] && \
    [ "$ENVIRONMENT" != "external-uat1" ] && \
    [ "$ENVIRONMENT" != "prod-copy" ] && \
    [ "$ENVIRONMENT" != "daily-build2" ] && \
    [ "$ENVIRONMENT" != "moscow-build3" ]
then
    exit 0
fi

if [ ! -d "$HOME/fxplus/fxplus-$TAG/bin" ]; then
    echo Could not find $HOME/fxplus/fxplus-$TAG/bin directory. >&3
    echo "Forgot to run deploy-fxplus.sh first ?" >&3
    exit 1
fi

# Move everything to the FX+ directory
DEPLOY_DIR=$HOME/fxplus-hub/

mkdir -p $DEPLOY_DIR || exit 1

echo " Deploying fxplus-hub" >&3
(
cd $HOME/fxplus || exit 1
SECRETS=""
if   [ -r "$HOME/SECRETS/fxplus/secrets.properties" ]; then
	SECRETS="-Dsecrets.properties=$HOME/SECRETS/fxplus/secrets.properties"
fi

if [ "$ENVIRONMENT" = "prod-uk" ]
then
  $ANT_BIN/ant -f config.xml -Dxml_config_filename=config/prod-us.xml -Dsrc=fxplus-$TAG -Dtarget=$DEPLOY_DIR $SECRETS
else
  $ANT_BIN/ant -f config.xml -Dxml_config_filename=config/$ENVIRONMENT-us.xml -Dsrc=fxplus-$TAG -Dtarget=$DEPLOY_DIR $SECRETS
fi

)
if [ "$?" -ne "0" ] ;then
    echo "FAILED" >&3
    exit 1
fi
