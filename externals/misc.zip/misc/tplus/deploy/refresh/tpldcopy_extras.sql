
set feed off

prompt set the global_name
ALTER DATABASE RENAME GLOBAL_NAME TO TPLDCOPY;

prompt set passwords to desired values...
alter user  FXP2AIBK                       identified by tpldcopy;
alter user  FXP2AIBK_AP                    identified by tpldcopy;
alter user  FXP2AIBK_RO                    identified by tpldcopy;
alter user  FXP2BCVG                       identified by tpldcopy;
alter user  FXP2BCVG_AP                    identified by tpldcopy;
alter user  FXP2BCVG_RO                    identified by tpldcopy;
alter user  FXP2BDGO                       identified by tpldcopy;
alter user  FXP2BDGO_AP                    identified by tpldcopy;
alter user  FXP2BDGO_RO                    identified by tpldcopy;
alter user  FXP2JYBM                       identified by tpldcopy;
alter user  FXP2JYBM_AP                    identified by tpldcopy;
alter user  FXP2JYBM_RO                    identified by tpldcopy;
alter user  FXP2OKOH                       identified by tpldcopy;
alter user  FXP2OKOH_AP                    identified by tpldcopy;
alter user  FXP2OKOH_RO                    identified by tpldcopy;
alter user  FXP2SABX                       identified by tpldcopy;
alter user  FXP2SABX_AP                    identified by tpldcopy;
alter user  FXP2SABX_RO                    identified by tpldcopy;
alter user  FXP2GKGO                       identified by tpldcopy;
alter user  FXP2GKGO_AP                    identified by tpldcopy;
alter user  FXP2GKGO_RO                    identified by tpldcopy;
alter user  FXP2SHIN                       identified by tpldcopy;
alter user  FXP2SHIN_AP                    identified by tpldcopy;
alter user  FXP2SHIN_RO                    identified by tpldcopy;
alter user  FXP2ESHK                       identified by tpldcopy;
alter user  FXP2ESHK_AP                    identified by tpldcopy;
alter user  FXP2ESHK_RO                    identified by tpldcopy;
alter user  FXP2PBZG                       identified by tpldcopy;
alter user  FXP2PBZG_AP                    identified by tpldcopy;
alter user  FXP2PBZG_RO                    identified by tpldcopy;
alter user  FXP2REFX                       identified by tpldcopy;
alter user  FXP2REFX_AP                    identified by tpldcopy;
alter user  FXP2REFX_RO                    identified by tpldcopy;
alter user  FXP2MANF                       identified by tpldcopy;
alter user  FXP2MANF_AP                    identified by tpldcopy;
alter user  FXP2MANF_RO                    identified by tpldcopy;

alter user  TP2AIBK                        identified by tpldcopy;
alter user  TP2AIBK_AP                     identified by tpldcopy;
alter user  TP2AIBK_RO                     identified by tpldcopy;
alter user  TP2BCVG                        identified by tpldcopy;
alter user  TP2BCVG_AP                     identified by tpldcopy;
alter user  TP2BCVG_RO                     identified by tpldcopy;
alter user  TP2BDGO                        identified by tpldcopy;
alter user  TP2BDGO_AP                     identified by tpldcopy;
alter user  TP2BDGO_RO                     identified by tpldcopy;
alter user  TP2JYBM                        identified by tpldcopy;
alter user  TP2JYBM_AP                     identified by tpldcopy;
alter user  TP2JYBM_RO                     identified by tpldcopy;
alter user  TP2OKOH                        identified by tpldcopy;
alter user  TP2OKOH_AP                     identified by tpldcopy;
alter user  TP2OKOH_RO                     identified by tpldcopy;
alter user  TP2SABX                        identified by tpldcopy;
alter user  TP2SABX_AP                     identified by tpldcopy;
alter user  TP2SABX_RO                     identified by tpldcopy;
alter user  FXP1DBAG                       identified by tpldcopy;
alter user  FXP1DBAG_AP                    identified by tpldcopy;
alter user  FXP1DBAG_RO                    identified by tpldcopy;
alter user  TP1DBAG                        identified by tpldcopy;
alter user  TP1DBAG_AP                     identified by tpldcopy;
alter user  TP1DBAG_RO                     identified by tpldcopy;
alter user  TP2GKGO                        identified by tpldcopy;
alter user  TP2GKGO_AP                     identified by tpldcopy;
alter user  TP2GKGO_RO                     identified by tpldcopy;
alter user  TP2SHIN                        identified by tpldcopy;
alter user  TP2SHIN_AP                     identified by tpldcopy;
alter user  TP2SHIN_RO                     identified by tpldcopy;
alter user  TP2ESHK                        identified by tpldcopy;
alter user  TP2ESHK_AP                     identified by tpldcopy;
alter user  TP2ESHK_RO                     identified by tpldcopy;
alter user  TP2PBZG                       identified by tpldcopy;
alter user  TP2PBZG_AP                    identified by tpldcopy;
alter user  TP2PBZG_RO                    identified by tpldcopy;
alter user  TP2REFX                       identified by tpldcopy;
alter user  TP2REFX_AP                    identified by tpldcopy;
alter user  TP2REFX_RO                    identified by tpldcopy;
alter user  TP2MANF                       identified by tpldcopy;
alter user  TP2MANF_AP                    identified by tpldcopy;
alter user  TP2MANF_RO                    identified by tpldcopy;

prompt Enable the admin users if disabled.

update tp1dbag.tplus_users set enabled = 'Y' where user_id = 'DBAG.ADMIN' and enabled = 'N';
update tp2aibk.tplus_users set enabled = 'Y' where user_id = 'AIBK.ADMIN' and enabled = 'N';
update tp2jybm.tplus_users set enabled = 'Y' where user_id = 'JYBM.ADMIN' and enabled = 'N';
update tp2sabx.tplus_users set enabled = 'Y' where user_id = 'SABX.ADMIN' and enabled = 'N';
update tp2bdgo.tplus_users set enabled = 'Y' where user_id = 'BDGO.ADMIN' and enabled = 'N';
update tp2bcvg.tplus_users set enabled = 'Y' where user_id = 'BCVG.ADMIN' and enabled = 'N';
update tp2okoh.tplus_users set enabled = 'Y' where user_id = 'OKOH.ADMIN' and enabled = 'N';
update tp2gkgo.tplus_users set enabled = 'Y' where user_id = 'GKGO.ADMIN' and enabled = 'N';
update tp2shin.tplus_users set enabled = 'Y' where user_id = 'SHIN.ADMIN' and enabled = 'N';
update tp2eshk.tplus_users set enabled = 'Y' where user_id = 'ESHK.ADMIN' and enabled = 'N';
update tp2pbzg.tplus_users set enabled = 'Y' where user_id = 'PBZG.ADMIN' and enabled = 'N';
update tp2refx.tplus_users set enabled = 'Y' where user_id = 'REFX.ADMIN' and enabled = 'N';
update tp2manf.tplus_users set enabled = 'Y' where user_id = 'MANF.ADMIN' and enabled = 'N';


update tp1dbag.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2aibk.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2jybm.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2sabx.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2bdgo.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2bcvg.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2okoh.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2gkgo.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2shin.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2eshk.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2pbzg.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2refx.tplus_users set email_address = 'gmebuild@list.db.com' ;
update tp2manf.tplus_users set email_address = 'gmebuild@list.db.com' ;

prompt granting extra privs for support purposes.
grant select_catalog_role to fxp1dbag;
grant select_catalog_role to fxp2jybm;
grant select_catalog_role to fxp2aibk;
grant select_catalog_role to fxp2sabx;
grant select_catalog_role to fxp2bdgo;
grant select_catalog_role to fxp2bcvg;
grant select_catalog_role to fxp2okoh;
grant select_catalog_role to fxp2gkgo;
grant select_catalog_role to fxp2shin;
grant select_catalog_role to fxp2eshk;
grant select_catalog_role to fxp2pbzg;
grant select_catalog_role to fxp2refx;
grant select_catalog_role to fxp2manf;

grant select_catalog_role to tp1dbag;
grant select_catalog_role to tp2jybm;
grant select_catalog_role to tp2aibk;
grant select_catalog_role to tp2sabx;
grant select_catalog_role to tp2bdgo;
grant select_catalog_role to tp2bcvg;
grant select_catalog_role to tp2okoh;
grant select_catalog_role to tp2gkgo;
grant select_catalog_role to tp2shin;
grant select_catalog_role to tp2eshk;
grant select_catalog_role to tp2pbzg;
grant select_catalog_role to tp2refx;
grant select_catalog_role to tp2manf;

grant alter system to tp1dbag;
grant alter system to tp2jybm;
grant alter system to tp2aibk;
grant alter system to tp2sabx;
grant alter system to tp2bdgo;
grant alter system to tp2bcvg;
grant alter system to tp2okoh;
grant alter system to tp2gkgo;
grant alter system to tp2shin;
grant alter system to tp2eshk;
grant alter system to tp2pbzg;
grant alter system to tp2refx;
grant alter system to tp2manf;

grant alter system to fxp1dbag;
grant alter system to fxp2jybm;
grant alter system to fxp2aibk;
grant alter system to fxp2sabx;
grant alter system to fxp2bdgo;
grant alter system to fxp2bcvg;
grant alter system to fxp2okoh;
grant alter system to fxp2gkgo;
grant alter system to fxp2shin;
grant alter system to fxp2pbzg;
grant alter system to fxp2refx;
grant alter system to fxp2manf;

grant dba to guesho identified by bubbles;

grant select on v_$database to public;
grant select on v_$instance to public;

rem prompt Add dblink to uat for derek moore
rem create public database link UAT_MIS
rem connect to B2B_MIS_UAT identified by B2B_MIS
rem using '(DESCRIPTION = (ADDRESS =(PROTOCOL = TCP)(HOST = longmfxf02u1b1.uk.db.com)(PORT = 1524))(CONNECT_DATA = (SID = VBMISU1)))';

prompt Reset reconciliation schema from production
alter user fxprecon identified by tpldcopy;

connect fxp1dbag/tpldcopy
drop database link RMS_DB_LINK;
create database link RMS_DB_LINK connect to fxplus_to_rms identified by fxplus_to_rmsrmsdev5 using 'RMSDEV5';



