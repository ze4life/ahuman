PROMPT No read only ts

