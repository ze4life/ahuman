STARTUP NOMOUNT
CREATE CONTROLFILE REUSE SET DATABASE "TPLDCOPY" RESETLOGS NOARCHIVELOG
 MAXLOGFILES 16
    MAXLOGMEMBERS 2
    MAXDATAFILES 1024
    MAXINSTANCES 1
    MAXLOGHISTORY 453
LOGFILE
  GROUP 1 (
    '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo01_a.dbf'
  ) SIZE 10M,
  GROUP 2 (
    '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo02_a.dbf'
  ) SIZE 10M,
  GROUP 3 (
    '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo03_a.dbf'
  ) SIZE 10M
DATAFILE
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_system01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_undotbs01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_audits_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_data01_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataaibk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datadbag_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datajybm_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datasabx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_index01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexaibk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexdbag_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexjybm_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexsabx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_users_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_tools_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_databcvg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexbcvg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_databdgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexbdgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_undotbs01_02.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataokoh_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexokoh_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datagkgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexgkgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datashin_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexshin_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataeshk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexeshk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datapbzg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexpbzg_01.dbf'
CHARACTER SET WE8ISO8859P1
;


