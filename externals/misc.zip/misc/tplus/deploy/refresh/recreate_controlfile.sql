STARTUP NOMOUNT pfile=/data/oracle/TPLDCOPY/admin/pfile/initTPLDCOPY.ora
CREATE CONTROLFILE REUSE SET DATABASE "TPLDCOPY" RESETLOGS  NOARCHIVELOG
--  SET STANDBY TO MAXIMIZE PERFORMANCE
    MAXLOGFILES 5
    MAXLOGMEMBERS 3
    MAXDATAFILES 100
    MAXINSTANCES 1
    MAXLOGHISTORY 1815
LOGFILE
  GROUP 1 '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo01a.dbf'  SIZE 10M,
  GROUP 2 '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo02a.dbf'  SIZE 10M,
  GROUP 3 '/data/oracle/TPLDCOPY/data01/TPLDCOPY_redo03a.dbf'  SIZE 10M
-- STANDBY LOGFILE
DATAFILE
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_system01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_undotbs01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_audits_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_data01_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataaibk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datadbag_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datajybm_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datasabx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_index01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexaibk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexdbag_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexjybm_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexsabx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_users_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_tools_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_databcvg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexbcvg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_databdgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexbdgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_undotbs01_02.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataokoh_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexokoh_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datagkgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexgkgo_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datashin_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexshin_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_dataeshk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexeshk_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datapbzg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexpbzg_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datadbag_02.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datarefx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexrefx_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datadbag_03.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_datamanf_01.dbf',
  '/data/oracle/TPLDCOPY/data01/TPLDCOPY_indexmanf_01.dbf'
CHARACTER SET WE8ISO8859P1
;
