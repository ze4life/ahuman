# Environment file for DailyBuild9 - External Options
#
# $Id: env-options.sh,v 1.21 2008/07/14 15:14:32 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="options";export ENVIRONMENT
FROM="FX+ Options"; export FROM
TPLUS_LAYERS="dbag"; export TPLUS_LAYERS
WAR_PROFILES="dbag-lan"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag
FXPLUS_LEVEL_2=""; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1="dbag"
TPLUS_LEVEL_2=""; export TPLUS_LEVEL_2
FXPLUS_DEBUG=on
