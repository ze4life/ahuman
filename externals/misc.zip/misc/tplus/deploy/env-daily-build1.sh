#
# $Id: env-daily-build1.sh,v 1.29 2008/07/14 15:14:32 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="daily-build1";export ENVIRONMENT
FROM="FX+ Daily Build 1"; export FROM
TPLUS_LAYERS="dbag jybm aibk"; export TPLUS_LAYERS
WAR_PROFILES="dbag-lan asia-lan jybm-lan aibk-lan"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag
FXPLUS_LEVEL_2="jybm aibk" ; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=dbag
TPLUS_LEVEL_2="jybm aibk"
FXPLUS_DEBUG=on
MIS_USERHOST="tplu5@longmgccappb1.uk.db.com"
MIS_WEBROOT="/home/tplu5/jrun4/servers/cfusion/cfusion-ear/cfusion-war"
