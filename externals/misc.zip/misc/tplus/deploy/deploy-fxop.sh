#!/bin/sh

. ./common.sh
. ./env.sh

if [ ! -f "$HOME/deploy/fxo.tar" ]; then
    echo Could not find $HOME/deploy/fxo.tar >&3
    echo FXO+ will not be deployed >&3
    exit 0
fi

DEPLOY_DIR=$HOME/fxplusoptions-$TAG

rm -rf $DEPLOY_DIR
mkdir -p $DEPLOY_DIR || exit 1

echo " Deploying fxplusoptions" >&3
(
cd $DEPLOY_DIR || exit 1
tar xvf $DEPLOY_HOME/fxo.tar

# ABFX-77: support for secrets.properties for fxplusoptions
SECRETS=""
if [ -r "$HOME/SECRETS/fxplusoptions/secrets.properties" ]; then
   SECRETS="-Dsecrets.properties=$HOME/SECRETS/fxplusoptions/secrets.properties"
fi
# ABFX-77: copy certs
if [ -r "$HOME/SECRETS/certs/fxplusoptions" ]; then
        cp -rp $HOME/SECRETS/certs/fxplusoptions/* $DEPLOY_DIR/certs/
fi
$ANT_BIN/ant -Dprofile=$ENVIRONMENT $SECRETS deploy
)
if [ "$?" -ne "0" ]; then
    echo "FAILED" >&3
    exit 1
fi

# Remove and recreate the symbolic link
rm -f $HOME/fxplusoptions
ln -s $HOME/fxplusoptions-$TAG $HOME/fxplusoptions
if [ "$?" -ne "0" ]; then
    echo " Error creating link from $HOME/fxplusoptions -> $HOME/fxplusoptions-$TAG" >&3
    exit 1
fi

if [ "$REMOVE_RELEASE_TARS" = "YES" ]; then
    # cleanup build files for non PROD-like envs.
    rm -f fxo.tar 
fi

