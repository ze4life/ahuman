#!/bin/sh
#
# $Id: common.sh,v 1.70.2.2 2008/12/16 14:32:36 kovyale Exp $
#


CURRENT_DIR=`pwd`
START_DATETIME=`date +"%Y%m%d%H%M"`
DATE=`date +"%Y.%m.%d.%H.%M.%S"`

# setup loggin
mkdir -p $CURRENT_DIR/log

# script name
SCRIPT_SELF_NAME=`basename $0`
CURRENT_LOG_LINK="$CURRENT_DIR/log/$SCRIPT_SELF_NAME.current.log"

# make easy to find current logs
rm $CURRENT_LOG_LINK 2>/dev/null
ln -s $CURRENT_DIR/log/$SCRIPT_SELF_NAME.log.$DATE $CURRENT_LOG_LINK
# As stdout, stderr will be redirected to file,
# you may echo some information using fd 3,
# foe example: 'echo "READ THIS" >&3'
exec 3>&1
exec 1>> $CURRENT_DIR/log/$SCRIPT_SELF_NAME.log.$DATE 2>&1
echo "$SCRIPT_SELF_NAME started. `date`" >&3

# more verbose
set -x

# renice self
renice +19 $$

# get the list of email right after the cvs update
MAILTO="`cat autodeploy.mailto`"

# some sendmail functions
Sendmail () {
    subj=$1
    shift

    echo "$subj $*" >&3

    (
    if [ -n "$FROM" ]; then
        echo "From: $FROM <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    elif [ -n "$ENVIRONMENT" ]; then
        echo "From: $ENVIRONMENT <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    fi
     echo "Subject: AUTODEPLOY $SCRIPT_SELF_NAME $subj"
     echo
     echo "$*" 
    ) | /usr/lib/sendmail $MAILTO
}

Sendfile () {
   subj=$1
    shift
    files=$*

    echo "$subj" >&3

    (
    if [ -n "$FROM" ]; then
        echo "From: $FROM <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    elif [ -n "$ENVIRONMENT" ]; then
        echo "From: $ENVIRONMENT <$LOGNAME.$HOSTNAME@discard.mail.db.com>"
    fi
     echo "Subject: AUTODEPLOY $SCRIPT_SELF_NAME $subj"
     echo
     cat $files | sed -e "s/^\./#./"
    ) | /usr/lib/sendmail $MAILTO
}

statsScript() {
    script=$1
    script_dir=`dirname $script`
    script_name=`basename $script`
    if [ -n "$SSH_USERHOST" ]; then
        $SSH_CMD $SSH_USERHOST "/bin/sh -ex" >&3 <<EOF
        PATH=\$HOME/bin:\$PATH
        export PATH
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name stats > /dev/null )
            else
                exit 3
            fi
        else
            exit 2
        fi
EOF
    else
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name stats > /dev/null ) >&3
            else
                ( exit 3 )
            fi
        else
            ( exit 2 )
        fi
    fi
    case $? in 
        0)
            echo "UP $SSH_USERHOST $script" >&3
            return 0
        ;;
        1)
            echo "[1mDOWN $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        2)
            echo "[1mNOT FOUND $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        3)
            echo "Disabled $SSH_USERHOST $script" >&3
            return 0
        ;;
    esac
}
startScript() {
    script=$1
    script_dir=`dirname $script`
    script_name=`basename $script`
    if [ -n "$SSH_USERHOST" ]; then
        $SSH_CMD $SSH_USERHOST "/bin/sh -ex" >&3 <<EOF
        PATH=\$HOME/bin:\$PATH
        export PATH
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name start > /dev/null )
            else
                exit 3
            fi
        else
            exit 2
        fi
EOF
    else
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name start > /dev/null ) >&3
            else
                ( exit 3 )
            fi
        else
            ( exit 2 )
        fi
    fi
    case $? in 
        0)
            echo "OK STARTED $SSH_USERHOST $script" >&3
            return 0
        ;;
        1)
            echo "[1mFAILED TO START $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        2)
            echo "[1mNOT FOUND $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        3)
            echo "Disabled $SSH_USERHOST $script" >&3
            return 0
        ;;
    esac
}
stopScript() {
    script=$1
    script_dir=`dirname $script`
    script_name=`basename $script`
    if [ -n "$SSH_USERHOST" ]; then
        $SSH_CMD $SSH_USERHOST "/bin/sh -ex" >&3 <<EOF
        PATH=\$HOME/bin:\$PATH
        export PATH
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name stop > /dev/null )
            else
                exit 3
            fi
        else
            exit 2
        fi
EOF
    else
        if [ -f "$script" ]; then
            if [ -x "$script" ]; then
                ( cd "$script_dir"  && ./$script_name stop > /dev/null ) >&3
            else
                ( exit 3 )
            fi
        else
            ( exit 2 )
        fi
    fi
    case $? in 
        0)
            echo "OK STOPPED $SSH_USERHOST $script" >&3
            return 0
        ;;
        1)
            echo "[1mFAILED TO STOP $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        2)
            echo "[1mNOT FOUND $SSH_USERHOST $script[m" >&3
            E_CODE=1
            return 1
        ;;
        3)
            echo "Disabled $SSH_USERHOST $script" >&3
            return 0
        ;;
    esac
}

# Common variables
BUILD_HOME="$HOME/build";export BUILD_HOME
DEPLOY_HOME="$HOME/deploy";export DEPLOY_HOME
INSTALL4J_LOCATION=$HOME/install4j ; export INSTALL4J_LOCATION
TPLUS_DEFAULT_TPLUSJAR_KEYSTORE=$HOME/certs/generic.jks
TPLUS_DEFAULT_TPLUSJAR_STOREPASS="password"
TPLUS_DEFAULT_TPLUSJAR_ALIAS="mykey"
JAVA_HOME="$HOME/java"; export JAVA_HOME
JAVA14_HOME="$HOME/java14"; export JAVA14_HOME
ANT_BIN="$HOME/ant/bin";export ANT_BIN
ANT_OPTS="-Xmx512m"; export ANT_OPTS
CVSROOT=":pserver:fxplusAutoBuild@gmcvsd1.uk.db.com:2401/export/home/cvs/CVS/FX";export CVSROOT
FXPLUS_DEBUG=no

# How we ssh connections
SSH_CMD="ssh -oPasswordAuthentication=no -oUserKnownHostsFile=/dev/null \
-oStrictHostKeyChecking=no -oCompression=yes -oCompressionLevel=6"

# set locale, ant will break some symbols
LC_ALL="en_GB"; export LC_ALL

# Start the environment after the autodeploy ?
START_AFTER_AUTODEPLOY=YES

# Create channels during autodeploy?
CREATE_CHANNELS=YES

# Remove the huge release tars and jars ?
REMOVE_RELEASE_TARS=YES

# Keep prev rlease (2 weeks logs) ?
KEEP_PREV_RELEASE=NO

# Keep the $HOME/build/* files ?
KEEP_BUILD_FILES=NO

# Signing jars takes a lot of CPU
SIGN_RICHCLIENT_JARS=NO

# Define the user@host for the T+ FX+ FXO+ WLC STPFPML
# The transfer_files.sh will copy over ssh the give module to the target host
TPLUS_USERHOST=""
FXPLUS_USERHOST=""
FXOPLUS_USERHOST=""
STPFPML_USERHOST=""
WLC_USERHOST=""
CFETS_SCS_USERHOST=""
FXPLUS_US_USERHOST=""
MIS_USERHOST=""
MIS_WEBROOT=""

CVS_MODULES="tplus richclient tplus-common-jars fxplusoptions fxplus coldfusion/wwwroot/mis"
BUILD_SCRIPTS="test-build-env.sh checkout.sh test-profiles.sh compile.sh rmi-jmx-jars.sh
               richclientwar.sh mktplustar.sh mkcoldfusiontar.sh"
DEPLOY_SCRIPTS="clear-prev-release-files.sh 
                deploy-tplus.sh deploy-fxplus.sh deploy-fxop.sh deploy-stp.sh deploy-fxplus-ushub.sh 
                deploy-web.sh deploy-mis.sh deploy-rmi-jmx.sh 
                deploy-stp-fix-tunnel.sh deploy-iapi-fix-tunnel.sh
                deploy-database.sh createchannels-stp.sh createchannels.sh"

STOPENV_SCRIPTS="stopenv.sh"
STARTENV_SCRIPTS="startenv.sh"

