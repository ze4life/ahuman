ENVIRONMENT="demo-us"
ANT_BIN=$HOME/ant/bin
CVS_MODULES="fxpricing"
BUILD_SCRIPTS="checkout.sh compile-reflex.sh mk-reflex-redist-tar.sh"
DEPLOY_SCRIPTS="deploy-reflex-backend.sh"
# createchannels-reflex.sh"
REALMS=""
STOPENV_SCRIPTS="stopenv-reflex.sh"
STARTENV_SCRIPTS="startenv-reflex.sh"
CVSROOT=":pserver:tsarvi@fxcvs.uk.db.com:/cvs/archive"; export CVSROOT
JAVA_HOME=$HOME/java
JAVA14_HOME=$HOME/java
export TAG
TAG=fxpricing-prod-8-3-rc20 ; export TAG
