#!/bin/sh
#
# $Id: startenv-reflex.sh,v 1.2 2008/09/05 07:38:28 schedmi Exp $
#

. ./common.sh
. ./env.sh

( cd $HOME/fxpricing/bin && ./restartAllRunning.sh )
if [ $? -ne 0 ]; then
    exit 1
fi
