#!/bin/ksh
#
# $Id: commit_prod_candidate_tag.sh,v 1.1 2007/12/05 14:37:03 kovyale Exp $
#
# alexey.kovyrshin@db.com
#

. ./common.sh

# get the latest prod tag
if [ ! -f "$DEPLOY_HOME/patches/latest_prod_tag.txt" ]; then
	echo "Can not find the latest prod tag file: $DEPLOY_HOME/patches/latest_prod_tag.txt" >&3
	exit 1
fi

LATEST_PRODTAG=`cat $DEPLOY_HOME/patches/latest_prod_tag.txt`

# get tag bits
major=`echo $LATEST_PRODTAG | cut -d- -f2`
minor=`echo $LATEST_PRODTAG | cut -d- -f3`
patchversion=`echo $LATEST_PRODTAG | cut -d- -f4`

# increment patchversion
pachversion=`expr $patchversion + 1`

# new tag
PRODTAG="prod-$major-$minor-$pachversion"

# candidate
CANDIDATETAG="prod-candidate-$major-$minor-$pachversion"

Sendmail "About to start cloning $CANDIDATETAG into $PRODTAG" "About to start cloning $CANDIDATETAG into $PRODTAG"

# The tag is created ok, let's clone it to the PRODTAG
# remove previously created tag
echo "Removing previously created $PRODTAG ..." >&3
cvs -q -z3 rtag -d $PRODTAG tplus richclient tplus-common-jars fxplusoptions fxplus coldfusion

# clone the tag
echo "Cloning $CANDIDATETAG into $PRODTAG ..." >&3
cvs -q -z3 rtag -F -r$CANDIDATETAG $PRODTAG tplus fxplus tplus-common-jars fxplusoptions richclient coldfusion
if [ "$?" -ne "0" ]; then
    echo "Error cloning the prod tag" "Could not clone $CANDIDATETAG to $PRODTAG. About to remove unsuccessfully created tag $PRODTAG" >&3
    Sendmail "Error cloning the prod tag" "Could not clone $CANDIDATETAG to $PRODTAG. About to remove unsuccessfully created tag $PRODTAG" 
    echo "Removing previously created $PRODTAG ..." >&3
    cvs -q -z3 rtag -d $PRODTAG tplus richclient tplus-common-jars fxplusoptions fxplus coldfusion
    echo "Unsuccessfully created tag $PRODTAG is removed" >&3
    Sendmail "Unsuccessfully created tag $PRODTAG is removed" ""
    exit 1
fi
Sendmail "Tag $PRODTAG has been successfully created from the $CANDIDATETAG" ""
echo "Tag $PRODTAG has been successfully created from the $CANDIDATETAG" >&3
