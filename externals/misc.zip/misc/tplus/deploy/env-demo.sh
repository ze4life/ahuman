# Environment file for Demo platform - Fujitsu
#
# $Id: env-demo.sh,v 1.46 2008/07/14 15:14:32 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="demo"; export ENVIRONMENT
FROM="FXPlus Demo"; export FROM
WAR_PROFILES="\
dbag-lan \
dbag-sin \
dbag-usa \
dbag-lon \
aibk-lon \
bcvg-lon \
jybm-lon \
okoh-lon \
pbzg-lon \
sabx-lon \
shin-lon \
prtr-lan \
prtr-lon \
prtr-vpn \
nbcm-lon \
"; export WAR_PROFILES
FXPLUS_LEVEL_1="dbag"; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="aibk bcvg jybm okoh sabx shin pbzg prtr nbcm"; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS

SIGN_RICHCLIENT_JARS=YES
START_AFTER_AUTODEPLOY=YES
CREATE_CHANNELS=YES
REMOVE_RELEASE_TARS=NO
KEEP_PREV_RELEASE=YES
KEEP_BUILD_FILES=NO
