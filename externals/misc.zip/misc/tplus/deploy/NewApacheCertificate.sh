#!/bin/sh
#
# Simple template for creating Apache certificates
# 

filename=$1
cn=$2
if [ -z "$filename" ] || [ -z "$cn" ]; then
    echo Use: $0 filename CN
    exit 1
fi

#set -x
SUBJ="/CN=$cn/C=GB/ST=England/L=London/O=Deutsche Bank AG/OU=CIB/"
CONFIG=/home/utils/SSL_forge/openssl.cnf
pass=password
capass=password
#ca=/export/home/utils/SSL_forge/Root_CA/dummy2-ca
#ca=/export/home/utils/SSL_forge/Root_CA/dummy-ca
ca=/export/home/utils/SSL_forge/Root_CA/generic-ca

# generate the key and remove the password
( openssl genrsa -passout pass:$pass -des3 -out $filename.key_ 1024 && \
  openssl rsa -passin pass:$pass -in $filename.key_ -out $filename.key && \
  rm $filename.key_ )
if [ $? -ne 0 ]; then
    echo Failed to create the $filename.key
    exit 1
fi

# generate the certificate request
#openssl req -config $CONFIG -new -key $filename.key -out $filename.csr -subj "$SUBJ"
openssl req -new -key $filename.key -out $filename.csr -subj "$SUBJ"
if [ $? -ne 0 ]; then
    echo Failed to create the certificate request $filename.csr
    exit 1
fi

# check if CA exists
if [ ! -r "$ca.crt" ]; then
    echo Could not read $ca.crt
    exit 1
fi
if [ ! -r "$ca.key" ]; then
    echo Could not read $ca.key
    exit 1
fi

# sign
openssl x509 -req -CA $ca.crt -CAkey $ca.key -passin pass:$capass -in $filename.csr -out $filename.crt -CAcreateserial -days 7300
if [ $? -ne 0 ]; then
    echo Failed to sign the $filename.csr using $ca.crt, $ca.key
    exit 1
fi

echo $filename.key and $filename.crt are created. 
