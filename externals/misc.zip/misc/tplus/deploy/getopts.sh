#!/bin/sh
# 
# $Id: getopts.sh,v 1.3 2007/12/21 14:19:23 kovyale Exp $
#
# Include this script into autodeploy.sh and build.sh
# The inclusion order should be as follows:
# . ./getopts.sh
# HERE CAN be . $HOME/.profile
# . ./common.sh
# . ./env,sh

# Preserve the original ARGS
ORIG_ARGS=$*

# Add options here
while getopts hD:r:e: c
do
    case $c in
        D )  
        CHECKOUT_DATE=$OPTARG
        export CHECKOUT_DATE
        ;;
        r )
        CHECKOUT_TAG=$OPTARG
        export CHECKOUT_TAG
        ;;
        \?|h)
        echo 
        echo "$0 [ -D YYYY.MM.DD.HH.MM.SS ] [ -r TAG ]"
        echo 
        echo "-D YYYY.MM.DD.HH.MM.SS"
        echo "   Checkout using given date - YYYY.MM.DD.HH.MM.SS"
        echo "-r TAG"
        echo "   Check out using given TAG"
        echo 
        echo "Running with no arguments will use current datetime"
        echo "Option -r override -D"
        echo 
        exit 2;;
    esac
done
shift `expr $OPTIND - 1`
