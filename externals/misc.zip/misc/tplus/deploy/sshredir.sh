#!/bin/sh

CMD="ssh localhost -24NfgL 31122:localhost:22"

PROC=`ps -eo args | grep "$CMD" | grep -v grep`

if  [ -n "$PROC"  ]; then
    exit 0
else
    $CMD &
    if [ "$?" -ne 0 ]; then
        echo "ERROR: Unable to start: $CMD"
        exit 1
    fi
fi
