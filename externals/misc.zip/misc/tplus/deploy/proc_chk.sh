#!/bin/sh
# This script check to see if all the processes are running for T+/FX+/Options
# Author: DAM
# Date:   11-04-2004
# $Id: proc_chk.sh,v 1.26 2008/06/04 13:33:22 kovyale Exp $
# Param: layer id

# this script should work on SunOS and Linux
if [ "`uname -s`" = "SunOS" ]
then
    PS=/usr/ucb/ps
else
    PS=ps
	ECHOOPT=-e
fi

# Usage
USAGE="`basename ${0}` <all|1|2|WLC|...>\nEg: To check all the layer 2 processes:\n\t`basename ${0}` 2\n"

if [ ${#} -ne 1 ]
then
    echo
    echo "Incorrect numher of parameters"
    echo $ECHOOPT "${USAGE}"
    echo
    exit 1
fi

# Get the necessary variables
. $HOME/deploy/env.sh

# need to hard code this sicne not includeing common.sh
T_BASE="$HOME/tplus/deploy"; export T_BASE
FX_BASE="$HOME/fxplus/level_";export FX_BASE
FXO_BASE="$HOME/fxplusoptions";export FXO_BASE
FX_L1_PID_FILES="cfetsbridge currenexbridge d2n fxallmdpibridge fxalltcpibridge ratefan rmsbridge dbmpProxy server emailserver";export FX_L1_PID_FILES
FX_L2_PID_FILES="server";export FX_L2_PID_FILES

# Useful variables
TPLUS_PID_FILES="authserver server"

# Keywords to find in ps output, delimited by space
SERVER_KWDS="CfetsBridge CurrenexBridge Dbus-To-Nirvana FxallFeedBridge FxallTradingBridge RateFan RMS-Bridge DBMP FXPlus-Core-Server EmailServer TPLUS-Server Auth-Server fxplus_options_server"

if [ "$ENVIRONMENT" = "prod-uk" ]; then
    FX_L1_PID_FILES="$FX_L1_PID_FILES dedicated_ratefan"
    SERVER_KWDS="$SERVER_KWDS DedicatedRF"
else
    #  Note this dbmp ack distributor in UAT only
    FX_L1_PID_FILES="$FX_L1_PID_FILES dbmpAckDistributor"
    SERVER_KWDS="$SERVER_KWDS DBMP-Ack-Distributor"
fi


# Param: 1: Pid of the process
# Param: 2: Name of the process
# Param: 3: Name of the server node
check_pid()
{
    if [ -f ${1} ]
    then
      PID=`cat ${1}`
      OUT=`$PS auxwww ${PID} | grep ${LOGNAME}`
      if [ "${3}" != "" ]
      then
        echo $ECHOOPT "${3} - \c"
      fi
      echo $ECHOOPT "${2}:\t\c"

      if [ -z "${OUT}" ]
      then
        echo $ECHOOPT "NOT running\tPID: ${PID}"
      else
        RES="NOT running"
        for i in ${SERVER_KWDS};
        do
          if [ -n "`echo $ECHOOPT "${OUT}" | grep $i`" ]
          then
            RES="running"
            break
          fi
        done
        echo $ECHOOPT ${RES}
      fi
    else
        echo $ECHOOPT "Unable to read pid file: ${1}"
    fi
}

if [ ${1} = "1" ] || [ ${1} = "all" ]
then
    # Check on layer 1
    echo $ECHOOPT "\nFX+ Layer 1:  "
    for FILE in ${FX_L1_PID_FILES}
    do
        check_pid ${FX_BASE}1/${FXPLUS_LEVEL_1}/release/log/${FILE}.pid ${FILE}
    done

    echo $ECHOOPT "\nFXO: "
    check_pid ${FXO_BASE}/log/fxo.pid fxo

    echo $ECHOOPT "\nT+ Layer 1: "
    for FILE in ${TPLUS_PID_FILES}
    do
        check_pid ${T_BASE}/${TPLUS_LEVEL_1}/log/${FILE}.pid ${FILE}
    done
fi

if [ ${1} = "2" ] || [ ${1} = "all" ]
then
    # Check on layer 2
    echo $ECHOOPT "\nFX+ Layer 2:"
    for NODE in ${FXPLUS_LEVEL_2}
    do
        for FILE in ${FX_L2_PID_FILES}
        do
            check_pid ${FX_BASE}2/${NODE}/release/log/${FILE}.pid ${FILE} ${NODE}
        done
    done

    echo $ECHOOPT "\nT+ Layer 2: "
    for T_NODE in ${TPLUS_LEVEL_2}
    do
        for FILE in ${TPLUS_PID_FILES}
        do
            check_pid ${T_BASE}/${T_NODE}/log/${FILE}.pid ${FILE} ${T_NODE}
        done
    done
else
    if [ ${1} != "1" ]
    then
        NODE=${1}
        if [ `echo $ECHOOPT ${TPLUS_LEVEL_2} | grep -c ${NODE}` != 1 ]
        then
            echo $ECHOOPT "Invalid node for environment: ${NODE}"
            echo $ECHOOPT "Valid nodes are: ${TPLUS_LEVEL_2}"
        else
            echo $ECHOOPT "\nFX+ Layer 2:"
            for FILE in ${FX_L2_PID_FILES}
            do
                check_pid ${FX_BASE}2/${NODE}/release/log/${FILE}.pid ${FILE} ${NODE}
            done
            echo $ECHOOPT "\nT+ Layer 2: "
            for FILE in ${TPLUS_PID_FILES}
            do
                check_pid ${T_BASE}/${NODE}/log/${FILE}.pid ${FILE} ${NODE}
            done

        fi
    fi
fi
