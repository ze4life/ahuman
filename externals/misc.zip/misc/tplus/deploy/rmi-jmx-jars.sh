#!/bin/sh
#
# $Id: rmi-jmx-jars.sh,v 1.8 2008/06/04 13:33:22 kovyale Exp $
#

. ./common.sh
. ./env.sh

if [ "$ENVIRONMENT" != "prod-uk" ] && [ "$ENVIRONMENT" != "demo" ] && \
   [ "$ENVIRONMENT" != "external-uat1" ]; then
       (
           cd $BUILD_HOME/$TAG/fxplus
           echo " Building rmi-jmx" >&3
           date
           ${ANT_BIN}/ant -buildfile rmi-jmx.xml
           mv $BUILD_HOME/$TAG/tplus-common-jars/output/lib/rmi-jmx/rmi-jmx.tar $DEPLOY_HOME
       )
       if [ "$?" -ne "0" ] ;then
           echo "FAILED" >&3
           exit 1
       fi

   else
       echo " Skipping building of rmi-jmx jars" >&3
fi
