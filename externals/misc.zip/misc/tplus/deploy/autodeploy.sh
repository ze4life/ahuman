#!/bin/ksh
#
# $Id: autodeploy.sh,v 1.134 2008/10/27 12:18:28 savcvla Exp $
#
# alexey.kovyrshin@db.com
#

# Get options. 
. ./getopts.sh

# need to get the profile, but somewhere it sets "-o vi" 
# that's why the script must be executed with #!/bin/ksh
. $HOME/.profile

# get the common variables
. ./common.sh

# 
# UPDATE THE DEPLOY MODULE AND RESTART.
#
if [ -z "$RESTARTED" ]; then
	# check for running instance
	for pid in autopatch autodeploy; do 
		if [ -f "$pid.pid" ]; then
			PID=`head -1 $pid.pid`
	                ISRUNNING=`ps -ef | grep $PID | grep $LOGNAME | grep -v grep | egrep "autodeploy\.sh|autopatch\.sh"`
			if [ -n "$ISRUNNING" ]; then
				echo "The instance of autopatch.sh or autodeploy.sh is already running." >&3
				echo "$ISRUNNING" >&3
				exit 1
			fi
		fi
	done
	echo $$ > "`basename $0 .sh`.pid"

	cvs -q -z3 up -Pd
	# set the RESTARTED flag
        RESTARTED=YES
	export RESTARTED
	# re-run self with the same arguments
        exec $0 $ORIG_ARGS >&3
else
	# ok environemnt var RESTARTED is set,
	# i am the restarted instance!
        echo Restarted $0 $ORIG_ARGS
        AUTODEPLOY=YES
        export AUTODEPLOY
fi

if [ ! -f "env.sh" ]; then
    echo "Could not find env.sh"
    Sendmail "Could not find env.sh" "Can not start the build"
    exit 1
fi

# load the environment vars
. ./env.sh

if [ -z "$CHECKOUT_TAG" ] && [ -z "$CHECKOUT_DATE" ]; then
    # If no tag given, Calculate the tag for PROD-like envs.
    if  [ "$ENVIRONMENT" = "prod-uk" ] || \
        [ "$ENVIRONMENT" = "demo" ] || \
        [ "$ENVIRONMENT" = "prod-copy" ] || \
        [ "$ENVIRONMENT" = "external-uat1" ]
    then
        if [ -f "$DEPLOY_HOME/patches/latest_prod_tag.txt" ]; then
            LATEST_PRODTAG=`cat $DEPLOY_HOME/patches/latest_prod_tag.txt`
            # get tag bits
            major=`echo $LATEST_PRODTAG | cut -d- -f2`
            minor=`echo $LATEST_PRODTAG | cut -d- -f3`
            patchversion=`echo $LATEST_PRODTAG | cut -d- -f4`
            # increment patchversion
            pachversion=`expr $patchversion + 1`
            # the new tag
            TAG="prod-$major-$minor-$pachversion"
            BUILD_ARGS="-r $TAG"
        else
            echo "Could not find the $DEPLOY_HOME/patches/latest_prod_tag.txt file" >&3
            Sendmail "latest_prod_tag.txt is not found" "Could not find the $DEPLOY_HOME/patches/latest_prod_tag.txt file.\nPossible reason - the tplus/deploy/patches/latest_prod_tag.txt is not commited. New release has recently happen?"
            exit 1
        fi
    else
        TAG="date-$DATE"
        BUILD_ARGS="-D $DATE"
    fi
else
    if [ -n "$CHECKOUT_TAG" ]; then
        TAG=$CHECKOUT_TAG
        BUILD_ARGS="-r $CHECKOUT_TAG"
    elif [ -n "$CHECKOUT_DATE" ]; then
        TAG="date-$CHECKOUT_DATE"
        BUILD_ARGS="-D $CHECKOUT_DATE"
    fi
fi

./build.sh $BUILD_ARGS >&3
if [ $? -ne 0 ]; then
    echo "Build failed, check log/build.sh.current.log" >&3
    exit 1
fi

echo "Stopping $ENVIRONMENT" >&3
for script in $STOPENV_SCRIPTS
do
    ./$script >&3
    if [ $? -ne 0 ]; then
        Sendfile "Errors running $script" "log/$script.current.log"
    fi
done

# deploy
./deploy.sh >&3
if [ $? -ne 0 ]; then
    echo "Deployment failed, check log/deploy.sh.current.log" >&3
    exit 1
fi

# deploy backend code to nodes
./transfer_files.sh >&3
if [ $? -ne 0 ]; then
    Sendmail "WARNING: transfer_files.sh failed!" "Please check the log/transfer_files.sh.current.log or see the email from transfer_files.sh script"
fi

# customise QA-managed environments
if  [ "$ENVIRONMENT" = "prod-copy" ] || \
    [ "$ENVIRONMENT" = "daily-build2" ] || \
    [ "$ENVIRONMENT" = "lab-uk" ] || \
    [ "$ENVIRONMENT" = "moscow-build8" ]
then
    if [ -x $HOME/fxtestsuite/_injections/scripts/fxautosetup.sh ]; then
        $HOME/fxtestsuite/_injections/scripts/fxautosetup.sh $ENVIRONMENT > /dev/null
    fi
fi

# start the ENVIRONMENT
if [ "$START_AFTER_AUTODEPLOY" = "YES" ] ; then
    echo "Starting $ENVIRONMENT" >&3
    for script in $STARTENV_SCRIPTS
    do
        ./$script >&3
        if [ $? -ne 0 ]; then
            Sendfile "Errors running $script" "log/$script.current.log"
        fi
    done
fi

# commit the latest prod tag
if [ "$ENVIRONMENT" = "prod-uk" ]; then
	# update it 
	echo $TAG > $DEPLOY_HOME/patches/latest_prod_tag.txt
	# and commit
	out=`( cd $DEPLOY_HOME/patches/  && \
          cvs -z3 ci -m"ABFX-007: commiting successfull prod tag $TAG" latest_prod_tag.txt )`
	if [ "$?" -ne "0" ]; then
		Sendmail "Could not commit latest prod tag $TAG" "$out"
	fi
fi

# done
if [ -n "$LIST_OF_PATCHES" ]; then
	PATCHES_APPLIED="Patches applied are $LIST_OF_PATCHES"
fi
echo "Deployment with arguments \"$ORIG_ARGS\" is done." >&3
Sendmail "$TAG has been successfully deployed. $PATCHES_APPLIED" "The $ENVIRONMENT has been successfully deployed from $TAG. $PATCHES_APPLIED"

exit 0
