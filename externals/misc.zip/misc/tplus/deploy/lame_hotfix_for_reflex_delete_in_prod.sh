#!/bin/sh

. ./common.sh
. ./env.sh

if [ "$ENVIRONMENT" = "live-uk" ] ||
 [ "$ENVIRONMENT" = "live-uk-bcp" ] ||
 [ "$ENVIRONMENT" = "live-uk-fwd" ] ||
 [ "$ENVIRONMENT" = "live-uk-fwd-bcp" ] ||
 [ "$ENVIRONMENT" = "live-us" ] ||
 [ "$ENVIRONMENT" = "live-us-bcp" ]
then
    cd $HOME/fxpricing/bin &&
    rm restartAllRunnung.sh
fi
