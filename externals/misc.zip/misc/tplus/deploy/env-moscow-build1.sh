# Environment specific settings
ENVIRONMENT=moscow-build1; export ENVIRONMENT
FROM="FX+ Moscow Build 1"; export FROM
FXPLUS_LEVEL_1=dbag; export FXPLUS_LEVEL_1
FXPLUS_LEVEL_2="jybm nbcm" ; export FXPLUS_LEVEL_2
TPLUS_LEVEL_1=$FXPLUS_LEVEL_1; export TPLUS_LEVEL_1
TPLUS_LEVEL_2=$FXPLUS_LEVEL_2; export TPLUS_LEVEL_2
TPLUS_LAYERS="$TPLUS_LEVEL_1 $TPLUS_LEVEL_2"; export TPLUS_LAYERS
WAR_PROFILES="dbag-lan jybm-lan nbcm-lan"; export WAR_PROFILES

FXPLUS_DEBUG=on
