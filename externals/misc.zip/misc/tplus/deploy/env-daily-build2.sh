#
# $Id: env-daily-build2.sh,v 1.40 2008/07/16 10:59:28 schedmi Exp $
#

# Environment specific settings
ENVIRONMENT="daily-build2";export ENVIRONMENT
FROM="FX+ Daily Build 2 UK"; export FROM
TPLUS_LAYERS="dbag jybm bcvg"; export TPLUS_LAYERS
WAR_PROFILES="dbag-lan dbag-lan2 dbag-lon asia-lan jybm-lan bcvg-lan"; export WAR_PROFILES
FXPLUS_LEVEL_1=dbag
FXPLUS_LEVEL_2="jybm bcvg"
TPLUS_LEVEL_1=dbag
TPLUS_LEVEL_2="jybm bcvg"
FXPLUS_DEBUG=on
STOPENV_SCRIPTS="$STOPENV_SCRIPTS StopUS.sh"
STARTENV_SCRIPTS="$STARTENV_SCRIPTS StartUS.sh"
FXPLUS_US_USERHOST="abfxu2@abfxu1.us.db.com"
MIS_USERHOST="tplu5@longmgccappb1.uk.db.com"
MIS_WEBROOT="/home/tplu5/jrun4/servers/cfusion/cfusion-ear/cfusion-war"
