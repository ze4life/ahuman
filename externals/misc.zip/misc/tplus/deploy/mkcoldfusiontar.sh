#!/bin/sh
# $Id: mkcoldfusiontar.sh,v 1.4 2007/12/19 15:39:56 kovyale Exp $

. ./common.sh
. ./env.sh

(
    cd "$BUILD_HOME/$TAG/coldfusion/wwwroot"
    echo "Creating coldfusion tar - $HOME/deploy/coldfusion.tar" >&3
    find . -type f | grep -v "/CVS/" | cpio -Hustar -o > $HOME/deploy/coldfusion.tar
)
if [ $? -ne 0 ] ;then
    echo "FAILED" >&3
    exit 1
fi
