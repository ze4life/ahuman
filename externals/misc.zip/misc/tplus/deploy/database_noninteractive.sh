#!/bin/ksh
#
# $Id: database_noninteractive.sh,v 1.23 2008/09/10 10:08:39 kovyale Exp $
#
# This script will make:
# * runtime verion of patches and finaly sql scripts.
# * check DATABASE_PATCHES table for alredy applied patches.
# * a set of korn shell scripts, which apply not yet applied patches to database (after removing safety catch)
# 

###
### Internal functions
### 
### NOTE: All UPPER cased variables used in functions
### NOTE: should be initialized before calling functions,
### NOTE: exept the $COMMENT variable
###

# set ABORT_TOOL to true
set_abort()
{
        ABORT_TOOL=1
}

# checks if ABORT_TOOL is true
check_abort()
{
        if [[ $ABORT_TOOL = 1 ]]; then
                echo "$0: ERROR OCURED, check logfile for more information" >&3
                exit 1
        fi
}

# check for the existance of all the properties files
validate_environment()
{
        # this func check existing of some property files,

        # this is mandatory profile
        local property_files="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"

        property_files="$property_files $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
        property_files="$property_files $FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"

        if [ "$LAYER" = "dbag" ]; then
                property_files="$property_files $FXOP_HOME/sql/profile/${PROFILE}.options.properties"
        fi

        for property_file in $property_files; do
                if [[ ! -r $property_file ]] ; then
                        echo "FAILED: property file $property_file have not been found." 
                        set_abort;
                fi
        done
}

# get value of preference from property file
get_prop_val()
{
        local prop=$1
        local file=$2
        # using tr for converting windows line end (if any) to unix. "0x0D0x0A" -> "0x0A" 
        result=`grep "^${prop}=" "$file" | tr -d '\r' | awk -F= '{ print $2 }'`
        echo "$result"
}

# test the oracle connection is correct
test_oracle_connection()
{
        local conn="$1@$2"
        local result=`sqlplus $conn 2>&1 <<EOF
exit
EOF
`
        # BUG11006 fix, check if sqlplus has been running properly
        local retcode=$?
        if [[ $retcode != 0 ]]; then
                echo "FAILED: test_oracle_connection: error running sqlplus: $result"
                set_abort;
        else
                local successful=`echo ${result} | grep ORA `
                if [[ -n $successful ]] ; then
                        echo "FAILED: test_oracle_connection: unsucessful connection: \"sqlplus $conn\": $successful" 
                        set_abort;
                fi
        fi
}

# checks to see if the database has already been patched . If it has then the call in the generated script is commented out
check_database_patches_table()
{
        local version_number=$1
        local result=`sqlplus -s ${USERID}/${PASSWORD}@${DATABASETNS} 2>&1 <<EOF
SET HEAD OFF FEED OFF LINES 80
COL AA FORMAT A100 NEWLINE
SELECT DISTINCT 'INFO : Patch '||FILENAME||' already applied on '||TO_CHAR(UPDATETIME,'DD-MON-YYYY "at" HH24:MI') AA FROM DATABASE_PATCHES 
WHERE VERSIONNUMBER = $version_number AND lower(APPLICATIONNAME) = lower('$APP_NAME');
EXIT
EOF
`
        # BUG11006 fix, check if sqlplus has been running properly
        local retcode=$?
        if [[ $retcode != 0 ]]; then
                echo "FAILED: check_database_patches_table: error running sqlplus: $result"
                set_abort;
        else
                # Handle oracle error
                if `echo $result | egrep "ORA-|SP2-"` ; then
                        echo "FAILED: check_database_patches_table. Connection: ${USERID}/${PASSWORD}@${DATABASETNS}. version_number: $1"
                        echo "$result"
                        set_abort;
                else
                        # If the patch has already been applied ensure that the call is commented out
                        if [[ -z `echo $result | grep INFO` ]] ; then
                                COMMENT=''
                                echo "$APP_NAME patch #$version_number is not applied" >&3
                        else
                                COMMENT='#'
                                echo "$APP_NAME patch #$version_number is already applied" >&3
                        fi
                fi
        fi
}

# checks patch filename against naming convention:
# * first 5 digits must be numeric
# * filename must not use underscores
# * name must have > 1 hypen in it
# * must be lower case only
# * must have the application name embedded in it
check_patch_filename()
{
        local filename=$1
        local basename=`basename $filename`
        local estr="ERROR: Patch file $filename breaks naming convention:"
        # * first 5 digits must be numeric
        if [[ -z `echo $basename | egrep "^[0-9][0-9][0-9][0-9][0-9]-"` ]]; then
                echo $estr "first 5 digits must be numeric."
                set_abort;
        fi
        # * filename must not use underscores
        if [[ -n `echo $basename | egrep "_"` ]]; then
                echo $estr "filename must not use underscores."
                set_abort;
        fi
        # * name must have > 1 hypen in it
        if [[ `echo $basename | sed -e "s/-/ /g" | wc -w | sed -e "s/^ *//"` -le 2 ]]; then
                echo $estr "name must have > 1 hypen in it."
                set_abort;
        fi
        # * must be lower case only
        if [[ -n `echo $basename | egrep "[A-Z]"` ]]; then
                echo $estr "must be lower case only."
                set_abort;
        fi
        # * must have the application name embedded in it
        # FIXME: need to discuss
}
# this func generates output for KSH_SCRIPT, to provide
# database patching, based on chking of already applied patches.
# it's important to set USERID, PASSWORD, USERID_AP, PASSWORD_AP,
# USERID_RO, PASSWORD_RO, KSH_SCRIPT, SQL_PATH, PROFILE, APP_NAME
# LAYER to proper values before calling gen_runtime;, COMMENT variable will
# be overwriten on each call of check_database_patches_table;
gen_runtime()
{
        # patches runtime
        local list_of_sql=`ls $SQL_PATH/patches/runtime/${PROFILE}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $SQL_PATH/patches/runtime/${PROFILE}/*.sql.runtime scripts not found." 
        fi
        for sql_patch in $list_of_sql
        do
                local basename=`basename $sql_patch`
                local version_number=`echo $basename | awk -F- '{ print $1 }'`
                local foundsyn=`echo $basename | grep -i syn | wc -l | sed -e "s/ //g"`

		# only permit the current and next release
                if [ -z "`echo $version_number | egrep \"^82[0-9][0-9][0-9]|^83[0-9][0-9][0-9]\"`" ]; then
                        echo Skipping $basename
                        continue
                fi

                check_patch_filename $sql_patch;
                        check_abort;
                check_database_patches_table $version_number
                        check_abort;

                if [[ $foundsyn = 0 ]]; then
                        cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus $USERID/$PASSWORD@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
EOF
                else
                        cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus $USERID_AP/$PASSWORD_AP@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
${COMMENT}echo > \$ORA_CHECK_LOG
${COMMENT}sqlplus $USERID_RO/$PASSWORD_RO@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
${COMMENT}check_for_errors;
EOF
                fi
        done

        # finally runtime

        list_of_sql=`ls $SQL_PATH/finally/runtime/${PROFILE}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $SQL_PATH/finally/runtime/${PROFILE}/*.sql.runtime scripts not found."
        fi
        for sql_patch in $list_of_sql
        do
# remove code so that it works
#               cat >> "${KSH_SCRIPT}" <<EOF
# echo > \$ORA_CHECK_LOG
# (cd $SQL_PATH ; sqlplus $USERID/$PASSWORD@$DATABASETNS @ ${sql_patch}) | tee -a \$LOG \$ORA_CHECK_LOG
# EOF
           local basename=`basename $sql_patch`
           local foundsyn=`echo $basename | grep -i syn | wc -l | sed -e "s/ //g"`
           if [[ $foundsyn = 0 ]]; then
                cat >> "${KSH_SCRIPT}" <<EOF
echo > \$ORA_CHECK_LOG
sqlplus $USERID/$PASSWORD@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
check_for_errors;
EOF
           else
                cat >> "${KSH_SCRIPT}" <<EOF
echo > \$ORA_CHECK_LOG
sqlplus $USERID_AP/$PASSWORD_AP@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
check_for_errors;
echo > \$ORA_CHECK_LOG
sqlplus $USERID_RO/$PASSWORD_RO@$DATABASETNS @ ${sql_patch} | tee -a \$LOG \$ORA_CHECK_LOG
check_for_errors;
EOF
           fi

        done
}

# make a query to the database
sql_query()
{
        local result=`sqlplus -s ${USERID}/${PASSWORD}@${DATABASETNS} 2>&1 <<EOF
SET HEAD OFF FEED OFF LINES 80
COL AA FORMAT A100 NEWLINE
$1
;
EXIT
EOF
`
        local retcode=$?
        if [[ $retcode != 0 ]]; then
                echo "FAILED: sql_query: error running sqlplus: $result"
                set_abort;
        else
                echo $result
        fi
}


### 
### Main start of script
###


# suck in common header or functions
. ./common.sh
# suck in environment variables
. ./env.sh

# set up project directories, where it was deployed
TPLUS_HOME=$HOME/tplus-$TAG
FXPLUS_HOME=$HOME/fxplus/fxplus-$TAG
FXOP_HOME=$HOME/fxplusoptions-$TAG

# ABFX-77: overwrite sql profiles from the release archive with ones from $HOME/SECRETS
if [ -r "$HOME/SECRETS/sql/tplus/sql/profile/abfx-${ENVIRONMENT}" ]; then
	cp -rp "$HOME/SECRETS/sql/tplus/sql/profile/abfx-${ENVIRONMENT}" $TPLUS_HOME/sql/profile/
fi
if [ -r "$HOME/SECRETS/sql/tplus/vpd/profile/abfx-${ENVIRONMENT}.properties" ]; then
	cp -rp "$HOME/SECRETS/sql/tplus/vpd/profile/abfx-${ENVIRONMENT}.properties" $TPLUS_HOME/vpd/profile
fi
if [ -r "$HOME/SECRETS/sql/fxplus/sql/profile/abfx-${ENVIRONMENT}" ]; then
	cp -rp "$HOME/SECRETS/sql/fxplus/sql/profile/abfx-${ENVIRONMENT}" $FXPLUS_HOME/sql/profile/
fi
if [ -r "$HOME/SECRETS/sql/fxplusoptions/sql/profile/abfx-${ENVIRONMENT}" ]; then
	cp -rp "$HOME/SECRETS/sql/fxplusoptions/sql/profile/abfx-${ENVIRONMENT}" $FXOP_HOME/sql/profile/
fi

ABORT_TOOL=0

# VPD
    # generate patches, finally, runtime ksh scripts
    ANT_ARGS="-Djustgen=true -Dvpd=true -Dvpdhome=$TPLUS_HOME/vpd -Dabfxenv=abfx-$ENVIRONMENT"
    ( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS patch )
    if [[ $? -ne 0 ]]; then
        echo "FAILED: could not make runtime patches for profile: $PROFILE" 
        echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
        echo `date` " $0 finished with errors" 
        set_abort;
    fi
    check_abort;
    DATABASETNS=`get_prop_val database.tnsname "$TPLUS_HOME/sql/profile/abfx-$ENVIRONMENT/dbag.database.properties"`
    PROPERTY_FILE="$TPLUS_HOME/vpd/profile/abfx-$ENVIRONMENT.properties"
    VPDUSERID=`get_prop_val master.vpd.username $PROPERTY_FILE`
    VPDPASSWORD=`get_prop_val master.vpd.password $PROPERTY_FILE`
    VPDUSERID_AP=`get_prop_val master.vpd.ap.username $PROPERTY_FILE`
    VPDPASSWORD_AP=`get_prop_val master.vpd.ap.password $PROPERTY_FILE`
    VPDUSERID_RO=`get_prop_val master.vpd.ro.username $PROPERTY_FILE`
    VPDPASSWORD_RO=`get_prop_val master.vpd.ro.password $PROPERTY_FILE`
    VPDUSEROD_FXPOWNER=`get_prop_val fxplus.owner.username $PROPERTY_FILE`
    VPDPASSWORD_FXPOWNER=`get_prop_val fxplus.owner.password $PROPERTY_FILE`
    for CONNECTION in "${VPDUSERID}/${VPDPASSWORD}" \
        "${VPDUSERID_AP}/${VPDPASSWORD_AP}" \
        "${VPDUSERID_RO}/${VPDPASSWORD_RO}" \
	"${VPDUSEROD_FXPOWNER}/${VPDPASSWORD_FXPOWNER}"
    do
        test_oracle_connection $CONNECTION $DATABASETNS
        check_abort;
    done

    # start script generation
    KSH_SCRIPT="abfx-$ENVIRONMENT-vpd.ksh"
    if [[ -r "${KSH_SCRIPT}" ]]; then
        mv "${KSH_SCRIPT}" "${KSH_SCRIPT}.old"
    fi
    touch "${KSH_SCRIPT}"
    if [[ "$?" -ne "0" ]]; then
        echo "FAILED: could not create ${KSH_SCRIPT}"
        echo `date` " $0 finished with errors"
        set_abort;
    fi
    check_abort;
    chmod 700 "${KSH_SCRIPT}"
    cat > "${KSH_SCRIPT}" <<EOF
#!/bin/ksh
LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.log.\`date +%Y.%m.%d.%H.%M.%S\`"
rm ${CURRENT_DIR}/log/${KSH_SCRIPT}.current.log > /dev/null
ln -s \$LOG ${CURRENT_DIR}/log/${KSH_SCRIPT}.current.log
ORA_CHECK_LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.oracheck.log"
ORA_ERROR_LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.error.log"
check_for_errors()
{
    error=\`egrep "ORA-|SP2-" \$ORA_CHECK_LOG | wc -l | sed -e "s/^ *//"\`
    if [[ \$error != 0 ]] ;  then
        cat \$ORA_CHECK_LOG >> \$ORA_ERROR_LOG
    fi
}

# Script to run patches into abfx schemas
# Autogenerated by $TPLUS_HOME/deploy/$0
# Created : ${START_DATETIME}
EOF
    echo "echo 'VPD Patches'" >> "${KSH_SCRIPT}"
    # set up "gen_runtime" variables
    USERID=$VPDUSERID
    PASSWORD=$VPDPASSWORD
    USERID_AP=$VPDUSERID_AP
    PASSWORD_AP=$VPDPASSWORD_AP
    USERID_RO=$VPDUSERID_RO
    PASSWORD_RO=$VPDPASSWORD_RO
    PROFILE=abfx-$ENVIRONMENT
    SQL_PATH="$TPLUS_HOME/vpd"
    APP_NAME="VPD"
    gen_runtime;
# End of VPD

# generate patches, finally, runtime ksh scripts
for LAYER in $TPLUS_LAYERS
do
        PROFILE="abfx-$ENVIRONMENT/$LAYER"

        # check needed property files
        validate_environment;
        check_abort;

        # default ant args
        ANT_ARGS="-Djustgen=true -Dabfxenv=abfx-$ENVIRONMENT -Dvpdhome=$TPLUS_HOME/vpd"
        
        ANT_ARGS="$ANT_ARGS -Dtplus=true -Dtplushome=$TPLUS_HOME/sql"

        ANT_ARGS="$ANT_ARGS -Dfxplus=true -Dfxplushome=$FXPLUS_HOME/sql"

        if [ "$LAYER" = "dbag" ]; then
                ANT_ARGS="$ANT_ARGS -Doptions=true -Doptionshome=$FXOP_HOME/sql"
        fi

        ANT_ARGS="$ANT_ARGS -Dlayerids=${PROFILE}"
        echo "Running patch target with options: $ANT_ARGS"
        ( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS patch )
        if [[ $? -ne 0 ]]; then
                echo "FAILED: could not make runtime patches for profile: $PROFILE" 
                echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
                echo `date` " $0 finished with errors" 
                set_abort;
        fi
        check_abort;

        DATABASETNS=`get_prop_val database.tnsname "$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"`

                PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"
                TPLUSUSERID=`get_prop_val tplus.owner.username $PROPERTY_FILE`
                TPLUSUSPASSWORD=`get_prop_val tplus.owner.password $PROPERTY_FILE`
                PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
                TPLUSUSERID_AP=`get_prop_val tplus.ap.username $PROPERTY_FILE`
                TPLUSUSPASSWORD_AP=`get_prop_val tplus.ap.password $PROPERTY_FILE`
                TPLUSUSERID_RO=`get_prop_val tplus.ro.username $PROPERTY_FILE`
                TPLUSUSPASSWORD_RO=`get_prop_val tplus.ro.password $PROPERTY_FILE`
                for CONNECTION in "${TPLUSUSERID}/${TPLUSUSPASSWORD}" \
                        "${TPLUSUSERID_AP}/${TPLUSUSPASSWORD_AP}" \
                        "${TPLUSUSERID_RO}/${TPLUSUSPASSWORD_RO}"
                do
                    test_oracle_connection $CONNECTION $DATABASETNS
                    check_abort;
                done

                # BUG11642
                PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"
                WLC_SHORT_CODE=`get_prop_val layer.internal.client.shortcode $PROPERTY_FILE`
                ISWLC=`get_prop_val layer.iswlc $PROPERTY_FILE`
                if [[ "$ISWLC" = "N" ]] || [[ "$ISWLC" = "n" ]]
                then
                    if [[ "$WLC_SHORT_CODE" != "DB" ]]
                    then
                        echo "layer.iswlc: ${ISWLC}, layer.internal.client.shortcode: ${WLC_SHORT_CODE}. Should be 'DB'"
                        echo "Please check sql profile $PROPERTY_FILE"
                        set_abort;
                    fi
                    check_abort;
                    echo "layer.iswlc check passed for $WLC_SHORT_CODE"
                else
                    # Check for parent.fxplus.owner.username/password
                    PROPERTY_FILE="$FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
                    PARENT_FXPLUS_OWNER_USERNAME=`get_prop_val parent.fxplus.owner.username $PROPERTY_FILE`
                    PARENT_FXPLUS_OWNER_PASSWORD=`get_prop_val parent.fxplus.owner.password $PROPERTY_FILE`
                    echo "Checking sql profile $PROPERTY_FILE"
                    test_oracle_connection "${PARENT_FXPLUS_OWNER_USERNAME}/${PARENT_FXPLUS_OWNER_PASSWORD}" $DATABASETNS
                    check_abort;
                    echo "parent.fxplus.owner.username/password check passed for $WLC_SHORT_CODE"

                    # Check for parent.tplus.owner.username/password
                    PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
                    PARENT_TPLUS_OWNER_USERNAME=`get_prop_val parent.tplus.owner.username $PROPERTY_FILE`
                    PARENT_TPLUS_OWNER_PASSWORD=`get_prop_val parent.tplus.owner.password $PROPERTY_FILE` 
                    echo "Checking sql profile $PROPERTY_FILE"
                    test_oracle_connection "${PARENT_TPLUS_OWNER_USERNAME}/${PARENT_TPLUS_OWNER_PASSWORD}" $DATABASETNS
                    check_abort;
                    echo "parent.tplus.owner.username/password check passed for $WLC_SHORT_CODE"

                    # check for correct WLC SHORT NAME in TPLUS_CLIENT table
                    USERID=$PARENT_TPLUS_OWNER_USERNAME
                    PASSWORD=$PARENT_TPLUS_OWNER_PASSWORD
                    sql_result=`sql_query "SELECT SHORT_CODE FROM TPLUS_CLIENT WHERE SHORT_CODE = '$WLC_SHORT_CODE'"`
                    check_abort;
                    if [[ -z "$sql_result" ]]
                    then
                        echo "The query: SELECT SHORT_CODE FROM TPLUS_CLIENT WHERE SHORT_CODE = '$WLC_SHORT_CODE' on ${USERID}/${PASSWORD}@${DATABASETNS} , returns nothing, should be $WLC_SHORT_CODE"
                        echo "Please check the sql profile $PROPERTY_FILE, or the CLIENT_TYPE table"
                        set_abort;
                    fi
                    check_abort;
                    echo "SHORT_CODE test in TPLUS_CLIENT table passed for $WLC_SHORT_CODE"
                fi

                PROPERTY_FILE="$FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
                FXPLUSUSERID=`get_prop_val fxplus.owner.username $PROPERTY_FILE`
                FXPLUSUSPASSWORD=`get_prop_val fxplus.owner.password $PROPERTY_FILE`
                FXPLUSUSERID_AP=`get_prop_val fxplus.ap.username $PROPERTY_FILE`
                FXPLUSUSPASSWORD_AP=`get_prop_val fxplus.ap.password $PROPERTY_FILE`
                FXPLUSUSERID_RO=`get_prop_val fxplus.ro.username $PROPERTY_FILE`
                FXPLUSUSPASSWORD_RO=`get_prop_val fxplus.ro.password $PROPERTY_FILE`
                for CONNECTION in "${FXPLUSUSERID}/${FXPLUSUSPASSWORD}" \
                        "${FXPLUSUSERID_AP}/${FXPLUSUSPASSWORD_AP}" \
                        "${FXPLUSUSERID_RO}/${FXPLUSUSPASSWORD_RO}"
                do
                        test_oracle_connection $CONNECTION $DATABASETNS
                done
                check_abort;

        # start script generation
        KSH_SCRIPT="`echo ${PROFILE}|sed -e "s/\//-/g"`.ksh"
        if [[ -r "${KSH_SCRIPT}" ]]; then
                mv "${KSH_SCRIPT}" "${KSH_SCRIPT}.old"
        fi
        touch "${KSH_SCRIPT}"
        if [[ "$?" -ne "0" ]]; then
                echo "FAILED: could not create ${KSH_SCRIPT}"
                echo `date` " $0 finished with errors"
                set_abort;
        fi
        check_abort;
        chmod 700 "${KSH_SCRIPT}"
        cat > "${KSH_SCRIPT}" <<EOF
#!/bin/ksh
LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.log.\`date +%Y.%m.%d.%H.%M.%S\`"
rm ${CURRENT_DIR}/log/${KSH_SCRIPT}.current.log > /dev/null
ln -s \$LOG ${CURRENT_DIR}/log/${KSH_SCRIPT}.current.log
ORA_CHECK_LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.oracheck.log"
ORA_ERROR_LOG="${CURRENT_DIR}/log/${KSH_SCRIPT}.error.log"
check_for_errors()
{
    error=\`egrep "ORA-|SP2-" \$ORA_CHECK_LOG | wc -l | sed -e "s/^ *//"\`
    if [[ \$error != 0 ]] ;  then
        cat \$ORA_CHECK_LOG >> \$ORA_ERROR_LOG
    fi
}

# Script to run patches into abfx schemas
# Autogenerated by $TPLUS_HOME/deploy/$0
# Created : ${START_DATETIME}
EOF
        # Tplus Patches
                echo "echo 'TPLUS Patches'" >> "${KSH_SCRIPT}"
                # set up "gen_runtime" variables
                USERID=$TPLUSUSERID
                PASSWORD=$TPLUSUSPASSWORD
                USERID_AP=$TPLUSUSERID_AP
                PASSWORD_AP=$TPLUSUSPASSWORD_AP
                USERID_RO=$TPLUSUSERID_RO
                PASSWORD_RO=$TPLUSUSPASSWORD_RO
                SQL_PATH="$TPLUS_HOME/sql"
                APP_NAME="TPLUS"
                gen_runtime;
        # FXplus Patches
                echo "echo 'FXPLUS Patches'" >> "${KSH_SCRIPT}"
                # set up "gen_runtime" variables
                USERID=$FXPLUSUSERID
                PASSWORD=$FXPLUSUSPASSWORD
                USERID_AP=$FXPLUSUSERID_AP
                PASSWORD_AP=$FXPLUSUSPASSWORD_AP
                USERID_RO=$FXPLUSUSERID_RO
                PASSWORD_RO=$FXPLUSUSPASSWORD_RO
                SQL_PATH="$FXPLUS_HOME/sql"
                APP_NAME="FXPLUS"
                gen_runtime;
        # FXoptions Patches
        if [ "$LAYER" = "dbag" ]; then
                # only for "dbag" skin
                echo "echo 'FXPLUS Patches'" >> "${KSH_SCRIPT}"
                # set up "gen_runtime" variables
                USERID=$FXPLUSUSERID
                PASSWORD=$FXPLUSUSPASSWORD
                USERID_AP=$FXPLUSUSERID_AP
                PASSWORD_AP=$FXPLUSUSPASSWORD_AP
                USERID_RO=$FXPLUSUSERID_RO
                PASSWORD_RO=$FXPLUSUSPASSWORD_RO
                SQL_PATH="$FXOP_HOME/sql"
                APP_NAME="FXOP"
                gen_runtime;
        fi
echo "Database patching script $KSH_SCRIPT created." >&3
done
# end
