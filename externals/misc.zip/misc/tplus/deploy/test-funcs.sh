#!/bin/sh
# $Id: test-funcs.sh,v 1.4 2004/11/04 08:54:57 kovyale Exp $

#
# Run on BUILD PC
#

checkVar()
{
  eval "val=$`echo $1`"

  if [ "$val" = "" ]
  then
    echo "ERROR: $1 is not set"
    echo "ERROR: $1 is not set" >&3
    exit 1
  fi
  echo "$1=$val"
}

checkFile()
{
  if [ "$1" = "" ]
  then
    echo "ERROR: checkFile: empty parameter"
    echo "ERROR: checkFile: empty parameter" >&3
    exit 1
  fi

  if [ ! -f $1 ]
  then
    echo "ERROR: file $1 does not exist"
    echo "ERROR: file $1 does not exist" >&3
    exit 1
  fi
}

checkDir()
{
  if [ "$1" = "" ]
  then
    echo "ERROR: checkDir: empty parameter"
    echo "ERROR: checkDir: empty parameter" >&3
    exit 1
  fi

  if [ ! -d $1 ]
  then
    echo "ERROR: dir $1 does not exist"
    echo "ERROR: dir $1 does not exist" >&3
    exit 1
  fi
}

