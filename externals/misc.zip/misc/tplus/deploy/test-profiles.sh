#!/bin/sh
# $Id: test-profiles.sh,v 1.11 2007/06/25 10:55:08 kovyale Exp $
#
# Run on BUILD PC
#

. ./common.sh
. ./test-funcs.sh
. ./env.sh

#
# T+
#

checkVar ENVIRONMENT
checkVar TPLUS_LAYERS
checkVar WAR_PROFILES

for LAYER in ${TPLUS_LAYERS}
do
  checkFile $BUILD_HOME/$TAG/tplus/profiles/abfx-${ENVIRONMENT}/${LAYER}.properties
done

for SKIN in ${WAR_PROFILES}
do
  checkFile $BUILD_HOME/$TAG/tplus/profiles/abfx-${ENVIRONMENT}/${SKIN}.properties
done

#
# FX+
#

if [ "${BUILD_FXPLUS}" = "Y" ]
then
	checkFile $BUILD_HOME/$TAG/fxplus/config/${ENVIRONMENT}.xml
fi

#
# FXO
#
if [ "${BUILD_FXPLUSOPTIONS}" = "Y" ]
then
    checkFile $BUILD_HOME/$TAG/fxplusoptions/profiles/${ENVIRONMENT}.properties
fi
