#!/bin/sh
#
# $Id: compile-reflex.sh,v 1.7 2008/10/29 16:38:52 fxplusAutoBuild Exp $
#

. ./common.sh
. ./env.sh

(
cd $BUILD_HOME/$TAG/fxpricing
echo ' Building fxpricing' >&3
$ANT_BIN/ant -Dbuild.version=$TAG -Dfxpricing.environment=$ENVIRONMENT \
             -Djdk.home.1.4=$JAVA14_HOME -Djdk.home.1.5=$JAVA_HOME all
)
if [ $? -ne 0 ] ;then
    echo FAILED >&3
    exit 1
fi

echo " Done. `date`" >&3
