#!/bin/ksh
#
# wlc creation script
#
# This script will build you a ksh script which calls all the sql scripts to build a new wlc
# Howard Guess
# 29th Dec 2004
# 
#
# Health Warning : 001-drop-user.sql . This will drop a schema. If you are creating
# a new schema comment out this command. You dont want to drop the wrong exists schema !
#
# Usage : 
# check these env variables. eg.
# TPLUS_HOME=/export/home/guesho/Projects/mainline/tplus
# FXPLUS_HOME=/export/home/guesho/Projects/mainline/fxplus
# FXOP_HOME=$HOME/fxplusoptions-${BUILD_TAG_FXPLUSOPTIONS}
# they should be fine as is
#
# Run ./wlc.sh <WLC name>
# where <WLC name> is the reuters code of the wlc you wish to create, eg sabx
# Check log dir



# set ABORT_TOOL to true
set_abort()
{
	ABORT_TOOL=1
}

# checks if ABORT_TOOL is true
check_abort()
{
	if [[ $ABORT_TOOL = 1 ]]; then
		echo "$0: ERROR OCURRED, check logfile for more information" >&3
		exit 1
	fi
}

# check for the existance of all the properties files
validate_environment()
{
	# this func check existing of some property files, it's depends on 
	# DEPLOY_TPLUS, DEPLOY_FXPLUS, DEPLOY_FXPLUSOPTIONS variables from env.sh

	# this is mandatory profile
        local property_files="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"

	if [[ "$DEPLOY_TPLUS" = "Y" ]]; then
        	property_files="$property_files $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
	fi

	if [[ "$DEPLOY_FXPLUS" = "Y" ]] || [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]]; then
        	property_files="$property_files $FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
	fi

	# Note: only layer1 supported for fxplusoptions (layer1 means dbag).
	if [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]] && [[ "$LAYER" = "dbag" ]]; then
		property_files="$property_files $FXOP_HOME/sql/profile/${PROFILE}.options.properties"
	fi

        for property_file in $property_files; do
                if [[ ! -r $property_file ]] ; then
                        echo "FAILED: property file $property_file have not been found." 
                        set_abort;
                fi
        done
}

# get value of preference from property file
get_prop_val()
{
        local prop=$1
        local file=$2
	# using tr for converting windows line end (if any) to unix. "0x0D0x0A" -> "0x0A" 
        result=`grep "^${prop}=" "$file" | tr -d '\r' | awk -F= '{ print $2 }'`
        echo "$result"
}

# test the oracle connection is correct
test_oracle_connection()
{
	local conn="$1@$2"
        local result=`sqlplus $conn 2>&1 <<!
exit
!
`
	# BUG11006 fix, check if sqlplus has been running properly
	local retcode=$?
	if [[ $retcode != 0 ]]; then
		echo "FAILED: test_oracle_connection: error running sqlplus: $result"
		set_abort;
	else
        	local successful=`echo ${result} | grep ORA `
        	if [[ -n $successful ]] ; then
                	echo "FAILED: test_oracle_connection: unsucessful connection: \"sqlplus $conn\": $successful" 
                	set_abort;
		fi
        fi
}

gen_runtime()
{
	# database
	local list_of_sql=`ls $SQL_PATH/database/runtime/${PROFILE}/*.sql.runtime`
	if [[ -z $list_of_sql ]]; then
		echo "WARNING: $SQL_PATH/database/runtime/${PROFILE}/*.sql.runtime scripts not found." 
	fi
	for sql_ddl in $list_of_sql
	do
		local basename=`basename $sql_ddl`
		cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}sqlplus -s ${DBAUSERID}/${DBAUSPASSWORD}@$DATABASETNS @ ${sql_ddl} | tee \$LOG
${COMMENT}check_for_errors;
EOF
	done
	
        # ddl
	local list_of_sql=`ls $SQL_PATH/ddl/runtime/${PROFILE}/*.sql.runtime`

	if [[ -z $list_of_sql ]]; then
		echo "WARNING: $SQL_PATH/ddl/runtime/${PROFILE}/*.sql.runtime scripts not found." 
	fi
	for sql_ddl in $list_of_sql
	do
		local basename=`basename $sql_ddl`
                local foundsyn=`echo $basename | grep -i synonym  | wc -l | sed -e "s/ //g"`
                if [[ $foundsyn = 0 ]]; then
			cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}sqlplus -s $USERID/$PASSWORD@$DATABASETNS @ ${sql_ddl} | tee \$LOG
${COMMENT}check_for_errors;
EOF
		else
                        cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}sqlplus -s $USERID_AP/$PASSWORD_AP@$DATABASETNS @ ${sql_ddl} | tee \$LOG
${COMMENT}check_for_errors;
${COMMENT}sqlplus -s $USERID_RO/$PASSWORD_RO@$DATABASETNS @ ${sql_ddl} | tee \$LOG
${COMMENT}check_for_errors;
EOF
               fi
        done
        
        # staticdata
	local list_of_sql=`ls $SQL_PATH/staticdata/runtime/${PROFILE}/*.sql.runtime`
	if [[ -z $list_of_sql ]]; then
		echo "WARNING: $SQL_PATH/staticdata/runtime/${PROFILE}/*.sql.runtime scripts not found." 
	fi
	for sql_ddl in $list_of_sql
	do
		local basename=`basename $sql_ddl`
		cat >> "${KSH_SCRIPT}" <<EOF
${COMMENT}sqlplus -s $USERID/$PASSWORD@$DATABASETNS @ ${sql_ddl} | tee \$LOG
${COMMENT}check_for_errors;
EOF
       done 

        # finally runtime
        list_of_sql=`ls $SQL_PATH/finally/runtime/${PROFILE}/*.sql.runtime`
        if [[ -z $list_of_sql ]]; then
                echo "WARNING: $SQL_PATH/finally/runtime/${PROFILE}/*.sql.runtime scripts not found."
        fi
        for sql_patch in $list_of_sql
        do
                cat >> "${KSH_SCRIPT}" <<EOF
(cd $SQL_PATH ; sqlplus -s $USERID/$PASSWORD@$DATABASETNS @ ${sql_patch}) | tee \$LOG
EOF
        done

}



### 
### Main start of script
###

# check arguments

if [ "x$1" = "x" ]
then
  echo ""
  echo "Usage:"
  echo "  $0 <WLC name>"
  echo ""
  echo "  EG:  $0 sabx"
  echo ""
  exit
fi

WLC=`echo $1 | tr -s '[:upper:]' '[:lower:]'`

# suck in environment variables
. ./common.sh
. ./env.sh
. ./env-prod-copy.sh

# set up project directories, where it was deployed
TPLUS_HOME=/export/home/guesho/Projects/master_patch_validator/tplus
FXPLUS_HOME=/export/home/guesho/Projects/master_patch_validator/fxplus
FXOP_HOME=${HOME}/fxplusoptions-${BUILD_TAG_FXPLUSOPTIONS}

ABORT_TOOL=0

# generate ddl for wlc layer 
for LAYER in $WLC; do
	PROFILE="abfx-$ENVIRONMENT/$LAYER"

	# check needed property files
	validate_environment;
	check_abort;

	# default ant args
	ANT_ARGS="-Djustgen=true"
	
	if [[ "$DEPLOY_TPLUS" = "Y" ]]; then
		ANT_ARGS="$ANT_ARGS -Dtplus=true -Dtplushome=$TPLUS_HOME/sql -Dvpdhome=$TPLUS_HOME/vpd  -Dabfxenv=abfx-$ENVIRONMENT"
	fi

	if [[ "$DEPLOY_FXPLUS" = "Y" ]]; then
		ANT_ARGS="$ANT_ARGS -Dfxplus=true -Dfxplushome=$FXPLUS_HOME/sql"
	fi

	if [[ "$DEPLOY_FXPLUSOPTIONS" = "Y" ]] && [[ "$LAYER" = "dbag" ]]; then
		ANT_ARGS="$ANT_ARGS -Doptions=true -Doptionshome=$FXOP_HOME/sql"
	fi

	ANT_ARGS="$ANT_ARGS -Dlayerids=${PROFILE}"
	echo "Running patch target with options: $ANT_ARGS"
	( cd $TPLUS_HOME/sql ; $ANT_BIN/ant $ANT_ARGS )
	if [[ $? -ne 0 ]]; then
		echo "FAILED: could not make runtime patches for profile: $PROFILE" 
		echo "FAILED: $ANT_BIN/ant $ANT_ARGS patch"
		echo `date` " $0 finished with errors" 
		exit 1
	fi

	DATABASETNS=`get_prop_val database.tnsname "$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"`

	if [[ $DEPLOY_TPLUS = "Y" ]]; then
		PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.database.properties"
		DBAUSERID=`get_prop_val "database.dba.username" $PROPERTY_FILE`
		DBAUSPASSWORD=`get_prop_val "database.dba.password" $PROPERTY_FILE`
		PARENTTPLUSUSERID=`get_prop_val "parent.tplus.owner.username" $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties`
		PARENTTPLUSUSPASSWORD=`get_prop_val "parent.tplus.owner.password" $TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties`
		TPLUSUSERID=`get_prop_val tplus.owner.username $PROPERTY_FILE`
		TPLUSUSPASSWORD=`get_prop_val tplus.owner.password $PROPERTY_FILE`
		PROPERTY_FILE="$TPLUS_HOME/sql/profile/${PROFILE}.tplus.properties"
		TPLUSUSERID_AP=`get_prop_val tplus.ap.username $PROPERTY_FILE`
		TPLUSUSPASSWORD_AP=`get_prop_val tplus.ap.password $PROPERTY_FILE`
		TPLUSUSERID_RO=`get_prop_val tplus.ro.username $PROPERTY_FILE`
		TPLUSUSPASSWORD_RO=`get_prop_val tplus.ro.password $PROPERTY_FILE`
		for CONNECTION in "${DBAUSERID}/${DBAUSPASSWORD}"  "${PARENTTPLUSUSERID}/${PARENTTPLUSUSPASSWORD}"
		do
			test_oracle_connection $CONNECTION ${DATABASETNS}
		done
		check_abort;
	fi

	if [[ "${DEPLOY_FXPLUS}" = "Y" ]] || [[ "${DEPLOY_FXPLUSOPTIONS}" = "Y" ]]; then
		PROPERTY_FILE="$FXPLUS_HOME/sql/profile/${PROFILE}.fxplus.properties"
		FXPLUSUSERID=`get_prop_val fxplus.owner.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD=`get_prop_val fxplus.owner.password $PROPERTY_FILE`
		PARENTFXPLUSUSERID=`get_prop_val "parent.fxplus.owner.username" $PROPERTY_FILE`
		PARENTFXPLUSUSPASSWORD=`get_prop_val "parent.fxplus.owner.password" $PROPERTY_FILE`
		FXPLUSUSERID_AP=`get_prop_val fxplus.ap.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD_AP=`get_prop_val fxplus.ap.password $PROPERTY_FILE`
		FXPLUSUSERID_RO=`get_prop_val fxplus.ro.username $PROPERTY_FILE`
		FXPLUSUSPASSWORD_RO=`get_prop_val fxplus.ro.password $PROPERTY_FILE`
		for CONNECTION in "${PARENTFXPLUSUSERID}/${PARENTFXPLUSUSPASSWORD}" 
		do
			test_oracle_connection $CONNECTION $DATABASETNS
		done
		check_abort;
	fi

	# start script generation
	KSH_SCRIPT="`echo ${PROFILE}|sed -e "s/\//-/g"`.ksh"
	if [[ -r "${KSH_SCRIPT}" ]]; then
		mv "${KSH_SCRIPT}" "${KSH_SCRIPT}.old"
	fi
	touch "${KSH_SCRIPT}"
	if [[ "$?" -ne "0" ]]; then
		echo "FAILED: could not create ${KSH_SCRIPT}"
		echo `date` " $0 finished with errors"
		exit 1
	fi
	chmod 700 "${KSH_SCRIPT}"
	cat > "${KSH_SCRIPT}" <<EOF
#!/bin/ksh
LOG="$CURRENT_DIR/log/\$0.log"
check_for_errors()
{
	error=\`grep "ORA-" \$LOG | wc -l | sed -e "s/^ *//"\`
	if [[ \$error != 0 ]] ;  then  
		echo 'ERROR : Oracle errors found in last script.'
		echo 'Do you want to continue or exit [^C to cancel ] [ RETURN to continue] '
		read x
	fi
}

#
echo "This operation WILL DESTROY the current $LAYER schema."
read ANS?'Are you sure you wnat to continue (y/n)? '

RESULT=\`echo \${ANS:-N} | cut -c1 | tr 'Y' 'y'\`

if [[ "\$RESULT" != "y" ]]
then
  exit
fi

# Script to create a new wlc 
# Autogenerated by $TPLUS_HOME/deploy/$0
# Created : ${START_DATETIME}

# load up logging
. ./common.sh

(
EOF

	# Tplus ddl create
	if [[ "${DEPLOY_TPLUS}" = "Y" ]]; then
		echo "echo 'TPLUS DDL'" >> "${KSH_SCRIPT}"
		# set up "gen_runtime" variables
		USERID=$TPLUSUSERID
		PASSWORD=$TPLUSUSPASSWORD
		USERID_AP=$TPLUSUSERID_AP
		PASSWORD_AP=$TPLUSUSPASSWORD_AP
		USERID_RO=$TPLUSUSERID_RO
		PASSWORD_RO=$TPLUSUSPASSWORD_RO
		SQL_PATH="$TPLUS_HOME/sql"
		APP_NAME="TPLUS"
		gen_runtime;
	fi
	# Fxplus ddl
	if [[ "${DEPLOY_FXPLUS}" = "Y" ]]; then
		echo "echo 'FXPLUS DDL'" >> "${KSH_SCRIPT}"
		# set up "gen_runtime" variables
		USERID=$FXPLUSUSERID
		PASSWORD=$FXPLUSUSPASSWORD
		USERID_AP=$FXPLUSUSERID_AP
		PASSWORD_AP=$FXPLUSUSPASSWORD_AP
		USERID_RO=$FXPLUSUSERID_RO
		PASSWORD_RO=$FXPLUSUSPASSWORD_RO
		SQL_PATH="$FXPLUS_HOME/sql"
		APP_NAME="FXPLUS"
		gen_runtime;
	fi
	# FXoptions Patches
	if [[ "${DEPLOY_FXPLUSOPTIONS}" = "Y" ]] && [[ "$LAYER" = "dbag" ]]; then
		# only for "dbag" skin
		echo "echo 'FXPLUS Patches'" >> "${KSH_SCRIPT}"
		# set up "gen_runtime" variables
		USERID=$FXPLUSUSERID
		PASSWORD=$FXPLUSUSPASSWORD
		USERID_AP=$FXPLUSUSERID_AP
		PASSWORD_AP=$FXPLUSUSPASSWORD_AP
		USERID_RO=$FXPLUSUSERID_RO
		PASSWORD_RO=$FXPLUSUSPASSWORD_RO
		SQL_PATH="$FXOP_HOME/sql"
		APP_NAME="FXOP"
		gen_runtime;
	fi


echo '' >> "${KSH_SCRIPT}"
echo ') >&3' >> "${KSH_SCRIPT}"

echo "Database patching script $KSH_SCRIPT created." >&3
done
echo `date`" $0 finished successfully"

# end
