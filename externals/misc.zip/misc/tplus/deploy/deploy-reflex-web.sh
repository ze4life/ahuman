#!/bin/sh
#
# $Id: deploy-reflex-web.sh,v 1.7 2008/10/29 12:59:20 fxplusAutoBuild Exp $
#

. ./common.sh
. ./env.sh

if [ ! -f "fxpricing-redist-$TAG.tgz" ]; then
    exit 1
fi

# exit on error
set -e

FXPRICING_TMP=$HOME/deploy/tmp/fxpricing-$TAG
mkdir -p $FXPRICING_TMP
gzip -d -c fxpricing-redist-$TAG.tgz | ( cd $FXPRICING_TMP && tar xf - )
if [ $? -ne 0 ]; then
    exit 1
fi

$TOMCAT_HOME/bin/shutdown.sh

rm -rf $TOMCAT_HOME/webapps/reflexII \
       $TOMCAT_HOME/webapps/reflexII-docs \
       $TOMCAT_HOME/webapps/reflexII-thirdparty \
       $TOMCAT_HOME/webapps/fxpricing 
rm -rf $TOMCAT_HOME/webapps/work/Catalina
cp -rp $FXPRICING_TMP/*.war $TOMCAT_HOME/webapps
ln -s fxpricing $TOMCAT_HOME/webapps/reflexII

# clear tmp
rm -rf $FXPRICING_TMP

$TOMCAT_HOME/bin/startup.sh
