---------------------------------------------
DEF FILENAME=001-compile-invalid-object.sql
--
-- Description: Discovers and recompiles any
--              invalid objects within the
--              given schema
--
--
-- History
-- When          Who       What
-- 24 Feb 2004   CEJ       Initial Revision
----------------------------------------------
WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME
set echo off
set pages 0
set line 500
set heading off
set feedback off
SPOOL finally\runtime\comiple.sql.@layer.id@.runtime

SELECT  'ALTER '||DECODE(object_type,'PACKAGE BODY','PACKAGE',object_type)||' '||object_name||' COMPILE '||DECODE(object_type,'PACKAGE BODY','BODY;',';')
FROM    user_objects
WHERE   status = 'INVALID';

SELECT 'EXIT;' FROM DUAL;
SPOOL OFF
START finally\runtime\comiple.sql.@layer.id@.runtime

PROMPT End of patch : &FILENAME

EXIT;
