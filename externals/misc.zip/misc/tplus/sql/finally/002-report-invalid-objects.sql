---------------------------------------------
DEF FILENAME=002-report-invalid-object.sql
--
-- Description: Prints out a report of invalid
--              objects - also writes out
--              to a log file
--
--
-- History
-- When          Who       What
-- 24 Feb 2004   CEJ       Initial Revision
----------------------------------------------
WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME
SET SERVEROUTPUT ON
SPOOL finally\runtime\@layer.id@-INVALID-OBJECTS.txt
DECLARE
    CURSOR c_get_invalid_objects
    IS
        SELECT object_type,
               object_name
        FROM   user_objects
        WHERE  status = 'INVALID';
BEGIN
    DBMS_OUTPUT.ENABLE(1000000);

    FOR i IN c_get_invalid_objects LOOP

        DBMS_OUTPUT.PUT_LINE ('The '||i.object_type||' '||i.object_name||' is invalid');

    END LOOP;
END;
/
SPOOL OFF
PROMPT End of patch : &FILENAME

EXIT;