--
DEF FILENAME=001-drop-user.sql
--
-- Description: Drops existing tplus users
--
--
-- History
-- When         Who     Reason
-- 16/Feb/2004  CEJ     Initial Revision
--

PROMPT Start of file : &FILENAME

drop user @tplus.owner.username@ cascade;
drop user @tplus.owner.username@_ap cascade;
drop user @tplus.owner.username@_ro cascade;
drop role @tplus.owner.username@_rw_role;
drop role @tplus.owner.username@_ro_role;
drop role @tplus.owner.username@_module_role;

PROMPT End of file : &FILENAME

EXIT;