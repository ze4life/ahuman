--
DEF FILENAME=002-create-user.sql
--
-- Description: Creates all the required users
--              and roles for the tplus database
--
--
-- History
-- When         Who     Reason
-- 16/Feb/2004  CEJ     Initial Revision
--

PROMPT Start of file : &FILENAME

create user @tplus.owner.username@ identified by @tplus.owner.password@ default tablespace @database.data.tablespace@;
alter user @tplus.owner.username@ temporary tablespace TEMP;
REM grant create session, dmg_owner_role to @tplus.owner.username@;
grant create type  to  @tplus.owner.username@ ;

grant dmg_connect, dmg_owner_role to @tplus.owner.username@;
grant create type  to  @tplus.owner.username@ ;


alter user @tplus.owner.username@ quota unlimited on @database.data.tablespace@;
alter user @tplus.owner.username@ quota unlimited on @database.index.tablespace@;

create role @tplus.owner.username@_rw_role;
REM Oracle automatically grants this role to the creating user with admin option. So revoke it
revoke @tplus.owner.username@_rw_role from @database.dba.username@;

create role @tplus.owner.username@_ro_role;
REM Oracle automatically grants this role to the creating user with admin option. So revoke it
revoke @tplus.owner.username@_ro_role from @database.dba.username@;

REM This role is stuff that TPLUS grants to the other modules (eg TPLUS_CLIENT table read access)
create role @tplus.owner.username@_module_role;
REM Oracle automatically grants this role to the creating user with admin option. So revoke it
revoke @tplus.owner.username@_module_role from @database.dba.username@;

create user @tplus.ap.username@ identified by @tplus.ap.password@ default tablespace @database.data.tablespace@;
alter  user @tplus.ap.username@ temporary tablespace TEMP;
REM grant create session, create synonym to @tplus.owner.username@_ap;
grant dmg_connect, create synonym to @tplus.ap.username@;
grant @tplus.owner.username@_ro_role, @tplus.owner.username@_rw_role to @tplus.ap.username@;

create user @tplus.ro.username@ identified by @tplus.ro.password@ default tablespace @database.data.tablespace@;
alter user @tplus.ro.username@ temporary tablespace TEMP;
REM grant create session, create synonym to @tplus.ro.username@;
grant dmg_connect, create synonym to @tplus.ro.username@;
grant @tplus.owner.username@_ro_role to @tplus.ro.username@;

PROMPT End of file : &FILENAME

EXIT;
