--
DEF FILENAME=003-verify-accounts.sql
--
-- Description: Check the ant variables 
--
--
-- History
-- When         Who     Reason
-- 30/12/2004   Hg      Initial Revision
--

WHENEVER SQLERROR EXIT

PROMPT Start of file : &FILENAME


prompt Attempt Connection to the Tplus ap account...
connect @tplus.ap.username@/@tplus.ap.password@#@database.tnsname@
show user

prompt Attempt Connection to the Tplus ro account...
connect @tplus.ro.username@/@tplus.ro.password@#@database.tnsname@
show user


prompt Attempt Connection to the Tplus schema owner...
connect @tplus.owner.username@/@tplus.owner.password@#@database.tnsname@
show user


prompt Check Tablespaces exists and are accessible ...

set heading off

select 'SUCCESSFUL : Tablespace @database.data.tablespace@ is accessible.' 
from user_ts_quotas where tablespace_name = upper('@database.data.tablespace@')
and user = upper('@tplus.owner.username@')
union
select 'ORA-ERROR : Tablespace @database.data.tablespace@ is not accessible.'
from dual
where not exists ( select null from user_ts_quotas 
                   where tablespace_name = upper('@database.data.tablespace@')
                   and user = upper('@tplus.owner.username@'));

select 'SUCCESSFUL : Tablespace @database.index.tablespace@ is accessible.' 
from user_ts_quotas where tablespace_name = upper('@database.index.tablespace@')
and user = upper('@tplus.owner.username@')
union
select 'ORA-ERROR : Tablespace @database.index.tablespace@ is not accessible.'
from dual
where not exists ( select null from user_ts_quotas 
                   where tablespace_name = upper('@database.index.tablespace@')
                   and user = upper('@tplus.owner.username@'));

prompt Attempt Connection to the Tplus parent (level 1) schema owner...
connect @parent.tplus.owner.username@/@parent.tplus.owner.password@#@database.tnsname@
show user


prompt Check to see if client exists in level 1

select 'SUCCESSFUL : Client @layer.client.server.id@ ('||full_name||') exists in level 1.'
from tplus_client
where CLIENT_ID = '@layer.client.server.id@'
and user = upper('@parent.tplus.owner.username@')
union
select 'ORA-ERROR : Client @layer.client.server.id@ does not exist in level 1.'
from dual
where not exists (select null from tplus_client
                  where CLIENT_ID = '@layer.client.server.id@'
                  and user = upper('@parent.tplus.owner.username@'));

prompt
prompt NOTE : The TPLUS CLIENT record must have previously been created and have a CLIENT_TYPE = WLC 
prompt Also the client record must have FX/Access and FX/Terms granted in the tplus PERMISSIONS record.
prompt

accept x char prompt 'Press [RETURN] to continue ...'

PROMPT End of file : &FILENAME

EXIT;
