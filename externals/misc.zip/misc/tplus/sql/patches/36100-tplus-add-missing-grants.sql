----------------------------------------------------
DEF FILENAME=36100-tplus-add-missing-grants.sql
--
-- History
-- When         Who             Reason
-- 14th oct	HG		BUG10472
--                              tplus tables introduced in 35 can not be seen by fxplus

PROMPT Start of file : &FILENAME

WHENEVER SQLERROR EXIT

grant select on  entities    to  @fxplus.owner.username@ with grant option;
grant select on  operations  to  @fxplus.owner.username@ with grant option;
grant select on  permissions to  @fxplus.owner.username@ with grant option;


INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 36100, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT;


