----------------------------------------------------
DEF FILENAME=36004-tplus-patches-index.sql
--
-- History
-- When         Who             Reason
-- 16thFeb      HG              BUG12507: Ensure indexing is correct on database_patches (correction to previous patch) 
--

PROMPT Start of file : &FILENAME

WHENEVER SQLERROR CONTINUE;

set term off
ALTER TABLE DATABASE_PATCHES DROP PRIMARY KEY
/
set term on

WHENEVER SQLERROR EXIT

CREATE UNIQUE INDEX PK_DATABASE_PATCHES
ON  DATABASE_PATCHES (DATABASEUSERID,FILENAME,VERSIONNUMBER)
TABLESPACE @database.index.tablespace@
/

ALTER TABLE DATABASE_PATCHES
ADD CONSTRAINT PK_DATABASE_PATCHES
PRIMARY KEY(DATABASEUSERID,FILENAME,VERSIONNUMBER) USING INDEX
/

INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 36004, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT;
