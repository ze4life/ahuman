--
DEF FILENAME=37001-tplus-aud-layout-tables-triggers.sql
--
-- Description: Add audit tables to gui layout
-- Parameters:
--
-- History
-- When         Who      Reason
-- 06/12/2004   HG       BUG8695 There are no AUD Tables on layout tables
--

WHENEVER SQLERROR EXIT
PROMPT Start of patch : &FILENAME


CREATE TABLE aud_tab_layout
    (aud_action                    VARCHAR2(10),
    aud_last_updated_by            VARCHAR2(48),
    aud_update_time                DATE,
    tab_id                         NUMBER(6,0) NOT NULL,
    user_id                        VARCHAR2(48) NOT NULL,
    tab_name                       VARCHAR2(30) NOT NULL,
    tab_status                     VARCHAR2(30) NOT NULL,
    tab_number                     NUMBER(2,0) NOT NULL,
    last_updated_by                VARCHAR2(48) NOT NULL,
    update_time                    DATE DEFAULT (SYSDATE)   NOT NULL)
  TABLESPACE  @database.data.tablespace@;

CREATE TABLE aud_screen_layout_prod_attrs
    (aud_action                    VARCHAR2(10),
    aud_last_updated_by            VARCHAR2(48),
    aud_update_time                DATE,
    tab_id                         NUMBER(6,0) NOT NULL,
    screen_id                      VARCHAR2(25) NOT NULL,
    name                           VARCHAR2(50) NOT NULL,
    value                          VARCHAR2(400),
    order_in_javascript            NUMBER(3,0) NOT NULL)
  TABLESPACE  @database.data.tablespace@;


CREATE OR REPLACE TRIGGER BUD_TAB_LAYOUT
BEFORE
UPDATE OR DELETE ON TAB_LAYOUT
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO AUD_TAB_LAYOUT (
       aud_action,
       aud_last_updated_by,
       aud_update_time,
       tab_id,
       user_id,
       tab_name,
       tab_status,
       tab_number,
       last_updated_by,
       update_time)
    VALUES (
       AUD_ACTION,
       AUD_LAST_UPDATED_BY,
       AUD_UPDATE_TIME,
       :OLD.tab_id,
       :OLD.user_id,
       :OLD.tab_name,
       :OLD.tab_status,
       :OLD.tab_number,
       :OLD.last_updated_by,
       :OLD.update_time);
END;
/

CREATE OR REPLACE TRIGGER BUD_SCREEN_LAYOUT_PROD_ATTRS
BEFORE
UPDATE OR DELETE ON SCREEN_LAYOUT_PRODUCT_ATTRIBS
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := user;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO AUD_SCREEN_LAYOUT_PROD_ATTRS
     ( aud_action,
       aud_last_updated_by,
       aud_update_time,
       tab_id, 
       screen_id,
       name,
       value,
       order_in_javascript)
    VALUES (
       AUD_ACTION,
       AUD_LAST_UPDATED_BY,
       AUD_UPDATE_TIME,
       :OLD.tab_id, 
       :OLD.screen_id,
       :OLD.name,
       :OLD.value,
       :OLD.order_in_javascript);
END;
/


GRANT SELECT ON aud_tab_layout TO @tplus.owner.username@_ro_role;
GRANT SELECT ON aud_screen_layout_prod_attrs TO @tplus.owner.username@_ro_role;

GRANT SELECT,INSERT ON aud_tab_layout TO @tplus.owner.username@_rw_role;
GRANT SELECT,INSERT ON aud_screen_layout_prod_attrs TO @tplus.owner.username@_rw_role;


INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 37001, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME
EXIT;
