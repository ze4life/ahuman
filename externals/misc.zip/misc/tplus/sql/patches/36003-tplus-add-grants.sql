----------------------------------------------------
DEF FILENAME=36003-tplus-add-grants.sql
--
-- History
-- When         Who             Reason
-- 29thOct	HG		BUG 8874 Allow new 3.5 tplus tables to be seen by fxplus ap and ro accounts. needed for coldfusion reporting
--                              

PROMPT Start of file : &FILENAME

WHENEVER SQLERROR EXIT

grant select on  entities    to  @tplus.owner.username@_MODULE_ROLE;
grant select on  operations  to  @tplus.owner.username@_MODULE_ROLE;
grant select on  permissions to  @tplus.owner.username@_MODULE_ROLE;


INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 36003, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT;

