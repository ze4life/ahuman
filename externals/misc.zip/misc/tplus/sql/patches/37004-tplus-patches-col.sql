--
DEF FILENAME=37004-tplus-patches-col.sql
--
-- Description:  Ensure database_patches has the correct col lengths
-- Parameters:
--
-- History
-- When         Who      Reason
-- 10/03/2005   HG       BUG12981:database_patches table may have wrong data lengths
--

WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME

ALTER TABLE DATABASE_PATCHES MODIFY (UPDATEUSERID   VARCHAR2(32));
ALTER TABLE DATABASE_PATCHES MODIFY (DATABASEUSERID VARCHAR2(32));

INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 37004, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME

EXIT;

