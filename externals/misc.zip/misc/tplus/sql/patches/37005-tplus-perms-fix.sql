--
DEF FILENAME=37005-tplus-perms-fix.sql
--
-- Description:  remove fxplus access for fxspp clients
-- Parameters:
--
-- History
-- When         Who      Reason
-- 10/03/2005   HG       
--

WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME

delete from permissions where entity_id = 7027 and operation = 'FX/Access' and user = 'TP1DBAG';
delete from permissions where entity_id = 7049 and operation = 'FX/Access' and user = 'TP1DBAG';


INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 37005, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME

EXIT;

