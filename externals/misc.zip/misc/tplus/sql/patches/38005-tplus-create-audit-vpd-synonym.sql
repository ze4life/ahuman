-----------------------------------------------------
DEF FILENAME=38005-tplus-create-audit-vpd-synonym.sql
--
-- Description: 
-- Create symonym for vpd.audit_trail
-- --------------------------------------------------

PROMPT Start of file : &FILENAME

WHENEVER SQLERROR EXIT

create or replace synonym AUDIT_TRAIL for @master.vpd.username@.AUDIT_TRAIL;

create or replace synonym AUDIT_TRAIL_SEQ for @master.vpd.username@.AUDIT_TRAIL_SEQ;

INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 38005, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT
