--
DEF FILENAME=36001-tplus-archive-database-patches.sql
--
-- Description: Tidy up the DATABASE_PATCHES table. Remove pre 3.5 patches by looking at the timestamp of the first 35 patch
-- Also add unique index and primary key to database_patches 
--
-- History
-- When         Who                  Reason
-- 5 Nov 2004   Howard Guess         Initial Revision


WHENEVER SQLERROR CONTINUE

prompt
prompt Create DATABASE_PATCHES table
prompt

set term off
CREATE TABLE database_patches_archive
    (applicationname                VARCHAR2(12),
    filename                       VARCHAR2(128),
    versionnumber                  NUMBER(*,0),
    updatetime                     DATE,
    updateuserid                   VARCHAR2(32),
    databaseuserid                 VARCHAR2(32))
  PCTFREE     10
  INITRANS    1
  MAXTRANS    255
  TABLESPACE   @database.data.tablespace@
  STORAGE   (
    INITIAL     131072
  )
/

set term on

WHENEVER SQLERROR EXIT

INSERT INTO database_patches_archive
SELECT * FROM database_patches
/

DELETE FROM database_patches
/

prompt
prompt INSERT back into DATABASE_PATCHES must recent version of patch applied
prompt Patches must be version 3.5 or 3.6
prompt

INSERT INTO database_patches
SELECT distinct applicationname,filename,versionnumber,updatetime,updateuserid,databaseuserid
FROM   database_patches_archive
WHERE    (databaseuserid,filename,versionnumber,updatetime)
                  in  (SELECT databaseuserid,filename,versionnumber,MAX(updatetime)
                       FROM database_patches_archive
                       GROUP BY databaseuserid,filename,versionnumber)
/

prompt
prompt Add unique index and primary key
prompt

CREATE UNIQUE INDEX pk_database_patches
ON  database_patches (databaseuserid,filename,versionnumber)
TABLESPACE  @database.index.tablespace@
/

ALTER TABLE database_patches
ADD CONSTRAINT pk_database_patches
PRIMARY KEY(databaseuserid,filename,versionnumber) USING INDEX
/


INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 36001, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT;
