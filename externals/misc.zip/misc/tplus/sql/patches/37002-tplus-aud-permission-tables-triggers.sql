--
DEF FILENAME=37002-tplus-aud-permission-tables-triggers.sql
--
-- Description: Add audit tables to permission table
-- Parameters:
--
-- History
-- When         Who      Reason
-- 09/03/2006   CEJ       BUG8695 There are no AUD Tables on permissions table
--

WHENEVER SQLERROR EXIT
PROMPT Start of patch : &FILENAME

CREATE TABLE AUD_PERMISSIONS
(
  AUD_ACTION             VARCHAR2(10),
  AUD_LAST_UPDATED_BY    VARCHAR2(48),
  AUD_UPDATE_TIME        DATE,
  ENTITY_ID              NUMBER(7),
  OPERATION              VARCHAR2(512),
  ACTION                 CHAR(1),
  LAST_UPDATED_BY        VARCHAR2(48),
  UPDATE_TIME            DATE
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCACHE
NOPARALLEL;

CREATE TABLE AUD_OPERATIONS
(
  AUD_ACTION             VARCHAR2(10),
  AUD_LAST_UPDATED_BY    VARCHAR2(48),
  AUD_UPDATE_TIME        DATE,
  OPERATION              VARCHAR2(512),
  DESCRIPTION            VARCHAR2(50),
  LAST_UPDATED_BY        VARCHAR2(48),
  UPDATE_TIME            DATE
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCACHE
NOPARALLEL;


CREATE OR REPLACE TRIGGER BUD_PERMISSIONS
BEFORE
UPDATE OR DELETE ON PERMISSIONS
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO AUD_PERMISSIONS (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        ENTITY_ID,
        OPERATION,
        ACTION,
        LAST_UPDATED_BY,
        UPDATE_TIME)
    VALUES (
       AUD_ACTION,
       AUD_LAST_UPDATED_BY,
       AUD_UPDATE_TIME,
       :OLD.ENTITY_ID,
       :OLD.OPERATION,
       :OLD.ACTION,
       :OLD.LAST_UPDATED_BY,
       :OLD.UPDATE_TIME);
END;
/

CREATE OR REPLACE TRIGGER BUD_OPERATIONS
BEFORE
UPDATE OR DELETE ON OPERATIONS
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := user;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO AUD_OPERATIONS
     (  AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        OPERATION,
        DESCRIPTION,
        LAST_UPDATED_BY,
        UPDATE_TIME)
    VALUES (
       AUD_ACTION,
       AUD_LAST_UPDATED_BY,
       AUD_UPDATE_TIME,
       :OLD.OPERATION,
       :OLD.DESCRIPTION,
       :OLD.LAST_UPDATED_BY,
       :OLD.UPDATE_TIME);
END;
/


GRANT SELECT ON AUD_PERMISSIONS TO @tplus.owner.username@_ro_role;
GRANT SELECT ON AUD_OPERATIONS TO @tplus.owner.username@_ro_role;

GRANT SELECT,INSERT ON AUD_PERMISSIONS TO @tplus.owner.username@_rw_role;
GRANT SELECT,INSERT ON AUD_OPERATIONS TO @tplus.owner.username@_rw_role;


INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 37002, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME
EXIT;

