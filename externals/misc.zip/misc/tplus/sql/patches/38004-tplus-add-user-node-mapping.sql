-----------------------------------------------------
DEF FILENAME=38004-tplus-add-user-node-mapping.sql
--
-- Description: 
-- Create symonym for vpd.audit_trail
-- --------------------------------------------------

PROMPT  &FILENAME migrated to VPD

WHENEVER SQLERROR EXIT

-- the sequence has been dropped and re-created by a vpd patch, so restore the grant from vpd_grants/001-grant-vpd-access.sql

CONNECT @master.vpd.username@/@master.vpd.password@#@database.tnsname@

grant select, alter on audit_trail_seq to @tplus.owner.username@;

CONNECT @tplus.owner.username@/@tplus.owner.password@#@database.tnsname@

INSERT INTO DATABASE_PATCHES VALUES( 'TPLUS', '&FILENAME', 38004, SYSDATE, '@user.running.patch@', USER );

COMMIT;

PROMPT End of file : &FILENAME

EXIT
