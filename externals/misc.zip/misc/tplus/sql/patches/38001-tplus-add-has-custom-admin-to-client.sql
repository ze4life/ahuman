--
DEF FILENAME=38001-tplus-add-has-custom-admin-to-client.sql
--
-- Description: Add the has_custom_admin column onto the audit and tplus_client table
-- Parameters:
--
-- History
-- When         Who      Reason
-- 14/03/2005   SP      BUG12285
--

WHENEVER SQLERROR EXIT
PROMPT Start of patch : &FILENAME

ALTER TABLE TPLUS_CLIENT ADD (HAS_CUSTOM_ADMIN CHAR(1) DEFAULT ('N') );
UPDATE TPLUS_CLIENT SET HAS_CUSTOM_ADMIN='N';
ALTER TABLE TPLUS_CLIENT MODIFY HAS_CUSTOM_ADMIN NOT NULL;


ALTER TABLE TPLUS_AUD_CLIENT ADD HAS_CUSTOM_ADMIN CHAR(1);
UPDATE TPLUS_AUD_CLIENT SET HAS_CUSTOM_ADMIN='N';
ALTER TABLE TPLUS_AUD_CLIENT MODIFY HAS_CUSTOM_ADMIN NOT NULL;

CREATE OR REPLACE TRIGGER BUD_TPLUS_CLIENT
BEFORE
UPDATE OR DELETE ON TPLUS_CLIENT
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO TPLUS_AUD_CLIENT
        (AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         CLIENT_ID,
         ACTIVE,
         ENABLED,
         CLIENT_TYPE,
         FULL_NAME,
         SHORT_CODE,
         ADDRESS,
         TELEPHONE,
         FAX,
         EMAIL_ADDRESS,
         PERMISSIONED_FI,
         PERMISSIONED_FX,
         PERMISSIONED_FXO,
         LAST_UPDATED_BY,
         UPDATE_TIME,
		 ENTITY_ID,
     HAS_CUSTOM_ADMIN)
    VALUES (
         AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         :OLD.CLIENT_ID,
         :OLD.ACTIVE,
         :OLD.ENABLED,
         :OLD.CLIENT_TYPE,
         :OLD.FULL_NAME,
         :OLD.SHORT_CODE,
         :OLD.ADDRESS,
         :OLD.TELEPHONE,
         :OLD.FAX,
         :OLD.EMAIL_ADDRESS,
         :OLD.PERMISSIONED_FI,
         :OLD.PERMISSIONED_FX,
         :OLD.PERMISSIONED_FXO,
         :OLD.LAST_UPDATED_BY,
         :OLD.UPDATE_TIME,
		 :OLD.ENTITY_ID,
     :OLD.HAS_CUSTOM_ADMIN
     );
END;
/


INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 38001, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME
EXIT;
