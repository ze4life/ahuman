--
DEF FILENAME=37003-tplus-add-enity-id-to-aud.sql
--
-- Description: Add the entity_id column onto the audit tables
--              of tplus_users and tplus_client
-- Parameters:
--
-- History
-- When         Who      Reason
-- 25/02/2005   CEJ      BUG10836
--

WHENEVER SQLERROR EXIT
PROMPT Start of patch : &FILENAME


ALTER TABLE TPLUS_AUD_USERS
ADD ENTITY_ID NUMBER(7)
/
ALTER TABLE TPLUS_AUD_CLIENT
ADD ENTITY_ID NUMBER(7)
/

CREATE OR REPLACE TRIGGER BUD_TPLUS_CLIENT
BEFORE
UPDATE OR DELETE ON TPLUS_CLIENT
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO TPLUS_AUD_CLIENT
        (AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         CLIENT_ID,
         ACTIVE,
         ENABLED,
         CLIENT_TYPE,
         FULL_NAME,
         SHORT_CODE,
         ADDRESS,
         TELEPHONE,
         FAX,
         EMAIL_ADDRESS,
         PERMISSIONED_FI,
         PERMISSIONED_FX,
         PERMISSIONED_FXO,
         LAST_UPDATED_BY,
         UPDATE_TIME,
		 ENTITY_ID)
    VALUES (
         AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         :OLD.CLIENT_ID,
         :OLD.ACTIVE,
         :OLD.ENABLED,
         :OLD.CLIENT_TYPE,
         :OLD.FULL_NAME,
         :OLD.SHORT_CODE,
         :OLD.ADDRESS,
         :OLD.TELEPHONE,
         :OLD.FAX,
         :OLD.EMAIL_ADDRESS,
         :OLD.PERMISSIONED_FI,
         :OLD.PERMISSIONED_FX,
         :OLD.PERMISSIONED_FXO,
         :OLD.LAST_UPDATED_BY,
         :OLD.UPDATE_TIME,
		 :OLD.ENTITY_ID
     );
END;
/

CREATE OR REPLACE TRIGGER BUD_TPLUS_USERS
BEFORE
UPDATE OR DELETE ON TPLUS_USERS
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT
    INTO TPLUS_AUD_USERS (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        USER_ID,
        ENABLED,
        ACTIVE,
        FIRST_NAME,
        LAST_NAME,
        EMAIL_ADDRESS,
        TELEPHONE_1,
        TELEPHONE_2,
        FAX,
        CLIENT,
        CW_TIMEOUT,
        PL_CUTOFF_TIME,
        LANGUAGE_CODE,
        IS_INTERNAL,
        AUTHENTICATION,
        PERMISSIONED_FI,
        PERMISSIONED_FX,
        PERMISSIONED_FXO,
        LAST_UPDATED_BY,
        UPDATE_TIME,
		ENTITY_ID
    )
    VALUES (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        :OLD.USER_ID,
        :OLD.ENABLED,
        :OLD.ACTIVE,
        :OLD.FIRST_NAME,
        :OLD.LAST_NAME,
        :OLD.EMAIL_ADDRESS,
        :OLD.TELEPHONE_1,
        :OLD.TELEPHONE_2,
        :OLD.FAX,
        :OLD.CLIENT,
        :OLD.CW_TIMEOUT,
        :OLD.PL_CUTOFF_TIME,
        :OLD.LANGUAGE_CODE,
        :OLD.IS_INTERNAL,
        :OLD.AUTHENTICATION,
        :OLD.PERMISSIONED_FI,
        :OLD.PERMISSIONED_FX,
        :OLD.PERMISSIONED_FXO,
        :OLD.LAST_UPDATED_BY,
        :OLD.UPDATE_TIME,
		:OLD.ENTITY_ID
    );
END;
/

INSERT INTO DATABASE_PATCHES VALUES('TPLUS', '&FILENAME', 37003, SYSDATE, '@user.running.patch@', USER);
COMMIT;

PROMPT End of patch : &FILENAME
EXIT;