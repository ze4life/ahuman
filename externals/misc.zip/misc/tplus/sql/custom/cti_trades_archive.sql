set serveroutput on size 1000000;

---- copy data from trade_id to temp_trade_id
select 'START cti_trades_archive.sql '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;

ALTER TABLE trades_archive ADD (temp_trade_id NUMBER);

CREATE OR REPLACE Procedure store_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET temp_trade_id = To_Number(trade_id) WHERE ROWNUM <= offset AND temp_trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_trade_id_data;
COMMIT;

---- modify trade_id type to number

ALTER TABLE trades_archive MODIFY trade_id NULL;

-- clear trade_id column
CREATE OR REPLACE Procedure clear_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET trade_id = null WHERE ROWNUM <= offset AND trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_trade_id_data;
COMMIT;

select 'MODIFY trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_archive MODIFY trade_id NUMBER;

---- return trade_id data
CREATE OR REPLACE Procedure restore_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET trade_id= temp_trade_id  WHERE ROWNUM <= offset AND trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_trade_id_data;
COMMIT;

ALTER TABLE trades_archive MODIFY trade_id NOT NULL;

----- 
-- change parent_trade_id
-- 

ALTER TABLE trades_archive ADD (temp_parent_trade_id NUMBER);

CREATE OR REPLACE Procedure store_parent_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET temp_parent_trade_id = To_Number(parent_trade_id) WHERE ROWNUM <= offset AND temp_parent_trade_id IS NULL AND parent_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_parent_trade_id_data;
COMMIT;

---- modify parent_trade_id type to number

-- clear parent_trade_id column
CREATE OR REPLACE Procedure clear_parent_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET parent_trade_id = null WHERE ROWNUM <= offset AND parent_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_parent_trade_id_data;
COMMIT;

select 'MODIFY parent_trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_archive MODIFY parent_trade_id NUMBER;

---- return parent_trade_id data
CREATE OR REPLACE Procedure restore_parent_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET parent_trade_id= temp_parent_trade_id  WHERE ROWNUM <= offset AND parent_trade_id IS NULL AND temp_parent_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_parent_trade_id_data;
COMMIT;


----- 
-- change child_trade_id
-- 

ALTER TABLE trades_archive ADD (temp_child_trade_id NUMBER);

CREATE OR REPLACE Procedure store_child_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET temp_child_trade_id = To_Number(child_trade_id) WHERE ROWNUM <= offset AND temp_child_trade_id IS NULL AND child_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_child_trade_id_data;
COMMIT;

---- modify child_trade_id type to number

-- clear child_trade_id column
CREATE OR REPLACE Procedure clear_child_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET child_trade_id = null WHERE ROWNUM <= offset AND child_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_child_trade_id_data;
COMMIT;

select 'MODIFY child_trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_archive MODIFY child_trade_id NUMBER;

---- return child_trade_id data
CREATE OR REPLACE Procedure restore_child_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET child_trade_id= temp_child_trade_id  WHERE ROWNUM <= offset AND child_trade_id IS NULL AND temp_child_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_child_trade_id_data;
COMMIT;


----- 
-- change replacing_trade_id
-- 

ALTER TABLE trades_archive ADD (temp_replacing_trade_id NUMBER);

CREATE OR REPLACE Procedure store_replacing_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET temp_replacing_trade_id = To_Number(replacing_trade_id) WHERE ROWNUM <= offset AND temp_replacing_trade_id IS NULL AND replacing_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_replacing_trade_id_data;
COMMIT;

---- modify replacing_trade_id type to number

-- clear replacing_trade_id column
CREATE OR REPLACE Procedure clear_replacing_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET replacing_trade_id = null WHERE ROWNUM <= offset AND replacing_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_replacing_trade_id_data;
COMMIT;

select 'MODIFY replacing_trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_archive MODIFY replacing_trade_id NUMBER;

---- return replacing_trade_id data
CREATE OR REPLACE Procedure restore_replacing_trade_id
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET replacing_trade_id= temp_replacing_trade_id  WHERE ROWNUM <= offset AND replacing_trade_id IS NULL AND temp_replacing_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_replacing_trade_id;
COMMIT;



----- 
-- change replaces_trade_id
-- 

ALTER TABLE trades_archive ADD (temp_replaces_trade_id NUMBER);

CREATE OR REPLACE Procedure store_replaces_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET temp_replaces_trade_id = To_Number(replaces_trade_id) WHERE ROWNUM <= offset AND temp_replaces_trade_id IS NULL AND replaces_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_replaces_trade_id_data;
COMMIT;

---- modify replaces_trade_id type to number

-- clear replaces_trade_id column
CREATE OR REPLACE Procedure clear_replaces_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET replaces_trade_id = null WHERE ROWNUM <= offset AND replaces_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_replaces_trade_id_data;
COMMIT;

select 'MODIFY replaces_trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_archive MODIFY replaces_trade_id NUMBER;

---- return replaces_trade_id data
CREATE OR REPLACE Procedure restore_replaces_trade_id
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_archive;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_archive SET replaces_trade_id= temp_replaces_trade_id  WHERE ROWNUM <= offset AND replaces_trade_id IS NULL AND temp_replaces_trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_replaces_trade_id;
COMMIT;

select 'FINISH cti_trades_archive.sql '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
set serveroutput off;
exit;