set serveroutput on size 1000000;

---- copy data from trade_id to temp_trade_id
select 'START cti_fbo_trade_detail.sql '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;

--- store data from trade_id to temp_trade_id
ALTER TABLE fbo_trade_detail ADD (temp_trade_id NUMBER);

CREATE OR REPLACE Procedure store_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM fbo_trade_detail;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE fbo_trade_detail SET temp_trade_id = To_Number(trade_id) WHERE ROWNUM <= offset AND temp_trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_trade_id_data;
COMMIT;

---- modify trade_id type to number
ALTER TABLE fbo_trade_detail DROP PRIMARY KEY;

-- clear trade_id column
CREATE OR REPLACE Procedure clear_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM fbo_trade_detail;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE fbo_trade_detail SET trade_id = null WHERE ROWNUM <= offset AND trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_trade_id_data;
COMMIT;

select 'MODIFY trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE fbo_trade_detail MODIFY trade_id NUMBER;

---- return trade_id data
CREATE OR REPLACE Procedure restore_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM fbo_trade_detail;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE fbo_trade_detail SET trade_id= temp_trade_id  WHERE ROWNUM <= offset AND trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_trade_id_data;
COMMIT;

ALTER TABLE fbo_trade_detail DROP COLUMN temp_trade_id;

CREATE UNIQUE INDEX pk_fbo_trade_detail ON fbo_trade_detail (TRADE_ID)
TABLESPACE datadbag
STORAGE(
      INITIAL      64 K
      NEXT          0 K
      MINEXTENTS    1
      MAXEXTENTS UNLIMITED
      PCTINCREASE   0
	)
/

ALTER TABLE fbo_trade_detail
  ADD CONSTRAINT pk_fbo_trade_detail PRIMARY KEY (
    trade_id
  )
  USING INDEX
/

COMMIT;
select 'FINISH cti_fbo_trade_detail.sql'||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
set serveroutput off;
exit;

