set serveroutput on size 1000000;

---- copy data from trade_id to temp_trade_id
select 'START cti_trades_buffer.sql'||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;

ALTER TABLE trades_buffer ADD (temp_trade_id NUMBER);

CREATE OR REPLACE Procedure store_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_buffer;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_buffer SET temp_trade_id = To_Number(trade_id) WHERE ROWNUM <= offset AND temp_trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'STORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC store_trade_id_data;
COMMIT;

---- modify trade_id type to number
ALTER TABLE trades_buffer DROP CONSTRAINT pk_trades_buffer;

ALTER TABLE trades_buffer MODIFY trade_id NULL;

-- clear trade_id column
CREATE OR REPLACE Procedure clear_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_buffer;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_buffer SET trade_id = null WHERE ROWNUM <= offset AND trade_id IS NOT NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'CLEAR '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC clear_trade_id_data;
COMMIT;

select 'MODIFY trade_id NUMBER '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
ALTER TABLE trades_buffer MODIFY trade_id NUMBER;

---- return trade_id data
CREATE OR REPLACE Procedure restore_trade_id_data
    AS
        row_count NUMBER;
        current_num NUMBER := 0;
        offset NUMBER := 100000;
    BEGIN
        SELECT Count(*) INTO row_count FROM trades_buffer;
        WHILE current_num < row_count
        LOOP
            current_num := current_num + offset;
            UPDATE trades_buffer SET trade_id= temp_trade_id  WHERE ROWNUM <= offset AND trade_id IS NULL;
            COMMIT;
            DBMS_OUTPUT.PUT_LINE (current_timestamp||' '||current_num);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/

select 'RESTORE '||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
EXEC restore_trade_id_data;
COMMIT;

ALTER TABLE trades_buffer DROP COLUMN temp_trade_id;

ALTER TABLE trades_buffer MODIFY trade_id NOT NULL;


CREATE UNIQUE INDEX pk_trades_buffer ON trades_buffer (TRADE_ID)
TABLESPACE indexdbag
STORAGE(
      INITIAL      64 K
      NEXT          0 K
      MINEXTENTS    1
      MAXEXTENTS UNLIMITED
      PCTINCREASE   0
	)
/

ALTER TABLE trades_buffer
  ADD CONSTRAINT pk_trades_buffer PRIMARY KEY (
    trade_id
  )
  USING INDEX
/

COMMIT;

select 'FINISH cti_trades_buffer.sql'||to_char(sysdate, 'Dy DD-Mon-YYYY HH24:MI:SS') from dual;
set serveroutput off;
exit;