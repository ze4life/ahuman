
--
DEF FILENAME=001-schema-sequences.sql
--
-- Description: Create all the required grants
--              statements and then runs them.
--              Also generates synonym sql.
--
--
-- History
-- When         Who     Reason
-- 16/Feb/2004  CEJ     Initial Revision
--

set echo off
set pages 0
set line 500
set heading off
set feedback off
SPOOL ddl\runtime\schema-synonym.sql.@layer.id@.runtime

select 'create synonym '||object_name||' for @tplus.owner.username@.'||object_name||';' from user_objects where object_type in (
'FUNCTION',
'PACKAGE',
'PROCEDURE',
'SEQUENCE',
'TABLE',
'VIEW'
) order by object_name;

SELECT 'EXIT;' FROM DUAL;
SPOOL OFF

SPOOL ddl\runtime\schema-grant.sql.@layer.id@.runtime

set echo off
REM set lines 32767
set pages 0
set line 500
set heading off
set feedback off
select 'grant update, insert, delete on '||object_name||' to @tplus.owner.username@_rw_role;' from user_objects where object_name not like 'AUD_%' and object_type in (
'TABLE',
'VIEW'
) order by object_name;

select 'grant execute on '||object_name||' to @tplus.owner.username@_rw_role;' from user_objects where object_type in (
'FUNCTION',
'PACKAGE',
'PROCEDURE'
) order by object_name;

select 'grant select on '||object_name||' to @tplus.owner.username@_ro_role;' from user_objects where object_type in (
'SEQUENCE',
'TABLE',
'VIEW'
) order by object_name;

REM Stuff TPLUS needs to expose to the modules...



select 'GRANT SELECT ON  AUD_TPLUS_PERMISSION_MAP TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  AUD_TPLUS_PERMISSION_MAP TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT SELECT ON  BLOTTERS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  BLOTTERS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  BLOTTER_COLUMNS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  BLOTTER_COLUMNS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  BLOTTER_COLUMNS_LINKS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  BLOTTER_COLUMNS_LINKS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT INSERT, SELECT ON  DATABASE_PATCHES TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT INSERT, SELECT ON  DATABASE_PATCHES TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT INSERT, SELECT ON  DATABASE_PATCHES TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  ENTITIES TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  ENTITIES TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  ENTITIES TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  ENTITY_RELATIONS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  ENTITY_RELATIONS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  LANGUAGE_CODES TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT SELECT ON  LANGUAGE_CODES TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  LINK_RULES TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  LINK_RULES TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  OPERATIONS TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  OPERATIONS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  OPERATIONS TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  PERMISSIONS TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  PERMISSIONS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, SELECT, UPDATE ON  PERMISSIONS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  SCREEN_LAYOUT TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  SCREEN_LAYOUT TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  SCREEN_LAYOUT_PRODUCT_ATTRIBS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  SCREEN_LAYOUT_PRODUCT_ATTRIBS TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  SEQ_TAB_LAYOUT_ID TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT SELECT ON  TAB_LAYOUT TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TAB_LAYOUT TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  TPLUS_AUD_CLIENT TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_AUD_CLIENT TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_AUD_CLIENT TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  TPLUS_AUD_USERS TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_AUD_USERS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_AUD_USERS TO @tplus.owner.username@_RW_ROLE;' from dual;



select 'GRANT SELECT ON  TPLUS_CLIENT TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_CLIENT TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_CLIENT TO @tplus.owner.username@_RW_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_PERMISSION TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_PERMISSION TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  TPLUS_PERMISSION_MAP TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_PERMISSION_MAP TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_PERMISSION_MAP TO @tplus.owner.username@_RW_ROLE;' from dual;


select 'GRANT SELECT ON  TPLUS_USERS TO @tplus.owner.username@_MODULE_ROLE;' from dual;

select 'GRANT SELECT ON  TPLUS_USERS TO @tplus.owner.username@_RO_ROLE;' from dual;

select 'GRANT DELETE, INSERT, UPDATE ON  TPLUS_USERS TO @tplus.owner.username@_RW_ROLE;' from dual;


SELECT 'EXIT;' FROM DUAL;
SPOOL OFF
START ddl\runtime\schema-grant.sql.@layer.id@.runtime

PROMPT End of file : &FILENAME

EXIT;
