--
DEF FILENAME=001-schema-sequences.sql
--
-- Description: Creates schema sequences
--
--
-- History
-- When         Who     Reason
-- 16/Feb/2004  CEJ     Initial Revision
-- 14/Dec/2004  HG      Updated for rev 3.6

WHENEVER SQLERROR EXIT

PROMPT Start of file : &FILENAME

CREATE SEQUENCE SEQ_ENTITY_ID
  START WITH 1
  NOMAXVALUE
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;


CREATE SEQUENCE SEQ_TAB_LAYOUT_ID
  START WITH 1
  NOMAXVALUE
  MINVALUE 1
  NOCYCLE
  NOCACHE
  NOORDER;

PROMPT End of file : &FILENAME

EXIT;