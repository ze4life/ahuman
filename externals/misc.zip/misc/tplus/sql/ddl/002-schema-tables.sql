--
DEF FILENAME=002-schema-tables.sql
--
-- Description: Creates tables (includes FK constraints)
--              for tplus database
--
--
-- History
-- When         Who     Reason
-- 16/Jan/2004  CEJ     Initial Revision
--

WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME

PROMPT Creating tables for schema

CREATE TABLE AUD_TPLUS_PERMISSION_MAP
(
  AUD_ACTION           VARCHAR2(10 BYTE),
  AUD_LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  AUD_UPDATE_TIME      DATE,
  PERMISSION_KEY       VARCHAR2(15 BYTE),
  USER_ID              VARCHAR2(48 BYTE),
  TC_ACCEPTED          CHAR(1 BYTE),
  LAST_UPDATED_BY      VARCHAR2(48 BYTE),
  UPDATE_TIME          DATE
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE BLOTTERS
(
  BLOTTER_NAME  VARCHAR2(20 BYTE),
  DESCRIPTION   VARCHAR2(30 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE BLOTTER_COLUMNS
(
  BLOTTER_COLUMNS_ID  NUMBER(8),
  BLOTTER_NAME        VARCHAR2(20 BYTE),
  COLUMN_NAME         VARCHAR2(20 BYTE),
  COLUMN_POSITION     NUMBER(2),
  COLUMN_WIDTH        NUMBER(3),
  COLUMN_TYPE         CHAR(1 BYTE),
  COLUMN_ALIGNED      CHAR(1 BYTE),
  COLUMN_KEY          VARCHAR2(200 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE BLOTTER_COLUMNS_LINKS
(
  LINK_ID             VARCHAR2(45 BYTE),
  BLOTTER_NAME        VARCHAR2(20 BYTE),
  BLOTTER_COLUMNS_ID  NUMBER(8),
  LINK_TYPE           CHAR(3 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE DATABASE_PATCHES
(
  APPLICATIONNAME  VARCHAR2(12 BYTE),
  FILENAME         VARCHAR2(128 BYTE),
  VERSIONNUMBER    INTEGER,
  UPDATETIME       DATE,
  UPDATEUSERID     VARCHAR2(32 BYTE),
  DATABASEUSERID   VARCHAR2(32 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE DATABASE_PATCHES_ARCHIVE
(
  APPLICATIONNAME  VARCHAR2(12 BYTE),
  FILENAME         VARCHAR2(128 BYTE),
  VERSIONNUMBER    INTEGER,
  UPDATETIME       DATE,
  UPDATEUSERID     VARCHAR2(32 BYTE),
  DATABASEUSERID   VARCHAR2(32 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE ENTITIES
(
  ENTITY_ID    NUMBER(7),
  ENTITY_TYPE  CHAR(1 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE ENTITY_RELATIONS
(
  ENTITY_ID_1   NUMBER(7),
  ENTITY_ID_2   NUMBER(7),
  RELATIONSHIP  VARCHAR2(20 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE LANGUAGE_CODES
(
  LANGUAGE_CODE  VARCHAR2(3 BYTE),
  DESCRIPTION    VARCHAR2(100 BYTE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE LINK_RULES
(
  LINK_FOR   VARCHAR2(20 BYTE),
  LINK_TYPE  CHAR(3 BYTE),
  PRIORITY   NUMBER(2)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE OPERATIONS
(
  OPERATION        VARCHAR2(512 BYTE),
  DESCRIPTION      VARCHAR2(50 BYTE),
  LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  UPDATE_TIME      DATE                         DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE PERMISSIONS
(
  ENTITY_ID        NUMBER(7),
  OPERATION        VARCHAR2(512 BYTE),
  ACTION           CHAR(1 BYTE),
  LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  UPDATE_TIME      DATE                         DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE SCREEN_LAYOUT
(
  TAB_ID      NUMBER(6),
  SCREEN_ID   VARCHAR2(25 BYTE),
  PRODUCT     VARCHAR2(4 BYTE),
  TYPE        VARCHAR2(25 BYTE),
  NAME        VARCHAR2(30 BYTE),
  RULE        VARCHAR2(40 BYTE),
  STATE       VARCHAR2(10 BYTE),
  TOP_POS     NUMBER(4),
  LEFT_POS    NUMBER(4),
  WIDTH_POS   NUMBER(4),
  HEIGHT_POS  NUMBER(4),
  X_POS       NUMBER(4),
  Y_POS       NUMBER(4),
  Z_INDEX     NUMBER(4)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE SCREEN_LAYOUT_PRODUCT_ATTRIBS
(
  TAB_ID               NUMBER(6),
  SCREEN_ID            VARCHAR2(25 BYTE),
  NAME                 VARCHAR2(50 BYTE),
  VALUE                VARCHAR2(400 BYTE),
  ORDER_IN_JAVASCRIPT  NUMBER(3)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TAB_LAYOUT
(
  TAB_ID           NUMBER(6),
  USER_ID          VARCHAR2(48 BYTE),
  TAB_NAME         VARCHAR2(30 BYTE),
  TAB_STATUS       VARCHAR2(30 BYTE),
  TAB_NUMBER       NUMBER(2),
  LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  UPDATE_TIME      DATE                         DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_AUD_CLIENT
(
  AUD_ACTION           VARCHAR2(10 BYTE),
  AUD_LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  AUD_UPDATE_TIME      DATE,
  CLIENT_ID            VARCHAR2(15 BYTE),
  ENABLED              CHAR(1 BYTE),
  ACTIVE               CHAR(1 BYTE),
  CLIENT_TYPE          VARCHAR2(3 BYTE),
  FULL_NAME            VARCHAR2(100 BYTE),
  SHORT_CODE           VARCHAR2(4 BYTE),
  ADDRESS              VARCHAR2(100 BYTE),
  TELEPHONE            VARCHAR2(20 BYTE),
  FAX                  VARCHAR2(20 BYTE),
  EMAIL_ADDRESS        VARCHAR2(500 BYTE),
  PERMISSIONED_FI      CHAR(1 BYTE),
  PERMISSIONED_FX      CHAR(1 BYTE),
  PERMISSIONED_FXO     CHAR(1 BYTE),
  LAST_UPDATED_BY      VARCHAR2(48 BYTE),
  UPDATE_TIME          DATE                     DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_AUD_USERS
(
  AUD_ACTION           VARCHAR2(10 BYTE),
  AUD_LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  AUD_UPDATE_TIME      DATE,
  USER_ID              VARCHAR2(48 BYTE),
  ENABLED              CHAR(1 BYTE),
  ACTIVE               CHAR(1 BYTE),
  FIRST_NAME           VARCHAR2(50 BYTE),
  LAST_NAME            VARCHAR2(50 BYTE),
  EMAIL_ADDRESS        VARCHAR2(100 BYTE),
  TELEPHONE_1          VARCHAR2(50 BYTE),
  TELEPHONE_2          VARCHAR2(50 BYTE),
  FAX                  VARCHAR2(50 BYTE),
  CLIENT               VARCHAR2(15 BYTE),
  CW_TIMEOUT           NUMBER(10)               DEFAULT 30000,
  PL_CUTOFF_TIME       VARCHAR2(5 BYTE),
  LANGUAGE_CODE        VARCHAR2(5 BYTE),
  IS_INTERNAL          CHAR(1 BYTE),
  AUTHENTICATION       CHAR(1 BYTE),
  PERMISSIONED_FI      CHAR(1 BYTE),
  PERMISSIONED_FX      CHAR(1 BYTE),
  PERMISSIONED_FXO     CHAR(1 BYTE),
  LAST_UPDATED_BY      VARCHAR2(48 BYTE),
  UPDATE_TIME          DATE                     DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_CLIENT
(
  CLIENT_ID         VARCHAR2(15 BYTE),
  ENABLED           CHAR(1 BYTE),
  ACTIVE            CHAR(1 BYTE)                DEFAULT ('Y'),
  CLIENT_TYPE       VARCHAR2(3 BYTE),
  FULL_NAME         VARCHAR2(100 BYTE),
  SHORT_CODE        VARCHAR2(4 BYTE),
  ADDRESS           VARCHAR2(100 BYTE),
  TELEPHONE         VARCHAR2(20 BYTE),
  FAX               VARCHAR2(20 BYTE),
  EMAIL_ADDRESS     VARCHAR2(500 BYTE),
  PERMISSIONED_FI   CHAR(1 BYTE),
  PERMISSIONED_FX   CHAR(1 BYTE),
  PERMISSIONED_FXO  CHAR(1 BYTE),
  LAST_UPDATED_BY   VARCHAR2(48 BYTE),
  UPDATE_TIME       DATE                        DEFAULT (SYSDATE),
  ENTITY_ID         NUMBER(7)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_PERMISSION
(
  PERMISSION_KEY          VARCHAR2(8 BYTE),
  PERMISSION_DESCRIPTION  VARCHAR2(16 BYTE),
  LAST_UPDATED_BY         VARCHAR2(48 BYTE),
  UPDATE_TIME             DATE                  DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_PERMISSION_MAP
(
  PERMISSION_KEY   VARCHAR2(8 BYTE),
  USER_ID          VARCHAR2(48 BYTE),
  TC_ACCEPTED      CHAR(1 BYTE),
  LAST_UPDATED_BY  VARCHAR2(48 BYTE),
  UPDATE_TIME      DATE                         DEFAULT (SYSDATE)
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE TABLE TPLUS_USERS
(
  USER_ID           VARCHAR2(48 BYTE),
  ENABLED           CHAR(1 BYTE),
  ACTIVE            CHAR(1 BYTE)                DEFAULT ('Y'),
  FIRST_NAME        VARCHAR2(50 BYTE),
  LAST_NAME         VARCHAR2(50 BYTE),
  EMAIL_ADDRESS     VARCHAR2(100 BYTE),
  TELEPHONE_1       VARCHAR2(50 BYTE),
  TELEPHONE_2       VARCHAR2(50 BYTE),
  FAX               VARCHAR2(50 BYTE),
  CLIENT            VARCHAR2(15 BYTE),
  CW_TIMEOUT        NUMBER(10)                  DEFAULT 30000,
  PL_CUTOFF_TIME    VARCHAR2(5 BYTE),
  LANGUAGE_CODE     VARCHAR2(5 BYTE),
  IS_INTERNAL       CHAR(1 BYTE),
  AUTHENTICATION    CHAR(1 BYTE),
  PERMISSIONED_FI   CHAR(1 BYTE),
  PERMISSIONED_FX   CHAR(1 BYTE),
  PERMISSIONED_FXO  CHAR(1 BYTE),
  LAST_UPDATED_BY   VARCHAR2(48 BYTE),
  UPDATE_TIME       DATE                        DEFAULT (SYSDATE),
  ENTITY_ID         NUMBER(7),
  CAPTURE_HEARTBEATS           CHAR(1)          DEFAULT 'N' NOT NULL,
  CAPTURING_STARTED_TIMESTAMP  DATE
)
TABLESPACE @database.data.tablespace@
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


PROMPT Creating primary foreign keys for tables

CREATE UNIQUE INDEX PK_BLOTTERS ON BLOTTERS
(BLOTTER_NAME)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_BLOTTER_COLUMNS ON BLOTTER_COLUMNS
(BLOTTER_COLUMNS_ID, BLOTTER_NAME, COLUMN_NAME)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_BLOTTER_COLUMNS_LINKS ON BLOTTER_COLUMNS_LINKS
(LINK_ID, BLOTTER_COLUMNS_ID, LINK_TYPE)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_DATABASE_PATCHES ON DATABASE_PATCHES
(DATABASEUSERID, FILENAME, VERSIONNUMBER)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_ENTITIES ON ENTITIES
(ENTITY_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_ENTITY_RELATIONS ON ENTITY_RELATIONS
(ENTITY_ID_1, ENTITY_ID_2, RELATIONSHIP)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_LANGUAGE_CODES ON LANGUAGE_CODES
(LANGUAGE_CODE)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_LINK_RULES ON LINK_RULES
(LINK_FOR, LINK_TYPE)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_OPERATIONS_OPERATION ON OPERATIONS
(OPERATION)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_PERMISSIONS ON PERMISSIONS
(ENTITY_ID, OPERATION)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_TAB_LAYOUT ON TAB_LAYOUT
(TAB_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_TPLUS_PERMISSION ON TPLUS_PERMISSION
(PERMISSION_KEY)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_CLIENT ON TPLUS_CLIENT
(CLIENT_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_SCREEN_LAYOUT ON SCREEN_LAYOUT
(TAB_ID, SCREEN_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_SCREEN_LAYOUT_PRD_ATTRIBS ON SCREEN_LAYOUT_PRODUCT_ATTRIBS
(TAB_ID, SCREEN_ID, NAME, ORDER_IN_JAVASCRIPT)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_USERS ON TPLUS_USERS
(USER_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX UK_CLIENT_SHORT_CODE ON TPLUS_CLIENT
(SHORT_CODE)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX PK_TPLUS_PERMISSION_MAP ON TPLUS_PERMISSION_MAP
(PERMISSION_KEY, USER_ID)
LOGGING
TABLESPACE @database.index.tablespace@
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          128K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


ALTER TABLE BLOTTERS ADD (
  CONSTRAINT PK_BLOTTERS PRIMARY KEY (BLOTTER_NAME)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE BLOTTER_COLUMNS ADD (
  CONSTRAINT PK_BLOTTER_COLUMNS PRIMARY KEY (BLOTTER_COLUMNS_ID, BLOTTER_NAME, COLUMN_NAME)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE BLOTTER_COLUMNS_LINKS ADD (
  CONSTRAINT PK_BLOTTER_COLUMNS_LINKS PRIMARY KEY (LINK_ID, BLOTTER_COLUMNS_ID, LINK_TYPE)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE DATABASE_PATCHES ADD (
  CONSTRAINT PK_DATABASE_PATCHES PRIMARY KEY (DATABASEUSERID, FILENAME, VERSIONNUMBER)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE ENTITIES ADD (
  CONSTRAINT PK_ENTITIES PRIMARY KEY (ENTITY_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE ENTITY_RELATIONS ADD (
  CONSTRAINT PK_ENTITY_RELATIONS PRIMARY KEY (ENTITY_ID_1, ENTITY_ID_2, RELATIONSHIP)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE LANGUAGE_CODES ADD (
  CONSTRAINT PK_LANGUAGE_CODES PRIMARY KEY (LANGUAGE_CODE)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE LINK_RULES ADD (
  CONSTRAINT PK_LINK_RULES PRIMARY KEY (LINK_FOR, LINK_TYPE)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE OPERATIONS ADD (
  CONSTRAINT PK_OPERATIONS_OPERATION PRIMARY KEY (OPERATION)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE PERMISSIONS ADD (
  CONSTRAINT PK_PERMISSIONS PRIMARY KEY (ENTITY_ID, OPERATION)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE TAB_LAYOUT ADD (
  CONSTRAINT PK_TAB_LAYOUT PRIMARY KEY (TAB_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE TPLUS_PERMISSION ADD (
  CONSTRAINT PK_TPLUS_PERMISSION PRIMARY KEY (PERMISSION_KEY)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE TPLUS_CLIENT ADD (
  CONSTRAINT PK_CLIENT PRIMARY KEY (CLIENT_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ),
  CONSTRAINT UK_CLIENT_SHORT_CODE UNIQUE (SHORT_CODE)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE SCREEN_LAYOUT ADD (
  CONSTRAINT PK_SCREEN_LAYOUT PRIMARY KEY (TAB_ID, SCREEN_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE SCREEN_LAYOUT_PRODUCT_ATTRIBS ADD (
  CONSTRAINT PK_SCREEN_LAYOUT_PRD_ATTRIBS PRIMARY KEY (TAB_ID, SCREEN_ID, NAME, ORDER_IN_JAVASCRIPT)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE TPLUS_USERS ADD (
  CONSTRAINT PK_USERS PRIMARY KEY (USER_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE TPLUS_PERMISSION_MAP ADD (
  CONSTRAINT PK_TPLUS_PERMISSION_MAP PRIMARY KEY (PERMISSION_KEY, USER_ID)
    USING INDEX 
    TABLESPACE @database.index.tablespace@
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          128K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));

ALTER TABLE BLOTTER_COLUMNS ADD (
  CONSTRAINT FK_BLOTTER_NAME FOREIGN KEY (BLOTTER_NAME) 
    REFERENCES BLOTTERS (BLOTTER_NAME));

ALTER TABLE PERMISSIONS ADD (
  CONSTRAINT FK_PRM_OPERATION FOREIGN KEY (OPERATION) 
    REFERENCES OPERATIONS (OPERATION));

ALTER TABLE TPLUS_CLIENT ADD (
  CONSTRAINT FK_TPC_ENTITY_ID FOREIGN KEY (ENTITY_ID) 
    REFERENCES ENTITIES (ENTITY_ID));

ALTER TABLE SCREEN_LAYOUT ADD (
  CONSTRAINT FK_TAB_ID FOREIGN KEY (TAB_ID) 
    REFERENCES TAB_LAYOUT (TAB_ID));

ALTER TABLE SCREEN_LAYOUT_PRODUCT_ATTRIBS ADD (
  CONSTRAINT FX_SCREEN_TAB_ID FOREIGN KEY (TAB_ID, SCREEN_ID) 
    REFERENCES SCREEN_LAYOUT (TAB_ID,SCREEN_ID));

ALTER TABLE TPLUS_USERS ADD (
  CONSTRAINT FK_LANGUAGE_CODES FOREIGN KEY (LANGUAGE_CODE) 
    REFERENCES LANGUAGE_CODES (LANGUAGE_CODE),
  CONSTRAINT FK_TPU_ENTITY_ID FOREIGN KEY (ENTITY_ID) 
    REFERENCES ENTITIES (ENTITY_ID),
  CONSTRAINT FK_USER_CLIENT FOREIGN KEY (CLIENT) 
    REFERENCES TPLUS_CLIENT (CLIENT_ID));

ALTER TABLE TPLUS_PERMISSION_MAP ADD (
  CONSTRAINT FK_TP_PERMISSION_KEY FOREIGN KEY (PERMISSION_KEY) 
    REFERENCES TPLUS_PERMISSION (PERMISSION_KEY)
    ON DELETE CASCADE,
  CONSTRAINT FK_TP_USER_ID FOREIGN KEY (USER_ID) 
    REFERENCES TPLUS_USERS (USER_ID)
    ON DELETE CASCADE);




PROMPT End of file : &FILENAME

EXIT;
