--
DEF FILENAME=002-schema-aud-tables.sql
--
-- Description: Creates audit tables
--              for tplus database
--
--
-- History
-- When         Who     Reason
-- 16/Jan/2004  CEJ     Initial Revision
-- 16/Dec/2004  HG      Absolete script

WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME

PROMPT This script is now done within 002-schema-tables.sql and the new 003-schema-triggers.sql.

PROMPT End of file : &FILENAME

EXIT;