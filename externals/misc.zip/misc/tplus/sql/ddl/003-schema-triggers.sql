--
DEF FILENAME=002-schema-triggers.sql
--
-- Description: Creates tplus triggers
--
--
-- History
-- When         Who     Reason
-- 16/12/2004   HG      Initial Revision
--

WHENEVER SQLERROR EXIT

PROMPT Start of patch : &FILENAME


CREATE OR REPLACE FUNCTION f_next_entity_id(entity_type_in CHAR)
RETURN NUMBER
IS
    new_entity_id		NUMBER(7);
BEGIN
    SELECT SEQ_ENTITY_ID.nextval
    INTO   new_entity_id
    FROM   DUAL;

    INSERT
    INTO  ENTITIES
          (entity_id,
           entity_type)
    VALUES
          (new_entity_id,
           entity_type_in);

    RETURN (new_entity_id);
END f_next_entity_id;
/

SHOW ERRORS;


CREATE OR REPLACE TRIGGER BIN_TPLUS_CLIENT
BEFORE
INSERT ON TPLUS_CLIENT
FOR EACH ROW
BEGIN
  :NEW.entity_id := f_next_entity_id('C');
END;
/
SHOW ERRORS;



CREATE OR REPLACE TRIGGER BIN_TPLUS_USERS
BEFORE
INSERT ON TPLUS_USERS
FOR EACH ROW
BEGIN
  :NEW.entity_id := f_next_entity_id('U');
END;
/
SHOW ERRORS;



CREATE OR REPLACE TRIGGER BUD_TPLUS_CLIENT
BEFORE
UPDATE OR DELETE ON TPLUS_CLIENT
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT INTO TPLUS_AUD_CLIENT
        (AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         CLIENT_ID,
         ACTIVE,
         ENABLED,
         CLIENT_TYPE,
         FULL_NAME,
         SHORT_CODE,
         ADDRESS,
         TELEPHONE,
         FAX,
         EMAIL_ADDRESS,
         PERMISSIONED_FI,
         PERMISSIONED_FX,
         PERMISSIONED_FXO,
         LAST_UPDATED_BY,
         UPDATE_TIME)
    VALUES (
         AUD_ACTION,
         AUD_LAST_UPDATED_BY,
         AUD_UPDATE_TIME,
         :OLD.CLIENT_ID,
         :OLD.ACTIVE,
         :OLD.ENABLED,
         :OLD.CLIENT_TYPE,
         :OLD.FULL_NAME,
         :OLD.SHORT_CODE,
         :OLD.ADDRESS,
         :OLD.TELEPHONE,
         :OLD.FAX,
         :OLD.EMAIL_ADDRESS,
         :OLD.PERMISSIONED_FI,
         :OLD.PERMISSIONED_FX,
         :OLD.PERMISSIONED_FXO,
         :OLD.LAST_UPDATED_BY,
         :OLD.UPDATE_TIME
     );
END;
/
SHOW ERRORS;



CREATE OR REPLACE TRIGGER BUD_TPLUS_PERMISSION_MAP
BEFORE
UPDATE OR DELETE ON TPLUS_PERMISSION_MAP
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT
    INTO AUD_TPLUS_PERMISSION_MAP (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        PERMISSION_KEY,
        USER_ID,
        TC_ACCEPTED,
        LAST_UPDATED_BY,
        UPDATE_TIME
    )
    VALUES (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        :OLD.PERMISSION_KEY,
        :OLD.USER_ID,
        :OLD.TC_ACCEPTED,
        :OLD.LAST_UPDATED_BY,
        :OLD.UPDATE_TIME
    );
END;
/
SHOW ERRORS;



CREATE OR REPLACE TRIGGER BUD_TPLUS_USERS
BEFORE
UPDATE OR DELETE ON TPLUS_USERS
FOR EACH ROW
DECLARE
    aud_action          VARCHAR2(10);
    aud_last_updated_by VARCHAR2(48);
    aud_update_time     DATE;
BEGIN
    IF updating THEN
        aud_action := 'UPDATE';
        aud_last_updated_by := :NEW.LAST_UPDATED_BY;
    ELSIF deleting THEN
        aud_action := 'DELETE';
        aud_last_updated_by := user;
    ELSE
        aud_action := '?';
        aud_last_updated_by := user;
    END IF;
    aud_update_time := sysdate;

    INSERT
    INTO TPLUS_AUD_USERS (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        USER_ID,
        ENABLED,
        ACTIVE,
        FIRST_NAME,
        LAST_NAME,
        EMAIL_ADDRESS,
        TELEPHONE_1,
        TELEPHONE_2,
        FAX,
        CLIENT,
        CW_TIMEOUT,
        PL_CUTOFF_TIME,
        LANGUAGE_CODE,
        IS_INTERNAL,
        AUTHENTICATION,
        PERMISSIONED_FI,
        PERMISSIONED_FX,
        PERMISSIONED_FXO,
        LAST_UPDATED_BY,
        UPDATE_TIME
    )
    VALUES (
        AUD_ACTION,
        AUD_LAST_UPDATED_BY,
        AUD_UPDATE_TIME,
        :OLD.USER_ID,
        :OLD.ENABLED,
        :OLD.ACTIVE,
        :OLD.FIRST_NAME,
        :OLD.LAST_NAME,
        :OLD.EMAIL_ADDRESS,
        :OLD.TELEPHONE_1,
        :OLD.TELEPHONE_2,
        :OLD.FAX,
        :OLD.CLIENT,
        :OLD.CW_TIMEOUT,
        :OLD.PL_CUTOFF_TIME,
        :OLD.LANGUAGE_CODE,
        :OLD.IS_INTERNAL,
        :OLD.AUTHENTICATION,
        :OLD.PERMISSIONED_FI,
        :OLD.PERMISSIONED_FX,
        :OLD.PERMISSIONED_FXO,
        :OLD.LAST_UPDATED_BY,
        :OLD.UPDATE_TIME
    );
END;
/
SHOW ERRORS;







PROMPT End of file : &FILENAME

EXIT;
