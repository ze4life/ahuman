--
DEF FILENAME=009-schema-synonyms.sql
--
-- Description: Creates synonyms for ap and ro accounts
--
--
-- History
-- When         Who     Reason
-- 29/Dec/2004  HG      created for rev 3.6 

PROMPT Start of file : &FILENAME

CREATE SYNONYM AUD_TPLUS_PERMISSION_MAP FOR @tplus.owner.username@.AUD_TPLUS_PERMISSION_MAP;                                        
CREATE SYNONYM BLOTTERS FOR @tplus.owner.username@.BLOTTERS;                                                                        
CREATE SYNONYM BLOTTER_COLUMNS FOR @tplus.owner.username@.BLOTTER_COLUMNS;                                                          
CREATE SYNONYM BLOTTER_COLUMNS_LINKS FOR @tplus.owner.username@.BLOTTER_COLUMNS_LINKS;                                              
CREATE SYNONYM DATABASE_PATCHES FOR @tplus.owner.username@.DATABASE_PATCHES;                                                        
CREATE SYNONYM ENTITIES FOR @tplus.owner.username@.ENTITIES;                                                                        
CREATE SYNONYM ENTITY_RELATIONS FOR @tplus.owner.username@.ENTITY_RELATIONS;                                                        
CREATE SYNONYM LANGUAGE_CODES FOR @tplus.owner.username@.LANGUAGE_CODES;                                                            
CREATE SYNONYM LINK_RULES FOR @tplus.owner.username@.LINK_RULES;                                                                    
CREATE SYNONYM OPERATIONS FOR @tplus.owner.username@.OPERATIONS;                                                                    
CREATE SYNONYM PERMISSIONS FOR @tplus.owner.username@.PERMISSIONS;                                                                  
CREATE SYNONYM SCREEN_LAYOUT FOR @tplus.owner.username@.SCREEN_LAYOUT;                                                              
CREATE SYNONYM SCREEN_LAYOUT_PRODUCT_ATTRIBS FOR @tplus.owner.username@.SCREEN_LAYOUT_PRODUCT_ATTRIBS;                              
CREATE SYNONYM SEQ_TAB_LAYOUT_ID FOR @tplus.owner.username@.SEQ_TAB_LAYOUT_ID;                                                      
CREATE SYNONYM TAB_LAYOUT FOR @tplus.owner.username@.TAB_LAYOUT;                                                                    
CREATE SYNONYM TPLUS_AUD_CLIENT FOR @tplus.owner.username@.TPLUS_AUD_CLIENT;                                                        
CREATE SYNONYM TPLUS_AUD_USERS FOR @tplus.owner.username@.TPLUS_AUD_USERS;                                                          
CREATE SYNONYM TPLUS_CLIENT FOR @tplus.owner.username@.TPLUS_CLIENT;                                                                
CREATE SYNONYM TPLUS_PERMISSION FOR @tplus.owner.username@.TPLUS_PERMISSION;                                                        
CREATE SYNONYM TPLUS_PERMISSION_MAP FOR @tplus.owner.username@.TPLUS_PERMISSION_MAP;                                                
CREATE SYNONYM TPLUS_USERS FOR @tplus.owner.username@.TPLUS_USERS;                                                                  

PROMPT End of file : &FILENAME

EXIT
